﻿Imports System.Windows.Forms
Imports System.IO

Public Class dlgSraToFastq
  Private mDone As Boolean, mSraFile() As String, mFastqDir As String
  Private mNumSraFile As Integer

  Public Function GetSraToFastqParam(ByRef sSraFile() As String, ByRef sFastqDir As String, ByRef iNumSraFile As Integer) As Boolean
    mDone = False
    Me.ShowDialog()
    If mDone Then
      sSraFile = mSraFile
      sFastqDir = mFastqDir
      iNumSraFile = mNumSraFile
      Return True
    Else
      Return False
    End If

  End Function

  Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click

    'No need to do anything when chkMultFile.Checked = True
    If Not chkMultFile.Checked Then
      ReDim mSraFile(0)
      mSraFile(0) = txtSraFile.Text
      If Not File.Exists(mSraFile(0)) Then
        MsgBox("The input SRA file " & mSraFile(0) & " does not exist.")
        txtSraFile.Focus()
        Exit Sub
      End If
      mNumSraFile = 1
    End If

    mFastqDir = txtFastqDir.Text
    If Not Directory.Exists(mFastqDir) Then
      MsgBox("The directory entered for FASTQ output: " & mFastqDir & " does not exist.", vbOKOnly)
      txtFastqDir.Focus()
      Exit Sub
    End If
    mDone = True
    Me.DialogResult = System.Windows.Forms.DialogResult.OK
    Me.Close()
  End Sub

  Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
    Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Close()
  End Sub

  Private Sub btnBrowseBlastDB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseSRA.Click
    If chkMultFile.Checked Then
      mSraFile = GetFileArray(OpenFileDialog1, "sra", sInputDir)
      mNumSraFile = UBound(mSraFile) + 1
      txtSraFile.Text = mNumSraFile & " files to dump"
    Else
      If Directory.Exists(txtSraFile.Text) Then
        txtSraFile.Text = GetOpenFileName("Open SRA file", "sra", OpenFileDialog1, txtSraFile.Text)
      Else
        txtSraFile.Text = GetOpenFileName("Open SRA file", "sra", OpenFileDialog1, sInputDir)
      End If
    End If
  End Sub

  'Private Sub btnBrowseFastq_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseFASTQ.Click
  '  Dim sFN As String = GetFNOnly(txtSraFile.Text)
  '  Dim sPath As String = Path.GetDirectoryName(txtSraFile.Text)
  '  txtFastqDir.Text = GetSaveFileName("Save to...", "Fastq", SaveFileDialog1, sPath, sFN)

  'End Sub

  Private Sub btnBrowseFASTQ_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseFASTQ.Click
    If Trim(txtSraFile.Text) = "" Then
      FolderBrowserDialog1.SelectedPath = sNewDataDir
    Else
      Dim sPath As String = Path.GetDirectoryName(txtSraFile.Text)
      With FolderBrowserDialog1
        .SelectedPath = sPath
      End With
    End If
    If (FolderBrowserDialog1.ShowDialog() = DialogResult.OK) Then
      txtFastqDir.Text = FolderBrowserDialog1.SelectedPath
    End If
  End Sub

End Class
