﻿Imports System.Windows.Forms
Imports System.IO

Public Class dlgFastqToMultFas
  Private mDone As Boolean, mFastqFile As String, mFasFile As String, mNumFasFile As Integer, mOutInfo As Boolean
  Public Function GetFastqToMultFasParam(ByRef sFastqFile As String, ByRef sFasFile As String, ByRef iNumFasFile As Integer, ByRef bOutInfo As Boolean) As Boolean
    mDone = False
    Me.ShowDialog()
    If mDone Then
      sFastqFile = mFastqFile
      sFasFile = mFasFile
      iNumFasFile = mNumFasFile
      bOutInfo = mOutInfo
      Return True
    Else
      Return False
    End If

  End Function
  Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
    mFastqFile = txtFastqFile.Text
    If Not File.Exists(mFastqFile) Then
      MsgBox("The input FASTQ file " & mFastqFile & " does not exist.", vbOKOnly)
      txtFastqFile.Focus()
      Exit Sub
    End If
    mFasFile = txtFasFile.Text
    If Trim(mFasFile) = "" Then
      MsgBox("Please enter name for the output FASTA file.", vbOKOnly)
      txtFasFile.Focus()
      Exit Sub
    End If
    mNumFasFile = udNumOutFile.Value
    mOutInfo = chkInfo.Checked
    mDone = True
    Me.DialogResult = System.Windows.Forms.DialogResult.OK
    Me.Close()
  End Sub

  Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
    Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Close()
  End Sub

  Private Sub btnBrowseFastq_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseFastq.Click
    txtFastqFile.Text = GetOpenFileName("Open FASTQ file", "fastq,fq,fastqP,fqP", OpenFileDialog1, sInputDir)
  End Sub

  Private Sub BrowseFasta_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BrowseFasta.Click
    If Trim(txtFastqFile.Text) = "" Then
      txtFasFile.Text = GetSaveFileName("Save to...", "fas,fasP", SaveFileDialog1, sNewDataDir)
    Else
      Dim sFN As String = GetFNOnly(txtFastqFile.Text)
      Dim sPath As String = GetPath(txtFastqFile.Text)
      txtFasFile.Text = GetSaveFileName("Save to...", "fas,fasP", SaveFileDialog1, sPath, sFN)
    End If
  End Sub

  Private Sub dlgFastqToMultFas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

  End Sub
End Class
