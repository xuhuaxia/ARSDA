﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class dlgFastqToMultFas
  Inherits System.Windows.Forms.Form

  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> _
  Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    Try
      If disposing AndAlso components IsNot Nothing Then
        components.Dispose()
      End If
    Finally
      MyBase.Dispose(disposing)
    End Try
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> _
  Private Sub InitializeComponent()
    Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
    Me.OK_Button = New System.Windows.Forms.Button()
    Me.Cancel_Button = New System.Windows.Forms.Button()
    Me.lblNumFastaFile = New System.Windows.Forms.Label()
    Me.BrowseFasta = New System.Windows.Forms.Button()
    Me.btnBrowseFastq = New System.Windows.Forms.Button()
    Me.udNumOutFile = New System.Windows.Forms.NumericUpDown()
    Me.txtFasFile = New System.Windows.Forms.TextBox()
    Me.lblFastaFile = New System.Windows.Forms.Label()
    Me.txtFastqFile = New System.Windows.Forms.TextBox()
    Me.lblFastqFile = New System.Windows.Forms.Label()
    Me.PictureBox1 = New System.Windows.Forms.PictureBox()
    Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
    Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
    Me.chkInfo = New System.Windows.Forms.CheckBox()
    Me.TableLayoutPanel1.SuspendLayout()
    CType(Me.udNumOutFile, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.SuspendLayout()
    '
    'TableLayoutPanel1
    '
    Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.TableLayoutPanel1.ColumnCount = 2
    Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.Controls.Add(Me.OK_Button, 0, 0)
    Me.TableLayoutPanel1.Controls.Add(Me.Cancel_Button, 1, 0)
    Me.TableLayoutPanel1.Location = New System.Drawing.Point(375, 497)
    Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
    Me.TableLayoutPanel1.RowCount = 1
    Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.Size = New System.Drawing.Size(146, 29)
    Me.TableLayoutPanel1.TabIndex = 0
    '
    'OK_Button
    '
    Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
    Me.OK_Button.Location = New System.Drawing.Point(3, 3)
    Me.OK_Button.Name = "OK_Button"
    Me.OK_Button.Size = New System.Drawing.Size(67, 23)
    Me.OK_Button.TabIndex = 0
    Me.OK_Button.Text = "OK"
    '
    'Cancel_Button
    '
    Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
    Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Cancel_Button.Location = New System.Drawing.Point(76, 3)
    Me.Cancel_Button.Name = "Cancel_Button"
    Me.Cancel_Button.Size = New System.Drawing.Size(67, 23)
    Me.Cancel_Button.TabIndex = 1
    Me.Cancel_Button.Text = "Cancel"
    '
    'lblNumFastaFile
    '
    Me.lblNumFastaFile.AutoSize = True
    Me.lblNumFastaFile.Location = New System.Drawing.Point(8, 447)
    Me.lblNumFastaFile.Name = "lblNumFastaFile"
    Me.lblNumFastaFile.Size = New System.Drawing.Size(147, 13)
    Me.lblNumFastaFile.TabIndex = 17
    Me.lblNumFastaFile.Text = "Number of output FASTA files"
    '
    'BrowseFasta
    '
    Me.BrowseFasta.Location = New System.Drawing.Point(445, 407)
    Me.BrowseFasta.Name = "BrowseFasta"
    Me.BrowseFasta.Size = New System.Drawing.Size(75, 23)
    Me.BrowseFasta.TabIndex = 16
    Me.BrowseFasta.Text = "Browse"
    Me.BrowseFasta.UseVisualStyleBackColor = True
    '
    'btnBrowseFastq
    '
    Me.btnBrowseFastq.Location = New System.Drawing.Point(445, 357)
    Me.btnBrowseFastq.Name = "btnBrowseFastq"
    Me.btnBrowseFastq.Size = New System.Drawing.Size(75, 23)
    Me.btnBrowseFastq.TabIndex = 15
    Me.btnBrowseFastq.Text = "Browse"
    Me.btnBrowseFastq.UseVisualStyleBackColor = True
    '
    'udNumOutFile
    '
    Me.udNumOutFile.Location = New System.Drawing.Point(9, 463)
    Me.udNumOutFile.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
    Me.udNumOutFile.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
    Me.udNumOutFile.Name = "udNumOutFile"
    Me.udNumOutFile.Size = New System.Drawing.Size(120, 20)
    Me.udNumOutFile.TabIndex = 14
    Me.udNumOutFile.Value = New Decimal(New Integer() {1, 0, 0, 0})
    '
    'txtFasFile
    '
    Me.txtFasFile.Location = New System.Drawing.Point(11, 410)
    Me.txtFasFile.Name = "txtFasFile"
    Me.txtFasFile.Size = New System.Drawing.Size(428, 20)
    Me.txtFasFile.TabIndex = 13
    '
    'lblFastaFile
    '
    Me.lblFastaFile.AutoSize = True
    Me.lblFastaFile.Location = New System.Drawing.Point(8, 394)
    Me.lblFastaFile.Name = "lblFastaFile"
    Me.lblFastaFile.Size = New System.Drawing.Size(388, 13)
    Me.lblFastaFile.TabIndex = 12
    Me.lblFastaFile.Text = "Output FASTA file name (Output files will be FileName_1.fas, FileName2.fas, etc.)" & _
        ""
    '
    'txtFastqFile
    '
    Me.txtFastqFile.Location = New System.Drawing.Point(11, 359)
    Me.txtFastqFile.Name = "txtFastqFile"
    Me.txtFastqFile.Size = New System.Drawing.Size(428, 20)
    Me.txtFastqFile.TabIndex = 11
    '
    'lblFastqFile
    '
    Me.lblFastqFile.AutoSize = True
    Me.lblFastqFile.Location = New System.Drawing.Point(8, 343)
    Me.lblFastqFile.Name = "lblFastqFile"
    Me.lblFastqFile.Size = New System.Drawing.Size(88, 13)
    Me.lblFastqFile.TabIndex = 10
    Me.lblFastqFile.Text = "Input FASTQ file:"
    '
    'PictureBox1
    '
    Me.PictureBox1.Image = Global.Tuxedo.My.Resources.Resources.Fastq2MultFas
    Me.PictureBox1.Location = New System.Drawing.Point(5, 9)
    Me.PictureBox1.Name = "PictureBox1"
    Me.PictureBox1.Size = New System.Drawing.Size(515, 319)
    Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
    Me.PictureBox1.TabIndex = 19
    Me.PictureBox1.TabStop = False
    '
    'OpenFileDialog1
    '
    Me.OpenFileDialog1.FileName = "OpenFileDialog1"
    '
    'chkInfo
    '
    Me.chkInfo.AutoSize = True
    Me.chkInfo.Location = New System.Drawing.Point(5, 509)
    Me.chkInfo.Name = "chkInfo"
    Me.chkInfo.Size = New System.Drawing.Size(221, 17)
    Me.chkInfo.TabIndex = 20
    Me.chkInfo.Text = "Include summary of sequence information"
    Me.chkInfo.UseVisualStyleBackColor = True
    '
    'dlgFastqToMultFas
    '
    Me.AcceptButton = Me.OK_Button
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.CancelButton = Me.Cancel_Button
    Me.ClientSize = New System.Drawing.Size(533, 538)
    Me.Controls.Add(Me.chkInfo)
    Me.Controls.Add(Me.PictureBox1)
    Me.Controls.Add(Me.lblNumFastaFile)
    Me.Controls.Add(Me.BrowseFasta)
    Me.Controls.Add(Me.btnBrowseFastq)
    Me.Controls.Add(Me.udNumOutFile)
    Me.Controls.Add(Me.txtFasFile)
    Me.Controls.Add(Me.lblFastaFile)
    Me.Controls.Add(Me.txtFastqFile)
    Me.Controls.Add(Me.lblFastqFile)
    Me.Controls.Add(Me.TableLayoutPanel1)
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "dlgFastqToMultFas"
    Me.ShowInTaskbar = False
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
    Me.Text = "FASTQ file to multiple FASTA files"
    Me.TableLayoutPanel1.ResumeLayout(False)
    CType(Me.udNumOutFile, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
  Friend WithEvents OK_Button As System.Windows.Forms.Button
  Friend WithEvents Cancel_Button As System.Windows.Forms.Button
  Friend WithEvents lblNumFastaFile As System.Windows.Forms.Label
  Friend WithEvents BrowseFasta As System.Windows.Forms.Button
  Friend WithEvents btnBrowseFastq As System.Windows.Forms.Button
  Friend WithEvents udNumOutFile As System.Windows.Forms.NumericUpDown
  Friend WithEvents txtFasFile As System.Windows.Forms.TextBox
  Friend WithEvents lblFastaFile As System.Windows.Forms.Label
  Friend WithEvents txtFastqFile As System.Windows.Forms.TextBox
  Friend WithEvents lblFastqFile As System.Windows.Forms.Label
  Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
  Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
  Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
  Friend WithEvents chkInfo As System.Windows.Forms.CheckBox

End Class
