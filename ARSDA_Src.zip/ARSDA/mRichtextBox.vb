﻿Module mRichtextBox

  Sub FindInRTF(ByVal Richtextbox1 As RichTextBox, ByVal sSearchText As String, ByVal bMatchCase As Boolean, ByVal bWholeWord As Boolean, _
                ByVal bSearchDown As Boolean)
    Dim indexToText As Integer
    If bMatchCase Then
      If bWholeWord Then
        If bSearchDown Then
          indexToText = Richtextbox1.Find(sSearchText, RichTextBoxFinds.MatchCase, RichTextBoxFinds.WholeWord)
        Else
          indexToText = Richtextbox1.Find(sSearchText, RichTextBoxFinds.MatchCase, RichTextBoxFinds.WholeWord, RichTextBoxFinds.Reverse)
        End If
      Else
        If bSearchDown Then
          indexToText = Richtextbox1.Find(sSearchText, RichTextBoxFinds.MatchCase)
        Else
          indexToText = Richtextbox1.Find(sSearchText, RichTextBoxFinds.MatchCase, RichTextBoxFinds.Reverse)
        End If
      End If
    Else
      If bWholeWord Then
        If bSearchDown Then
          indexToText = Richtextbox1.Find(sSearchText, RichTextBoxFinds.WholeWord)
        Else
          indexToText = Richtextbox1.Find(sSearchText, RichTextBoxFinds.WholeWord, RichTextBoxFinds.Reverse)
        End If
      Else
        If bSearchDown Then
          indexToText = Richtextbox1.Find(sSearchText)
        Else
          indexToText = Richtextbox1.Find(sSearchText, RichTextBoxFinds.Reverse)
        End If
      End If
    End If
    If indexToText = 0 Then
      MsgBox("The text: " & sSearchText & " is not found.")
    Else
    End If
  End Sub

  Sub FindNextInRTF(ByVal Richtextbox1 As RichTextBox, ByVal sSearchText As String, ByVal bMatchCase As Boolean, ByVal bWholeWord As Boolean, _
                ByVal bSearchDown As Boolean)
    Dim indexToText As Integer = 0
    While indexToText <> -1
      If bMatchCase Then
        If bWholeWord Then
          If bSearchDown Then
            indexToText = Richtextbox1.Find(sSearchText, indexToText, RichTextBoxFinds.MatchCase, RichTextBoxFinds.WholeWord)
          Else
            'indexToText = Richtextbox1.Find(sSearchText, indexToText, RichTextBoxFinds.MatchCase, RichTextBoxFinds.WholeWord, RichTextBoxFinds.Reverse)
            indexToText = Richtextbox1.Find(sSearchText, indexToText, RichTextBoxFinds.MatchCase, RichTextBoxFinds.WholeWord)
          End If
        Else
          If bSearchDown Then
            indexToText = Richtextbox1.Find(sSearchText, indexToText, RichTextBoxFinds.MatchCase)
          Else
            indexToText = Richtextbox1.Find(sSearchText, indexToText, RichTextBoxFinds.MatchCase, RichTextBoxFinds.Reverse)
          End If
        End If
      Else
        If bWholeWord Then
          If bSearchDown Then
            indexToText = Richtextbox1.Find(sSearchText, indexToText, RichTextBoxFinds.WholeWord)
          Else
            indexToText = Richtextbox1.Find(sSearchText, indexToText, RichTextBoxFinds.WholeWord, RichTextBoxFinds.Reverse)
          End If
        Else
          If bSearchDown Then
            indexToText = Richtextbox1.Find(sSearchText, indexToText, RichTextBoxFinds.None)
          Else
            indexToText = Richtextbox1.Find(sSearchText, indexToText, RichTextBoxFinds.Reverse)
          End If
        End If
      End If
      If indexToText <> -1 Then
        ' do your own thing here.
        Richtextbox1.SelectionBackColor = Color.Orange
        indexToText += 1
      End If
    End While
    Richtextbox1.DeselectAll()

  End Sub
End Module
