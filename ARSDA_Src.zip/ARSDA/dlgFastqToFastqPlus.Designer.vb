﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class dlgFastqToFastqPlus
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
    Me.OK_Button = New System.Windows.Forms.Button()
    Me.Cancel_Button = New System.Windows.Forms.Button()
    Me.BrowseFastqPlus = New System.Windows.Forms.Button()
    Me.btnBrowseFastq = New System.Windows.Forms.Button()
    Me.txtFastqPlusFile = New System.Windows.Forms.TextBox()
    Me.lblFastqPlusFile = New System.Windows.Forms.Label()
    Me.txtFastqFile = New System.Windows.Forms.TextBox()
    Me.lblFastqFile = New System.Windows.Forms.Label()
    Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
    Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
    Me.lblInfo = New System.Windows.Forms.Label()
    Me.PictureBox1 = New System.Windows.Forms.PictureBox()
    Me.lblReadLenInfo = New System.Windows.Forms.Label()
    Me.txtReadLen = New System.Windows.Forms.TextBox()
    Me.lblReadLen = New System.Windows.Forms.Label()
    Me.TableLayoutPanel1.SuspendLayout()
    CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.SuspendLayout()
    '
    'TableLayoutPanel1
    '
    Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.TableLayoutPanel1.ColumnCount = 2
    Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.Controls.Add(Me.OK_Button, 0, 0)
    Me.TableLayoutPanel1.Controls.Add(Me.Cancel_Button, 1, 0)
    Me.TableLayoutPanel1.Location = New System.Drawing.Point(380, 475)
    Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
    Me.TableLayoutPanel1.RowCount = 1
    Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.Size = New System.Drawing.Size(146, 29)
    Me.TableLayoutPanel1.TabIndex = 0
    '
    'OK_Button
    '
    Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
    Me.OK_Button.Location = New System.Drawing.Point(3, 3)
    Me.OK_Button.Name = "OK_Button"
    Me.OK_Button.Size = New System.Drawing.Size(67, 23)
    Me.OK_Button.TabIndex = 0
    Me.OK_Button.Text = "OK"
    '
    'Cancel_Button
    '
    Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
    Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Cancel_Button.Location = New System.Drawing.Point(76, 3)
    Me.Cancel_Button.Name = "Cancel_Button"
    Me.Cancel_Button.Size = New System.Drawing.Size(67, 23)
    Me.Cancel_Button.TabIndex = 1
    Me.Cancel_Button.Text = "Cancel"
    '
    'BrowseFastqPlus
    '
    Me.BrowseFastqPlus.Location = New System.Drawing.Point(452, 410)
    Me.BrowseFastqPlus.Name = "BrowseFastqPlus"
    Me.BrowseFastqPlus.Size = New System.Drawing.Size(75, 23)
    Me.BrowseFastqPlus.TabIndex = 32
    Me.BrowseFastqPlus.Text = "Browse"
    Me.BrowseFastqPlus.UseVisualStyleBackColor = True
    '
    'btnBrowseFastq
    '
    Me.btnBrowseFastq.Location = New System.Drawing.Point(452, 360)
    Me.btnBrowseFastq.Name = "btnBrowseFastq"
    Me.btnBrowseFastq.Size = New System.Drawing.Size(75, 23)
    Me.btnBrowseFastq.TabIndex = 31
    Me.btnBrowseFastq.Text = "Browse"
    Me.btnBrowseFastq.UseVisualStyleBackColor = True
    '
    'txtFastqPlusFile
    '
    Me.txtFastqPlusFile.Location = New System.Drawing.Point(18, 413)
    Me.txtFastqPlusFile.Name = "txtFastqPlusFile"
    Me.txtFastqPlusFile.Size = New System.Drawing.Size(428, 20)
    Me.txtFastqPlusFile.TabIndex = 30
    '
    'lblFastqPlusFile
    '
    Me.lblFastqPlusFile.AutoSize = True
    Me.lblFastqPlusFile.Location = New System.Drawing.Point(15, 397)
    Me.lblFastqPlusFile.Name = "lblFastqPlusFile"
    Me.lblFastqPlusFile.Size = New System.Drawing.Size(128, 13)
    Me.lblFastqPlusFile.TabIndex = 29
    Me.lblFastqPlusFile.Text = "Output FASTQ+ file name"
    '
    'txtFastqFile
    '
    Me.txtFastqFile.Location = New System.Drawing.Point(18, 362)
    Me.txtFastqFile.Name = "txtFastqFile"
    Me.txtFastqFile.Size = New System.Drawing.Size(428, 20)
    Me.txtFastqFile.TabIndex = 28
    '
    'lblFastqFile
    '
    Me.lblFastqFile.AutoSize = True
    Me.lblFastqFile.Location = New System.Drawing.Point(15, 346)
    Me.lblFastqFile.Name = "lblFastqFile"
    Me.lblFastqFile.Size = New System.Drawing.Size(184, 13)
    Me.lblFastqFile.TabIndex = 27
    Me.lblFastqFile.Text = "Input FASTQ file in strict 4-line format:"
    '
    'OpenFileDialog1
    '
    Me.OpenFileDialog1.FileName = "OpenFileDialog1"
    '
    'lblInfo
    '
    Me.lblInfo.AutoSize = True
    Me.lblInfo.Location = New System.Drawing.Point(15, 481)
    Me.lblInfo.Name = "lblInfo"
    Me.lblInfo.Size = New System.Drawing.Size(297, 13)
    Me.lblInfo.TabIndex = 34
    Me.lblInfo.Text = "Note: Sequences containing unresolved nuc. will be removed"
    '
    'PictureBox1
    '
    Me.PictureBox1.Image = Global.ARSDA.My.Resources.Resources.FastqToFastqPlus
    Me.PictureBox1.Location = New System.Drawing.Point(12, 12)
    Me.PictureBox1.Name = "PictureBox1"
    Me.PictureBox1.Size = New System.Drawing.Size(515, 319)
    Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
    Me.PictureBox1.TabIndex = 33
    Me.PictureBox1.TabStop = False
    '
    'lblReadLenInfo
    '
    Me.lblReadLenInfo.AutoSize = True
    Me.lblReadLenInfo.Location = New System.Drawing.Point(131, 450)
    Me.lblReadLenInfo.Name = "lblReadLenInfo"
    Me.lblReadLenInfo.Size = New System.Drawing.Size(336, 13)
    Me.lblReadLenInfo.TabIndex = 55
    Me.lblReadLenInfo.Text = "(Shorter sequences will be excluded and longer sequences truncated)"
    '
    'txtReadLen
    '
    Me.txtReadLen.Location = New System.Drawing.Point(83, 447)
    Me.txtReadLen.Name = "txtReadLen"
    Me.txtReadLen.Size = New System.Drawing.Size(38, 20)
    Me.txtReadLen.TabIndex = 54
    Me.txtReadLen.Text = "50"
    Me.txtReadLen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
    '
    'lblReadLen
    '
    Me.lblReadLen.AutoSize = True
    Me.lblReadLen.Location = New System.Drawing.Point(13, 450)
    Me.lblReadLen.Name = "lblReadLen"
    Me.lblReadLen.Size = New System.Drawing.Size(68, 13)
    Me.lblReadLen.TabIndex = 53
    Me.lblReadLen.Text = "Read length:"
    '
    'dlgFastqToFastqPlus
    '
    Me.AcceptButton = Me.OK_Button
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.CancelButton = Me.Cancel_Button
    Me.ClientSize = New System.Drawing.Size(538, 516)
    Me.Controls.Add(Me.lblReadLenInfo)
    Me.Controls.Add(Me.txtReadLen)
    Me.Controls.Add(Me.lblReadLen)
    Me.Controls.Add(Me.lblInfo)
    Me.Controls.Add(Me.PictureBox1)
    Me.Controls.Add(Me.BrowseFastqPlus)
    Me.Controls.Add(Me.btnBrowseFastq)
    Me.Controls.Add(Me.txtFastqPlusFile)
    Me.Controls.Add(Me.lblFastqPlusFile)
    Me.Controls.Add(Me.txtFastqFile)
    Me.Controls.Add(Me.lblFastqFile)
    Me.Controls.Add(Me.TableLayoutPanel1)
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "dlgFastqToFastqPlus"
    Me.ShowInTaskbar = False
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
    Me.Text = "Convert FASTQ file to FASTQ+ file"
    Me.TableLayoutPanel1.ResumeLayout(False)
    CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
  Friend WithEvents OK_Button As System.Windows.Forms.Button
  Friend WithEvents Cancel_Button As System.Windows.Forms.Button
  Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
  Friend WithEvents BrowseFastqPlus As System.Windows.Forms.Button
  Friend WithEvents btnBrowseFastq As System.Windows.Forms.Button
  Friend WithEvents txtFastqPlusFile As System.Windows.Forms.TextBox
  Friend WithEvents lblFastqPlusFile As System.Windows.Forms.Label
  Friend WithEvents txtFastqFile As System.Windows.Forms.TextBox
  Friend WithEvents lblFastqFile As System.Windows.Forms.Label
  Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
  Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
  Friend WithEvents lblInfo As System.Windows.Forms.Label
  Friend WithEvents lblReadLenInfo As System.Windows.Forms.Label
  Friend WithEvents txtReadLen As System.Windows.Forms.TextBox
  Friend WithEvents lblReadLen As System.Windows.Forms.Label

End Class
