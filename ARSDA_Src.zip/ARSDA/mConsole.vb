﻿Imports System.IO
'These functions are needed for Mac and Linux where Shell statement does not seem to work (Learned from VB6 but may be true for VB.Net as well).
'The WorkingDirectory property behaves differently depending on the value of the UseShellExecute property:
'  When UseShellExecute is true, the WorkingDirectory property specifies the location of the executable. If WorkingDirectory is an empty string, 
'    it is assumed that the current directory contains the executable.
'  When UseShellExecute is false, the WorkingDirectory property is not used to find the executable. Instead, it is used as if you have Chdir(WorkingDirectory) and run
'    the executable there. When UseShellExecute is false, the FileName property can be either a 
'    fully qualified path to the executable, or a simple executable name that the system will attempt to find within folders specified by the PATH 
'    environment variable.

Module mConsole
  Function RunExeAndWait(ByVal sProgFull As String, ByVal sArg As String, ByVal sWorkDir As String, _
                         ByVal bGetStdOut As Boolean, Optional ByRef sOut As String = "") As Boolean
    Dim Proc As New Process

    Proc.StartInfo.FileName = sProgFull
    Proc.StartInfo.Arguments = sArg
    Proc.StartInfo.WorkingDirectory = sWorkDir
    Proc.StartInfo.UseShellExecute = False
    Proc.StartInfo.RedirectStandardOutput = bGetStdOut
    'Proc.StartInfo.RedirectStandardError = True
    Proc.StartInfo.WindowStyle = ProcessWindowStyle.Hidden
    Proc.StartInfo.CreateNoWindow = True 'This would be ignored if Proc.StartInfo.UseShellExecute = True
    Proc.Start()

    If bGetStdOut Then
      sOut = Proc.StandardOutput.ReadToEnd()
      'sOut = sOut & Proc.StandardError.ReadToEnd()
    End If
    Proc.WaitForExit()
    Return True
  End Function


End Module
