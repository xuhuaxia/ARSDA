﻿Imports System.IO
Imports System.Text
Imports System.Collections
Module mSeqUtil
  Sub SeqView(ByVal sSeq() As String, ByVal sName() As String, ByVal iNumSeq As Integer, ByVal iSeqLen() As Integer, ByRef sOut As String)
    Dim I As Integer, MaxNameLen As Integer, TotalSeqLen As Integer
    Dim sb As New StringBuilder

    MaxNameLen = 0
    TotalSeqLen = 0
    For I = 0 To iNumSeq - 1
      TotalSeqLen = TotalSeqLen + iSeqLen(I)
      If MaxNameLen < Len(sName(I)) Then
        MaxNameLen = Len(sName(I))
      End If
    Next
    MaxNameLen = MaxNameLen + 1
    For I = 0 To iNumSeq - 1
      sb.Append(sName(I).PadRight(MaxNameLen) & sSeq(I) & vbCrLf)
    Next
    sOut = sb.ToString
    sb = Nothing
  End Sub

  Sub OutFas(ByVal sOutFasFile As String, ByVal sSeq() As String, ByVal sName() As String, ByVal iNumSeq As Integer)
    Dim I As Integer
    Dim sb As New StringBuilder
    For I = 0 To iNumSeq - 1
      sb.Append(">" & sName(I) & " " & sSeq(I).Length & vbCrLf & sSeq(I) & vbCrLf)
    Next
    File.WriteAllText(sOutFasFile, sb.ToString)
  End Sub

  Sub ReadFasStr(ByVal sFasFileStr As String, ByRef sSeq() As String, ByRef sName() As String, ByRef iNumSeq As Integer)
    Dim I As Integer, FindAt As Integer, FindAt2 As Integer
    Dim LineArray() As String
    If Strings.Left(sFasFileStr, 1) <> ">" Then
      FindAt = InStr(sFasFileStr, ">")
      sFasFileStr = Mid(sFasFileStr, FindAt)
    End If
    sFasFileStr = LTrim(sFasFileStr)
    sFasFileStr = Replace(sFasFileStr, vbCr, "")
    LineArray = Split(sFasFileStr, vbLf & ">")
    iNumSeq = UBound(LineArray) 'Will add 1 later
    ReDim sSeq(iNumSeq), sName(iNumSeq)
    If InStr(sFasFileStr, " ") > 0 Then
      For I = 0 To iNumSeq
        FindAt = InStr(LineArray(I), vbLf)
        sSeq(I) = Mid(LineArray(I), FindAt + 1)
        FindAt2 = InStr(LineArray(I), " ")
        If FindAt > FindAt2 Then
          sName(I) = Strings.Left(LineArray(I), FindAt2 - 1)
        Else
          sName(I) = Strings.Left(LineArray(I), FindAt - 1)
        End If
      Next
    Else
      For I = 0 To iNumSeq
        FindAt = InStr(LineArray(I), vbLf)
        sSeq(I) = Mid(LineArray(I), FindAt + 1)
        sName(I) = Strings.Left(LineArray(I), FindAt - 1)
      Next
    End If
    For I = 0 To iNumSeq
      sSeq(I) = Replace(sSeq(I), vbLf, "")
      sSeq(I) = Replace(sSeq(I), " ", "")
    Next
    sName(0) = Mid(sName(0), 2)
    iNumSeq = iNumSeq + 1
  End Sub
End Module
