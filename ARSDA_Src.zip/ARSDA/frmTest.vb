﻿Public Class frmTest

  Dim i As Integer
  Dim i2 As Integer

  Dim thread() As System.Threading.Thread

  Private Sub countup()
    Do Until i = 10000
      i = i + 1
      Label1.Text = i
      'Me.Refresh()
    Loop
  End Sub

  Private Sub countup2()
    Do Until i2 = 10000
      i2 = i2 + 1
      Label2.Text = i2
      'Me.Refresh()
    Loop
  End Sub

  Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
    thread(0) = New System.Threading.Thread(AddressOf countup)
    thread(0).Start()
  End Sub

  Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
    thread(1) = New System.Threading.Thread(AddressOf countup2)
    thread(1).Start()
  End Sub

  Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    Control.CheckForIllegalCrossThreadCalls = False
    ReDim thread(1)
  End Sub

End Class