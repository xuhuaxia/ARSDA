﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class dlgBlastFasToGE
  Inherits System.Windows.Forms.Form

  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> _
  Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    Try
      If disposing AndAlso components IsNot Nothing Then
        components.Dispose()
      End If
    Finally
      MyBase.Dispose(disposing)
    End Try
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> _
  Private Sub InitializeComponent()
    Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
    Me.Cancel_Button = New System.Windows.Forms.Button()
    Me.OK_Button = New System.Windows.Forms.Button()
    Me.txtBlastDB = New System.Windows.Forms.TextBox()
    Me.txtFasFile = New System.Windows.Forms.TextBox()
    Me.lblFastqFile = New System.Windows.Forms.Label()
    Me.lblFasFile = New System.Windows.Forms.Label()
    Me.btnBrowseFasFile = New System.Windows.Forms.Button()
    Me.btnBrowseBLAST = New System.Windows.Forms.Button()
    Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
    Me.btnBrowseOutFile = New System.Windows.Forms.Button()
    Me.lblOutfile = New System.Windows.Forms.Label()
    Me.txtOutfile = New System.Windows.Forms.TextBox()
    Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
    Me.frBlastOpt = New System.Windows.Forms.GroupBox()
    Me.chkUngapped = New System.Windows.Forms.CheckBox()
    Me.cboStrand = New System.Windows.Forms.ComboBox()
    Me.lblStrand = New System.Windows.Forms.Label()
    Me.btnHelp = New System.Windows.Forms.Button()
    Me.txtMaxTarget = New System.Windows.Forms.TextBox()
    Me.lblMaxNumMatch = New System.Windows.Forms.Label()
    Me.udWordLen = New System.Windows.Forms.NumericUpDown()
    Me.udNumCPU = New System.Windows.Forms.NumericUpDown()
    Me.lblWordLen = New System.Windows.Forms.Label()
    Me.lblEval = New System.Windows.Forms.Label()
    Me.lblNumCPU = New System.Windows.Forms.Label()
    Me.txtEval = New System.Windows.Forms.TextBox()
    Me.PictureBox1 = New System.Windows.Forms.PictureBox()
    Me.btnHelp2 = New System.Windows.Forms.Button()
    Me.chkIsFasP = New System.Windows.Forms.CheckBox()
    Me.lblInfo = New System.Windows.Forms.Label()
    Me.TableLayoutPanel1.SuspendLayout()
    Me.frBlastOpt.SuspendLayout()
    CType(Me.udWordLen, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.udNumCPU, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.SuspendLayout()
    '
    'TableLayoutPanel1
    '
    Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.TableLayoutPanel1.ColumnCount = 2
    Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.Controls.Add(Me.Cancel_Button, 1, 0)
    Me.TableLayoutPanel1.Controls.Add(Me.OK_Button, 0, 0)
    Me.TableLayoutPanel1.Location = New System.Drawing.Point(602, 645)
    Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
    Me.TableLayoutPanel1.RowCount = 1
    Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.Size = New System.Drawing.Size(146, 29)
    Me.TableLayoutPanel1.TabIndex = 0
    '
    'Cancel_Button
    '
    Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
    Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Cancel_Button.Location = New System.Drawing.Point(76, 3)
    Me.Cancel_Button.Name = "Cancel_Button"
    Me.Cancel_Button.Size = New System.Drawing.Size(67, 23)
    Me.Cancel_Button.TabIndex = 1
    Me.Cancel_Button.Text = "Cancel"
    '
    'OK_Button
    '
    Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
    Me.OK_Button.Location = New System.Drawing.Point(3, 3)
    Me.OK_Button.Name = "OK_Button"
    Me.OK_Button.Size = New System.Drawing.Size(67, 23)
    Me.OK_Button.TabIndex = 0
    Me.OK_Button.Text = "OK"
    '
    'txtBlastDB
    '
    Me.txtBlastDB.Location = New System.Drawing.Point(104, 469)
    Me.txtBlastDB.Name = "txtBlastDB"
    Me.txtBlastDB.Size = New System.Drawing.Size(568, 20)
    Me.txtBlastDB.TabIndex = 14
    '
    'txtFasFile
    '
    Me.txtFasFile.Location = New System.Drawing.Point(104, 433)
    Me.txtFasFile.Name = "txtFasFile"
    Me.txtFasFile.Size = New System.Drawing.Size(568, 20)
    Me.txtFasFile.TabIndex = 13
    '
    'lblFastqFile
    '
    Me.lblFastqFile.AutoSize = True
    Me.lblFastqFile.Location = New System.Drawing.Point(9, 472)
    Me.lblFastqFile.Name = "lblFastqFile"
    Me.lblFastqFile.Size = New System.Drawing.Size(86, 13)
    Me.lblFastqFile.TabIndex = 12
    Me.lblFastqFile.Text = "Input BLAST DB"
    '
    'lblFasFile
    '
    Me.lblFasFile.AutoSize = True
    Me.lblFasFile.Location = New System.Drawing.Point(9, 436)
    Me.lblFasFile.Name = "lblFasFile"
    Me.lblFasFile.Size = New System.Drawing.Size(88, 13)
    Me.lblFasFile.TabIndex = 11
    Me.lblFasFile.Text = "Query FASTA file"
    '
    'btnBrowseFasFile
    '
    Me.btnBrowseFasFile.Location = New System.Drawing.Point(678, 431)
    Me.btnBrowseFasFile.Name = "btnBrowseFasFile"
    Me.btnBrowseFasFile.Size = New System.Drawing.Size(75, 23)
    Me.btnBrowseFasFile.TabIndex = 10
    Me.btnBrowseFasFile.Text = "Browse"
    Me.btnBrowseFasFile.UseVisualStyleBackColor = True
    '
    'btnBrowseBLAST
    '
    Me.btnBrowseBLAST.Location = New System.Drawing.Point(678, 469)
    Me.btnBrowseBLAST.Name = "btnBrowseBLAST"
    Me.btnBrowseBLAST.Size = New System.Drawing.Size(75, 23)
    Me.btnBrowseBLAST.TabIndex = 9
    Me.btnBrowseBLAST.Text = "Browse"
    Me.btnBrowseBLAST.UseVisualStyleBackColor = True
    '
    'OpenFileDialog1
    '
    Me.OpenFileDialog1.FileName = "OpenFileDialog1"
    '
    'btnBrowseOutFile
    '
    Me.btnBrowseOutFile.Location = New System.Drawing.Point(678, 506)
    Me.btnBrowseOutFile.Name = "btnBrowseOutFile"
    Me.btnBrowseOutFile.Size = New System.Drawing.Size(75, 23)
    Me.btnBrowseOutFile.TabIndex = 15
    Me.btnBrowseOutFile.Text = "Browse"
    Me.btnBrowseOutFile.UseVisualStyleBackColor = True
    '
    'lblOutfile
    '
    Me.lblOutfile.AutoSize = True
    Me.lblOutfile.Location = New System.Drawing.Point(9, 506)
    Me.lblOutfile.Name = "lblOutfile"
    Me.lblOutfile.Size = New System.Drawing.Size(55, 13)
    Me.lblOutfile.TabIndex = 16
    Me.lblOutfile.Text = "Output file"
    '
    'txtOutfile
    '
    Me.txtOutfile.Location = New System.Drawing.Point(104, 506)
    Me.txtOutfile.Name = "txtOutfile"
    Me.txtOutfile.Size = New System.Drawing.Size(566, 20)
    Me.txtOutfile.TabIndex = 17
    '
    'frBlastOpt
    '
    Me.frBlastOpt.Controls.Add(Me.chkUngapped)
    Me.frBlastOpt.Controls.Add(Me.cboStrand)
    Me.frBlastOpt.Controls.Add(Me.lblStrand)
    Me.frBlastOpt.Controls.Add(Me.btnHelp)
    Me.frBlastOpt.Controls.Add(Me.txtMaxTarget)
    Me.frBlastOpt.Controls.Add(Me.lblMaxNumMatch)
    Me.frBlastOpt.Controls.Add(Me.udWordLen)
    Me.frBlastOpt.Controls.Add(Me.udNumCPU)
    Me.frBlastOpt.Controls.Add(Me.lblWordLen)
    Me.frBlastOpt.Controls.Add(Me.lblEval)
    Me.frBlastOpt.Controls.Add(Me.lblNumCPU)
    Me.frBlastOpt.Controls.Add(Me.txtEval)
    Me.frBlastOpt.Location = New System.Drawing.Point(12, 543)
    Me.frBlastOpt.Name = "frBlastOpt"
    Me.frBlastOpt.Size = New System.Drawing.Size(672, 96)
    Me.frBlastOpt.TabIndex = 18
    Me.frBlastOpt.TabStop = False
    Me.frBlastOpt.Text = "BLAST options"
    '
    'chkUngapped
    '
    Me.chkUngapped.AutoSize = True
    Me.chkUngapped.Location = New System.Drawing.Point(314, 61)
    Me.chkUngapped.Name = "chkUngapped"
    Me.chkUngapped.Size = New System.Drawing.Size(124, 17)
    Me.chkUngapped.TabIndex = 38
    Me.chkUngapped.Text = "Ungapped alignment"
    Me.chkUngapped.UseVisualStyleBackColor = True
    '
    'cboStrand
    '
    Me.cboStrand.FormattingEnabled = True
    Me.cboStrand.Location = New System.Drawing.Point(210, 59)
    Me.cboStrand.Name = "cboStrand"
    Me.cboStrand.Size = New System.Drawing.Size(73, 21)
    Me.cboStrand.TabIndex = 35
    Me.cboStrand.Text = "both"
    '
    'lblStrand
    '
    Me.lblStrand.AutoSize = True
    Me.lblStrand.Location = New System.Drawing.Point(169, 63)
    Me.lblStrand.Name = "lblStrand"
    Me.lblStrand.Size = New System.Drawing.Size(38, 13)
    Me.lblStrand.TabIndex = 34
    Me.lblStrand.Text = "Strand"
    '
    'btnHelp
    '
    Me.btnHelp.Location = New System.Drawing.Point(135, 60)
    Me.btnHelp.Name = "btnHelp"
    Me.btnHelp.Size = New System.Drawing.Size(20, 19)
    Me.btnHelp.TabIndex = 29
    Me.btnHelp.Text = "?"
    Me.btnHelp.UseVisualStyleBackColor = True
    '
    'txtMaxTarget
    '
    Me.txtMaxTarget.Enabled = False
    Me.txtMaxTarget.Location = New System.Drawing.Point(76, 59)
    Me.txtMaxTarget.Name = "txtMaxTarget"
    Me.txtMaxTarget.Size = New System.Drawing.Size(53, 20)
    Me.txtMaxTarget.TabIndex = 27
    Me.txtMaxTarget.Text = "1000000"
    Me.txtMaxTarget.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
    '
    'lblMaxNumMatch
    '
    Me.lblMaxNumMatch.AutoSize = True
    Me.lblMaxNumMatch.Location = New System.Drawing.Point(5, 63)
    Me.lblMaxNumMatch.Name = "lblMaxNumMatch"
    Me.lblMaxNumMatch.Size = New System.Drawing.Size(74, 13)
    Me.lblMaxNumMatch.TabIndex = 28
    Me.lblMaxNumMatch.Text = "Max_N_target"
    '
    'udWordLen
    '
    Me.udWordLen.Location = New System.Drawing.Point(240, 22)
    Me.udWordLen.Maximum = New Decimal(New Integer() {28, 0, 0, 0})
    Me.udWordLen.Minimum = New Decimal(New Integer() {12, 0, 0, 0})
    Me.udWordLen.Name = "udWordLen"
    Me.udWordLen.Size = New System.Drawing.Size(52, 20)
    Me.udWordLen.TabIndex = 23
    Me.udWordLen.Value = New Decimal(New Integer() {18, 0, 0, 0})
    '
    'udNumCPU
    '
    Me.udNumCPU.Location = New System.Drawing.Point(408, 21)
    Me.udNumCPU.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
    Me.udNumCPU.Name = "udNumCPU"
    Me.udNumCPU.Size = New System.Drawing.Size(34, 20)
    Me.udNumCPU.TabIndex = 22
    Me.udNumCPU.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
    Me.udNumCPU.Value = New Decimal(New Integer() {1, 0, 0, 0})
    '
    'lblWordLen
    '
    Me.lblWordLen.AutoSize = True
    Me.lblWordLen.Location = New System.Drawing.Point(169, 26)
    Me.lblWordLen.Name = "lblWordLen"
    Me.lblWordLen.Size = New System.Drawing.Size(65, 13)
    Me.lblWordLen.TabIndex = 2
    Me.lblWordLen.Text = "Word length"
    '
    'lblEval
    '
    Me.lblEval.AutoSize = True
    Me.lblEval.Location = New System.Drawing.Point(6, 26)
    Me.lblEval.Name = "lblEval"
    Me.lblEval.Size = New System.Drawing.Size(43, 13)
    Me.lblEval.TabIndex = 0
    Me.lblEval.Text = "E-value"
    '
    'lblNumCPU
    '
    Me.lblNumCPU.AutoSize = True
    Me.lblNumCPU.Location = New System.Drawing.Point(311, 25)
    Me.lblNumCPU.Name = "lblNumCPU"
    Me.lblNumCPU.Size = New System.Drawing.Size(91, 13)
    Me.lblNumCPU.TabIndex = 19
    Me.lblNumCPU.Text = "Processors to use"
    '
    'txtEval
    '
    Me.txtEval.Location = New System.Drawing.Point(55, 22)
    Me.txtEval.Name = "txtEval"
    Me.txtEval.Size = New System.Drawing.Size(74, 20)
    Me.txtEval.TabIndex = 1
    Me.txtEval.Text = "0.0000000001"
    Me.txtEval.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
    '
    'PictureBox1
    '
    Me.PictureBox1.Image = Global.ARSDA.My.Resources.Resources.BLAST2GE
    Me.PictureBox1.Location = New System.Drawing.Point(12, 12)
    Me.PictureBox1.Name = "PictureBox1"
    Me.PictureBox1.Size = New System.Drawing.Size(740, 411)
    Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
    Me.PictureBox1.TabIndex = 8
    Me.PictureBox1.TabStop = False
    '
    'btnHelp2
    '
    Me.btnHelp2.Location = New System.Drawing.Point(233, 643)
    Me.btnHelp2.Name = "btnHelp2"
    Me.btnHelp2.Size = New System.Drawing.Size(25, 23)
    Me.btnHelp2.TabIndex = 33
    Me.btnHelp2.Text = "?"
    Me.btnHelp2.UseVisualStyleBackColor = True
    '
    'chkIsFasP
    '
    Me.chkIsFasP.AutoSize = True
    Me.chkIsFasP.Checked = True
    Me.chkIsFasP.CheckState = System.Windows.Forms.CheckState.Checked
    Me.chkIsFasP.Location = New System.Drawing.Point(12, 647)
    Me.chkIsFasP.Name = "chkIsFasP"
    Me.chkIsFasP.Size = New System.Drawing.Size(224, 17)
    Me.chkIsFasP.TabIndex = 32
    Me.chkIsFasP.Text = "BLAST database derived from FasPlus file"
    Me.chkIsFasP.UseVisualStyleBackColor = True
    '
    'lblInfo
    '
    Me.lblInfo.ForeColor = System.Drawing.Color.Red
    Me.lblInfo.Location = New System.Drawing.Point(472, 565)
    Me.lblInfo.Name = "lblInfo"
    Me.lblInfo.Size = New System.Drawing.Size(206, 54)
    Me.lblInfo.TabIndex = 39
    Me.lblInfo.Text = "Sequence names in the Query FASTA file must be unique."
    '
    'dlgBlastFasToGE
    '
    Me.AcceptButton = Me.OK_Button
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.CancelButton = Me.Cancel_Button
    Me.ClientSize = New System.Drawing.Size(760, 686)
    Me.Controls.Add(Me.lblInfo)
    Me.Controls.Add(Me.btnHelp2)
    Me.Controls.Add(Me.chkIsFasP)
    Me.Controls.Add(Me.frBlastOpt)
    Me.Controls.Add(Me.txtOutfile)
    Me.Controls.Add(Me.lblOutfile)
    Me.Controls.Add(Me.btnBrowseOutFile)
    Me.Controls.Add(Me.txtBlastDB)
    Me.Controls.Add(Me.txtFasFile)
    Me.Controls.Add(Me.lblFastqFile)
    Me.Controls.Add(Me.lblFasFile)
    Me.Controls.Add(Me.btnBrowseFasFile)
    Me.Controls.Add(Me.btnBrowseBLAST)
    Me.Controls.Add(Me.PictureBox1)
    Me.Controls.Add(Me.TableLayoutPanel1)
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "dlgBlastFasToGE"
    Me.ShowInTaskbar = False
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
    Me.Text = "(Query FASTA file + BLAST DB) to gene expression"
    Me.TableLayoutPanel1.ResumeLayout(False)
    Me.frBlastOpt.ResumeLayout(False)
    Me.frBlastOpt.PerformLayout()
    CType(Me.udWordLen, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.udNumCPU, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
  Friend WithEvents OK_Button As System.Windows.Forms.Button
  Friend WithEvents Cancel_Button As System.Windows.Forms.Button
  Friend WithEvents txtBlastDB As System.Windows.Forms.TextBox
  Friend WithEvents txtFasFile As System.Windows.Forms.TextBox
  Friend WithEvents lblFastqFile As System.Windows.Forms.Label
  Friend WithEvents lblFasFile As System.Windows.Forms.Label
  Friend WithEvents btnBrowseFasFile As System.Windows.Forms.Button
  Friend WithEvents btnBrowseBLAST As System.Windows.Forms.Button
  Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
  Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
  Friend WithEvents btnBrowseOutFile As System.Windows.Forms.Button
  Friend WithEvents lblOutfile As System.Windows.Forms.Label
  Friend WithEvents txtOutfile As System.Windows.Forms.TextBox
  Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
  Friend WithEvents frBlastOpt As System.Windows.Forms.GroupBox
  Friend WithEvents udNumCPU As System.Windows.Forms.NumericUpDown
  Friend WithEvents lblWordLen As System.Windows.Forms.Label
  Friend WithEvents lblEval As System.Windows.Forms.Label
  Friend WithEvents lblNumCPU As System.Windows.Forms.Label
  Friend WithEvents txtEval As System.Windows.Forms.TextBox
  Friend WithEvents udWordLen As System.Windows.Forms.NumericUpDown
  Friend WithEvents btnHelp As System.Windows.Forms.Button
  Friend WithEvents txtMaxTarget As System.Windows.Forms.TextBox
  Friend WithEvents lblMaxNumMatch As System.Windows.Forms.Label
  Friend WithEvents cboStrand As System.Windows.Forms.ComboBox
  Friend WithEvents lblStrand As System.Windows.Forms.Label
  Friend WithEvents chkUngapped As System.Windows.Forms.CheckBox
  Friend WithEvents btnHelp2 As System.Windows.Forms.Button
  Friend WithEvents chkIsFasP As System.Windows.Forms.CheckBox
  Friend WithEvents lblInfo As System.Windows.Forms.Label

End Class
