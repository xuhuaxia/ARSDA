﻿Imports System.Net
Imports System.IO
Imports System.Text
Public Class frmFTP
  Private mFtpClient As FtpWebRequest = Nothing
  Private mCurServerUri As Uri
  Private mNCBI As Boolean
  Private mLogin As String, mPassword As String
  Private mParentUri() As String, mUriDepth As Integer, mMaxDepth As Integer 'mUriDepth: 0-rootDir (e.g., ftp://ftp-trace.ncbi.nlm.nih.gov/sra/sra-instant/reads/), 1-first-level subdir (e.g., ftp://ftp-trace.ncbi.nlm.nih.gov/sra/sra-instant/reads/ByExp/), ...
  Private mDirFileName() As String, mIsDir() As Boolean, mFileSize() As Integer  'A file/directory names in the current directory, used for constructing new Uri when lstDir is clicked. The the first element is "Parent Dir"

  Public Sub FtpToNCBI(ByVal serverUri As Uri)
    mFtpClient = CType(WebRequest.Create(serverUri), FtpWebRequest)
    mCurServerUri = serverUri

    Me.ShowDialog()
    mFtpClient = Nothing
    Erase mParentUri
  End Sub

  Public Sub FtpGeneral(ByVal serverUri As Uri, ByVal sUserID As String, ByVal sPassword As String)
    mFtpClient = CType(WebRequest.Create(serverUri), FtpWebRequest)
    mFtpClient.Credentials = New NetworkCredential(sUserID, sPassword)

    Me.ShowDialog()
    mFtpClient = Nothing
    Erase mParentUri
    Erase mParentUri
  End Sub


  Private Sub frmFTP_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    Dim sFromServer As String = ""

    mMaxDepth = 20
    ReDim mParentUri(mMaxDepth)
    mUriDepth = 0
    mParentUri(mUriDepth) = mCurServerUri.ToString

    If GetDirStr(sFromServer, True) Then
      DirToList(sFromServer, lstDir) 'Root directory, no "ParentDir" entry
    Else
      RichTextBox1.Text = "Error in GetDirStr"
    End If
  End Sub

  Private Sub DirToList(ByVal sDir As String, ByVal lstDir As ListBox)
    Dim I As Integer, UppInd As Integer
    Dim LineArray() As String, Field() As String

    sDir = Replace(sDir, vbCrLf, vbLf)
    sDir = Replace(sDir, vbCr, vbLf)
    LineArray = Split(sDir, vbLf) 'sDOrF Num(1:file, >1:dir) "ftp" "anonymous" FileSize Month Date Year Name
    '                       Used   ^                                           ^        ^    ^     ^    ^ 
    UppInd = UBound(LineArray)
    ReDim mIsDir(UppInd + 1), mDirFileName(UppInd + 1), mFileSize(UppInd + 1)
    mDirFileName(0) = "Parent dir"
    mIsDir(0) = True
    For I = 0 To UppInd
      LineArray(I) = Trim(LineArray(I))
      If LineArray(I) = "" Then
        UppInd = I
        Exit For
      Else
        Call TrimTo1Sp(LineArray(I))
        Field = Split(LineArray(I), " ")
        LineArray(I) = Field(0).PadRight(11) & Field(4).PadLeft(13) & " " & (Field(5) & " " & Field(6) & ", " & Field(7)).PadRight(14) & Field(8)
        mFileSize(I + 1) = CLng(Field(4))
        mDirFileName(I + 1) = Field(8)
        If Field(1) <> "1" Then
          mIsDir(I + 1) = True
        End If
      End If
    Next
    With lstDir
      .Items.Clear()
      .Items.Add("Parent Dir")
      For I = 0 To UppInd
        .Items.Add(LineArray(I))
      Next
    End With
  End Sub

  Private Function UriWellFormed(ByVal serverUri As Uri) As Boolean
    ' The serverUri parameter should start with the ftp:// scheme.
    If serverUri.Scheme <> Uri.UriSchemeFtp Then
      Return False
    Else
      Return True
    End If
  End Function

  Private Sub lstDir_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lstDir.SelectedIndexChanged
    Dim sURL As String
    Dim sFromServer As String = ""
    Dim NewUri As Uri

    With ToolStripStatusLabel1
      .ForeColor = Color.Red
      .Text = "Working..."
    End With


    If lstDir.SelectedIndex = 0 Then 'ParentDir
      mUriDepth = mUriDepth - 1
      If mUriDepth > 0 Then
        sURL = mParentUri(mUriDepth)
        NewUri = New Uri(sURL)
        mFtpClient = CType(WebRequest.Create(NewUri), FtpWebRequest)

        If GetDirStr(sFromServer, True) Then
          DirToList(sFromServer, lstDir)
        Else
          RichTextBox1.Text = "Error in GetDirStr"
        End If
      End If
    Else 'SelectedIndex > 0, either a file or a directory
      If mIsDir(lstDir.SelectedIndex) Then
        sURL = mParentUri(mUriDepth) & mDirFileName(lstDir.SelectedIndex)
        mUriDepth = mUriDepth + 1
        If mUriDepth > mMaxDepth Then
          mMaxDepth = mMaxDepth + 10
          ReDim Preserve mParentUri(mMaxDepth)
        End If
        NewUri = New Uri(sURL)
        mFtpClient = CType(WebRequest.Create(NewUri), FtpWebRequest)
        mParentUri(mUriDepth) = NewUri.ToString & "/"
        If GetDirStr(sFromServer, True) Then
          DirToList(sFromServer, lstDir)
        Else
          RichTextBox1.Text = "Error in GetDirStr"
        End If
      Else 'File
        Dim sFileType As String = RightOfChar(mDirFileName(lstDir.SelectedIndex), ".")
        Dim sFN As String = UCase(GetFNOnly(mDirFileName(lstDir.SelectedIndex)))
        Dim bTextFile As Boolean
        If InStr(sFN, "READ") > 0 Then 'assume text file
          bTextFile = True
        ElseIf InStr("OUT,TXT,TEXT,FAS,FFN,FAA,FRN,GBK", sFN) > 0 Then 'assume text file
          bTextFile = True
        Else
          bTextFile = False
        End If

        sURL = mParentUri(mUriDepth) & mDirFileName(lstDir.SelectedIndex)
        NewUri = New Uri(sURL)
        'mFtpClient = CType(WebRequest.Create(NewUri), FtpWebRequest)
        If bTextFile And mFileSize(lstDir.SelectedIndex) < 1000000 Then
          If GetFileStr(NewUri, sFromServer) Then
            RichTextBox1.Text = sFromServer
          End If
        Else
          If MsgBox("Do you want to download the file: " & sURL, vbYesNo) = vbYes Then
            Dim sTmpFN As String = Mid(sURL, InStrRev(sURL, "/") + 1)
            Dim sOutFile As String = GetSaveFileName("Save to...", sFileType, SaveFileDialog1, CurDir, sTmpFN)
            If sOutFile <> "" Then
              If WGet(sURL, sOutFile) Then
                MsgBox("The file: " & sURL & " has been downloaded to " & sOutFile)
              End If
            End If
          End If
        End If
      End If
    End If
    With ToolStripStatusLabel1
      .ForeColor = Color.Black
      .Text = "Ready"
    End With
  End Sub

  Private Function GetDirStr(ByRef sOut As String, ByVal bDetail As Boolean) As Boolean
    Dim oResponse As Object
    If bDetail Then
      mFtpClient.Method = WebRequestMethods.Ftp.ListDirectoryDetails
    Else
      mFtpClient.Method = WebRequestMethods.Ftp.ListDirectory
    End If
    oResponse = DirectCast(mFtpClient.GetResponse(), FtpWebResponse)

    Dim responseStream As Stream = oResponse.GetResponseStream()
    Dim reader As New StreamReader(responseStream)

    sOut = reader.ReadToEnd()
    oResponse = Nothing
    Return True
  End Function

  Private Function GetFileStr(ByVal serverUri As Uri, ByRef sPage As String) As Boolean
    ' The serverUri parameter should start with the ftp:// scheme.
    If serverUri.Scheme <> Uri.UriSchemeFtp Then
      MsgBox("Error in GetFileStr: Input Uri not same as Uri.UriSchemeFtp")
      Return False
    End If
    ' Get the object used to communicate with the server.
    Dim oClient As New WebClient()

    Try
      Dim newFileData() As Byte = oClient.DownloadData(serverUri.ToString())
      sPage = Encoding.UTF8.GetString(newFileData)
      Return True
    Catch e As WebException
      sPage = e.ToString()
      Return False
    End Try
  End Function

  'This blocks the calling thread until the download is complete. For asynchronous downloading, use .DownloadFileAsymc 
  Private Function WGet(ByVal sFileURL As String, ByVal sLocalName As String) As Boolean
    Dim client As New Net.WebClient
    client.DownloadFile(sFileURL, sLocalName)
    Return True
  End Function

  'At NCBI sra FTP, there are run directories (DRR, ERR, SRR), experiment directories (DRX, ERX, SRX), sample directories (DRS, ERS, SRS), and study directories (DRP, ERP, and SRP).
  '  Only IDs in the form of xRR (run directories) can be used to infer the full path.
  'When clicking "All runs" in a Study or Sample, a list of SRA ID will be displayed. Under 'Download', click 'Accession List' will save the SRA accession to a file.
  'This file can then be used to produce sSRRID()
  Private Function WGetMult(ByRef sSRRID() As String, ByVal sSaveDir As String, ByRef ProgressBar1 As ToolStripProgressBar) As Boolean

    Dim I As Integer
    Dim client As New Net.WebClient
    Dim sURL_root As String
    Dim sID As String, sFileURL As String, sLocalName As String
    Dim sFirst6Ch As String

    Select Case Strings.Left(sSRRID(0), 3)
      Case "SRR"
        sURL_root = "ftp://ftp-trace.ncbi.nlm.nih.gov/sra/sra-instant/reads/ByRun/sra/SRR/"
      Case "ERR"
        sURL_root = "ftp://ftp-trace.ncbi.nlm.nih.gov/sra/sra-instant/reads/ByRun/sra/ERR/"
      Case "DRR"
        sURL_root = "ftp://ftp-trace.ncbi.nlm.nih.gov/sra/sra-instant/reads/ByRun/sra/DRR/"
    End Select

    If Strings.Right(sSaveDir, 1) <> Path.DirectorySeparatorChar Then
      sSaveDir = sSaveDir & Path.DirectorySeparatorChar
    End If
    ProgressBar1.Minimum = 0
    ProgressBar1.Maximum = UBound(sSRRID)
    For I = 0 To UBound(sSRRID)
      sID = sSRRID(I)
      sFirst6Ch = Strings.Left(sID, 6)
      sLocalName = sID & ".sra"
      sFileURL = sURL_root & sFirst6Ch & "/" & sID & "/" & sID & ".sra"
      sLocalName = sSaveDir & sLocalName
      client.DownloadFile(sFileURL, sLocalName)
      ProgressBar1.Value = I
    Next
    ProgressBar1.Value = 0
    Return True
  End Function

  Private Sub NewFTPSiteToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewFTPSiteToolStripMenuItem.Click
    Dim sURL As String = InputBox("New FTP address", "User input", "ftp://")
    If Strings.Right(sURL, 1) <> "/" Then
      sURL = sURL & "/"
    End If
    Dim NewUri As New Uri(sURL)
    Dim sFromServer As String = ""
    If NewUri.Scheme <> Uri.UriSchemeFtp Then
      MsgBox("Error: Input not same as Uri.UriSchemeFtp (i.e., ftp://...")
      Exit Sub
    End If

    With ToolStripStatusLabel1
      .ForeColor = Color.Red
      .Text = "Connecting..."
    End With
    mFtpClient = CType(WebRequest.Create(NewUri), FtpWebRequest)
    mUriDepth = 0
    mParentUri(mUriDepth) = sURL
    If GetDirStr(sFromServer, True) Then
      DirToList(sFromServer, lstDir)
    Else
      RichTextBox1.Text = "Error in GetDirStr"
    End If
    With ToolStripStatusLabel1
      .ForeColor = Color.Black
      .Text = "Ready"
    End With

  End Sub

  Private Sub DownloadToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DownloadToolStripMenuItem1.Click
    Dim sURL As String = mParentUri(mUriDepth) & mDirFileName(lstDir.SelectedIndex)
    Dim sFileType As String = RightOfChar(mDirFileName(lstDir.SelectedIndex), ".")
    Dim sOutFile As String = GetSaveFileName("Save to...", sFileType, SaveFileDialog1, CurDir)

    With ToolStripStatusLabel1
      .ForeColor = Color.Red
      .Text = "Downloading..."
    End With
    If WGet(sURL, sOutFile) Then
      MsgBox("File: " & sURL & " has been save to local file: " & sOutFile)
    End If
    With ToolStripStatusLabel1
      .ForeColor = Color.Black
      .Text = "Ready"
    End With
  End Sub

  Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
    Me.Close()
  End Sub


  Private Sub DownloadMult_Click(sender As System.Object, e As System.EventArgs) Handles DownloadMult.Click
    'At NCBI SRA, when clicking "All runs" in a Study or Sample, a list of SRA ID will be displayed. Under 'Download', click 'Accession List' will save the SRA accession to a file.
    'This file can then be used to produce sSRRID()
    If MsgBox("This function is used when you have saved a list of SRA accession IDs each in the form of 'SRR######'. When you are browsing NCBI SRA database, e.g., 'https://www.ncbi.nlm.nih.gov/sra/SRX1728180[accn]', click 'All runs', and you will see a list of SRA IDs displayed. Under 'Download', click 'Accession List' will save the SRA accession IDs to a file. This file can then be used to batch-download the associated SRA files. Have you already obtained such an ID list file?", vbYesNo) = vbNo Then
      Exit Sub
    End If

    Dim sDir As String = CurDir()
    Dim sSRR_ID_file As String = GetOpenFileName("Open saved SRR ID file", "txt,out", OpenFileDialog1, sDir)
    Dim sSRRID() As String = File.ReadAllLines(sSRR_ID_file)

    With FolderBrowserDialog1
      .ShowNewFolderButton = True
      .Description = "Directory for new data"
      .ShowDialog()
      sDir = .SelectedPath
    End With

    Call WGetMult(sSRRID, sDir, ToolStripProgressBar1)
  End Sub
End Class