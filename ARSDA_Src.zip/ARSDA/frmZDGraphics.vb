﻿'In ZedGraph, Point.X and Point.Y are double, so input X and Y arrays should be "As Double" (otherwise they need to be converted
'  to Double), but there is some convenience in having " Sub DrawGraph(ByVal X As Object, ByVal Y As Object, ..." because
'  one can pass either an array or a matrix to Y. Will keep it this way unless I see a visible cost of computation speed.
'
Imports ZedGraph
Public Class frmZDGraphics
  Public Enum enumChartType
    Bar
    Line
    Scatter
  End Enum

  Private mXarray As Object, mYarray As Object, mNameX As String, mNameY As String 'For copying data to clipboard, mNameY is in format of "NameY1,NameY2,..."

  'In ZedGraph, Point.X and Point.Y are double, so input X and Y arrays should be "As Double" (otherwise they need to be converted
  '  to Double), but there is some convenience in having " Sub DrawGraph(ByVal X As Object, ByVal Y As Object, ..." because
  '  one can pass either an array or a matrix to Y. Will keep it this way unless I see a visible cost of computation speed.
  'X is one-dimensional array, and Y could be either one-dimensional (NumDV = 1) or multi-dimensional (NumDV > 1) in which case Y(NumPoint-1,NumDV-1)
  'if NumDV > 1, then sLegend ="NameY1,NameY2,..."
  Sub DrawGraph(ByVal X As Object, ByVal Y As Object, ByVal NumPoint As Integer, ByVal NumDV As Integer, _
            ByVal sNameX As String, ByVal sNameY As String, ByVal GraphType As enumChartType, _
            Optional ByVal sTitle As String = "", Optional ByVal sLegend As String = "")

    Dim I As Integer, J As Integer
    Dim MinX As Double, MaxX As Double, MinY As Double, MaxY As Double
    Dim myPane As GraphPane = ZG1.GraphPane
    Dim myCurve As LineItem
    Dim myBar As BarItem
    Dim list As New PointPairList

    mXarray = X
    mYarray = Y
    mNameX = sNameX
    mNameY = sNameY

    ' Set the titles and axis labels
    If sTitle = "" Then
      myPane.Title.IsVisible = False
    Else
      myPane.Title.Text = sTitle
    End If
    myPane.XAxis.Title.Text = sNameX
    myPane.YAxis.Title.Text = sNameY

    MinX = X(0)
    MaxX = X(0)
    For I = 1 To NumPoint - 1
      If MinX > X(I) Then
        MinX = X(I)
      ElseIf MaxX < X(I) Then
        MaxX = X(I)
      End If
    Next

    If NumDV = 1 Then

      MinY = Y(0)
      MaxY = Y(0)
      For I = 1 To NumPoint - 1
        If MinY > Y(I) Then
          MinY = Y(I)
        ElseIf MaxY < Y(I) Then
          MaxY = Y(I)
        End If
      Next


      For I = 0 To NumPoint - 1
        list.Add(X(I), Y(I))
      Next I

      Select Case GraphType
        Case enumChartType.Bar
          myBar = myPane.AddBar(" ", list, Color.Red)
        Case enumChartType.Line
          myCurve = myPane.AddCurve(sNameY, list, Color.Red, SymbolType.Diamond)
          myCurve.Symbol.Fill = New Fill(Color.White)
        Case enumChartType.Scatter
          myCurve = myPane.AddCurve(sNameY, list, Color.Red, SymbolType.Diamond)
          myCurve.Line.IsVisible = False
          myCurve.Symbol.Fill = New Fill(Color.White)
      End Select

    Else
      Dim ColorArray() As System.Drawing.Color
      Dim SymbolArray() As ZedGraph.SymbolType
      Dim Legend() As String
      Dim Ind As Integer

      ReDim ColorArray(NumDV - 1), SymbolArray(NumDV - 1)

      Legend = Split(sLegend, ",")

      For I = 0 To NumDV - 1
        Select Case I Mod 8
          Case 0
            ColorArray(I) = Color.Black
            SymbolArray(I) = SymbolType.Circle
          Case 1
            ColorArray(I) = Color.Red
            SymbolArray(I) = SymbolType.Diamond
          Case 2
            ColorArray(I) = Color.Blue
            SymbolArray(I) = SymbolType.Plus
          Case 3
            ColorArray(I) = Color.Green
            SymbolArray(I) = SymbolType.Square
          Case 4
            ColorArray(I) = Color.Yellow
            SymbolArray(I) = SymbolType.Star
          Case 5
            ColorArray(I) = Color.Orange
            SymbolArray(I) = SymbolType.Triangle
          Case 6
            ColorArray(I) = Color.Purple
            SymbolArray(I) = SymbolType.XCross
          Case 7
            ColorArray(I) = Color.Brown
            SymbolArray(I) = SymbolType.TriangleDown
        End Select
      Next

      'Get min and max of the first column of Y
      MinY = Y(0, 0)
      MaxY = Y(0, 0)
      For I = 0 To NumDV - 1
        For J = 0 To NumPoint - 1
          If MinY > Y(J, I) Then
            MinY = Y(J, I)
          ElseIf MaxY < Y(J, I) Then
            MaxY = Y(J, I)
          End If
        Next
      Next
      For I = 0 To NumDV - 1
        For J = 0 To NumPoint - 1
          list.Add(X(J), Y(J, I))
        Next
        'myCurve = myPane.AddCurve(sNameY, ListArray(I), Color.Red, SymbolType.Diamond)
        Ind = I Mod 8
        If GraphType = enumChartType.Bar Then
          myBar = myPane.AddBar(Legend(I), list, ColorArray(Ind))
        Else
          myCurve = myPane.AddCurve(Legend(I), list, ColorArray(Ind), SymbolArray(Ind))
          If GraphType = enumChartType.Scatter Then
            myCurve.Line.IsVisible = False
          End If
          ' Fill the symbols with white
          myCurve.Symbol.Fill = New Fill(Color.White)
        End If
        list = New PointPairList
      Next
    End If

    ' Show the x axis grid
    myPane.XAxis.MajorGrid.IsVisible = True

    ' Make the Y axis scale red
    myPane.YAxis.Scale.FontSpec.FontColor = Color.Black
    myPane.YAxis.Title.FontSpec.FontColor = Color.Black
    ' turn off the opposite tics so the Y tics don't show up on the Y2 axis
    myPane.YAxis.MajorTic.IsOpposite = False
    myPane.YAxis.MinorTic.IsOpposite = False
    ' Don't display the Y zero line
    myPane.YAxis.MajorGrid.IsZeroLine = False
    ' Align the Y axis labels so they are flush to the axis
    myPane.YAxis.Scale.Align = AlignP.Inside
    ' Manually set the axis range
    myPane.YAxis.Scale.Min = MinY - (MaxY - MinY) * 0.01
    myPane.YAxis.Scale.Max = MaxY + (MaxY - MinY) * 0.01

    If GraphType = enumChartType.Bar Then
      myPane.XAxis.Scale.Min = MinX
      myPane.XAxis.Scale.Max = MaxX
    Else
      myPane.XAxis.Scale.Min = MinX - (MaxX - MinX) * 0.01
      myPane.XAxis.Scale.Max = MaxX + (MaxX - MinX) * 0.01
    End If

    ' Fill the axis background with a gradient
    myPane.Chart.Fill = New Fill(Color.White, Color.LightGray, 45.0F)

    ' Enable scrollbars if needed
    ZG1.IsShowHScrollBar = True
    ZG1.IsShowVScrollBar = True
    ZG1.IsAutoScrollRange = True

    ZG1.IsShowPointValues = True

    ZG1.AxisChange()
    ' Make sure the Graph gets redrawn
    ZG1.Invalidate()

    Me.ShowDialog()
    myPane = Nothing
    myCurve = Nothing
    myBar = Nothing
    list = Nothing

  End Sub

  'X, Y and Y2 are one-dimensional arrays
  'In ZedGraph, Point.X and Point.Y are double, so input X, Y and Y2 arrays should be "As Double" (otherwise they need to be converted
  '  to Double).
  Sub DrawGraph2Y(ByVal X() As Double, ByVal Y() As Double, ByVal Y2() As Double, ByVal NumPoint As Integer, _
            ByVal sNameX As String, ByVal sNameY1 As String, ByVal sNameY2 As String, Optional ByVal sTitle As String = "")

    Dim I As Integer
    Dim MinY As Double, MaxY As Double
    Dim myPane As GraphPane = ZG1.GraphPane

    mXarray = X
    ReDim mYarray(NumPoint - 1, 1)
    For I = 0 To NumPoint - 1
      mYarray(I, 0) = Y(I)
      mYarray(I, 1) = Y2(I)
    Next
    mNameX = sNameX
    mNameY = sNameY1 & "," & sNameY2

    MinY = Y(0)
    MaxY = Y(0)
    For I = 1 To NumPoint - 1
      If MinY > Y(I) Then
        MinY = Y(I)
      ElseIf MaxY < Y(I) Then
        MaxY = Y(I)
      End If
    Next

    ' Set the titles and axis labels
    If sTitle <> "" Then
      myPane.Title.Text = sTitle
    End If
    myPane.XAxis.Title.Text = sNameX
    myPane.YAxis.Title.Text = sNameY1
    myPane.Y2Axis.Title.Text = sNameY2

    ' Make up some data points based on the Sine function
    Dim list As New PointPairList
    Dim list2 As New PointPairList

    For I = 0 To NumPoint - 1
      list.Add(X(I), Y(I))
      list2.Add(X(I), Y2(I))
    Next I

    ' Generate a red curve with diamond symbols, and sNameY1 in the legend
    Dim myCurve As LineItem
    myCurve = myPane.AddCurve(sNameY1, list, Color.Red, SymbolType.Diamond)
    ' Fill the symbols with white
    myCurve.Symbol.Fill = New Fill(Color.White)

    ' Generate a blue curve with circle symbols, and "Beta" in the legend
    myCurve = myPane.AddCurve(sNameY2, list2, Color.Blue, SymbolType.Circle)
    ' Fill the symbols with white
    myCurve.Symbol.Fill = New Fill(Color.White)
    ' Associate this curve with the Y2 axis
    myCurve.IsY2Axis = True

    ' Show the x axis grid
    myPane.XAxis.MajorGrid.IsVisible = True

    ' Make the Y axis scale red
    myPane.YAxis.Scale.FontSpec.FontColor = Color.Red
    myPane.YAxis.Title.FontSpec.FontColor = Color.Red
    ' turn off the opposite tics so the Y tics don't show up on the Y2 axis
    myPane.YAxis.MajorTic.IsOpposite = False
    myPane.YAxis.MinorTic.IsOpposite = False
    ' Don't display the Y zero line
    myPane.YAxis.MajorGrid.IsZeroLine = False
    ' Align the Y axis labels so they are flush to the axis
    myPane.YAxis.Scale.Align = AlignP.Inside
    ' Manually set the axis range
    myPane.YAxis.Scale.Min = MinY - (MaxY - MinY) * 0.01
    myPane.YAxis.Scale.Max = MaxY + (MaxY - MinY) * 0.01

    ' Enable the Y2 axis display
    myPane.Y2Axis.IsVisible = True
    ' Make the Y2 axis scale blue
    myPane.Y2Axis.Scale.FontSpec.FontColor = Color.Blue
    myPane.Y2Axis.Title.FontSpec.FontColor = Color.Blue
    ' turn off the opposite tics so the Y2 tics don't show up on the Y axis
    myPane.Y2Axis.MajorTic.IsOpposite = False
    myPane.Y2Axis.MinorTic.IsOpposite = False
    ' Display the Y2 axis grid lines
    myPane.Y2Axis.MajorGrid.IsVisible = True
    ' Align the Y2 axis labels so they are flush to the axis
    myPane.Y2Axis.Scale.Align = AlignP.Inside
    'myPane.Y2Axis.Scale.Min = MinY2
    'myPane.Y2Axis.Scale.Max = MaxY2

    ' Fill the axis background with a gradient
    myPane.Chart.Fill = New Fill(Color.White, Color.LightGray, 45.0F)

    ' Add a text box with instructions
    'Dim text As New TextObj("Zoom: left mouse & drag" & Chr(10) & "Pan: middle mouse & drag" & Chr(10) & "Context Menu: right mouse", 0.05F, 0.95F, CoordType.ChartFraction, AlignH.Left, AlignV.Bottom)
    'text.FontSpec.StringAlignment = StringAlignment.Near
    'myPane.GraphObjList.Add(text)

    ' Enable scrollbars if needed
    ZG1.IsShowHScrollBar = True
    ZG1.IsShowVScrollBar = True
    ZG1.IsAutoScrollRange = True
    ZG1.IsScrollY2 = True

    ZG1.IsShowPointValues = True

    ' Size the control to fit the window
    'SetSize()

    ' Tell ZedGraph to calculate the axis ranges
    ' Note that you MUST call this after enabling IsAutoScrollRange, since AxisChange() sets
    ' up the proper scrolling parameters
    ZG1.AxisChange()
    ' Make sure the Graph gets redrawn
    ZG1.Invalidate()

    Me.ShowDialog()
    myPane = Nothing
    myCurve = Nothing
    list = Nothing
    list2 = Nothing

  End Sub

  Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileExit.Click
    Me.Close()
  End Sub

  Private Sub frmZDGraphics_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
    Erase mXarray, mYarray
    mNameX = ""
    mNameY = ""
  End Sub

  Private Sub frmGraphics_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    With cboGraphType
      .Items.Clear()
      .Items.Add("Bar")
      .Items.Add("Line")
      .Items.Add("Scatter")
    End With
    With cboMarkerStyle.Items
      .Clear()
      .Add("Circle")
      .Add("Cross")
      .Add("Diamond")
      .Add("None")
      .Add("Square")
      .Add("Star10")
      .Add("Star4")
      .Add("Star5")
      .Add("Star6")
      .Add("Triangle")
    End With
    With cboMarkerColor.Items
      .Clear()
      .Add("Aqua")
      .Add("Azure")
      .Add("Black")
      .Add("Blue")
      .Add("Brown")
      .Add("Crimson")
      .Add("Cyan")
      .Add("Green")
      .Add("Purple")
      .Add("Red")
      .Add("Violet")
      .Add("White")
      .Add("Yellow")
    End With
  End Sub

  Private Sub cboGraphType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboGraphType.SelectedIndexChanged
    Dim I As Integer, NumDV As Integer, Ind As Integer
    Dim myPane = ZG1.GraphPane
    Dim myCurveList = myPane.CurveList
    Dim ListArray() As PointPairList
    Dim ColorArray(7) As Color
    Dim SymbolArray(7) As SymbolType
    Dim sLabel() As String
    Dim myCurve As LineItem

    NumDV = myCurveList.Count

    ReDim ListArray(NumDV - 1), sLabel(NumDV - 1)

    For I = 0 To NumDV - 1
      Select Case I Mod 8
        Case 0
          ColorArray(I) = Color.Black
          SymbolArray(I) = SymbolType.Circle
        Case 1
          ColorArray(I) = Color.Red
          SymbolArray(I) = SymbolType.Diamond
        Case 2
          ColorArray(I) = Color.Blue
          SymbolArray(I) = SymbolType.Plus
        Case 3
          ColorArray(I) = Color.Green
          SymbolArray(I) = SymbolType.Square
        Case 4
          ColorArray(I) = Color.Yellow
          SymbolArray(I) = SymbolType.Star
        Case 5
          ColorArray(I) = Color.Orange
          SymbolArray(I) = SymbolType.Triangle
        Case 6
          ColorArray(I) = Color.Purple
          SymbolArray(I) = SymbolType.XCross
        Case 7
          ColorArray(I) = Color.Brown
          SymbolArray(I) = SymbolType.TriangleDown
      End Select
    Next


    For I = 0 To NumDV - 1
      ListArray(I) = myCurveList(I).Points
      sLabel(I) = myCurveList(I).Label.Text
    Next

    myCurveList.Clear()

    Select Case cboGraphType.SelectedIndex
      Case 0 'Bar
        For I = 0 To NumDV - 1
          Ind = I Mod 8
          myPane.AddBar(sLabel(I), ListArray(I), ColorArray(Ind))
        Next
      Case 1 'Line
        For I = 0 To NumDV - 1
          Ind = I Mod 8
          myPane.AddCurve(sLabel(I), ListArray(I), ColorArray(Ind), SymbolArray(Ind))
        Next
      Case 2 'Scatter
        For I = 0 To NumDV - 1
          Ind = I Mod 8
          myCurve = myPane.AddCurve(sLabel(I), ListArray(I), ColorArray(Ind), SymbolArray(Ind))
          myCurve.Line.IsVisible = False
        Next
    End Select
    ' Make sure the Graph gets redrawn
    ZG1.Invalidate()

  End Sub


  'Display customized tooltips when the mouse hovers over a point
  Private Function MyPointValueEvent(ByVal control As ZedGraphControl, _
          ByVal pane As GraphPane, ByVal curve As CurveItem, _
          ByVal iPt As Integer) As String Handles zg1.PointValueEvent

    ' Get the PointPair that is under the mouse
    Dim pt As PointPair = curve(iPt)

    Return curve.Label.Text + " is " + pt.Y.ToString("f2") + " units at " + pt.X.ToString("f1") + " days"
  End Function

  ' On resize action, resize the ZedGraphControl to fill most of the Form, with a small
  ' margin around the outside
  'Private Sub Form1_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize
  '  SetSize()
  'End Sub

  'Private Sub SetSize()
  '  Dim loc As New Point(10, 10)
  '  zg1.Location = loc
  '  ' Leave a small margin around the outside of the control
  '  Dim size As New Size(Me.ClientRectangle.Width - 20, Me.ClientRectangle.Height - 20)
  '  zg1.Size = size
  'End Sub


  ' Customize the context menu by adding a new item to the end of the menu
  Private Sub MyContextMenuBuilder(ByVal control As ZedGraphControl, _
             ByVal menu As ContextMenuStrip, ByVal mousePt As Point, _
             ByVal objState As ZedGraphControl.ContextMenuObjectState) _
          Handles zg1.ContextMenuBuilder
    Dim item As New ToolStripMenuItem
    item.Name = "add-beta"
    item.Tag = "add-beta"
    item.Text = "Add a new Beta Point"
    AddHandler item.Click, AddressOf Me.AddBetaPoint

    menu.Items.Add(item)
  End Sub

  ' Handle the "Add New Beta Point" context menu item.  This finds the curve with
  ' the CurveItem.Label = "Beta", and adds a new point to it.
  Private Sub AddBetaPoint(ByVal sender As Object, ByVal args As EventArgs)
    ' Get a reference to the "Beta" curve PointPairList
    Dim x As Double, y As Double

    Dim ip As IPointListEdit = zg1.GraphPane.CurveList("Beta").Points

    If (Not IsNothing(ip)) Then
      x = ip.Count * 5.0
      y = Math.Sin(ip.Count * Math.PI / 15.0) * 16.0 * 13.5
      ip.Add(x, y)
      zg1.AxisChange()
      zg1.Refresh()
    End If
  End Sub

  'Private Sub zg1_ZoomEvent(ByVal control As ZedGraphControl, ByVal oldState As ZoomState, _
  '      ByVal newState As ZoomState) Handles zg1.ZoomEvent
  '  'Here we get notification everytime the user zooms
  'End Sub


  Private Sub mnuHelpGeneral_Click(sender As Object, e As EventArgs) Handles mnuHelpGeneral.Click
    Dim sInfo As String = "Zoom: left mouse & drag" & Chr(10) & "Pan: middle mouse & drag" & Chr(10) & "Context Menu: right mouse"
    Call MsgBox(sInfo, vbInformation, "Help")
  End Sub

  Private Sub NumericUpDown1_ValueChanged(sender As Object, e As EventArgs) Handles NumericUpDown1.ValueChanged
    ZG1.GraphPane.YAxis.Scale.FontSpec.Size = NumericUpDown1.Value
    ZG1.GraphPane.YAxis.Title.FontSpec.Size = NumericUpDown1.Value
    ZG1.GraphPane.XAxis.Scale.FontSpec.Size = NumericUpDown1.Value
    ZG1.GraphPane.XAxis.Title.FontSpec.Size = NumericUpDown1.Value
    ZG1.GraphPane.Title.FontSpec.Size = NumericUpDown1.Value
    ' Make sure the Graph gets redrawn
    ZG1.Invalidate()
  End Sub

  Private Sub udMarkerSize_ValueChanged(sender As Object, e As EventArgs) Handles udMarkerSize.ValueChanged
  End Sub

  Private Sub cboMarkerStyle_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboMarkerStyle.SelectedIndexChanged

  End Sub

  Private Sub cboMarkerColor_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboMarkerColor.SelectedIndexChanged

  End Sub

  Private Sub mnuFileSaveEMF_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileSaveEMF.Click
    Dim sOutFile As String = GetSaveFileName("Save to...", "emf", SaveFileDialog1, CurDir)
    If sOutFile <> "" Then
      ZG1.GraphPane.GetMetafile.Save(sOutFile)
    End If

    Call MsgBox("Metafile saved to file: " & sOutFile, vbInformation)
  End Sub

  Private Sub mnuFileSaveBMP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileSaveBMP.Click
    Dim sOutFile As String = GetSaveFileName("Save to...", "bmp", SaveFileDialog1, CurDir)
    If sOutFile <> "" Then
      ZG1.GraphPane.GetImage.Save(sOutFile)
    End If
    Call MsgBox("Bitmap saved to file: " & sOutFile, vbInformation)
  End Sub

  Private Sub mnuEditCopyBMP_Click(sender As Object, e As EventArgs) Handles mnuEditCopyBMP.Click
    Clipboard.SetDataObject(ZG1.MasterPane.GetImage)
    Call MsgBox("Bitmap copied to clipboard. You may go to a graphic program and paste the image.", vbInformation)
  End Sub

  Private Sub mnuEditCopyEMF_Click(sender As Object, e As EventArgs) Handles mnuEditCopyEMF.Click
    'NET clipboard function below does not seem to work with metafile
    'Clipboard.SetDataObject(ZG1.MasterPane.GetMetafile)
    Dim myPane = ZG1.GraphPane
    Dim g As Graphics = Me.CreateGraphics()
    Dim hdc As System.IntPtr = g.GetHdc()
    Dim metaFile As New Imaging.Metafile(hdc, Imaging.EmfType.EmfOnly)

    g.ReleaseHdc(hdc)
    g.Dispose()

    Dim gMeta As Graphics = Graphics.FromImage(metaFile)
    myPane.Draw(gMeta)
    gMeta.Dispose()

    ClipboardMetafileHelper.PutEnhMetafileOnClipboard(Me.Handle, metaFile)

    Call MsgBox("Metafile copied to clipboard. You may go to a graphic program and paste the image.", vbInformation)
  End Sub

  Private Sub mnuCopyData_Click(sender As Object, e As EventArgs) Handles mnuCopyData.Click
    Dim I As Integer, J As Integer, UppInd As Integer, NumDV As Integer
    Dim sb As New System.Text.StringBuilder

    UppInd = UBound(mXarray)
    NumDV = UBound(mYarray, 2) + 1
    sb.Append(mNameX & Replace(mNameY, ",", vbTab) & vbCrLf)
    If NumDV = 1 Then
      For I = 0 To UppInd
        sb.Append(mXarray(I).ToString & vbTab & mYarray(I) & vbCrLf)
      Next
    Else
      For I = 0 To UppInd
        sb.Append(mXarray(I).ToString)
        For J = 0 To NumDV - 1
          sb.Append(vbTab & mYarray(I, J))
        Next
        sb.Append(vbCrLf)
      Next
    End If
    Clipboard.Clear()
    Clipboard.SetText(sb.ToString)
    sb = Nothing
    Call MsgBox("Data copied to clipboard. You may go to Microsoft EXCEL (or similar programs) and paste.", vbInformation)
  End Sub
End Class