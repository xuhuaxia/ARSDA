﻿Imports System.Windows.Forms
Imports System.IO

Public Class dlgSraFasToGE

  Private mDone As Boolean, mFasFile As String, mSraFile As String, mOutfile As String 'BlastDB will be the base name (e.g., MyDB.nin will show MyDB)
  Private mEvalue As Double, mWordLen As Integer, mNumCPU As Integer, mMaxDescr As Integer = 0
  Private mStrand As String 'both, plus, minus
  Private mUngapped As Boolean

  Public Function GetSraFasToGE(ByRef sFasFile As String, ByRef sSraFile As String, ByRef sOutfile As String, _
                                      ByRef Evalue As Double, ByRef iWordLen As Integer, ByRef sStrand As String, ByRef bUngapped As Boolean, ByRef iNumCPU As Integer, _
                                      ByRef iMaxDescr As Integer) As Boolean
    mDone = False
    Me.ShowDialog()
    If mDone Then
      sFasFile = mFasFile
      sSraFile = mSraFile
      sOutfile = mOutfile
      Evalue = mEvalue
      iWordLen = mWordLen
      sStrand = mStrand
      bUngapped = mUngapped
      iNumCPU = mNumCPU
      iMaxDescr = mMaxDescr
      Return True
    Else
      Return False
    End If
  End Function

  Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
    mFasFile = txtFasFile.Text
    If Not File.Exists(mFasFile) Then
      MsgBox("The input FAS file " & mFasFile & " does not exist.", vbOKOnly)
      txtFasFile.Focus()
      Exit Sub
    End If
    mSraFile = txtSraFile.Text
    If Not File.Exists(mSraFile) Then
      MsgBox("The input SRA file: " & mSraFile & " does not exist.", vbOKOnly)
      txtSraFile.Focus()
      Exit Sub
    End If

    mOutfile = txtOutfile.Text
    If Trim(mOutfile) = "" Then
      MsgBox("Please enter name for the output file.", vbOKOnly)
      txtOutfile.Focus()
      Exit Sub
    End If
    If IsNumeric(txtEval.Text) Then
      mEvalue = CDbl(txtEval.Text)
    End If
    If mEvalue <= 0 Then
      MsgBox("E-value should be greater than 0", vbOKOnly)
      txtEval.Focus()
      Exit Sub
    End If
    mNumCPU = udNumCPU.Value
    mWordLen = udWordLen.Value
    mMaxDescr = Val(txtNumAln.Text)
    mStrand = cboStrand.Text
    mDone = True
    Me.DialogResult = System.Windows.Forms.DialogResult.OK
    Me.Close()
  End Sub

  Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
    Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Close()
  End Sub

  Private Sub btnBrowseSRA_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseSRA.Click
    If Directory.Exists(txtSraFile.Text) Then
      txtSraFile.Text = GetOpenFileName("Open SRA file", "sra", OpenFileDialog1, txtSraFile.Text)
    Else
      txtSraFile.Text = GetOpenFileName("Open SRA file", "sra", OpenFileDialog1, sInputDir)
    End If
  End Sub

  Private Sub btnBrowseFAS_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseFAS.Click
    If Directory.Exists(txtFasFile.Text) Then
      txtFasFile.Text = GetOpenFileName("Open FASTA file", "fasta,fas,ffn,fna,frn", OpenFileDialog1, txtFasFile.Text)
    Else
      txtFasFile.Text = GetOpenFileName("Open FASTA file", "fasta,fas,ffn,fna,frn", OpenFileDialog1, sInputDir)
    End If
  End Sub

  Private Sub btnBrowseOutFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseOutFile.Click
    If Directory.Exists(txtOutfile.Text) Then
      txtOutfile.Text = GetSaveFileName("Save to...", "out", SaveFileDialog1, txtOutfile.Text)
    Else
      txtOutfile.Text = GetSaveFileName("Save to...", "out", SaveFileDialog1, sResultDir)
    End If
  End Sub

  Private Sub dlgSraFasToGE_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    Dim NumProcessor As Integer = Environment.ProcessorCount
    udNumCPU.Maximum = NumProcessor
    Select Case NumProcessor
      Case 1, 2
        udNumCPU.Value = 1
      Case 3
        udNumCPU.Value = 2
      Case Else
        udNumCPU.Value = NumProcessor - 2
    End Select

  End Sub

  Private Sub btnHelp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHelp.Click
    Dim sInfo As String
    sInfo = "The -max_target_seqs parameter in blastn and blastn_vdb (the latter being a special blastn for searching against SRA databases). This parameter limits the number of matched sequences in the SRA database for a query sequence (N). We use N for query sequence i (N_i) as a proxy of gene expression (optionally adjusted for duplicated sequences). Some highly expressed genes, especially certain rRNA genes, may have N_i = 500,000 or even higher. If you set the parameter to, say, 500 (which is the default), then all higly expressed genes will have an expression value of 500."
    MsgBox(sInfo, vbInformation)
  End Sub


End Class
