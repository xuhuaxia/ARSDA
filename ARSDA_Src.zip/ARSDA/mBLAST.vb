﻿Imports System.IO
Imports System.Text
Module mBLAST
  Private Structure tGE
    Public N_U As Integer
    Public N_DH As Integer
    Public OtherFamMember As String 'A comma-delimited string of other members of the gene family, used to retrieve N_DH of other members of the gene family.
    Public SeqLen As Integer
    'For reads that match a gene family --------------------------------------------------------------------------------------------------------------------
    Public N_I As Integer 'If reads SeqID_20 and SeqID_30 matches 3 members and 4 members, respectively, equally well, but do not match other genes, then
    '                      N_I=20+30
    Public N_I_prod       'N_I_Read = 3*20+4*30. This gives an average gene family size of N_I_Read/N_I = 3.6
    '                      The fraction of N_I assigned to this gene will be
    '                      N_I * [(1+N_DH)/(3.6+N_DH_All)
  End Structure

  Function CreateBlastDB(ByVal sFullMakeBlastDbName As String, ByVal sInFasFile As String, ByVal sBlastDbName As String, _
                         ByVal sBlastDbDir As String, ByVal bNuc As Boolean, _
                         ByRef sOut As String) As Boolean
    Dim sArg As String
    Dim sDbType As String = IIf(bNuc, "nucl", "prot")
    Dim sOldDir As String = CurDir()

    sArg = " -in " & sInFasFile & " -dbtype " & sDbType & " -parse_seqids -out " & sBlastDbName
#If TARGET = "LINUX" Then
    ChDir(sBlastDbDir)
#Else
    ChDrive(Left(sBlastDbDir, InStr(sBlastDbDir, ":")))
    ChDir(sBlastDbDir)
#End If

    If RunExeAndWait(sFullMakeBlastDbName, sArg, sBlastDbDir, False) Then
      Dim sIndFile As String = sBlastDbDir & Path.DirectorySeparatorChar & sBlastDbName & IIf(bNuc, ".nin", "pin")
      If File.Exists(sIndFile) Then
        sOut = "BLAST database " & sBlastDbName & " has been created from " & sInFasFile & " in directory " & sBlastDbDir & vbCrLf
        Return True
      Else
        'Blast DB split to multiple files
        sIndFile = sBlastDbDir & Path.DirectorySeparatorChar & sBlastDbName & IIf(bNuc, ".00.nin", ".00.pin")
        If File.Exists(sIndFile) Then
          sOut = "BLAST database " & sBlastDbName & " has been created from " & sInFasFile & " in directory " & sBlastDbDir & vbCrLf
          ChDrive(Left(sOldDir, InStr(sOldDir, ":")))
          ChDir(sOldDir)
          Return True
        Else
          sOut = "Error in running CreateBlastDB: RunExeAndWait worked but did not create the desired BLAST database. Input file: " & sInFasFile & vbCrLf
          ChDrive(Left(sOldDir, InStr(sOldDir, ":")))
          ChDir(sOldDir)
          Return False
        End If
      End If
    Else
      sOut = "Error in running CreateBlastDB"
      ChDrive(Left(sOldDir, InStr(sOldDir, ":")))
      ChDir(sOldDir)
      Return False
    End If
  End Function

  'Input sFullMakeBlastDbName, sInFasFile(), sBlastDBDir, bNuc, sOut
  'Derive BLASTDBName() from FileName (without path and file type)
  'All output BLAST database will save to sBlastDbDir
  Function CreateBlastDBMult(ByVal sFullMakeBlastDbName As String, ByVal sInFasFile() As String, _
                       ByVal sBlastDbDir As String, ByVal bNuc As Boolean, _
                       ByRef sOut As String) As Boolean
    Dim I As Integer, FindAt As Integer
    Dim sBlastDbName As String
    Dim sArg As String
    Dim sDbType As String = IIf(bNuc, "nucl", "prot")
    Dim sOldDir As String = CurDir()
    Dim sIndFile As String

#If TARGET = "LILNUX" Then
    ChDir(sBlastDbDir)
#Else
    ChDrive(Left(sBlastDbDir, InStr(sBlastDbDir, ":")))
    ChDir(sBlastDbDir)
#End If
    For I = 0 To UBound(sInFasFile)
      FindAt = InStr(sInFasFile(I), Path.DirectorySeparatorChar)
      sBlastDbName = Path.GetFileNameWithoutExtension(sInFasFile(I))
      sArg = " -in " & sInFasFile(I) & " -dbtype " & sDbType & " -parse_seqids -out " & sBlastDbName
      If RunExeAndWait(sFullMakeBlastDbName, sArg, sBlastDbDir, False) Then
        sIndFile = sBlastDbDir & Path.DirectorySeparatorChar & sBlastDbName & IIf(bNuc, ".nin", "pin")
        If File.Exists(sIndFile) Then
          sOut = sOut & "BLAST database " & sBlastDbName & " has been created from " & sInFasFile(I) & " in directory " & sBlastDbDir & vbCrLf
        Else
          'Blast DB split to multiple files
          sIndFile = sBlastDbDir & Path.DirectorySeparatorChar & sBlastDbName & IIf(bNuc, ".00.nin", ".00.pin")
          If File.Exists(sIndFile) Then
            sOut = "BLAST database " & sBlastDbName & " has been created from " & sInFasFile(I) & " in directory " & sBlastDbDir & vbCrLf
          Else
            sOut = sOut & "Error in running CreateBlastDB: RunExeAndWait worked but did not create the desired BLAST database. Input file: " & sInFasFile(I) & vbCrLf
          End If
        End If
      Else
        sOut = sOut & "Error in running CreateBlastDB. Input file: " & sInFasFile(I) & vbCrLf
      End If
    Next I
    ChDrive(Left(sOldDir, InStr(sOldDir, ":")))
    ChDir(sOldDir)
    Return True
  End Function

  Function ProcessBlastOutForGE(ByVal sBlastnOutFile As String, ByVal sOutFileGE As String, ByVal bPlus As Boolean, ByVal ProgressBar1 As ToolStripProgressBar) As Boolean
    'sBlastnOutfile: intermediate file containing the comma-delimited blastn_vdb output (without column annotation)
    'Query,DbSeq,%match,matchLen,NumMismatch,GO,q.start,q.end,dbSeqStart, dbSeqEnd, evalue, bit score
    'thrL,gnl|SRA|SRR1536586.6379132.1,100.00,49,0,0,18,66,1,49,2e-018,91.6
    'thrL,gnl|SRA|SRR1536586.6356742.1,100.00,49,0,0,18,66,1,49,2e-018,91.6
    '...
    'thrL,gnl|SRA|SRR1536586.4527718.1,100.00,36,0,0,31,66,1,36,3e-011,67.6
    'thrA,gnl|SRA|SRR1536586.6502929.1,100.00,50,0,0,1822,1871,1,50,3e-017,93.5
    'thrA,gnl|SRA|SRR1536586.6502478.1,100.00,50,0,0,2360,2409,1,50,3e-017,93.5
    '
    'If bPlus, then the BLAST database is created from FASTA+ files with names such as SeqGroupN_Count

    Dim I As Integer, J As Integer, lFileLen As Long, UppInd As Integer, FindAt As Integer, NumMatch As Integer
    Dim sQueryName As String = ""
    Dim lChunkLen As Integer, lFreeMem As Long
    Dim sChunk As String, LineArray() As String, Field() As String
    Dim sb As New StringBuilder

    Try
      lFreeMem = GetAvailablePhysicalMem()
    Catch ex As Exception
      MsgBox("Error Encountered in getting system memory!" & CRCR & ex.ToString, vbInformation, "Error")
      lFreeMem = 2000000000
    End Try
    lFileLen = FileLen(sBlastnOutFile)
    lChunkLen = lFreeMem \ 1000
    sb.Append("Result of gene expression as number of read matches" & CRCR)
    sb.Append("Gene".PadRight(20) & "Matches".PadLeft(10) & vbCrLf)
    If lChunkLen > lFileLen Then
      sChunk = File.ReadAllText(sBlastnOutFile)
      sChunk = Replace(sChunk, vbCrLf, vbLf)
      LineArray = Split(sChunk, vbLf)
      UppInd = UBound(LineArray)

      ProgressBar1.Minimum = 0
      ProgressBar1.Maximum = UppInd

      If bPlus Then
        Field = Split(LineArray(0), ",")
        sQueryName = Field(0)
        FindAt = InStrRev(Field(1), "_") + 1
        NumMatch = Val(Mid(Field(1), FindAt))
        For I = 1 To UppInd - IIf(LineArray(UppInd) = "", 1, 0)
          Field = Split(LineArray(I), ",")
          FindAt = InStrRev(Field(1), "_") + 1
          If sQueryName = Field(0) Then
            NumMatch = NumMatch + Val(Mid(Field(1), FindAt))
          Else
            sb.Append(sQueryName.PadRight(20) & NumMatch.ToString.PadLeft(10) & vbCrLf)
            NumMatch = Val(Mid(Field(1), FindAt))
            sQueryName = Field(0)
          End If
          ProgressBar1.Value = I
        Next
      Else
        Field = Split(LineArray(0), ",")
        sQueryName = Field(0)
        NumMatch = 1
        For I = 1 To UppInd - IIf(LineArray(UppInd) = "", 1, 0)
          Field = Split(LineArray(I), ",")
          If sQueryName = Field(0) Then
            NumMatch = NumMatch + 1
          Else
            sb.Append(sQueryName.PadRight(20) & NumMatch.ToString.PadLeft(10) & vbCrLf)
            NumMatch = 1
            sQueryName = Field(0)
          End If
          ProgressBar1.Value = I
        Next
      End If
      'print the last 
      sb.Append(sQueryName.PadRight(20) & NumMatch.ToString.PadLeft(10) & vbCrLf)
    Else
      Dim fs As New FileStream(sBlastnOutFile, FileMode.Open, FileAccess.Read)
      Dim NumByteRead As Integer, lNumChunk As Integer, lRemainLen As Integer
      Dim tmpByte() As Byte
      Dim sRemain As String = ""

      lNumChunk = lFileLen \ lChunkLen
      lRemainLen = lFileLen Mod lChunkLen

      ProgressBar1.Minimum = 0
      ProgressBar1.Maximum = lNumChunk
      For I = 0 To lNumChunk - 1
        ReDim tmpByte(lChunkLen - 1)
        NumByteRead = fs.Read(tmpByte, 0, lChunkLen)
        sChunk = Encoding.ASCII.GetString(tmpByte)
        sChunk = Replace(sChunk, vbCrLf, vbLf)
        sChunk = sRemain & sChunk
        LineArray = Split(sChunk, vbLf)
        UppInd = UBound(LineArray)
        'Three scenarios for the last line
        '1. The last byte is vbLf ---> last line is empty
        '2. The last byte is just before vbLf ---> the last line is complete
        '3. The last byte is in the middle of a line ---> partial line
        'Regardless, the last line will be assigned to sRemain.
        If I = 0 Then
          If bPlus Then
            Field = Split(LineArray(0), ",")
            sQueryName = Field(0)
            FindAt = InStrRev(Field(1), "_") + 1
            NumMatch = Val(Mid(Field(1), FindAt))
            For J = 1 To UppInd - 1
              Field = Split(LineArray(J), ",")
              FindAt = InStrRev(Field(1), "_") + 1
              If sQueryName = Field(0) Then
                NumMatch = NumMatch + Val(Mid(Field(1), FindAt))
              Else
                sb.Append(sQueryName.PadRight(20) & NumMatch.ToString.PadLeft(10) & vbCrLf)
                NumMatch = Val(Mid(Field(1), FindAt))
                sQueryName = Field(0)
              End If
            Next
          Else
            Field = Split(LineArray(0), ",")
            sQueryName = Field(0)
            NumMatch = 1
            For J = 1 To UppInd - 1
              Field = Split(LineArray(J), ",")
              If sQueryName = Field(0) Then
                NumMatch = NumMatch + 1
              Else
                sb.Append(sQueryName.PadRight(20) & NumMatch.ToString.PadLeft(10) & vbCrLf)
                NumMatch = 1
                sQueryName = Field(0)
              End If
            Next
          End If
        Else
          If bPlus Then
            For J = 0 To UppInd - 1
              Field = Split(LineArray(J), ",")
              FindAt = InStrRev(Field(1), "_") + 1
              If sQueryName = Field(0) Then
                NumMatch = NumMatch + Val(Mid(Field(1), FindAt))
              Else
                sb.Append(sQueryName.PadRight(20) & NumMatch.ToString.PadLeft(10) & vbCrLf)
                NumMatch = Val(Mid(Field(1), FindAt))
                sQueryName = Field(0)
              End If
            Next
          Else
            For J = 0 To UppInd - 1
              Field = Split(LineArray(J), ",")
              If sQueryName = Field(0) Then
                NumMatch = NumMatch + 1
              Else
                sb.Append(sQueryName.PadRight(20) & NumMatch.ToString.PadLeft(10) & vbCrLf)
                NumMatch = 1
                sQueryName = Field(0)
              End If
            Next
          End If
        End If
        sRemain = LineArray(UppInd)
        ProgressBar1.Value = I
      Next
      If lRemainLen > 0 Then
        ReDim tmpByte(lRemainLen - 1)
        NumByteRead = fs.Read(tmpByte, 0, lRemainLen)
        sChunk = sRemain & Encoding.ASCII.GetString(tmpByte)
        sChunk = Replace(sChunk, vbCrLf, vbLf)
        LineArray = Split(sChunk, vbLf)
        sChunk = ""
        UppInd = UBound(LineArray)
        If bPlus Then
          For J = 0 To UppInd - 1 'The last line is empty
            Field = Split(LineArray(J), ",")
            FindAt = InStrRev(Field(1), "_") + 1
            If sQueryName = Field(0) Then
              NumMatch = NumMatch + Val(Mid(Field(1), FindAt))
            Else
              sb.Append(sQueryName.PadRight(20) & NumMatch.ToString.PadLeft(10) & vbCrLf)
              NumMatch = Val(Mid(Field(1), FindAt))
              sQueryName = Field(0)
            End If
          Next
        Else
          For J = 0 To UppInd - 1 'The last line is empty
            Field = Split(LineArray(J), ",")
            If sQueryName = Field(0) Then
              NumMatch = NumMatch + 1
            Else
              sb.Append(sQueryName.PadRight(20) & NumMatch.ToString.PadLeft(10) & vbCrLf)
              NumMatch = 1
              sQueryName = Field(0)
            End If
          Next
        End If
        sb.Append(sQueryName.PadRight(20) & NumMatch.ToString.PadLeft(10) & vbCrLf)
      End If
      fs.Close()
    End If
    ProgressBar1.Value = 0
    File.WriteAllText(sOutFileGE, sb.ToString)
    'Kill(sBlastnOutFile)
    sb = Nothing
    Return True
  End Function

  Function ProcessBlastOutForGE2(ByVal QueryName() As String, ByVal iQueryLen() As Integer, ByVal iNumQuery As Integer, _
                                ByVal sBlastnOutFile As String, ByVal sOutFileGE As String, ByVal bPlus As Boolean, _
                                ByVal ProgressBar1 As ToolStripProgressBar) As Boolean
    'sBlastnOutfile: intermediate file containing the comma-delimited blastn_vdb output (without column annotation)
    'Query,DbSeq,%match,matchLen,NumMismatch,GO,q.start,q.end,dbSeqStart, dbSeqEnd, evalue, bit score
    'Gene	RS	%Match	MatchLen	MisM	GO	qStart	qEnd	RSStart	RSEnd	evalue	bitScore
    'thrL	SeqGr46909_37	100	49	0	0	18	66	1	49	3.00E-19	91.6
    'thrL	SeqGr160704_4	100	48	0	0	19	66	1	48	1.00E-18	89.8
    'thrL	SeqGr28806_27	100	45	0	0	22	66	1	45	6.00E-17	84.2
    'thrL	SeqGr947439_1	100	44	0	0	23	66	1	44	2.00E-16	82.4
    'thrL	SeqGr227511_6	100	44	0	0	23	66	1	44	2.00E-16	82.4
    'thrL	SeqGr785093_1	100	36	0	0	31	66	1	36	6.00E-12	67.6
    'thrA	SeqGr1005020_1	100	50	0	0	1691	1740	1	50	4.00E-18	93.5
    'thrA	SeqGr1004221_1	100	50	0	0	373	422	1	50	4.00E-18	93.5
    'thrA	SeqGr992946_1	100	50	0	0	2244	2293	1	50	4.00E-18	93.5
    '
    'If bPlus, then the BLAST database is created from FASTA+ files with names such as SeqGroupN_Count

    Dim I As Integer, J As Integer, K As Integer, UppInd As Integer, FindAt As Integer, NumMatch() As Integer
    Dim lFreeMem As Long, lInstalledMem As Long, lFileLen As Long
    Dim LineArray() As String, Field() As String
    Dim sb As New StringBuilder
    Dim dictGE As New Dictionary(Of String, tGE)
    Dim dictItem As tGE
    Dim ValuePair As KeyValuePair(Of String, tGE)
    Dim sQueryName() As String, sTargetName() As String
    Dim BitScore() As Single
    Dim StartInd As Integer, EndInd As Integer
    Dim NumEqualMatch 'Number of paralogous genes matching the read equally well
    Dim MaxBitScore As Single = 0
    Dim bNot_I As Boolean 'members in a gene family do not match the read equally well


    For I = 0 To iNumQuery - 1
      dictItem.SeqLen = iQueryLen(I)
      dictGE.Add(QueryName(I), dictItem)
    Next

    lFreeMem = GetAvailablePhysicalMem()
    lInstalledMem = GetTotalPhysicalMem()

    lFileLen = FileLen(sBlastnOutFile)
    Select Case lFreeMem \ lFileLen
      Case Is < 10
        If lInstalledMem \ lFileLen > 50 Then
          MsgBox("Your computer has " & lInstalledMem \ 1073741824 & " GB of physical memory, but  current free memory is only " & lFreeMem \ 1073741824 & " GB, which is insufficient for this function. Close some programs or restart the computer may give you enough memory to proceed.")
          Return False
        Else
          MsgBox("Your computer has only " & lFreeMem \ 1073741824 & " GB free, which is insufficient for this function. Install this program on a computer with more memory and re-run.")
          Return False
        End If
      Case Is < 50
        If MsgBox("You may run out of memory. Proceed?", vbYesNo, "Warning") = vbNo Then
          Return False
        End If
    End Select
    ProgressBar1.Minimum = 0
    LineArray = File.ReadAllLines(sBlastnOutFile)
    UppInd = UBound(LineArray)

    For I = UppInd To 0 Step -1
      If InStr(LineArray(I), ",") > 0 Then
        UppInd = I
        Exit For
      End If
    Next
    ReDim sQueryName(UppInd), sTargetName(UppInd), BitScore(UppInd), NumMatch(UppInd)

    ProgressBar1.Maximum = UppInd
    If bPlus Then 'FasPlus format
      For I = 0 To UppInd
        Field = Split(LineArray(I), ",")
        sQueryName(I) = Field(0)
        sTargetName(I) = Field(1)
        FindAt = InStr(sTargetName(I), "_")
        NumMatch(I) = Val(Mid(sTargetName(I), FindAt + 1))
        BitScore(I) = CSng(Field(11))
        ProgressBar1.Value = I
      Next
    Else
      For I = 0 To UppInd
        Field = Split(LineArray(I), ",")
        sQueryName(I) = Field(0)
        sTargetName(I) = Field(1)
        NumMatch(I) = 1
        BitScore(I) = CSng(Field(11))
        ProgressBar1.Value = I
      Next
    End If

    QuickSort4ArrayA(sTargetName, sQueryName, NumMatch, BitScore, 0, UppInd)

    StartInd = 0
    MaxBitScore = BitScore(0)
    NumEqualMatch = 1
    bNot_I = False
    If bPlus Then
      For I = 1 To UppInd
        If sTargetName(I) = sTargetName(I - 1) Then 'Same gene family
          If MaxBitScore < BitScore(I) Then
            MaxBitScore = BitScore(I)
            NumEqualMatch = 1
            bNot_I = True
          ElseIf MaxBitScore = BitScore(I) Then
            NumEqualMatch = NumEqualMatch + 1
          Else
            bNot_I = True
          End If
        Else 'First of another gene (family)
          EndInd = I - 1
          If StartInd = EndInd Then 'the read matching only this one gene
            dictItem = dictGE(sQueryName(EndInd))
            dictItem.N_U = dictItem.N_U + NumMatch(EndInd)
            dictGE(sQueryName(EndInd)) = dictItem
          Else 'mult-member gene family
            If bNot_I Then 'For two-gene family, this also implies NumEqualMatch = 1
              For J = StartInd To EndInd
                dictItem = dictGE(sQueryName(J))
                For k = StartInd To EndInd
                  If k <> J Then
                    If InStr(dictItem.OtherFamMember, sQueryName(k)) = 0 Then
                      dictItem.OtherFamMember = dictItem.OtherFamMember & "," & sQueryName(k)
                    End If
                  End If
                Next
                If BitScore(J) = MaxBitScore Then
                  dictItem.N_DH = dictItem.N_DH + NumMatch(J) / NumEqualMatch
                End If
                dictGE(sQueryName(J)) = dictItem
              Next
            Else 'All paralogous genes match the read equally well
              For J = StartInd To EndInd
                dictItem = dictGE(sQueryName(J))
                dictItem.N_I = dictItem.N_I + NumMatch(J)
                dictItem.N_I_prod = dictItem.N_I_prod + NumEqualMatch * NumMatch(J)
                dictGE(sQueryName(J)) = dictItem
              Next
            End If
          End If
          StartInd = I
          MaxBitScore = BitScore(I)
          NumEqualMatch = 1
          bNot_I = False
        End If
        ProgressBar1.Value = I
      Next
    Else
      For I = 1 To UppInd
        If sTargetName(I) = sTargetName(I - 1) Then 'Same gene family
          If MaxBitScore < BitScore(I) Then
            MaxBitScore = BitScore(I)
            NumEqualMatch = 1
            bNot_I = True
          ElseIf MaxBitScore = BitScore(I) Then
            NumEqualMatch = NumEqualMatch + 1
          Else
            bNot_I = True
          End If
        Else 'First of another gene (family)
          EndInd = I - 1
          If StartInd = EndInd Then 'the read matching only this one gene
            dictItem = dictGE(sQueryName(EndInd))
            dictItem.N_U = dictItem.N_U + 1
            dictGE(sQueryName(EndInd)) = dictItem
          Else 'mult-member gene family
            If bNot_I Then
              For J = StartInd To EndInd
                dictItem = dictGE(sQueryName(J))
                For k = StartInd To EndInd
                  If k <> J Then
                    If InStr(dictItem.OtherFamMember, sQueryName(k)) = 0 Then
                      dictItem.OtherFamMember = dictItem.OtherFamMember & "," & sQueryName(k)
                    End If
                  End If
                Next
                If BitScore(J) = MaxBitScore Then
                  dictItem.N_DH = dictItem.N_DH + 1 / NumEqualMatch
                  dictGE(sQueryName(J)) = dictItem
                End If
              Next
            Else 'All paralogous genes match the read equally well
              For J = StartInd To EndInd
                dictItem = dictGE(sQueryName(J))
                dictItem.N_I = dictItem.N_I + 1
                dictItem.N_I_prod = dictItem.N_I_prod + NumEqualMatch
                dictGE(sQueryName(J)) = dictItem
              Next
            End If
          End If
          StartInd = I
          MaxBitScore = BitScore(I)
          NumEqualMatch = 1
          bNot_I = False
        End If
        ProgressBar1.Value = I
      Next
    End If

    Erase sTargetName

    'Get total matched reads
    Dim Count() As Double, CountPerKb() As Double, FPKM As Double, SeqLen() As Integer
    Dim MaxNameLen As Integer = 10
    Dim MeanGeneFamilySize As Double
    Dim dTmp As Double
    Dim SumOther_DH As Double
    Dim N_TMR As Double = 0 'Total number of matched reads
    Dim Member() As String
    ReDim sQueryName(dictGE.Count - 1)
    ReDim Count(dictGE.Count - 1), CountPerKb(dictGE.Count - 1), SeqLen(dictGE.Count - 1)
    I = 0
    ProgressBar1.Maximum = dictGE.Count
    For Each ValuePair In dictGE
      If ValuePair.Value.N_I > 0 Then
        MeanGeneFamilySize = ValuePair.Value.N_I_prod / ValuePair.Value.N_I
        If ValuePair.Value.OtherFamMember = "" Then
          dTmp = 1 / MeanGeneFamilySize
        Else
          Member = Split(Mid(ValuePair.Value.OtherFamMember, 2), ",")
          SumOther_DH = 0
          For J = 0 To UBound(Member)
            SumOther_DH = SumOther_DH + dictGE(Member(J)).N_DH
          Next
          dTmp = (ValuePair.Value.N_DH + 1) / (ValuePair.Value.N_DH + SumOther_DH + MeanGeneFamilySize) 'Proportion of shared reads assigned to this gene
        End If
        Count(I) = ValuePair.Value.N_U + ValuePair.Value.N_DH + ValuePair.Value.N_I * dTmp
      Else
        Count(I) = ValuePair.Value.N_U + ValuePair.Value.N_DH
      End If
      SeqLen(I) = ValuePair.Value.SeqLen
      If Count(I) > 0 Then
        CountPerKb(I) = 1000 * Count(I) / SeqLen(I)
        N_TMR = N_TMR + Count(I)
      End If
      sQueryName(I) = ValuePair.Key
      If MaxNameLen < sQueryName(I).Length Then
        MaxNameLen = sQueryName(I).Length
      End If
      ProgressBar1.Value = I
      I = I + 1
    Next

    ProgressBar1.Value = 0
    dictGE.Clear()
    dictGE = Nothing

    MaxNameLen = MaxNameLen + 1
    dTmp = 1000000 / N_TMR
    'produce output
    sb.Append("Gene".PadRight(MaxNameLen) & "  SeqLen       Count    Count/Kb        FPKM" & vbCrLf)
    ProgressBar1.Maximum = iNumQuery
    For I = 0 To iNumQuery - 1
      FPKM = CountPerKb(I) * dTmp
      sb.Append(sQueryName(I).PadRight(MaxNameLen) & SeqLen(I).ToString.PadLeft(8) & FormatNumber(Count(I), 3, , , TriState.False).PadLeft(12) & FormatNumber(CountPerKb(I), 3, , , TriState.False).PadLeft(12) & FormatNumber(FPKM, 3, , , TriState.False).PadLeft(12) & vbCrLf)
      ProgressBar1.Value = I
    Next
    File.WriteAllText(sOutFileGE, sb.ToString)
    sb.Clear()
    sb = Nothing
    ProgressBar1.Value = 0
    'Kill(sBlastnOutFile)
    Return True
  End Function

End Module
