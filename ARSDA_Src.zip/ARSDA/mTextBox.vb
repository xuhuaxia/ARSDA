﻿Module mTextBox
  'Used for both TextBox and RichTextBox
  Sub Text2Array(ByVal txtIn As Object, ByRef sArray() As String, ByRef lNumLine As Integer, ByRef LineLen() As Integer)
    Dim I As Integer
    sArray = txtIn.Lines
    lNumLine = UBound(sArray) + 1
    ReDim LineLen(lNumLine - 1)
    For I = 0 To lNumLine - 1
      LineLen(I) = sArray(I).Length
    Next
  End Sub
End Module
