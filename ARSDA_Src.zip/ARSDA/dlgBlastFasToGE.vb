﻿Imports System.Windows.Forms
Imports System.IO

Public Class dlgBlastFasToGE
  Private mDone As Boolean, mBlastDB As String, mFasFile As String, mOutFileGE As String, mBlastDbDir As String
  Private mEvalue As Double, mWordLen As Integer, mNumCPU As Integer, mMaxTarget As Integer = 0
  Private mStrand As String 'both, plus, minus
  Private mIsFasP As Boolean, mUngapped As Boolean, mBasicBLAST As Boolean
  Private mNumBlastDB As Integer

  Public Function GetBlastFasGEParam(ByRef sBlastDB As String, ByRef sBlastDbDir As String, ByRef sFasFile As String, ByRef sOutFileGE As String, _
                                      ByRef Evalue As Double, ByRef iWordLen As Integer, ByRef sStrand As String, ByRef bUngapped As Boolean, _
                                      ByRef iMaxTarget As Integer, ByRef iNumCPU As Integer, ByRef bIsFasP As Boolean, _
                                      Optional ByVal bBasicBlast As Boolean = False) As Boolean
    mDone = False
    mBasicBLAST = bBasicBlast
    Me.ShowDialog()
    If mDone Then
      sBlastDB = mBlastDB
      sBlastDbDir = mBlastDbDir
      sFasFile = mFasFile
      sOutFileGE = mOutFileGE
      Evalue = mEvalue
      iWordLen = mWordLen
      sStrand = mStrand
      bUngapped = mUngapped
      iMaxTarget = mMaxTarget
      iNumCPU = mNumCPU
      bIsFasP = mIsFasP
      Return True
    Else
      Return False
    End If
  End Function

  Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
    mBlastDB = txtBlastDB.Text
    If mNumBlastDB > 1 Then 'Multiple BlastDBs used
      Dim Field() As String = Split(mBlastDB, " ")
      Dim I As Integer
      For I = 0 To mNumBlastDB - 1
        If Not File.Exists(Path.Combine(mBlastDbDir, Field(I) & ".nin")) Then
          MsgBox("One of the input BLAST databases: " & Field(I) & ".ini" & ", does not exist.", vbOKOnly)
          txtBlastDB.Focus()
          Exit Sub
        End If
      Next
      mBlastDB = Chr(34) & mBlastDB & Chr(34)
    Else
      If Not File.Exists(Path.Combine(mBlastDbDir, mBlastDB & ".nin")) Then
        MsgBox("The input BLAST database: " & mBlastDB & ", does not exist.", vbOKOnly)
        txtBlastDB.Focus()
        Exit Sub
      End If
    End If
    mFasFile = txtFasFile.Text
    If Not File.Exists(mFasFile) Then
      MsgBox("The input FASTA file " & mFasFile & " does not exist.", vbOKOnly)
      txtFasFile.Focus()
      Exit Sub
    End If

    mOutFileGE = txtOutfile.Text
    If Trim(mOutFileGE) = "" Then
      MsgBox("Please enter name for the output file.", vbOKOnly)
      txtOutfile.Focus()
      Exit Sub
    End If
    If IsNumeric(txtEval.Text) Then
      mEvalue = CDbl(txtEval.Text)
    End If
    If mEvalue <= 0 Then
      MsgBox("E-value should be greater than 0", vbOKOnly)
      txtEval.Focus()
      Exit Sub
    End If
    mStrand = cboStrand.Text
    mUngapped = chkUngapped.Checked
    mNumCPU = udNumCPU.Value
    mWordLen = udWordLen.Value
    mMaxTarget = Val(txtMaxTarget.Text)
    mIsFasP = chkIsFasP.Checked

    mDone = True
    Me.DialogResult = System.Windows.Forms.DialogResult.OK
    Me.Close()
  End Sub

  Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
    Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Close()
  End Sub

  Private Sub btnBrowseFasFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseFasFile.Click
    Dim sFasFile As String = txtFasFile.Text
    Dim sPath = ""
    If File.Exists(sFasFile) Then
      sPath = Path.GetDirectoryName(sFasFile)
    Else
      sPath = sInputDir
    End If
    sFasFile = GetOpenFileName("Open FASTA query file", "fas,fasta,ffn,frn", OpenFileDialog1, sInputDir)
    If File.Exists(sFasFile) Then
      Dim HasSpaceAt As Integer = InStr(sFasFile, " ")
      If HasSpaceAt > 0 Then
        Dim sInfo As String
        sInfo = "This function requires input file/path name to have no space. Your input file:" & CRCR
        sInfo = sInfo & sFasFile & CRCR
        sInfo = sInfo & "has space at position " & HasSpaceAt & CRCR
        sInfo = sInfo & "You are advised to rename the file so that it contains no space in it before running this function." & CRCR
        sInfo = sInfo & "Sorry for this inconvenience."
        Call MsgBox(sInfo, vbInformation)
        Exit Sub
      End If
      txtFasFile.Text = sFasFile
    End If
  End Sub

  Private Sub btnBrowseBLAST_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseBLAST.Click
    Dim dr As DialogResult
    With Me.OpenFileDialog1
      .Title = "Open BLAST DB"
      .Multiselect = True
      .Filter = UCase("nin") & " Files (*." & "nin" & ")|*." & "nin"
      dr = .ShowDialog()
    End With
    If (dr = System.Windows.Forms.DialogResult.OK) Then
      ' Read the files 
      Dim file As String
      Dim sBlastIndFile As String = ""
      mNumBlastDB = OpenFileDialog1.FileNames.Count
      For Each file In OpenFileDialog1.FileNames
        sBlastIndFile = sBlastIndFile & Path.GetFileNameWithoutExtension(file) & " "
      Next
      'XX Check
      mBlastDbDir = Path.GetDirectoryName(OpenFileDialog1.FileNames(0))
      sBlastIndFile = RTrim(sBlastIndFile)
      Dim HasSpaceAt As Integer = InStr(sBlastIndFile, " ")
      If HasSpaceAt > 0 Then
        Dim sInfo As String
        sInfo = "This function requires file/path name to have no space. Your input BLAST database:" & CRCR
        sInfo = sInfo & sBlastIndFile & CRCR
        sInfo = sInfo & "has space at position " & HasSpaceAt & CRCR
        sInfo = sInfo & "You are advised to copy your query file and local BLAST database to a directory with no space in it, e.g., 'C:\Temp', and rename/change file names so they do not contain spaces." & CRCR
        sInfo = sInfo & "Sorry for this inconvenience."
        Call MsgBox(sInfo, vbInformation)
        Exit Sub
      End If
      txtBlastDB.Text = sBlastIndFile
    End If
  End Sub

  Private Sub btnBrowseOutFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseOutFile.Click
    If Directory.Exists(txtOutfile.Text) Then
      txtOutfile.Text = GetSaveFileName("Save to...", "out", SaveFileDialog1, txtOutfile.Text)
    Else
      txtOutfile.Text = GetSaveFileName("Save to...", "out", SaveFileDialog1, sResultDir)
    End If
  End Sub

  Private Sub dlgFastqBlastDbToGE_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    Dim NumCPU As Integer = Environment.ProcessorCount
    If mBasicBLAST Then
      chkIsFasP.Visible = False
      btnHelp2.Visible = False
      udWordLen.Value = 12
      txtEval.Text = "0.001"
      Me.Text = "Local BLAST tool"
    Else
      chkIsFasP.Visible = True
      btnHelp2.Visible = True
      udWordLen.Value = 18
      txtEval.Text = "0.0000000001"
      Me.Text = "(Query FASTA file + BLAST DB) to gene expression"
    End If
    udNumCPU.Maximum = NumCPU
    udNumCPU.Value = (NumCPU + 1) \ 2
    With cboStrand.Items
      .Clear()
      .Add("both")
      .Add("plus")
      .Add("minus")
    End With
    cboStrand.SelectedIndex = 0
  End Sub

  Private Sub btnHelp2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHelp2.Click
    Dim sInfo As String
    sInfo = "FasPlus file has the same format as regular FASTA file, but sequence names are in the format of '>SeqID_Count', e.g., a FASTA file has 200 sequences, but 100 sequences are identical to each other, then these 100 sequences in a FasPlus file would be represented as SeqID_100."
    MsgBox(sInfo, vbInformation, "Help")
  End Sub
End Class
