﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCanvas
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
    Me.mnuFile = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileOpenTreeFile = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuFileSaveTreeFile = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuFilePrint = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuFileExit = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileTest = New System.Windows.Forms.ToolStripMenuItem()
    Me.MenuStrip1.SuspendLayout()
    Me.SuspendLayout()
    '
    'MenuStrip1
    '
    Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFile})
    Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
    Me.MenuStrip1.Name = "MenuStrip1"
    Me.MenuStrip1.Size = New System.Drawing.Size(838, 24)
    Me.MenuStrip1.TabIndex = 0
    Me.MenuStrip1.Text = "MenuStrip1"
    '
    'mnuFile
    '
    Me.mnuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFileOpenTreeFile, Me.ToolStripMenuItem1, Me.mnuFileSaveTreeFile, Me.ToolStripMenuItem2, Me.mnuFileTest, Me.mnuFilePrint, Me.ToolStripMenuItem3, Me.mnuFileExit})
    Me.mnuFile.Name = "mnuFile"
    Me.mnuFile.Size = New System.Drawing.Size(37, 20)
    Me.mnuFile.Text = "File"
    '
    'mnuFileOpenTreeFile
    '
    Me.mnuFileOpenTreeFile.Name = "mnuFileOpenTreeFile"
    Me.mnuFileOpenTreeFile.Size = New System.Drawing.Size(152, 22)
    Me.mnuFileOpenTreeFile.Text = "Open tree file"
    '
    'ToolStripMenuItem1
    '
    Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
    Me.ToolStripMenuItem1.Size = New System.Drawing.Size(149, 6)
    '
    'mnuFileSaveTreeFile
    '
    Me.mnuFileSaveTreeFile.Name = "mnuFileSaveTreeFile"
    Me.mnuFileSaveTreeFile.Size = New System.Drawing.Size(152, 22)
    Me.mnuFileSaveTreeFile.Text = "Save tree file"
    '
    'ToolStripMenuItem2
    '
    Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
    Me.ToolStripMenuItem2.Size = New System.Drawing.Size(149, 6)
    '
    'mnuFilePrint
    '
    Me.mnuFilePrint.Name = "mnuFilePrint"
    Me.mnuFilePrint.Size = New System.Drawing.Size(152, 22)
    Me.mnuFilePrint.Text = "Print"
    '
    'ToolStripMenuItem3
    '
    Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
    Me.ToolStripMenuItem3.Size = New System.Drawing.Size(149, 6)
    '
    'mnuFileExit
    '
    Me.mnuFileExit.Name = "mnuFileExit"
    Me.mnuFileExit.Size = New System.Drawing.Size(152, 22)
    Me.mnuFileExit.Text = "exit"
    '
    'mnuFileTest
    '
    Me.mnuFileTest.Name = "mnuFileTest"
    Me.mnuFileTest.Size = New System.Drawing.Size(152, 22)
    Me.mnuFileTest.Text = "Test"
    '
    'frmCanvas
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(838, 762)
    Me.Controls.Add(Me.MenuStrip1)
    Me.MainMenuStrip = Me.MenuStrip1
    Me.Name = "frmCanvas"
    Me.Text = "frmCanvas"
    Me.MenuStrip1.ResumeLayout(False)
    Me.MenuStrip1.PerformLayout()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
  Friend WithEvents mnuFile As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuFileOpenTreeFile As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents mnuFileSaveTreeFile As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents mnuFilePrint As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents mnuFileExit As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuFileTest As System.Windows.Forms.ToolStripMenuItem
End Class
