﻿Imports System.Xml
Imports System.IO
Module mData

  Function StrArray2DblArray(sIn() As String) As Double()
    Return Array.ConvertAll(sin, New Converter(Of Integer, Double)(AddressOf Double.Parse))

  End Function

  'CType and DirectCast, the latter is faster for converting a string object to a string or a number object to a number, e.g., 
  '  Dim A as object = 0.223
  '  Dim NewA As Double = DirectCast(A, Double)
End Module
