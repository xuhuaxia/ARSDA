﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class dlgFasToBlastDB
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
    Me.OK_Button = New System.Windows.Forms.Button()
    Me.Cancel_Button = New System.Windows.Forms.Button()
    Me.btnBrowse = New System.Windows.Forms.Button()
    Me.rbNuc = New System.Windows.Forms.RadioButton()
    Me.rbAA = New System.Windows.Forms.RadioButton()
    Me.txtInFasFile = New System.Windows.Forms.TextBox()
    Me.lblInFasFile = New System.Windows.Forms.Label()
    Me.frSeqType = New System.Windows.Forms.GroupBox()
    Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
    Me.txtOutBlastDB = New System.Windows.Forms.TextBox()
    Me.lblOutBlastDBName = New System.Windows.Forms.Label()
    Me.btnBrowseOutDir = New System.Windows.Forms.Button()
    Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
    Me.PictureBox1 = New System.Windows.Forms.PictureBox()
    Me.lblOutputDir = New System.Windows.Forms.Label()
    Me.txtOutputDir = New System.Windows.Forms.TextBox()
    Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
    Me.chkMultFile = New System.Windows.Forms.CheckBox()
    Me.TableLayoutPanel1.SuspendLayout()
    Me.frSeqType.SuspendLayout()
    CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.SuspendLayout()
    '
    'TableLayoutPanel1
    '
    Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.TableLayoutPanel1.ColumnCount = 2
    Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.Controls.Add(Me.OK_Button, 0, 0)
    Me.TableLayoutPanel1.Controls.Add(Me.Cancel_Button, 1, 0)
    Me.TableLayoutPanel1.Location = New System.Drawing.Point(571, 566)
    Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
    Me.TableLayoutPanel1.RowCount = 1
    Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.Size = New System.Drawing.Size(146, 29)
    Me.TableLayoutPanel1.TabIndex = 0
    '
    'OK_Button
    '
    Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
    Me.OK_Button.Location = New System.Drawing.Point(3, 3)
    Me.OK_Button.Name = "OK_Button"
    Me.OK_Button.Size = New System.Drawing.Size(67, 23)
    Me.OK_Button.TabIndex = 0
    Me.OK_Button.Text = "OK"
    '
    'Cancel_Button
    '
    Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
    Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Cancel_Button.Location = New System.Drawing.Point(76, 3)
    Me.Cancel_Button.Name = "Cancel_Button"
    Me.Cancel_Button.Size = New System.Drawing.Size(67, 23)
    Me.Cancel_Button.TabIndex = 1
    Me.Cancel_Button.Text = "Cancel"
    '
    'btnBrowse
    '
    Me.btnBrowse.Location = New System.Drawing.Point(633, 405)
    Me.btnBrowse.Name = "btnBrowse"
    Me.btnBrowse.Size = New System.Drawing.Size(84, 23)
    Me.btnBrowse.TabIndex = 2
    Me.btnBrowse.Text = "Browse"
    Me.btnBrowse.UseVisualStyleBackColor = True
    '
    'rbNuc
    '
    Me.rbNuc.AutoSize = True
    Me.rbNuc.Checked = True
    Me.rbNuc.Location = New System.Drawing.Point(8, 19)
    Me.rbNuc.Name = "rbNuc"
    Me.rbNuc.Size = New System.Drawing.Size(76, 17)
    Me.rbNuc.TabIndex = 4
    Me.rbNuc.TabStop = True
    Me.rbNuc.Text = "Nucleotide"
    Me.rbNuc.UseVisualStyleBackColor = True
    '
    'rbAA
    '
    Me.rbAA.AutoSize = True
    Me.rbAA.Location = New System.Drawing.Point(103, 19)
    Me.rbAA.Name = "rbAA"
    Me.rbAA.Size = New System.Drawing.Size(58, 17)
    Me.rbAA.TabIndex = 5
    Me.rbAA.Text = "Protein"
    Me.rbAA.UseVisualStyleBackColor = True
    '
    'txtInFasFile
    '
    Me.txtInFasFile.Location = New System.Drawing.Point(15, 408)
    Me.txtInFasFile.Name = "txtInFasFile"
    Me.txtInFasFile.Size = New System.Drawing.Size(612, 20)
    Me.txtInFasFile.TabIndex = 6
    '
    'lblInFasFile
    '
    Me.lblInFasFile.AutoSize = True
    Me.lblInFasFile.Location = New System.Drawing.Point(12, 392)
    Me.lblInFasFile.Name = "lblInFasFile"
    Me.lblInFasFile.Size = New System.Drawing.Size(289, 13)
    Me.lblInFasFile.TabIndex = 7
    Me.lblInFasFile.Text = "Input FASTA file (which should be unaligned, with no indels)"
    '
    'frSeqType
    '
    Me.frSeqType.Controls.Add(Me.rbNuc)
    Me.frSeqType.Controls.Add(Me.rbAA)
    Me.frSeqType.Location = New System.Drawing.Point(12, 547)
    Me.frSeqType.Name = "frSeqType"
    Me.frSeqType.Size = New System.Drawing.Size(176, 51)
    Me.frSeqType.TabIndex = 8
    Me.frSeqType.TabStop = False
    Me.frSeqType.Text = "Sequence type"
    '
    'OpenFileDialog1
    '
    Me.OpenFileDialog1.FileName = "OpenFileDialog1"
    '
    'txtOutBlastDB
    '
    Me.txtOutBlastDB.Location = New System.Drawing.Point(15, 458)
    Me.txtOutBlastDB.Name = "txtOutBlastDB"
    Me.txtOutBlastDB.Size = New System.Drawing.Size(612, 20)
    Me.txtOutBlastDB.TabIndex = 20
    '
    'lblOutBlastDBName
    '
    Me.lblOutBlastDBName.AutoSize = True
    Me.lblOutBlastDBName.Location = New System.Drawing.Point(12, 442)
    Me.lblOutBlastDBName.Name = "lblOutBlastDBName"
    Me.lblOutBlastDBName.Size = New System.Drawing.Size(115, 13)
    Me.lblOutBlastDBName.TabIndex = 19
    Me.lblOutBlastDBName.Text = "Output database name"
    '
    'btnBrowseOutDir
    '
    Me.btnBrowseOutDir.Location = New System.Drawing.Point(633, 508)
    Me.btnBrowseOutDir.Name = "btnBrowseOutDir"
    Me.btnBrowseOutDir.Size = New System.Drawing.Size(84, 23)
    Me.btnBrowseOutDir.TabIndex = 18
    Me.btnBrowseOutDir.Text = "Browse"
    Me.btnBrowseOutDir.UseVisualStyleBackColor = True
    '
    'PictureBox1
    '
    Me.PictureBox1.Image = Global.ARSDA.My.Resources.Resources.Fas2BlastDB
    Me.PictureBox1.Location = New System.Drawing.Point(12, 12)
    Me.PictureBox1.Name = "PictureBox1"
    Me.PictureBox1.Size = New System.Drawing.Size(705, 367)
    Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
    Me.PictureBox1.TabIndex = 1
    Me.PictureBox1.TabStop = False
    '
    'lblOutputDir
    '
    Me.lblOutputDir.AutoSize = True
    Me.lblOutputDir.Location = New System.Drawing.Point(12, 495)
    Me.lblOutputDir.Name = "lblOutputDir"
    Me.lblOutputDir.Size = New System.Drawing.Size(204, 13)
    Me.lblOutputDir.TabIndex = 21
    Me.lblOutputDir.Text = "Directory to save output BLAST database"
    '
    'txtOutputDir
    '
    Me.txtOutputDir.Location = New System.Drawing.Point(15, 510)
    Me.txtOutputDir.Name = "txtOutputDir"
    Me.txtOutputDir.Size = New System.Drawing.Size(612, 20)
    Me.txtOutputDir.TabIndex = 22
    '
    'chkMultFile
    '
    Me.chkMultFile.AutoSize = True
    Me.chkMultFile.Location = New System.Drawing.Point(208, 566)
    Me.chkMultFile.Name = "chkMultFile"
    Me.chkMultFile.Size = New System.Drawing.Size(83, 17)
    Me.chkMultFile.TabIndex = 23
    Me.chkMultFile.Text = "Multiple files"
    Me.chkMultFile.UseVisualStyleBackColor = True
    '
    'dlgFasToBlastDB
    '
    Me.AcceptButton = Me.OK_Button
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.CancelButton = Me.Cancel_Button
    Me.ClientSize = New System.Drawing.Size(729, 607)
    Me.Controls.Add(Me.chkMultFile)
    Me.Controls.Add(Me.txtOutputDir)
    Me.Controls.Add(Me.lblOutputDir)
    Me.Controls.Add(Me.txtOutBlastDB)
    Me.Controls.Add(Me.lblOutBlastDBName)
    Me.Controls.Add(Me.btnBrowseOutDir)
    Me.Controls.Add(Me.frSeqType)
    Me.Controls.Add(Me.lblInFasFile)
    Me.Controls.Add(Me.txtInFasFile)
    Me.Controls.Add(Me.btnBrowse)
    Me.Controls.Add(Me.PictureBox1)
    Me.Controls.Add(Me.TableLayoutPanel1)
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "dlgFasToBlastDB"
    Me.ShowInTaskbar = False
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
    Me.Text = "FASTA file to BLAST database"
    Me.TableLayoutPanel1.ResumeLayout(False)
    Me.frSeqType.ResumeLayout(False)
    Me.frSeqType.PerformLayout()
    CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
  Friend WithEvents OK_Button As System.Windows.Forms.Button
  Friend WithEvents Cancel_Button As System.Windows.Forms.Button
  Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
  Friend WithEvents btnBrowse As System.Windows.Forms.Button
  Friend WithEvents rbNuc As System.Windows.Forms.RadioButton
  Friend WithEvents rbAA As System.Windows.Forms.RadioButton
  Friend WithEvents txtInFasFile As System.Windows.Forms.TextBox
  Friend WithEvents lblInFasFile As System.Windows.Forms.Label
  Friend WithEvents frSeqType As System.Windows.Forms.GroupBox
  Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
  Friend WithEvents txtOutBlastDB As System.Windows.Forms.TextBox
  Friend WithEvents lblOutBlastDBName As System.Windows.Forms.Label
  Friend WithEvents btnBrowseOutDir As System.Windows.Forms.Button
  Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
  Friend WithEvents lblOutputDir As System.Windows.Forms.Label
  Friend WithEvents txtOutputDir As System.Windows.Forms.TextBox
  Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
  Friend WithEvents chkMultFile As System.Windows.Forms.CheckBox

End Class
