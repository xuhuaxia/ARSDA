﻿Module mInternet


  'Not checked
  Public Sub WGetLogin(ByVal sFileURL As String, ByVal sLoginURL As String, ByVal sEmail As String, ByVal sPassword As String, ByVal sLocalName As String)
    Dim client As New Net.WebClient
    Dim loginInfo As New Specialized.NameValueCollection
    loginInfo.Add("email", sEmail)
    loginInfo.Add("password", sPassword)
    client.UploadValues(sLoginURL, "POST", loginInfo)
    client.DownloadFile(sFileURL, sLocalName)
  End Sub
End Module
