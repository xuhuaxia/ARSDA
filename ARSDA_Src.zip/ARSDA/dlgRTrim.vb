﻿Imports System.Windows.Forms
Imports System.IO

Public Class dlgRTrim
  Private mDone As Boolean, mInfile As String, mOutFile As String, mLimitLen As Integer, mRidN As Boolean 'if LimitLen =50, then keep the left 50 nt. If mRidN=True, exclude reads with ambiguous nuc N
  Public Function RTrimParam(ByRef sInFile As String, ByRef sOutFile As String, ByRef LimitLen As Integer, ByRef bRidN As Boolean) As Boolean
    mDone = False
    Me.ShowDialog()
    If mDone Then
      sInFile = mInfile
      sOutFile = mOutFile
      LimitLen = mLimitLen
      bRidN = mRidN
      Return True
    Else
      Return False
    End If
  End Function

  Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
    If File.Exists(txtInFile.Text) Then
      mInfile = txtInFile.Text
    End If

    mOutFile = txtOutFasFile.Text
    If File.Exists(mOutFile) Then
      Kill(mOutFile)
    End If
    mLimitLen = Val(txtLimitLen.Text)
    If mLimitLen < 30 Then
      Call MsgBox("The minimum length is 30, but you entered " & mLimitLen)
      Exit Sub
    End If
    mRidN = chkRidN.Checked
    mDone = True
    Me.DialogResult = System.Windows.Forms.DialogResult.OK
    Me.Close()
  End Sub

  Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
    Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Close()
  End Sub

  Private Sub btnBrowseFastq_Click(sender As Object, e As EventArgs) Handles btnBrowseFastq.Click
    txtInFile.Text = GetOpenFileName("Open FASTA file", "fas,fasta,fasP", OpenFileDialog1, sInputDir)
  End Sub

  Private Sub BrowseFasta_Click(sender As Object, e As EventArgs) Handles BrowseFasta.Click
    txtOutFasFile.Text = GetSaveFileName("Save to...", "fas,fasP", SaveFileDialog1, sNewDataDir)
  End Sub
End Class
