﻿Imports System.Xml
Imports System.Text

Module mYouTubeXML
  'genre:
  '1 – Action & Adventure
  '2 – Animation & Cartoons
  '3 – Classic TV
  '4 – Comedy
  '5 – Drama
  '6 – Home & Garden
  '7 – News
  '8 – Reality & Game Shows
  '9 – Science & Tech
  '10 – Science Fiction
  '11 – Soaps
  '       12 children
  '13 – Sports
  '14 – Travel
  '       15 math tutor
  '16 – Entertainment
  '17 – Documentary
  '       18 physics tutor
  '       19 chemistry tutor
  '20 – Nature
  '21 – Beauty & Fashion
  '       22 biology
  '23 – Food
  '24 – Gaming
  '25 – Health & Fitness
  '26 – Learning & Education
  '27 – Foreign Language  '
  'movie-genre:
  '1 – Action & Adventure
  '2 – Animation & Cartoons
  '3 – Classics
  '4 – Comedy
  '5 – Crime
  '6 – Drama
  '7 – Documentary & Biography
  '8 – Family
  '9 – Foreign
  '10 – Horror
  '11 – Mystery & Suspense
  '12 – Romance
  '13 – Science Fiction
  '15 – Sports
  '18 – Indian Cinema
  '19 – Nigerian Cinema
  'sSearchKeyWords is a string with items separated by comma: e.g., "Qin moon+HD+-adult"
  '                        /feeds/api/videos/-/%7Bhttp%3A%2F%2Fgdata.youtube.com%2Fschemas%2F2007%2Fcategories.cat%7DComedy/%7Bhttp%3A%2F%2Fgdata.youtube.com%2Fschemas%2F2007%2Fkeywords.cat%7DCadillac/%7Bhttp%3A%2F%2Fgdata.youtube.com%2Fschemas%2F2007%2Fkeywords.cat%7DDodge%20Caravan/%7Bhttp%3A%2F%2Fgdata.youtube.com%2Fschemas%2F2007%2Fkeywords.cat%7DMDX
  'http://www.youtube.com/results?search_query=Jeremy+Xia
  Public Function GetYouTubeURI(ByVal sSearchKeyWords As String, ByVal bLong As Boolean, _
        Optional ByVal bNoAdultCont As Boolean = True, _
        Optional ByVal bHD As Boolean = True, _
        Optional ByVal MaxResult As Integer = 35, Optional ByVal En1Ch2Fr3All4 As Short = 4) As String

    Dim builder As New StringBuilder
    builder.Append("https://gdata.youtube.com/feeds/api/videos?q=")

    builder.Append(sSearchKeyWords)
    If bNoAdultCont Then
      builder.Append("+-adult")
    End If
    If bHD Then
      builder.Append("&hd=true")
    End If
    'builder.Append("&movie-genre=" & MovieGenre.ToString)
    If bLong Then
      builder.Append("&duration=long")
    End If
    Select Case En1Ch2Fr3All4
      Case 1
        builder.Append("&lr=" & "en")
      Case 2
        builder.Append("&lr=" & "zh")
      Case 3
        builder.Append("&lr=" & "fr")
      Case Else
    End Select
    builder.Append("&max-results=" & MaxResult.ToString)
    builder.Append("&prettyprint=true")
    builder.Append("&v=2")
    Return builder.ToString
  End Function


  Public Sub ParseYouTubeXML(ByVal xmlURI As String, ByVal File1Text2 As Integer, ByVal sTag As String, ByRef NumNode As Integer, _
             ByRef sTitle() As String, ByRef sDuration() As String, ByRef imgURI() As String, ByRef sUploadTime() As String, _
             ByRef sVideoURI() As String, Optional ByVal En1Ch2Fr3All4 As Integer = 1)
    Dim I As Integer = 0, CC As Integer = 0
    Dim xmldom As New XmlDocument
    Dim nodes As XmlNodeList
    Dim node1 As XmlNode, node2 As XmlNode, node3 As XmlNode
    Dim Attrib As XmlAttribute
    If File1Text2 = 1 Then
      xmldom.Load(xmlURI)
    Else
      xmldom.LoadXml(xmlURI)
    End If
    nodes = xmldom.GetElementsByTagName(sTag)
    NumNode = nodes.Count()
    ReDim sTitle(NumNode - 1), sDuration(NumNode - 1), imgURI(NumNode - 1), sUploadTime(NumNode - 1), sVideoURI(NumNode - 1)
    For Each node1 In nodes
      For Each node2 In node1.ChildNodes
        If node2.Name = "media:group" Then
          For Each node3 In node2.ChildNodes
            Select Case node3.Name
              Case "media:content" '<media:content url='https://www.youtube.com/v/jmAm6xDB6uE?version=3&amp;f=videos&amp;app=youtube_gdata' type='application/x-shockwave-flash' medium='video' isDefault='true' expression='full' duration='3078' yt:format='5'/>
                If sVideoURI(I) = "" Then
                  For Each Attrib In node3.Attributes
                    If Attrib.Name = "url" Then
                      sVideoURI(I) = Attrib.Value
                      Exit For
                    End If
                  Next
                End If
              Case "media:player" '<media:player url='https://www.youtube.com/watch?v=numdu7xErrA&amp;feature=youtube_gdata_player'/>
                If sVideoURI(I) = "" Then
                  For Each Attrib In node3.Attributes
                    If Attrib.Name = "url" Then
                      sVideoURI(I) = Attrib.Value
                      Exit For
                    End If
                  Next
                End If
              Case "media:thumbnail"
                If imgURI(I) = "" Then
                  For Each Attrib In node3.Attributes
                    If Attrib.Name = "url" Then
                      imgURI(I) = Attrib.Value
                      Exit For
                    End If
                  Next
                End If
              Case "media:title"
                sTitle(I) = node3.InnerText
              Case "yt:duration"
                sDuration(I) = node3.Attributes(0).Value
              Case "yt:uploaded"
                sUploadTime(I) = node3.InnerText
                sUploadTime(I) = Left(sUploadTime(I), 10)
            End Select
          Next
        End If
      Next
      I += 1
    Next
    For I = 0 To NumNode - 1
      If Left(sVideoURI(I), 4) = "http" Then
        sVideoURI(CC) = sVideoURI(I)
        sTitle(CC) = sTitle(I)
        sDuration(CC) = sDuration(I)
        imgURI(CC) = imgURI(I)
        sUploadTime(CC) = sUploadTime(I)
        CC += 1
      End If
    Next
    NumNode = CC
    'detecting language
    If En1Ch2Fr3All4 < 4 Then
      'English: 33-126
      'French-unique: 128-252
      'CJK: 4E00-9FFF: 19968-40959
      'System.Convert.ToInt32("台"c)
      'System.Convert.ToInt32("A"c)
      Dim ChArray() As Char
      Dim iNum As Integer, J As Integer
      Dim NumEn As Integer, NumFr As Integer, NumCJK As Integer
      CC = 0
      For I = 0 To NumNode - 1
        ChArray = sTitle(I).ToCharArray()
        NumEn = 0
        NumFr = 0
        NumCJK = 0
        For J = 0 To ChArray.Length - 1
          iNum = Convert.ToInt32(ChArray(J))
          Select Case iNum
            Case 33 To 126
              NumEn += 1
            Case 128 To 252
              NumFr += 1
            Case 19968 To 40959
              NumCJK += 1
          End Select
        Next
        If En1Ch2Fr3All4 = 1 Then
          If NumFr = 0 And NumCJK = 0 Then
            sVideoURI(CC) = sVideoURI(I)
            sTitle(CC) = sTitle(I)
            sDuration(CC) = sDuration(I)
            imgURI(CC) = imgURI(I)
            sUploadTime(CC) = sUploadTime(I)
            CC += 1
          End If
        ElseIf En1Ch2Fr3All4 = 2 Then
          If NumCJK > 0 Then
            sVideoURI(CC) = sVideoURI(I)
            sTitle(CC) = sTitle(I)
            sDuration(CC) = sDuration(I)
            imgURI(CC) = imgURI(I)
            sUploadTime(CC) = sUploadTime(I)
            CC += 1
          End If
        ElseIf En1Ch2Fr3All4 = 3 Then
          If NumFr > 0 Then
            sVideoURI(CC) = sVideoURI(I)
            sTitle(CC) = sTitle(I)
            sDuration(CC) = sDuration(I)
            imgURI(CC) = imgURI(I)
            sUploadTime(CC) = sUploadTime(I)
            CC += 1
          End If
        End If
      Next
    End If
    NumNode = CC
    ReDim Preserve sVideoURI(NumNode - 1), sTitle(NumNode - 1), sDuration(NumNode - 1), imgURI(NumNode - 1), sUploadTime(NumNode - 1)
  End Sub

End Module
