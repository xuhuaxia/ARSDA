﻿Imports System.Text
Module mStrUtilNuc
  'If sequence is fully resolved, then should recode ACGT to 0123 and simply get Nuc(0)*64+Nuc(1)*16+Nuc(2)*4+Nuc(3) instead of all these Select Case statements. Need to test which is faster.
  'The input sequence is already patched with trailing 'A' to have length = 4*N

  Function PackNuc(ByVal NucByte() As Byte, ByVal iSeqLen As Integer, ByRef OutByte() As Byte) As Boolean
    Dim I As Integer, CC As Integer
    ReDim OutByte(iSeqLen \ 4 - 1)
    For I = 0 To iSeqLen - 4 Step 4
      Select Case NucByte(I)
        Case 65
          Select Case NucByte(I + 1)
            Case 65
              Select Case NucByte(I + 2)
                Case 65
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 0
                    Case 67
                      OutByte(CC) = 1
                    Case 71
                      OutByte(CC) = 2
                    Case 84
                      OutByte(CC) = 3
                    Case Else
                      Return False
                  End Select
                Case 67
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 4
                    Case 67
                      OutByte(CC) = 5
                    Case 71
                      OutByte(CC) = 6
                    Case 84
                      OutByte(CC) = 7
                    Case Else
                      Return False
                  End Select
                Case 71
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 8
                    Case 67
                      OutByte(CC) = 9
                    Case 71
                      OutByte(CC) = 10
                    Case 84
                      OutByte(CC) = 11
                    Case Else
                      Return False
                  End Select
                Case 84
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 12
                    Case 67
                      OutByte(CC) = 13
                    Case 71
                      OutByte(CC) = 14
                    Case 84
                      OutByte(CC) = 15
                    Case Else
                      Return False
                  End Select
                Case Else
                  Return False
              End Select
            Case 67
              Select Case NucByte(I + 2)
                Case 65
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 16
                    Case 67
                      OutByte(CC) = 17
                    Case 71
                      OutByte(CC) = 18
                    Case 84
                      OutByte(CC) = 19
                    Case Else
                      Return False
                  End Select
                Case 67
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 20
                    Case 67
                      OutByte(CC) = 21
                    Case 71
                      OutByte(CC) = 22
                    Case 84
                      OutByte(CC) = 23
                    Case Else
                      Return False
                  End Select
                Case 71
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 24
                    Case 67
                      OutByte(CC) = 25
                    Case 71
                      OutByte(CC) = 26
                    Case 84
                      OutByte(CC) = 27
                    Case Else
                      Return False
                  End Select
                Case 84
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 28
                    Case 67
                      OutByte(CC) = 29
                    Case 71
                      OutByte(CC) = 30
                    Case 84
                      OutByte(CC) = 31
                    Case Else
                      Return False
                  End Select
                Case Else
                  Return False
              End Select
            Case 71
              Select Case NucByte(I + 2)
                Case 65
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 32
                    Case 67
                      OutByte(CC) = 33
                    Case 71
                      OutByte(CC) = 34
                    Case 84
                      OutByte(CC) = 35
                    Case Else
                      Return False
                  End Select
                Case 67
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 36
                    Case 67
                      OutByte(CC) = 37
                    Case 71
                      OutByte(CC) = 38
                    Case 84
                      OutByte(CC) = 39
                    Case Else
                      Return False
                  End Select
                Case 71
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 40
                    Case 67
                      OutByte(CC) = 41
                    Case 71
                      OutByte(CC) = 42
                    Case 84
                      OutByte(CC) = 43
                    Case Else
                      Return False
                  End Select
                Case 84
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 44
                    Case 67
                      OutByte(CC) = 45
                    Case 71
                      OutByte(CC) = 46
                    Case 84
                      OutByte(CC) = 47
                    Case Else
                      Return False
                  End Select
                Case Else
                  Return False
              End Select
            Case 84
              Select Case NucByte(I + 2)
                Case 65
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 48
                    Case 67
                      OutByte(CC) = 49
                    Case 71
                      OutByte(CC) = 50
                    Case 84
                      OutByte(CC) = 51
                    Case Else
                      Return False
                  End Select
                Case 67
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 52
                    Case 67
                      OutByte(CC) = 53
                    Case 71
                      OutByte(CC) = 54
                    Case 84
                      OutByte(CC) = 55
                    Case Else
                      Return False
                  End Select
                Case 71
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 56
                    Case 67
                      OutByte(CC) = 57
                    Case 71
                      OutByte(CC) = 58
                    Case 84
                      OutByte(CC) = 59
                    Case Else
                      Return False
                  End Select
                Case 84
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 60
                    Case 67
                      OutByte(CC) = 61
                    Case 71
                      OutByte(CC) = 62
                    Case 84
                      OutByte(CC) = 63
                    Case Else
                      Return False
                  End Select
                Case Else
                  Return False
              End Select
            Case Else
              Return False
          End Select
        Case 67
          Select Case NucByte(I + 1)
            Case 65
              Select Case NucByte(I + 2)
                Case 65
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 64
                    Case 67
                      OutByte(CC) = 65
                    Case 71
                      OutByte(CC) = 66
                    Case 84
                      OutByte(CC) = 67
                    Case Else
                      Return False
                  End Select
                Case 67
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 68
                    Case 67
                      OutByte(CC) = 69
                    Case 71
                      OutByte(CC) = 70
                    Case 84
                      OutByte(CC) = 71
                    Case Else
                      Return False
                  End Select
                Case 71
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 72
                    Case 67
                      OutByte(CC) = 73
                    Case 71
                      OutByte(CC) = 74
                    Case 84
                      OutByte(CC) = 75
                    Case Else
                      Return False
                  End Select
                Case 84
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 76
                    Case 67
                      OutByte(CC) = 77
                    Case 71
                      OutByte(CC) = 78
                    Case 84
                      OutByte(CC) = 79
                    Case Else
                      Return False
                  End Select
                Case Else
                  Return False
              End Select
            Case 67
              Select Case NucByte(I + 2)
                Case 65
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 80
                    Case 67
                      OutByte(CC) = 81
                    Case 71
                      OutByte(CC) = 82
                    Case 84
                      OutByte(CC) = 83
                    Case Else
                      Return False
                  End Select
                Case 67
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 84
                    Case 67
                      OutByte(CC) = 85
                    Case 71
                      OutByte(CC) = 86
                    Case 84
                      OutByte(CC) = 87
                    Case Else
                      Return False
                  End Select
                Case 71
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 88
                    Case 67
                      OutByte(CC) = 89
                    Case 71
                      OutByte(CC) = 90
                    Case 84
                      OutByte(CC) = 91
                    Case Else
                      Return False
                  End Select
                Case 84
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 92
                    Case 67
                      OutByte(CC) = 93
                    Case 71
                      OutByte(CC) = 94
                    Case 84
                      OutByte(CC) = 95
                    Case Else
                      Return False
                  End Select
                Case Else
                  Return False
              End Select
            Case 71
              Select Case NucByte(I + 2)
                Case 65
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 96
                    Case 67
                      OutByte(CC) = 97
                    Case 71
                      OutByte(CC) = 98
                    Case 84
                      OutByte(CC) = 99
                    Case Else
                      Return False
                  End Select
                Case 67
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 100
                    Case 67
                      OutByte(CC) = 101
                    Case 71
                      OutByte(CC) = 102
                    Case 84
                      OutByte(CC) = 103
                    Case Else
                      Return False
                  End Select
                Case 71
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 104
                    Case 67
                      OutByte(CC) = 105
                    Case 71
                      OutByte(CC) = 106
                    Case 84
                      OutByte(CC) = 107
                    Case Else
                      Return False
                  End Select
                Case 84
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 108
                    Case 67
                      OutByte(CC) = 109
                    Case 71
                      OutByte(CC) = 110
                    Case 84
                      OutByte(CC) = 111
                    Case Else
                      Return False
                  End Select
                Case Else
                  Return False
              End Select
            Case 84
              Select Case NucByte(I + 2)
                Case 65
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 112
                    Case 67
                      OutByte(CC) = 113
                    Case 71
                      OutByte(CC) = 114
                    Case 84
                      OutByte(CC) = 115
                    Case Else
                      Return False
                  End Select
                Case 67
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 116
                    Case 67
                      OutByte(CC) = 117
                    Case 71
                      OutByte(CC) = 118
                    Case 84
                      OutByte(CC) = 119
                    Case Else
                      Return False
                  End Select
                Case 71
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 120
                    Case 67
                      OutByte(CC) = 121
                    Case 71
                      OutByte(CC) = 122
                    Case 84
                      OutByte(CC) = 123
                    Case Else
                      Return False
                  End Select
                Case 84
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 124
                    Case 67
                      OutByte(CC) = 125
                    Case 71
                      OutByte(CC) = 126
                    Case 84
                      OutByte(CC) = 127
                    Case Else
                      Return False
                  End Select
                Case Else
                  Return False
              End Select
            Case Else
              Return False
          End Select
        Case 71
          Select Case NucByte(I + 1)
            Case 65
              Select Case NucByte(I + 2)
                Case 65
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 128
                    Case 67
                      OutByte(CC) = 129
                    Case 71
                      OutByte(CC) = 130
                    Case 84
                      OutByte(CC) = 131
                    Case Else
                      Return False
                  End Select
                Case 67
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 132
                    Case 67
                      OutByte(CC) = 133
                    Case 71
                      OutByte(CC) = 134
                    Case 84
                      OutByte(CC) = 135
                    Case Else
                      Return False
                  End Select
                Case 71
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 136
                    Case 67
                      OutByte(CC) = 137
                    Case 71
                      OutByte(CC) = 138
                    Case 84
                      OutByte(CC) = 139
                    Case Else
                      Return False
                  End Select
                Case 84
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 140
                    Case 67
                      OutByte(CC) = 141
                    Case 71
                      OutByte(CC) = 142
                    Case 84
                      OutByte(CC) = 143
                    Case Else
                      Return False
                  End Select
                Case Else
                  Return False
              End Select
            Case 67
              Select Case NucByte(I + 2)
                Case 65
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 144
                    Case 67
                      OutByte(CC) = 145
                    Case 71
                      OutByte(CC) = 146
                    Case 84
                      OutByte(CC) = 147
                    Case Else
                      Return False
                  End Select
                Case 67
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 148
                    Case 67
                      OutByte(CC) = 149
                    Case 71
                      OutByte(CC) = 150
                    Case 84
                      OutByte(CC) = 151
                    Case Else
                      Return False
                  End Select
                Case 71
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 152
                    Case 67
                      OutByte(CC) = 153
                    Case 71
                      OutByte(CC) = 154
                    Case 84
                      OutByte(CC) = 155
                    Case Else
                      Return False
                  End Select
                Case 84
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 156
                    Case 67
                      OutByte(CC) = 157
                    Case 71
                      OutByte(CC) = 158
                    Case 84
                      OutByte(CC) = 159
                    Case Else
                      Return False
                  End Select
                Case Else
                  Return False
              End Select
            Case 71
              Select Case NucByte(I + 2)
                Case 65
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 160
                    Case 67
                      OutByte(CC) = 161
                    Case 71
                      OutByte(CC) = 162
                    Case 84
                      OutByte(CC) = 163
                    Case Else
                      Return False
                  End Select
                Case 67
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 164
                    Case 67
                      OutByte(CC) = 165
                    Case 71
                      OutByte(CC) = 166
                    Case 84
                      OutByte(CC) = 167
                    Case Else
                      Return False
                  End Select
                Case 71
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 168
                    Case 67
                      OutByte(CC) = 169
                    Case 71
                      OutByte(CC) = 170
                    Case 84
                      OutByte(CC) = 171
                    Case Else
                      Return False
                  End Select
                Case 84
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 172
                    Case 67
                      OutByte(CC) = 173
                    Case 71
                      OutByte(CC) = 174
                    Case 84
                      OutByte(CC) = 175
                    Case Else
                      Return False
                  End Select
                Case Else
                  Return False
              End Select
            Case 84
              Select Case NucByte(I + 2)
                Case 65
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 176
                    Case 67
                      OutByte(CC) = 177
                    Case 71
                      OutByte(CC) = 178
                    Case 84
                      OutByte(CC) = 179
                    Case Else
                      Return False
                  End Select
                Case 67
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 180
                    Case 67
                      OutByte(CC) = 181
                    Case 71
                      OutByte(CC) = 182
                    Case 84
                      OutByte(CC) = 183
                    Case Else
                      Return False
                  End Select
                Case 71
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 184
                    Case 67
                      OutByte(CC) = 185
                    Case 71
                      OutByte(CC) = 186
                    Case 84
                      OutByte(CC) = 187
                    Case Else
                      Return False
                  End Select
                Case 84
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 188
                    Case 67
                      OutByte(CC) = 189
                    Case 71
                      OutByte(CC) = 190
                    Case 84
                      OutByte(CC) = 191
                    Case Else
                      Return False
                  End Select
                Case Else
                  Return False
              End Select
            Case Else
              Return False
          End Select
        Case 84
          Select Case NucByte(I + 1)
            Case 65
              Select Case NucByte(I + 2)
                Case 65
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 192
                    Case 67
                      OutByte(CC) = 193
                    Case 71
                      OutByte(CC) = 194
                    Case 84
                      OutByte(CC) = 195
                    Case Else
                      Return False
                  End Select
                Case 67
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 196
                    Case 67
                      OutByte(CC) = 197
                    Case 71
                      OutByte(CC) = 198
                    Case 84
                      OutByte(CC) = 199
                    Case Else
                      Return False
                  End Select
                Case 71
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 200
                    Case 67
                      OutByte(CC) = 201
                    Case 71
                      OutByte(CC) = 202
                    Case 84
                      OutByte(CC) = 203
                    Case Else
                      Return False
                  End Select
                Case 84
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 204
                    Case 67
                      OutByte(CC) = 205
                    Case 71
                      OutByte(CC) = 206
                    Case 84
                      OutByte(CC) = 207
                    Case Else
                      Return False
                  End Select
                Case Else
                  Return False
              End Select
            Case 67
              Select Case NucByte(I + 2)
                Case 65
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 208
                    Case 67
                      OutByte(CC) = 209
                    Case 71
                      OutByte(CC) = 210
                    Case 84
                      OutByte(CC) = 211
                    Case Else
                      Return False
                  End Select
                Case 67
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 212
                    Case 67
                      OutByte(CC) = 213
                    Case 71
                      OutByte(CC) = 214
                    Case 84
                      OutByte(CC) = 215
                    Case Else
                      Return False
                  End Select
                Case 71
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 216
                    Case 67
                      OutByte(CC) = 217
                    Case 71
                      OutByte(CC) = 218
                    Case 84
                      OutByte(CC) = 219
                    Case Else
                      Return False
                  End Select
                Case 84
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 220
                    Case 67
                      OutByte(CC) = 221
                    Case 71
                      OutByte(CC) = 222
                    Case 84
                      OutByte(CC) = 223
                    Case Else
                      Return False
                  End Select
                Case Else
                  Return False
              End Select
            Case 71
              Select Case NucByte(I + 2)
                Case 65
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 224
                    Case 67
                      OutByte(CC) = 225
                    Case 71
                      OutByte(CC) = 226
                    Case 84
                      OutByte(CC) = 227
                    Case Else
                      Return False
                  End Select
                Case 67
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 228
                    Case 67
                      OutByte(CC) = 229
                    Case 71
                      OutByte(CC) = 230
                    Case 84
                      OutByte(CC) = 231
                    Case Else
                      Return False
                  End Select
                Case 71
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 232
                    Case 67
                      OutByte(CC) = 233
                    Case 71
                      OutByte(CC) = 234
                    Case 84
                      OutByte(CC) = 235
                    Case Else
                      Return False
                  End Select
                Case 84
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 236
                    Case 67
                      OutByte(CC) = 237
                    Case 71
                      OutByte(CC) = 238
                    Case 84
                      OutByte(CC) = 239
                    Case Else
                      Return False
                  End Select
                Case Else
                  Return False
              End Select
            Case 84
              Select Case NucByte(I + 2)
                Case 65
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 240
                    Case 67
                      OutByte(CC) = 241
                    Case 71
                      OutByte(CC) = 242
                    Case 84
                      OutByte(CC) = 243
                    Case Else
                      Return False
                  End Select
                Case 67
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 244
                    Case 67
                      OutByte(CC) = 245
                    Case 71
                      OutByte(CC) = 246
                    Case 84
                      OutByte(CC) = 247
                    Case Else
                      Return False
                  End Select
                Case 71
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 248
                    Case 67
                      OutByte(CC) = 249
                    Case 71
                      OutByte(CC) = 250
                    Case 84
                      OutByte(CC) = 251
                    Case Else
                      Return False
                  End Select
                Case 84
                  Select Case NucByte(I + 3)
                    Case 65
                      OutByte(CC) = 252
                    Case 67
                      OutByte(CC) = 253
                    Case 71
                      OutByte(CC) = 254
                    Case 84
                      OutByte(CC) = 255
                    Case Else
                      Return False
                  End Select
                Case Else
                  Return False
              End Select
            Case Else
              Return False
          End Select
        Case Else
          Return False
      End Select
      CC = CC + 1
    Next
    Return True
  End Function

  'For example, the true sequence is TTTTA with iTrueLen = 5. The packedNuc will be be TTTTAaaa where the trailing aaa is just to add the length to multiples of 4.
  'The OutByte from PackNuc will be {255,0} which would expand to TTTTAAAA. The iTrueLen is used in UnpackNuc to trim off the trailing AAA.
  Sub UnpackNuc(ByVal PackedByte() As Byte, ByVal iPackedLen As Integer, ByVal iTrueLen As Integer, ByRef OriginalByte() As Byte)
    Dim I As Integer, CC As Integer
    ReDim OriginalByte(iPackedLen * 4 - 1)
    For I = 0 To iPackedLen - 1
      CC = I * 4
      Select Case PackedByte(I)
        Case 0
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 65
        Case 1
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 67
        Case 2
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 71
        Case 3
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 84
        Case 4
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 65
        Case 5
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 67
        Case 6
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 71
        Case 7
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 84
        Case 8
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 65
        Case 9
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 67
        Case 10
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 71
        Case 11
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 84
        Case 12
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 65
        Case 13
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 67
        Case 14
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 71
        Case 15
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 84
        Case 16
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 65
        Case 17
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 67
        Case 18
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 71
        Case 19
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 84
        Case 20
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 65
        Case 21
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 67
        Case 22
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 71
        Case 23
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 84
        Case 24
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 65
        Case 25
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 67
        Case 26
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 71
        Case 27
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 84
        Case 28
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 65
        Case 29
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 67
        Case 30
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 71
        Case 31
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 84
        Case 32
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 65
        Case 33
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 67
        Case 34
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 71
        Case 35
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 84
        Case 36
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 65
        Case 37
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 67
        Case 38
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 71
        Case 39
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 84
        Case 40
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 65
        Case 41
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 67
        Case 42
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 71
        Case 43
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 84
        Case 44
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 65
        Case 45
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 67
        Case 46
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 71
        Case 47
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 84
        Case 48
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 65
        Case 49
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 67
        Case 50
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 71
        Case 51
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 84
        Case 52
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 65
        Case 53
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 67
        Case 54
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 71
        Case 55
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 84
        Case 56
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 65
        Case 57
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 67
        Case 58
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 71
        Case 59
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 84
        Case 60
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 65
        Case 61
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 67
        Case 62
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 71
        Case 63
          OriginalByte(CC) = 65
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 84
        Case 64
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 65
        Case 65
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 67
        Case 66
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 71
        Case 67
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 84
        Case 68
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 65
        Case 69
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 67
        Case 70
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 71
        Case 71
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 84
        Case 72
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 65
        Case 73
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 67
        Case 74
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 71
        Case 75
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 84
        Case 76
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 65
        Case 77
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 67
        Case 78
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 71
        Case 79
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 84
        Case 80
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 65
        Case 81
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 67
        Case 82
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 71
        Case 83
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 84
        Case 84
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 65
        Case 85
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 67
        Case 86
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 71
        Case 87
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 84
        Case 88
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 65
        Case 89
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 67
        Case 90
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 71
        Case 91
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 84
        Case 92
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 65
        Case 93
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 67
        Case 94
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 71
        Case 95
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 84
        Case 96
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 65
        Case 97
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 67
        Case 98
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 71
        Case 99
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 84
        Case 100
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 65
        Case 101
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 67
        Case 102
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 71
        Case 103
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 84
        Case 104
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 65
        Case 105
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 67
        Case 106
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 71
        Case 107
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 84
        Case 108
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 65
        Case 109
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 67
        Case 110
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 71
        Case 111
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 84
        Case 112
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 65
        Case 113
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 67
        Case 114
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 71
        Case 115
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 84
        Case 116
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 65
        Case 117
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 67
        Case 118
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 71
        Case 119
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 84
        Case 120
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 65
        Case 121
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 67
        Case 122
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 71
        Case 123
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 84
        Case 124
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 65
        Case 125
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 67
        Case 126
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 71
        Case 127
          OriginalByte(CC) = 67
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 84
        Case 128
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 65
        Case 129
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 67
        Case 130
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 71
        Case 131
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 84
        Case 132
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 65
        Case 133
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 67
        Case 134
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 71
        Case 135
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 84
        Case 136
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 65
        Case 137
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 67
        Case 138
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 71
        Case 139
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 84
        Case 140
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 65
        Case 141
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 67
        Case 142
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 71
        Case 143
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 84
        Case 144
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 65
        Case 145
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 67
        Case 146
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 71
        Case 147
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 84
        Case 148
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 65
        Case 149
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 67
        Case 150
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 71
        Case 151
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 84
        Case 152
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 65
        Case 153
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 67
        Case 154
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 71
        Case 155
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 84
        Case 156
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 65
        Case 157
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 67
        Case 158
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 71
        Case 159
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 84
        Case 160
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 65
        Case 161
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 67
        Case 162
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 71
        Case 163
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 84
        Case 164
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 65
        Case 165
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 67
        Case 166
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 71
        Case 167
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 84
        Case 168
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 65
        Case 169
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 67
        Case 170
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 71
        Case 171
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 84
        Case 172
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 65
        Case 173
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 67
        Case 174
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 71
        Case 175
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 84
        Case 176
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 65
        Case 177
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 67
        Case 178
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 71
        Case 179
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 84
        Case 180
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 65
        Case 181
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 67
        Case 182
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 71
        Case 183
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 84
        Case 184
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 65
        Case 185
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 67
        Case 186
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 71
        Case 187
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 84
        Case 188
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 65
        Case 189
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 67
        Case 190
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 71
        Case 191
          OriginalByte(CC) = 71
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 84
        Case 192
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 65
        Case 193
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 67
        Case 194
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 71
        Case 195
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 84
        Case 196
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 65
        Case 197
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 67
        Case 198
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 71
        Case 199
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 84
        Case 200
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 65
        Case 201
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 67
        Case 202
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 71
        Case 203
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 84
        Case 204
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 65
        Case 205
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 67
        Case 206
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 71
        Case 207
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 65
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 84
        Case 208
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 65
        Case 209
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 67
        Case 210
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 71
        Case 211
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 84
        Case 212
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 65
        Case 213
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 67
        Case 214
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 71
        Case 215
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 84
        Case 216
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 65
        Case 217
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 67
        Case 218
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 71
        Case 219
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 84
        Case 220
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 65
        Case 221
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 67
        Case 222
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 71
        Case 223
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 67
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 84
        Case 224
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 65
        Case 225
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 67
        Case 226
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 71
        Case 227
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 84
        Case 228
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 65
        Case 229
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 67
        Case 230
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 71
        Case 231
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 84
        Case 232
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 65
        Case 233
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 67
        Case 234
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 71
        Case 235
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 84
        Case 236
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 65
        Case 237
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 67
        Case 238
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 71
        Case 239
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 71
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 84
        Case 240
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 65
        Case 241
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 67
        Case 242
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 71
        Case 243
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 65
          OriginalByte(CC + 3) = 84
        Case 244
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 65
        Case 245
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 67
        Case 246
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 71
        Case 247
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 67
          OriginalByte(CC + 3) = 84
        Case 248
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 65
        Case 249
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 67
        Case 250
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 71
        Case 251
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 71
          OriginalByte(CC + 3) = 84
        Case 252
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 65
        Case 253
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 67
        Case 254
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 71
        Case 255
          OriginalByte(CC) = 84
          OriginalByte(CC + 1) = 84
          OriginalByte(CC + 2) = 84
          OriginalByte(CC + 3) = 84
      End Select
    Next
    ReDim Preserve OriginalByte(iTrueLen - 1)
  End Sub
End Module
