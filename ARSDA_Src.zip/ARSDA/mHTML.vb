﻿Imports System.Net
Imports System.Xml
Imports System.IO
Module mHTML
  Public Function GetHTML(ByVal sURI As String, ByRef sHTML As String) As Boolean
    Dim wbClient As New WebClient
    Dim strData As Stream = wbClient.OpenRead(sURI)
    Dim sr As StreamReader = New System.IO.StreamReader(strData)
    sHTML = sr.ReadToEnd()
    Return True
  End Function

  Public Function GetPageAsString(ByVal sURI As String, ByRef sHTML As String) As Boolean

    Dim request As HttpWebRequest
    Dim response As HttpWebResponse = Nothing
    Dim reader As StreamReader
    Dim Address As New Uri(sURI)

    Try
      ' Create the web request  
      request = DirectCast(WebRequest.Create(Address), HttpWebRequest)

      ' Get response  
      response = DirectCast(request.GetResponse(), HttpWebResponse)

      ' Get the response stream into a reader  
      reader = New StreamReader(response.GetResponseStream())

      ' Read the whole contents and return as a string  
      sHTML = reader.ReadToEnd()
    Finally
      If Not response Is Nothing Then response.Close()
    End Try

    Return True

  End Function

  Public Sub GetXMLNodeByTag(ByVal xml As String, ByVal File1Text2 As Integer, ByVal sTag As String, ByRef NumNode As Integer, ByRef nodes As XmlNodeList)
    Dim xmldom As New XmlDocument
    If File1Text2 = 1 Then
      xmldom.Load(xml)
    Else
      xmldom.LoadXml(xml)
    End If
    Dim i As Integer = 1
    nodes = xmldom.GetElementsByTagName(sTag)
    NumNode = nodes.Count()
  End Sub

  Public Function ShowXMLinDataGridView(ByVal sFileXML As String, ByVal DGV As DataGridView) As Boolean
    Dim xmlFile As XmlReader
    xmlFile = XmlReader.Create(sFileXML, New XmlReaderSettings())
    Dim ds As New DataSet
    ds.ReadXml(xmlFile)
    DGV.DataSource = ds '.Tables(0)
    Return True
  End Function
End Module
