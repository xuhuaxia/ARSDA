﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmWeb
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
    Me.mnuWeb = New System.Windows.Forms.MenuStrip()
    Me.URLToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
    Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuWeb.SuspendLayout()
    Me.SuspendLayout()
    '
    'RichTextBox1
    '
    Me.RichTextBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                Or System.Windows.Forms.AnchorStyles.Left) _
                Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.RichTextBox1.Location = New System.Drawing.Point(1, 27)
    Me.RichTextBox1.Name = "RichTextBox1"
    Me.RichTextBox1.Size = New System.Drawing.Size(890, 541)
    Me.RichTextBox1.TabIndex = 0
    Me.RichTextBox1.Text = ""
    '
    'mnuWeb
    '
    Me.mnuWeb.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.URLToolStripMenuItem})
    Me.mnuWeb.Location = New System.Drawing.Point(0, 0)
    Me.mnuWeb.Name = "mnuWeb"
    Me.mnuWeb.Size = New System.Drawing.Size(893, 24)
    Me.mnuWeb.TabIndex = 1
    Me.mnuWeb.Text = "mnuWeb"
    '
    'URLToolStripMenuItem
    '
    Me.URLToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1, Me.ExitToolStripMenuItem})
    Me.URLToolStripMenuItem.Name = "URLToolStripMenuItem"
    Me.URLToolStripMenuItem.Size = New System.Drawing.Size(40, 20)
    Me.URLToolStripMenuItem.Text = "URL"
    '
    'ToolStripMenuItem1
    '
    Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
    Me.ToolStripMenuItem1.Size = New System.Drawing.Size(149, 6)
    '
    'ExitToolStripMenuItem
    '
    Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
    Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
    Me.ExitToolStripMenuItem.Text = "Exit"
    '
    'frmWeb
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(893, 570)
    Me.Controls.Add(Me.RichTextBox1)
    Me.Controls.Add(Me.mnuWeb)
    Me.MainMenuStrip = Me.mnuWeb
    Me.Name = "frmWeb"
    Me.Text = "Web client"
    Me.mnuWeb.ResumeLayout(False)
    Me.mnuWeb.PerformLayout()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
  Friend WithEvents mnuWeb As System.Windows.Forms.MenuStrip
  Friend WithEvents URLToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
