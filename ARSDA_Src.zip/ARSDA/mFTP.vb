﻿Imports System.Net
Imports System.Text
Module mFTP

  Public Function GetPageURI(ByVal serverUri As Uri, ByVal bAnonymous As Boolean, ByRef sPage As String, _
                             Optional ByVal sEmail As String = "", Optional ByVal sLogin As String = "", Optional ByVal sPassword As String = "") As Boolean
    ' The serverUri parameter should start with the ftp:// scheme.
    If serverUri.Scheme <> Uri.UriSchemeFtp Then
      Return False
    End If
    ' Get the object used to communicate with the server.
    Dim oClient As New WebClient()

    If bAnonymous Then
      oClient.Credentials = New NetworkCredential("anonymous", sEmail)
    Else
      oClient.Credentials = New NetworkCredential(sLogin, sPassword)
    End If
    Try
      Dim newFileData() As Byte = oClient.DownloadData(serverUri.ToString())
      sPage = Encoding.UTF8.GetString(newFileData)
      Return True
    Catch e As WebException
      sPage = e.ToString()
      Return False
    End Try
  End Function

  Public Function DeleteFileOnServer(ByVal serverUri As Uri) As Boolean
    ' The serverUri parameter should use the ftp:// scheme.
    ' It contains the name of the server file that is to be deleted.
    ' Example: ftp://contoso.com/someFile.txt.
    ' 

    If serverUri.Scheme <> Uri.UriSchemeFtp Then
      Return False
    End If
    ' Get the object used to communicate with the server.
    Dim oClient As FtpWebRequest = CType(WebRequest.Create(serverUri), FtpWebRequest)
    oClient.Method = WebRequestMethods.Ftp.DeleteFile

    Dim response As FtpWebResponse = CType(oClient.GetResponse(), FtpWebResponse)
    Console.WriteLine("Delete status: {0}", response.StatusDescription)
    response.Close()
    Return True
  End Function

End Module
