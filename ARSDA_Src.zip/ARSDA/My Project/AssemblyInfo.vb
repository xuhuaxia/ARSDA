﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("ARSDA")> 
<Assembly: AssemblyDescription("Comprehensive software workbench for RNA-Seq data, written and maintained by Prof. Xuhua Xia at Department of Biology, University of Ottawa (xxia@uottawa.ca)")> 
<Assembly: AssemblyCompany("XiaLab at University of Ottawa")> 
<Assembly: AssemblyProduct("ARSDA")> 
<Assembly: AssemblyCopyright("Copyright ©  2015")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("e9c0b9b6-4c27-44f3-9f6c-48ff97426738")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.1.6")> 
<Assembly: AssemblyFileVersion("1.0.1.6")> 
