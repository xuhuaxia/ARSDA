﻿Imports System.Windows.Forms
Imports System.IO

Public Class dlgFastqInfo

  Private mFastqFile As String, mPlotBaseQual As Boolean, mPlotSeqQual As Boolean, mPlotSeqLen As Boolean, mDone As Boolean

  Public Function GetFastqInfoParam(ByRef sFastqFile As String, ByRef bPlotBaseQual As Boolean, ByRef bPlotSeqQual As Boolean, ByRef bPlotSeqLen As Boolean) As Boolean
    mDone = False

    Me.ShowDialog()
    If mDone Then
      sFastqFile = mFastqFile
      bPlotBaseQual = mPlotBaseQual
      bPlotSeqQual = mPlotSeqQual
      bPlotSeqLen = mPlotSeqLen
      Return True
    Else
      Return False
    End If
  End Function

  Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
    mFastqFile = txtFastqFile.Text
    If Not File.Exists(mFastqFile) Then
      MsgBox("Specified file " & mFastqFile & " does not exist.", vbOKOnly)
      txtFastqFile.Focus()
      Exit Sub
    End If
    mPlotBaseQual = chkBaseQual.Checked
    mPlotSeqQual = chkSeqQual.Checked
    mPlotSeqLen = chkPlotSeqLen.Checked
    mDone = True
    Me.Close()
  End Sub

  Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
    Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Close()
  End Sub

  Private Sub btnBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowse.Click
    If Directory.Exists(txtFastqFile.Text) Then
      txtFastqFile.Text = GetOpenFileName("Open .FASTQ file", "fastq,fq", OpenFileDialog1, txtFastqFile.Text)
    Else
      txtFastqFile.Text = GetOpenFileName("Open .FASTQ file", "fastq,fq", OpenFileDialog1, sInputDir)
    End If
  End Sub
End Class
