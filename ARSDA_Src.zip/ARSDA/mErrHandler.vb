﻿Module mErrHandler
  Private Const MyEmail = "xxia@uottawa.ca"

  Sub RaiseErr(ByVal ErrSrc As String, ByVal ErrInfo As String)
    If err.Number = 0 Then
      err.Raise(1, ErrSrc, ErrInfo)
    Else
      err.source = err.source & "," & ErrSrc & vbCrLf
      err.Description = err.Description & "," & ErrInfo & vbCrLf
    End If
  End Sub



  Function ErrorHandler(ByVal ErrorIn As Integer) As Short




    Dim sMsg As String = ""
    Dim iType As Short
    Dim sTitle As String

    iType = vbCritical + vbAbortRetryIgnore

    Select Case ErrorIn
      Case 1
        sTitle = "Erorr"
        sMsg = "An unexpected error has occurred." & vbCrLf & vbCrLf
        sMsg = sMsg & "Error number: " & CStr(ErrorIn)
        sMsg = sMsg & "," & Err.Source & vbCrLf
        sMsg = sMsg & "Error source: " & Err.Source & vbCrLf & vbCrLf
        sMsg = sMsg & "Please write down the number and message " & vbCrLf
        sMsg = sMsg & "and email me at " & MyEmail & vbCrLf
        sMsg = sMsg & " to report the error. Please include the" & vbCrLf
        sMsg = sMsg & "keystrokes and mouse clicks that have" & vbCrLf
        sMsg = sMsg & "led to the error. Thank you."
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 6
        sMsg = "Overflow" & vbCrLf & vbCrLf
        sMsg = sMsg & "An unexpected error condition has occurred." & vbCrLf & vbCrLf
        sMsg = sMsg & "Please write down the number and message " & vbCrLf
        sMsg = sMsg & "and email me at " & MyEmail & vbCrLf
        sMsg = sMsg & " to report the error. Please include the" & vbCrLf
        sMsg = sMsg & "keystrokes and mouse clicks that have" & vbCrLf
        sMsg = sMsg & "led to the error. Thank you."
        sTitle = "System error"
        ErrorHandler = MsgBox(sMsg, iType, sTitle)

      Case 2 To 5, 9, 11, 14 To 49, 59, 90, 94
        sTitle = "Erorr"
        sMsg = "An unexpected error condition has occurred." & vbCrLf & vbCrLf
        sMsg = sMsg & "Error number: " & CStr(ErrorIn)
        sMsg = sMsg & "," & Err.Source & vbCrLf & vbCrLf
        sMsg = sMsg & "Please write down the number and message " & vbCrLf
        sMsg = sMsg & "and email me at " & MyEmail & vbCrLf
        sMsg = sMsg & " to report the error. Please include the" & vbCrLf
        sMsg = sMsg & "keystrokes and mouse clicks that have" & vbCrLf
        sMsg = sMsg & "led to the error. Thank you."
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 7
        sTitle = "Out of memory"
        sMsg = sMsg & "Not enough memory to complete the operation" & vbCrLf
        sMsg = sMsg & "Save your work Then close any open "
        sMsg = sMsg & "programs and try again."
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 10
        sTitle = "Error"
        sMsg = sMsg & "The computer has been disconnected from the network." & vbCrLf
        sMsg = sMsg & "Try internet function latter."
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 13
        sTitle = "Error"
        sMsg = sMsg & "Type mismatch." & CRCR
        sMsg = sMsg & "Error number: " & CStr(ErrorIn)
        sMsg = sMsg & "," & Err.Source & vbCrLf & vbCrLf
        sMsg = sMsg & "Please write down the number and message " & vbCrLf
        sMsg = sMsg & "and email me at " & MyEmail & vbCrLf
        sMsg = sMsg & " to report the error. Please include the" & vbCrLf
        sMsg = sMsg & "keystrokes and mouse clicks that have" & vbCrLf
        sMsg = sMsg & "led to the error. Thank you."
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 51
        sTitle = "Internal system error"
        sMsg = "Report error to system administrator (or to yourself)......"
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, "Warning")

      Case 52 To 56, 58, 60, 62 To 66, 69 To 70, 73 To 76
        sMsg = Err.Source
        sTitle = "System file error number " & Err.ToString & ""
        ErrorHandler = MsgBox(sMsg, iType, sTitle)

      Case 61
        sMsg = "Disk is full" & vbCrLf & vbCrLf
        sMsg = sMsg & "Change disks or delete " & vbCrLf
        sMsg = sMsg & "unwanted files"
        sTitle = "System disk error"
        ErrorHandler = MsgBox(sMsg, iType, sTitle)

      Case 57, 68, 71 To 72
        sMsg = "Disk not ready or unavailable" & vbCrLf & vbCrLf
        sMsg = sMsg & "Check the disk before continuing."
        sTitle = "System disk error"
        ErrorHandler = MsgBox(sMsg, iType, sTitle)

      Case 67
        sMsg = "Not enough file handles to complete the operation " & vbCrLf
        sMsg = sMsg & "Increase the FILES = number in your config.sys file."
        sTitle = "File handles error"
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 94
        sMsg = "Invalid use of Null " & vbCrLf
        sTitle = "Language Error"
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 281 To 297
        sMsg = Err.Source
        sTitle = "System DDE error"
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 340 To 344
        sMsg = Err.Source
        sTitle = "Control array error"
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 380

        sMsg = Err.Source & CRCR
        sMsg = sMsg & "An object does not fully support my functions."
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, "Warning")

      Case 482

        sTitle = "Check printer."
        sMsg = Err.Source
        sMsg = sMsg & "," & Err.Source & vbCrLf & vbCrLf
        sMsg = sMsg & "To report the error,please write down the number " & vbCrLf
        sMsg = sMsg & "and message,and email me at " & MyEmail & vbCrLf
        sMsg = sMsg & "Thank you."
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 483

        sMsg = Err.Source & CRCR
        sMsg = sMsg & "Some printer properties were not set properly."
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, "Warning")

      Case 484

        sTitle = "Make sure that the printer is installed properly. Try printing from other programs."
        sMsg = Err.Source
        sMsg = sMsg & "," & Err.Source & vbCrLf & vbCrLf
        sMsg = sMsg & "To report the error,please write down the number " & vbCrLf
        sMsg = sMsg & "and message,and email me at " & MyEmail & vbCrLf
        sMsg = sMsg & "Thank you."
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 486

        sTitle = "Printer Error."
        sMsg = Err.Source
        sMsg = sMsg & "," & Err.Source & vbCrLf & vbCrLf
        sMsg = sMsg & "To report the error,please write down the number " & vbCrLf
        sMsg = sMsg & "and message,and email me at " & MyEmail & vbCrLf
        sMsg = sMsg & "Thank you. (Let me know what printer you have.)"
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 32755
        sTitle = "Error"
        sMsg = "You have cancelled the file operation." & vbCrLf
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 35761
        sTitle = "Error"
        sMsg = "Request time out. Make sure that your computer is properly connected to internet." & vbCrLf
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 35764
        sTitle = "Error"
        sMsg = "Please be patient. The network is a bit slow. I am busy requesting information from the host." & vbCrLf
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 35750 To 35760, 35762, 35763 To 35878
        sTitle = "Network Error"
        sMsg = "An unexpected network error has occurred." & vbCrLf & vbCrLf
        sMsg = sMsg & "Error number: " & CStr(ErrorIn)
        sMsg = sMsg & "," & Err.Source & vbCrLf & vbCrLf
        sMsg = sMsg & "To report the error,please write down the number " & vbCrLf
        sMsg = sMsg & "and message,and email me at " & MyEmail & vbCrLf
        sMsg = sMsg & "Thank you."
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 35896 To 35904
        sTitle = "Gopher Error"
        sMsg = "Error accessing the gopher site." & vbCrLf
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 35916 To 35922
        sTitle = "HTTP Error"
        sMsg = "Error accessing the gopher site." & vbCrLf
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 35923
        sTitle = "Network Error"
        sMsg = "Security channel error." & vbCrLf
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 35924
        sTitle = "Network Error"
        sMsg = "Unable to cache file." & vbCrLf
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 35927
        sTitle = "Network Error"
        sMsg = "You must confirm a server-supplied cookie before the download can proceed." & vbCrLf
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 35928
        sTitle = "Network Error"
        sMsg = "A cookie supplied by the server was not accepted." & vbCrLf
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 35930
        sTitle = "Network Error"
        sMsg = "The requested server was unable to be connected to. This was determined by receipt of a WSAEHOSTUNREACH error from WinSock." & vbCrLf
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 35931
        sTitle = "Network Error"
        sMsg = "The requested proxy server was unable to be reached." & vbCrLf
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 35932
        sTitle = "Network Error"
        sMsg = "There is an error in the proxy auto-configuration script,so the script cannot be run." & vbCrLf
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 35933
        sTitle = "Network Error"
        sMsg = "The required proxy auto-configuration file could not be retrieved." & vbCrLf
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 35934
        sTitle = "Network Error"
        sMsg = "You must confirm a protocol-level redirection before the download can proceed." & vbCrLf
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 35935
        sTitle = "Network Error"
        sMsg = "The certificate is invalid." & vbCrLf
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 35936
        sTitle = "Network Error"
        sMsg = "The certificate has been revoked." & vbCrLf
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case 35937
        sTitle = "Network Error"
        sMsg = "The operation you attempted failed because it could not pass the security check." & vbCrLf
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)

      Case Else
        sTitle = "Hmmm.. Something has gone wrong."
        sMsg = "An unexpected error condition has occurred." & vbCrLf & vbCrLf
        sMsg = sMsg & "Error number: " & CStr(ErrorIn)
        sMsg = sMsg & "," & Err.Source & vbCrLf & vbCrLf
        sMsg = sMsg & "To report the error,please write down the number " & vbCrLf
        sMsg = sMsg & "and message,and email me at " & MyEmail & vbCrLf
        sMsg = sMsg & "Thank you."
        ErrorHandler = MsgBox(sMsg, vbCritical + vbAbortRetryIgnore, sTitle)
    End Select
  End Function


End Module
