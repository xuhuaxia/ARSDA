﻿Module mXML
  Sub VarFromXML(ByVal sXMLFile As String, ByVal sTableID As String, ByRef iNumVar As Integer, ByRef sVarName() As String, ByVal sVarValMat() As String)
    Dim ds As New DataSet()
    ds.ReadXml(sXMLFile)
    For Each row As DataRow In ds.Tables(sTableID).Rows
      'MessageBox.Show(row("ID").ToString() & " " & row("FirstName").ToString())
    Next
  End Sub
End Module
