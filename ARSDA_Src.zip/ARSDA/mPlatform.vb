﻿'Other platform-specific notes:
'1. Shell does not work in Linux/Mac, use my RunExeAndWait function
'2. Can use platform-specific programs. For example, there are blastn.exe, blastp.exe for Windows, and blanstn, blastp for 
'   Mac (typically in the /usr/local/ncbi/bin directory). The executables may be be stored in the same directory in both Windows and Linux/Mac versions, e.g., 
'   Application.StartupPath\NCBI\ in Windows, and Application.StartupPath/NCBI/. To this directory, we copy blastn.exe, blastp.exe, etc., for Windows, but platfor-specific
'   blastn, blastp, etc., for Linux/Mac. It is important NOT to include the ".exe" part in the calling function.
'   Note that Windows .exe, may not work with Mac through mono, but appear to work fine with Ubuntu through mono.
'3. In Ubuntu Linux, terminal to the NCBI directory and issue 'chmod 755 *' to set execute permission, or right-click each NCBI program, click the 'Permission' tab and check 'Execute'
'4. In Ubuntu Linux, after installing mono, issue:
'   sudo apt-get install mono-vbnc (otherwise may encounter Mono: error: The entry point method could not be loaded)
'5. The directory path separator is “\” in WIndows but “/” in Linux. Should replace this with Path.DirectorySeparatorChar
'6. Linux is case sensitive in file names
'7. XmlReader does not seem to work with Mac mono
'If there are Windows applications that cannot run on Mac or Linux because of file path problems, one could use:
' export MONO_IOMAP=all
' mono myapp.exe
'For ASP.NET applications hosted with mod_mono, add the following to Appach configuration file:
' MonboSetEnv MONO_IOMAP=all
'For programs written in VB to run on Linux, one may need to issue the following after mono installation (to avoid the "Error: The entry point method could not be loaded")
' sudo apt-get install mono-vbnc
Module mPlatform
  Function GetAvailablePhysicalMem() As Long
#If TARGET = "LINUX" Then

    Dim PC As New System.Diagnostics.PerformanceCounter("Mono Memory", "Available Physical Memory")
    Return PC.RawValue
#Else
    return My.Computer.Info.AvailablePhysicalMemory
#End If
    'If report in MB, divide by 1048576 (= 1024 * 1024)
  End Function

  Function GetTotalPhysicalMem() As Long
#If TARGET = "LINUX" Then
    Dim PC As New System.Diagnostics.PerformanceCounter("Mono Memory", "Total Physical Memory")
    Return PC.RawValue
#Else
    return My.Computer.Info.TotalPhysicalMemory
#End If
  End Function

  Function GetAvailableVirtualMem() As Long
#If TARGET = "LINUX" Then
    'Not tested
    Dim PC As New System.Diagnostics.PerformanceCounter("Mono Memory", "Available Virtual Memory")
    Return PC.RawValue
#Else
    Return My.Computer.Info.AvailableVirtualMemory
#End If
  End Function

  Function GetTotalVirtualMem() As Long
#If TARGET = "LINUX" Then
    'Not tested
    Dim PC As New System.Diagnostics.PerformanceCounter("Mono Memory", "Total Virtual Memory")
    Return PC.RawValue
#Else
    Return My.Computer.Info.TotalVirtualMemory
#End If
  End Function

End Module
