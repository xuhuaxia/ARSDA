﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmFTP
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Me.lstDir = New System.Windows.Forms.ListBox()
    Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
    Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
    Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
    Me.ToolStripProgressBar1 = New System.Windows.Forms.ToolStripProgressBar()
    Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
    Me.mnuFTP = New System.Windows.Forms.MenuStrip()
    Me.DownloadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.NewFTPSiteToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.DownloadToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
    Me.DownloadMult = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
    Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
    Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
    Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
    Me.StatusStrip1.SuspendLayout()
    Me.mnuFTP.SuspendLayout()
    Me.SuspendLayout()
    '
    'lstDir
    '
    Me.lstDir.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.lstDir.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.lstDir.FormattingEnabled = True
    Me.lstDir.ItemHeight = 14
    Me.lstDir.Location = New System.Drawing.Point(0, 28)
    Me.lstDir.Name = "lstDir"
    Me.lstDir.Size = New System.Drawing.Size(465, 452)
    Me.lstDir.TabIndex = 0
    '
    'StatusStrip1
    '
    Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel2, Me.ToolStripProgressBar1})
    Me.StatusStrip1.Location = New System.Drawing.Point(0, 492)
    Me.StatusStrip1.Name = "StatusStrip1"
    Me.StatusStrip1.Size = New System.Drawing.Size(977, 22)
    Me.StatusStrip1.TabIndex = 1
    Me.StatusStrip1.Text = "StatusStrip1"
    '
    'ToolStripStatusLabel1
    '
    Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
    Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(39, 17)
    Me.ToolStripStatusLabel1.Text = "Ready"
    '
    'ToolStripStatusLabel2
    '
    Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
    Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(25, 17)
    Me.ToolStripStatusLabel2.Text = "File"
    '
    'ToolStripProgressBar1
    '
    Me.ToolStripProgressBar1.Name = "ToolStripProgressBar1"
    Me.ToolStripProgressBar1.Size = New System.Drawing.Size(200, 16)
    '
    'RichTextBox1
    '
    Me.RichTextBox1.Dock = System.Windows.Forms.DockStyle.Right
    Me.RichTextBox1.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.RichTextBox1.Location = New System.Drawing.Point(471, 24)
    Me.RichTextBox1.Name = "RichTextBox1"
    Me.RichTextBox1.Size = New System.Drawing.Size(506, 468)
    Me.RichTextBox1.TabIndex = 2
    Me.RichTextBox1.Text = ""
    Me.RichTextBox1.WordWrap = False
    '
    'mnuFTP
    '
    Me.mnuFTP.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DownloadToolStripMenuItem})
    Me.mnuFTP.Location = New System.Drawing.Point(0, 0)
    Me.mnuFTP.Name = "mnuFTP"
    Me.mnuFTP.Size = New System.Drawing.Size(977, 24)
    Me.mnuFTP.TabIndex = 3
    Me.mnuFTP.Text = "MenuStrip1"
    '
    'DownloadToolStripMenuItem
    '
    Me.DownloadToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewFTPSiteToolStripMenuItem, Me.DownloadToolStripMenuItem1, Me.DownloadMult, Me.ToolStripMenuItem1, Me.ExitToolStripMenuItem})
    Me.DownloadToolStripMenuItem.Name = "DownloadToolStripMenuItem"
    Me.DownloadToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
    Me.DownloadToolStripMenuItem.Text = "File"
    '
    'NewFTPSiteToolStripMenuItem
    '
    Me.NewFTPSiteToolStripMenuItem.Name = "NewFTPSiteToolStripMenuItem"
    Me.NewFTPSiteToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
    Me.NewFTPSiteToolStripMenuItem.Text = "New FTP site"
    '
    'DownloadToolStripMenuItem1
    '
    Me.DownloadToolStripMenuItem1.Name = "DownloadToolStripMenuItem1"
    Me.DownloadToolStripMenuItem1.Size = New System.Drawing.Size(199, 22)
    Me.DownloadToolStripMenuItem1.Text = "Download"
    '
    'DownloadMult
    '
    Me.DownloadMult.Name = "DownloadMult"
    Me.DownloadMult.Size = New System.Drawing.Size(199, 22)
    Me.DownloadMult.Text = "Download Multiple SRA"
    '
    'ToolStripMenuItem1
    '
    Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
    Me.ToolStripMenuItem1.Size = New System.Drawing.Size(196, 6)
    '
    'ExitToolStripMenuItem
    '
    Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
    Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(199, 22)
    Me.ExitToolStripMenuItem.Text = "Exit"
    '
    'OpenFileDialog1
    '
    Me.OpenFileDialog1.FileName = "OpenFileDialog1"
    '
    'frmFTP
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(977, 514)
    Me.Controls.Add(Me.RichTextBox1)
    Me.Controls.Add(Me.StatusStrip1)
    Me.Controls.Add(Me.mnuFTP)
    Me.Controls.Add(Me.lstDir)
    Me.MainMenuStrip = Me.mnuFTP
    Me.Name = "frmFTP"
    Me.Text = "FTP Client"
    Me.StatusStrip1.ResumeLayout(False)
    Me.StatusStrip1.PerformLayout()
    Me.mnuFTP.ResumeLayout(False)
    Me.mnuFTP.PerformLayout()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents lstDir As System.Windows.Forms.ListBox
  Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
  Friend WithEvents ToolStripProgressBar1 As System.Windows.Forms.ToolStripProgressBar
  Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
  Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
  Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
  Friend WithEvents mnuFTP As System.Windows.Forms.MenuStrip
  Friend WithEvents DownloadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents NewFTPSiteToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents DownloadToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
  Friend WithEvents DownloadMult As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
  Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
End Class
