﻿Imports System.Windows.Forms
Imports System.IO
Public Class dlgSraInfo
  Private mSraFile As String, mReadQuality As Boolean, mDone As Boolean

  Public Function GetSraInfoParam(ByRef sSraFile As String, ByRef bReadQuality As Boolean) As Boolean
    mDone = False

    Me.ShowDialog()
    If mDone Then
      sSraFile = mSraFile
      bReadQuality = mReadQuality
      Return True
    Else
      Return False
    End If
  End Function

  Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
    mSraFile = txtSraFile.Text
    If Not File.Exists(mSraFile) Then
      MsgBox("Specified file " & mSraFile & " does not exist.", vbOKOnly)
      txtSraFile.Focus()
      Exit Sub
    End If
    mReadQuality = chkReadQual.Checked
    mDone = True
    Me.Close()
  End Sub

  Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
    Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Close()
  End Sub

  Private Sub btnBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowse.Click
    If Directory.Exists(txtSraFile.Text) Then
      txtSraFile.Text = GetOpenFileName("Open .SRA file", "sra", OpenFileDialog1, txtSraFile.Text)
    Else
      txtSraFile.Text = GetOpenFileName("Open .SRA file", "sra", OpenFileDialog1, sInputDir)
    End If

  End Sub
End Class
