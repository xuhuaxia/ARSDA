﻿Imports System
Imports System.Net
Imports System.IO
Public Class frmWeb
  Private mURL As String
  Private mClient As WebClient
  Private mStreamData As Stream
  Private mStreamReader As StreamReader

  Public Sub Retrieve(ByVal sURL As String, ByVal sEmail As String, ByVal sPassword As String)
    mURL = sURL
    Me.ShowDialog()

    mStreamData.Close()
    mStreamReader.Close()
    mClient = Nothing

  End Sub 'Main

  Private Sub frmWeb_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
    mClient = New WebClient()
    ' Add a user agent header in case the  
    ' requested URI contains a query.
    mClient.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)")

    mStreamData = mClient.OpenRead(mURL)
    mStreamReader = New StreamReader(mStreamData)
    RichTextBox1.Text = mStreamReader.ReadToEnd
  End Sub

  Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
    Me.Close()

  End Sub

End Class