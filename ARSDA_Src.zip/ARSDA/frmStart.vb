﻿Imports System.IO
Imports System.Text
Imports System.Collections
Imports System.Net
Public Class frmStart
  'Private Declare Function Test Lib "C:\Users\xxia\Documents\Visual Studio 2010\Projects\Lengthy\x64\Debug\lengthy.dll" (ByRef LastArrayVal As Byte) As Boolean
  ''                        BenchMark(                                                                                              char *sOutFile, char *sFileString1, char *sFileString2, char *sFileOS, char *sFileOF)
  'Private Declare Function BenchMark Lib "C:\Users\xxia\Documents\Visual Studio 2010\Projects\Lengthy\x64\Debug\lengthy.dll" (ByVal sOutFile As String, ByVal sFileString1 As String, ByVal sFileString2 As String, ByVal sFileOS As String, ByVal sFileOF As String) As Boolean
  Private mPrevSearch As String, mMatchCase As Boolean, mWholeWord As Boolean, mSearchDown As Boolean 'For RichtextBox Find and Find next
  Private Const mErrReport As String = "Please contact Dr. Xuhua Xia at xxia@uottawa.ca"

  Private Sub TestToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TestToolStripMenuItem.Click
#If TARGET = "LINUX" Then
    Call MsgBox("Todo: Relative abundance of splicing isoforms.")
#Else
    frmCanvas.ShowDialog()
#End If
  End Sub

  Private Sub mnuFileExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileExit.Click
    Me.Close()
  End Sub

  Private Sub mnuFileFastqToFas_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileFastqToFas.Click
    Dim sFastqFile As String = ""
    Dim sFasFile As String = "", sDir As String
    Dim sOut As String = "", sErr As String = ""
    Dim NumFasFile As Integer

    If dlgFastqToFas.GetFastqToFasParam(sFastqFile, sFasFile) Then
      RichTextBox1.Text = "Writing " & sFastqFile & " to FASTA file" & IIf(NumFasFile = 1, ".", "s.")
      ToolStripStatusLabel1.ForeColor = Color.Red
      ToolStripStatusLabel1.Text = "Working..."
      ToolStripStatusLabel2.Text = sFastqFile

      sDir = Path.GetDirectoryName(sFastqFile)
      'Try
      If FastqToFas(sFastqFile, sFasFile, ToolStripProgressBar1) Then
        sOut = "The FASTQ file " & sFastqFile & " has been saved to " & sFasFile & " in the directory: " & Path.GetDirectoryName(sFasFile) & vbCrLf
        RichTextBox1.Text = sOut
      End If
      'Catch ex As Exception
      '  MsgBox("Error Encountered!" & CRCR & "1. " & sErr & CRCR & "2. " & ex.ToString & CRCR & mErrReport, vbInformation, "Error")
      'End Try
      ToolStripStatusLabel2.Text = ""
      ToolStripStatusLabel1.ForeColor = Color.Black
      ToolStripStatusLabel1.Text = "Ready"
    End If
  End Sub

  Private Sub mnuFileSRAtoFASTQ_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileSRAtoFASTQ.Click
    Dim sSRAFile() As String, sFastqOutDir As String = "", sOut As String = "", sErr As String = ""
    Dim bPaired As Boolean, bAligned As Boolean
    Dim NumSraFile As Integer
    Dim I As Integer

    If dlgSraToFastq.GetSraToFastqParam(sSRAFile, sFastqOutDir, NumSraFile) Then
      RichTextBox1.Text = "The job is running. This window will be updated when the job is finished."
      ToolStripStatusLabel1.ForeColor = Color.Red
      ToolStripStatusLabel1.Text = "Working..."
      If NumSraFile = 1 Then
        ToolStripStatusLabel2.Text = sSRAFile(0)
      Else
        ToolStripStatusLabel2.Text = NumSraFile & " files to dump."
      End If
      Try
        If NumSraFile = 1 Then
          If GetSraInfo(sSRAFile(0), bPaired, bAligned, "", sErr, 0, False) Then
            If bPaired Then
              If MsgBox("The SRA file: " & sSRAFile(0) & " contains paired reads. Do you want to dump them into two separate files?", vbYesNo) = vbNo Then
                bPaired = False
              End If
            End If
            If SRA2FASTQ(sSRAFile(0), sFastqOutDir, bPaired, bAligned, sOut) Then
              RichTextBox1.Text = sOut
            End If
          Else
            MsgBox("Error in GetSraInfo", vbOKOnly)
            Exit Sub
          End If
        Else
          Dim sb = New StringBuilder
          ToolStripProgressBar1.Minimum = 0
          ToolStripProgressBar1.Maximum = NumSraFile
          For I = 0 To NumSraFile - 1
            If GetSraInfo(sSRAFile(I), bPaired, bAligned, "", sErr, 0, False) Then
              sb.Append(sSRAFile(I) & vbCrLf)
              If SRA2FASTQ(sSRAFile(I), sFastqOutDir, bPaired, bAligned, sOut) Then
                sb.Append(sOut & CRCR)
              End If
            Else
              sb.Append("Error in running GetSraInfo on " & sSRAFile(I) & vbCrLf)
            End If
            ToolStripProgressBar1.Value = I
          Next
          RichTextBox1.Text = sb.ToString
          sb.Clear()
          sb = Nothing
        End If
      Catch ex As Exception
        MsgBox("Error Encountered!" & CRCR & "1. " & sErr & CRCR & "2. " & ex.ToString & CRCR & mErrReport, vbInformation, "Error")
      End Try

      ToolStripProgressBar1.Value = 0
      ToolStripStatusLabel2.Text = ""
      ToolStripStatusLabel1.ForeColor = Color.Black
      ToolStripStatusLabel1.Text = "Ready"
    End If
  End Sub

  Private Sub frmStart_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    Dim sSRAtoolkitDir As String = Path.DirectorySeparatorChar & "NCBI" & Path.DirectorySeparatorChar 'relative to the startupPath of ARSDA.exe
    Dim sBlastDir As String = Path.DirectorySeparatorChar & "NCBI" & Path.DirectorySeparatorChar 'relative to the startupPath of ARSDA.exe
    Dim sIniFile As String = Application.StartupPath & Path.DirectorySeparatorChar & "ARSDA.ini"
    'Double-quoted just in case the path contains space
    'fastqDump = Chr(34) & Application.StartupPath & sSRAtoolkitDir & fastqDump & Chr(34)
    'samDump = Chr(34) & Application.StartupPath & sSRAtoolkitDir & samDump & Chr(34)
    'sraPileup = Chr(34) & Application.StartupPath & sSRAtoolkitDir & sraPileup & Chr(34)
    'sraStat = Chr(34) & Application.StartupPath & sSRAtoolkitDir & sraStat & Chr(34)
    'vdbDump = Chr(34) & Application.StartupPath & sSRAtoolkitDir & vdbDump & Chr(34)
    'blastnVdb = Chr(34) & Application.StartupPath & sSRAtoolkitDir & blastnVdb & Chr(34)

    'BLASTn = Chr(34) & Application.StartupPath & sBlastDir & BLASTn & Chr(34)
    'BLASTdbcheck = Chr(34) & Application.StartupPath & sBlastDir & BLASTdbcheck & Chr(34)
    'BLASTdbcmd = Chr(34) & Application.StartupPath & sBlastDir & BLASTdbcmd & Chr(34)
    'BLASTformatter = Chr(34) & Application.StartupPath & sBlastDir & BLASTformatter & Chr(34)
    'makeBLASTdb = Chr(34) & Application.StartupPath & sBlastDir & makeBLASTdb & Chr(34)
    Dim sInfo As String = "ARSDA is a software package written and maintained by Prof. Xuhua Xia at University of Ottawa (xxia@uottawa.ca)" & CRCR
    sInfo = sInfo & "1. It is for analyzing high-throughput sequecing data, especially RNS-Seq data" & vbCrLf
    sInfo = sInfo & "2. It runs best with 32 GB of RAM, but works well with 16GB of RAM for RNA-seq data from prokaryotes." & vbCrLf
    sInfo = sInfo & "3. All three versions (Win-64, Macintosh and Linux) are available at http://dambe.bio.uottawa.ca/ARSDA/ARSDA.aspx" & vbCrLf
    sInfo = sInfo & "4. A quick-start tutorial is available at http://dambe.bio.uottawa.ca/ARSDA/QuickStart.pdf" & vbCrLf
    sInfo = sInfo & "5. Sample data files for quantifying gene expression in various organisms are available at http://coevol.rdc.uottawa.ca/" & vbCrLf
    sInfo = sInfo & "6. ARSDA is offerred free to all researchers, but without any warranty. However, I do provide quick response to user queries."
    Me.RichTextBox1.Text = sInfo
    fastqDump = Application.StartupPath & sSRAtoolkitDir & fastqDump
    'samDump = Application.StartupPath & sSRAtoolkitDir & samDump
    'sraPileup = Application.StartupPath & sSRAtoolkitDir & sraPileup
    sraStat = Application.StartupPath & sSRAtoolkitDir & sraStat
    vdbDump = Application.StartupPath & sSRAtoolkitDir & vdbDump
    blastnVdb = Application.StartupPath & sSRAtoolkitDir & blastnVdb

    BLASTn = Application.StartupPath & sBlastDir & BLASTn
    BLASTdbcheck = Application.StartupPath & sBlastDir & BLASTdbcheck
    BLASTdbcmd = Application.StartupPath & sBlastDir & BLASTdbcmd
    BLASTformatter = Application.StartupPath & sBlastDir & BLASTformatter
    makeBLASTdb = Application.StartupPath & sBlastDir & makeBLASTdb
    If File.Exists(sIniFile) Then
      Dim LineArray() As String = File.ReadAllLines(sIniFile)
      Dim Field() As String
      Dim I As Integer
      For I = 0 To UBound(LineArray)
        Field = Split(LineArray(I), "=")
        Select Case Trim(Field(0))
          Case "InputDir"
            sInputDir = Trim(Field(1))
          Case "NewDataDir"
            sNewDataDir = Trim(Field(1))
          Case "ResultDir"
            sResultDir = Trim(Field(1))
        End Select
      Next
    Else
      'Write out to ARSDA.ini
      Dim sOut As String
      sInputDir = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile)
      sNewDataDir = sInputDir
      sResultDir = sInputDir
      sOut = "InputDir=" & sInputDir & vbCrLf & "NewDataDir=" & sNewDataDir & vbCrLf & "ResultDir=" & sResultDir
      File.WriteAllText(Application.StartupPath & "\ARSDA.ini", sOut)
    End If
    'Access command-line arguments
    'Dim I As Integer = 1
    'Dim sOut As String = ""
    'For Each argument As String In My.Application.CommandLineArgs
    '  sOut = sOut & I & argument & vbCrLf
    'Next
    'MsgBox(sOut)
    'Me.Close()
  End Sub

  Private Sub mnuDbInfoBlastDB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuDbInfoBlastDB.Click
    Dim sArg As String = "", sBlastDB As String, sWorkDir As String, sFN As String
    Dim sOut As String = "", sErr As String = ""

    sBlastDB = GetOpenFileName("Open BLAST database", "nin,pin", OpenFileDialog1, sInputDir)
    If sBlastDB = "" Then
      Exit Sub
    End If
    sFN = GetFNOnly(sBlastDB)
    sWorkDir = Path.GetDirectoryName(sBlastDB)
    sArg = sArg & " -db " & sFN & " -info"
    ToolStripStatusLabel1.ForeColor = Color.Red
    ToolStripStatusLabel1.Text = "Working"
    ToolStripStatusLabel2.Text = sBlastDB
    RichTextBox1.Text = "Get information of " & sFN & CRCR & "This display will be updated when the job is finished" & vbCrLf
    Try
      If RunExeAndWait(BLASTdbcmd, sArg, sWorkDir, True, sOut) Then
        RichTextBox1.Text = sOut
      Else
        RichTextBox1.Text = "Error in running RunExeAndWait:" & vbCrLf & sErr
      End If
    Catch ex As Exception
      MsgBox("Error Encountered!" & CRCR & "1. " & sErr & CRCR & "2. " & ex.ToString & CRCR & mErrReport, vbInformation, "Error")
    End Try

    ToolStripStatusLabel2.Text = ""
    ToolStripStatusLabel1.ForeColor = Color.Black
    ToolStripStatusLabel1.Text = "Ready"


  End Sub




  Private Sub Test2ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Test2ToolStripMenuItem.Click
    Dim i As Integer, x(35) As Integer, y(35, 1) As Double, y2(35) As Double
    Dim numPoint As Integer = 36

    For i = 0 To numPoint - 1
      x(i) = i * 5.0
      y(i, 0) = Math.Sin(i * Math.PI / 15.0) * 16.0
      y(i, 1) = y(i, 0) * 1.5
    Next i

    'Call frmZDGraphics.DrawGraph(x, y, numPoint, 1, "X", "Y1", frmZDGraphics.enumChartType.Bar, "my Title")
    'Dim XX As Double() = Array.ConvertAll(x, New Converter(Of Integer, Double)(AddressOf Double.Parse))
    'Dim YY As Double(,) = Array.ConvertAll(y, New Converter(Of Integer(), Double)(AddressOf Double.Parse))
    'Call frmZDGraphics.DrawGraph(XX, YY, numPoint, 2, "X", "Y", frmZDGraphics.enumChartType.Bar, "", "Y1,Y2")
    Call frmZDGraphics.DrawGraph(x, y, numPoint, 2, "X", "Y1", frmZDGraphics.enumChartType.Line, "my Title", "Y1,Y2")
  End Sub

  Private Sub mnuFileSRA_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileSRAinfo.Click
    Dim sSRAFile As String = ""
    Dim sOut As String = "", sErr As String = ""
    Dim NumQualCh As Integer, QualVal() As Double, QualCount() As Double
    Dim bPaired As Boolean, bAligned As Boolean
    Dim bReadQuality As Boolean

    If Not dlgSraInfo.GetSraInfoParam(sSRAFile, bReadQuality) Then
      Exit Sub
    End If

    RichTextBox1.Text = "The job is running. This window will be updated when the job is finished."
    ToolStripStatusLabel1.ForeColor = Color.Red
    ToolStripStatusLabel1.Text = "Working..."
    ToolStripStatusLabel2.Text = sSRAFile
    Try
      If GetSraInfo(sSRAFile, bPaired, bAligned, sOut, sErr, 10, True, NumQualCh, QualVal, QualCount) Then
        RichTextBox1.Text = sOut
        If bReadQuality Then
#If TARGET = "LINUX" Then
          Call frmZDGraphics.DrawGraph(QualVal, QualCount, NumQualCh, 1, "Quality index", "Count", frmZDGraphics.enumChartType.Bar)
#Else
          Call frmGraphics.DrawGraph(QualVal, QualCount, NumQualCh, "Quality index", "Count", DataVisualization.Charting.SeriesChartType.Column)
#End If
        End If
      Else
        RichTextBox1.Text = sErr
      End If
    Catch ex As Exception
      MsgBox("Error Encountered!" & CRCR & "1. " & sErr & CRCR & "2. " & ex.ToString & CRCR & mErrReport, vbInformation, "Error")
    End Try
    ToolStripStatusLabel2.Text = ""
    ToolStripStatusLabel1.ForeColor = Color.Black
    ToolStripStatusLabel1.Text = "Ready"
  End Sub

  'makeblastdb does not have numthrread option
  Private Sub mnuDbCreateBlast_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuDbCreateBlast.Click
    Dim sFasFile() As String, sBlastDBName As String = "", sResultDir As String = ""
    Dim bIsNuc As Boolean, bMultFile As Boolean
    'makeblastdb –in mydb.fsa –dbtype nucl –parse_seqids 

    If dlgFasToBlastDB.GetFasToBlastDbParam(sFasFile, sBlastDBName, sResultDir, bIsNuc, bMultFile) Then
      Dim sOut As String = ""
      ToolStripStatusLabel1.ForeColor = Color.Red
      ToolStripStatusLabel1.Text = "Working"
      'ToolStripStatusLabel2.Text = sFasFile
      RichTextBox1.Text = "The job is running. This display will be updated when the job is finished." & vbCrLf
      Try
        If bMultFile Then
          If CreateBlastDBMult(makeBLASTdb, sFasFile, sResultDir, bIsNuc, sOut) Then
            RichTextBox1.Text = sOut
          Else
            RichTextBox1.Text = "Error encountered:" & CRCR & sOut
          End If
        Else
          If CreateBlastDB(makeBLASTdb, sFasFile(0), sBlastDBName, sResultDir, bIsNuc, sOut) Then
            RichTextBox1.Text = sOut
          Else
            RichTextBox1.Text = "Error encountered:" & CRCR & sOut
          End If
        End If
      Catch ex As Exception
        MsgBox("Error Encountered!" & CRCR & ex.ToString & CRCR & mErrReport, vbInformation, "Error")
      End Try
      ToolStripStatusLabel2.Text = ""
      ToolStripStatusLabel1.ForeColor = Color.Black
      ToolStripStatusLabel1.Text = "Ready"
    End If

  End Sub

  Private Sub mnuFileSaveBuffer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileSaveBuffer.Click
    Dim sOutFile As String = GetSaveFileName("Save...", "txt", SaveFileDialog1, sResultDir)
    If sOutFile <> "" Then
      File.WriteAllText(sOutFile, RichTextBox1.Text)
      MsgBox("The text in the display has been written to file: " & sOutFile, vbInformation, "Info")
    End If
  End Sub


  Private Sub mnuAnaBlastGE_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAnaBlastGE.Click

    Dim sFasFileQuery As String, sBlastDB As String, sBlastDbDir As String, sOutFileGE As String
    Dim Evalue As Double
    Dim WordLen As Integer, NumCPU As Integer, MaxTarget As Integer
    Dim sStrand As String
    Dim bFasPlus As Boolean, bUngapped As Boolean
    Dim sErr As String = "", sTmp As String
    Dim iTmp As Integer
    Dim sBLASTnOutFile As String
    Dim sArg As String
    If dlgBlastFasToGE.GetBlastFasGEParam(sBlastDB, sBlastDbDir, sFasFileQuery, sOutFileGE, Evalue, WordLen, sStrand, bUngapped, MaxTarget, NumCPU, bFasPlus) Then
      ToolStripStatusLabel1.ForeColor = Color.Red
      ToolStripStatusLabel1.Text = "working"
      ToolStripStatusLabel2.Text = sFasFileQuery
      sTmp = "This is a two-step process:" & CRCR & "1. Match/align query sequences against sequences in BLAST database." & vbCrLf & "2. Compile/present gene expression result." & CRCR
      sTmp = sTmp & "Once the job is finished, this display window will be updated with gene expression results."
      RichTextBox1.Text = sTmp
      sTmp = ""

      Try
        'sBlastnOutfile: intermediate file containing the comma-delimited blastn_vdb output (without column annotation)
        'Query,DbSeq,%match,matchLen,NumMismatch,GO,q.start,q.end,dbSeqStart, dbSeqEnd, evalue, bit score
        'thrL,gnl|SRA|SRR1536586.6379132.1,100.00,49,0,0,18,66,1,49,2e-018,91.6
        'thrL,gnl|SRA|SRR1536586.6356742.1,100.00,49,0,0,18,66,1,49,2e-018,91.6
        '...
        'thrL,gnl|SRA|SRR1536586.4527718.1,100.00,36,0,0,31,66,1,36,3e-011,67.6
        'thrA,gnl|SRA|SRR1536586.6502929.1,100.00,50,0,0,1822,1871,1,50,3e-017,93.5
        'thrA,gnl|SRA|SRR1536586.6502478.1,100.00,50,0,0,2360,2409,1,50,3e-017,93.5
        'THe above output is produced by
        'blastn -db SRR1536586 -query testblast.fas -evalue 0.0000000001 -word_size 18 -ungapped -strand both -max_target_seqs 1000000 -outfmt 10 -num_threads NumCPU -out testBlast.out
        If Strings.Left(sBlastDB, 1) = Chr(34) Then 'multiple blast db
          sBLASTnOutFile = sFasFileQuery & "_MultBlastDb_blast.out"
        Else
          sBLASTnOutFile = sFasFileQuery & "_" & sBlastDB & "_blast.out"
        End If

        sArg = " -db " & sBlastDB & " -query " & sFasFileQuery & " -evalue " & Evalue & " -word_size " & WordLen & IIf(bUngapped, " -ungapped", "") & " -strand " & sStrand & " -max_target_seqs " & MaxTarget & " -outfmt 10 -num_threads " & NumCPU & " -out " & sBLASTnOutFile

        ToolStripStatusLabel2.Text = "BLASTing..."
        If RunExeAndWait(BLASTn, sArg, sBlastDbDir, False) Then
          If File.Exists(sBLASTnOutFile) Then
            If FileLen(sBLASTnOutFile) < 10 Then
              RichTextBox1.Text = "Warning:" & CRCR & "The match/align file: " & sBLASTnOutFile & " is empty. You may have set the E-value too low."
              Exit Sub
            End If
          Else
            RichTextBox1.Text = "Warning:" & vbCrLf & sBLASTnOutFile & " is not produced. You may have set the E-value too low."
            Exit Sub
          End If
        Else
          RichTextBox1.Text = "blastn failed to run."
          Exit Sub
        End If

        RichTextBox1.Text = RichTextBox1.Text & CRCR & "Step 1 has finished. Now processing the intermediate results..."
        Application.DoEvents()
        Dim sSeq() As String, sName() As String, SeqLen() As Integer, NumSeq As Integer
        ReadFasStr(File.ReadAllText(sFasFileQuery), sSeq, sName, NumSeq)
        ReDim SeqLen(NumSeq - 1)
        For i = 0 To NumSeq - 1
          SeqLen(i) = sSeq(i).Length
        Next
        Erase sSeq
        'If ProcessBlastOutForGE(sBLASTnOutFile, sOutFileGE, True, ToolStripProgressBar1) Then
        If ProcessBlastOutForGE2(sName, SeqLen, NumSeq, sBLASTnOutFile, sOutFileGE, bFasPlus, ToolStripProgressBar1) Then
          MsgBox("The output has been saved to file: " & sOutFileGE & " but will also be displayed on the display window. " & vbCrLf, vbOKOnly)
          sTmp = "Gene expression output:" & CRCR & "Query file: " & sFasFileQuery & vbCrLf & "BLAST DB: " & sBlastDB & vbCrLf & "Output file: " & sOutFileGE & vbCrLf & "BLASTn file: " & sBLASTnOutFile & CRCR
          sTmp = sTmp & File.ReadAllText(sOutFileGE)
          RichTextBox1.Text = sTmp
          'Kill(sBLASTnOutFile) already killed in ProcessBlastOutForGE
        Else
          MsgBox("Error encountered when running ProcessBlastOutForGE with the following files:" & vbCrLf & "BLAST DB: " & sBlastDB & vbCrLf & "Query FASTA file: " & sFasFileQuery & vbCrLf & "Match Outfile: " & sBLASTnOutFile, vbOKOnly)
        End If
      Catch ex As Exception
        If sErr <> "" Then
          MsgBox("Error Encountered!" & CRCR & "1. " & sErr & CRCR & "2. " & ex.ToString & CRCR & mErrReport, vbInformation, "Error")
        Else
          MsgBox("Error Encountered!" & CRCR & ex.ToString & CRCR & mErrReport, vbInformation, "Error")
        End If
      End Try

      ToolStripStatusLabel2.Text = ""
      ToolStripStatusLabel1.ForeColor = Color.Black
      ToolStripStatusLabel1.Text = "Ready"
    End If
  End Sub

  Private Sub mnuFileSRAtoFASTA_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileSRAtoFASTA.Click
    Dim I As Integer
    Dim sSRAFile() As String, sOutDir As String = "", sOut As String = "", sErr As String = ""
    Dim bPaired As Boolean, bAligned As Boolean
    Dim NumSraFile As Integer

    RichTextBox1.Text = "The job is running. This window will be updated when the job is finished."
    ToolStripStatusLabel1.ForeColor = Color.Red
    ToolStripStatusLabel1.Text = "Working..."

    Try
      If dlgSraToFAS.GetSraToFasParam(sSRAFile, sOutDir, NumSraFile) Then
        If NumSraFile = 1 Then
          ToolStripStatusLabel2.Text = sSRAFile(0)
        Else
          ToolStripStatusLabel2.Text = NumSraFile & "files to dump."
        End If
        ToolStripProgressBar1.Minimum = 0
        ToolStripProgressBar1.Maximum = NumSraFile
        Dim sb = New StringBuilder
        For I = 0 To NumSraFile - 1
          sb.Append(sSRAFile(I) & vbCrLf)
          If GetSraInfo(sSRAFile(I), bPaired, bAligned, "", sErr, 0, False) Then
            If SRA2FASTA(sSRAFile(I), bPaired, bAligned, sOut) Then
              sb.Append(sOut & CRCR)
            End If
          Else
            sb.Append("Error when running GetSraInfo on " & sSRAFile(I) & CRCR)
          End If
          ToolStripProgressBar1.Value = I
        Next
        RichTextBox1.Text = sb.ToString
        ToolStripProgressBar1.Value = 0
        sb.Clear()
        sb = Nothing
      End If
    Catch ex As Exception
      MsgBox("Error Encountered!" & CRCR & "1. " & sErr & CRCR & "2. " & ex.ToString & CRCR & mErrReport, vbInformation, "Error")
    End Try

    ToolStripStatusLabel2.Text = ""
    ToolStripStatusLabel1.ForeColor = Color.Black
    ToolStripStatusLabel1.Text = "Ready"
  End Sub

  Private Sub mnuDbBlastLocalRibosomalProfile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

  End Sub

  Private Sub mnuAnaSraGE_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuAnaSraGE.Click
    'blastn_vdb -db SRR2035445.sra -query test.fas -evalue 0.00001 -word_size 20 -num_alignments 0 -num_threads 4 -out WS20NumAln0B.out

    Dim sSraFile As String, sFasFile As String, sOutFileGE As String
    Dim sBlastn_vdbOutfile As String = Path.GetTempFileName  'This is useful for debugging, i.e., if parsing the result fails....
    Dim Evalue As Double
    Dim WordLen As Integer, NumCPU As Integer, MaxTarget As Integer 'MaxTarget = 0: no alignment output to save text processing.
    Dim sErr As String, sStrand As String
    Dim bUngapped As Boolean

    If MsgBox("This function may take a day or two to finish and may consume a lot of memory. You are adviced to close all non-essential programs. Proceed?", vbYesNo) = vbNo Then
      Exit Sub
    End If
    ' If dlgBlastFasToGE.GetBlastFasGEParam(sBlastDB, sFasFileQuery, sOutFileGE, Evalue, WordLen, sStrand, bUngapped, MaxTarget, NumCPU, bIsFasPlicateGene) Then
    If dlgSraFasToGE.GetSraFasToGE(sFasFile, sSraFile, sOutFileGE, Evalue, WordLen, sStrand, bUngapped, NumCPU, MaxTarget) Then
      RichTextBox1.Text = "The job is running. This window will be updated when the job is finished."
      ToolStripStatusLabel1.ForeColor = Color.Red
      ToolStripStatusLabel1.Text = "Working..."
      ToolStripStatusLabel2.Text = sSraFile

      '
      'sBlastn_vdbOutfile: intermediate file containing the comma-delimited blastn_vdb output (without column annotation)
      'Query,DbSeq,%match,matchLen,NumMismatch,GO,q.start,q.end,dbSeqStart, dbSeqEnd, evalue, bit score
      'thrL,gnl|SRA|SRR1536586.6379132.1,100.00,49,0,0,18,66,1,49,2e-018,91.6
      'thrL,gnl|SRA|SRR1536586.6356742.1,100.00,49,0,0,18,66,1,49,2e-018,91.6
      '...
      'thrL,gnl|SRA|SRR1536586.4527718.1,100.00,36,0,0,31,66,1,36,3e-011,67.6
      'thrA,gnl|SRA|SRR1536586.6502929.1,100.00,50,0,0,1822,1871,1,50,3e-017,93.5
      'thrA,gnl|SRA|SRR1536586.6502478.1,100.00,50,0,0,2360,2409,1,50,3e-017,93.5
      'THe above output is produced by
      'blastn_vdb -db SRR1536586.sra -query testblast.fas -word_size 18 -out testBlast.out -evalue 0.0000000001 -outfmt 10 -max_target_seqs 1000000

      Dim sArg As String = " -db " & sSraFile & " -query " & sFasFile & " -evalue " & Evalue & " -word_size " & WordLen & IIf(bUngapped, " -ungapped", "") & " -strand " & sStrand & " -max_target_seqs " & MaxTarget & " -outfmt 10 -num_threads " & NumCPU & " -out " & sBlastn_vdbOutfile
      Dim sPath As String = Path.GetDirectoryName(sFasFile)

      Try
        'XX Check
        If RunExeAndWait(blastnVdb, sArg, sPath, False) = 0 Then
          If FileLen(sBlastn_vdbOutfile) < 1000 Then
            RichTextBox1.Text = "Error in SraFasToGE: output file " & sBlastn_vdbOutfile & " is not produced."
          End If
        Else
          RichTextBox1.Text = "blastn_vdb failed to run."
        End If

      Catch ex As Exception
        MsgBox("Error encountered when blasting with the following files:" & vbCrLf & "SRA file: " & sSraFile & vbCrLf & "FAS file: " & sFasFile & vbCrLf & "Match Outfile: " & sBlastn_vdbOutfile & CRCR & "1. " & sErr & CRCR & "2. " & ex.ToString & CRCR & mErrReport, vbInformation, "Error")
      End Try

      Dim sSeq() As String, sName() As String, SeqLen() As Integer, NumSeq As Integer
      ReadFasStr(File.ReadAllText(sFasFile), sSeq, sName, NumSeq)
      ReDim SeqLen(NumSeq - 1)
      For i = 0 To NumSeq - 1
        SeqLen(i) = sSeq(i).Length
      Next
      Erase sSeq
      If ProcessBlastOutForGE2(sName, SeqLen, NumSeq, sBlastn_vdbOutfile, sOutFileGE, False, ToolStripProgressBar1) Then
        MsgBox("The output has been saved to file: " & sOutFileGE & " but will also be displayed on the display window. " & vbCrLf, vbOKOnly)
        RichTextBox1.Text = File.ReadAllText(sOutFileGE)
        Kill(sBlastn_vdbOutfile)
      Else
        MsgBox("Error encountered when running SraFasToGE with the following files:" & vbCrLf & "SRA file: " & sSraFile & vbCrLf & "FAS file: " & sFasFile & vbCrLf & "Match Outfile: " & sBlastn_vdbOutfile, vbOKOnly)
      End If
      ToolStripStatusLabel2.Text = ""
      ToolStripStatusLabel1.ForeColor = Color.Black
      ToolStripStatusLabel1.Text = "Ready"
    End If
  End Sub

  Private Function CheckSRAFileName(ByVal sSRAFileName As String) As Boolean
    Dim bGoodName As Boolean
    bGoodName = (UCase(sSRAFileName) Like "?RR*######.SRA") 'DRR*, ERR*, SRR*
    If Not bGoodName Then
      Dim sInfo As String = "To ensure accuracy, only .sra file names in the form of SRR#######.sra are accepted , only. These are the file names that researchers deposit and download from database hosts such as NCBI. If you are sure that nothing in the file has been changed in the content of the file, please rename the file back to its original and call this function again."
      Call MsgBox(sInfo, vbOKOnly)
    End If
    Return bGoodName
  End Function

  Private Sub mnuNCBIDownloadBlastDB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuNCBIDownloadBlastDB.Click
    'The URL should end with '/'
    Dim UriBlast As New Uri("ftp://ftp.ncbi.nlm.nih.gov/blast/db/")
    frmFTP.FtpToNCBI(UriBlast)
  End Sub

  Private Sub NcbiDownloadSRAFiles_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuNCBIDownloadSRA.Click
    'The URL should end with '/'
    Dim UriBlast As New Uri("ftp://ftp-trace.ncbi.nlm.nih.gov/sra/sra-instant/reads/")
    frmFTP.FtpToNCBI(UriBlast)

  End Sub

  Private Sub mnuEditUndo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuEditUndo.Click
    If RichTextBox1.CanUndo Then
      RichTextBox1.Undo()
    Else
      MsgBox("Nothing to undo.")
    End If
  End Sub

  Private Sub mnuEditRedo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuEditRedo.Click
    If RichTextBox1.CanRedo Then
      RichTextBox1.Redo()
    Else
      MsgBox("Nothing to redo.")
    End If

  End Sub

  Private Sub mnuEditCut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuEditCut.Click
    RichTextBox1.Cut()
  End Sub

  Private Sub mnuEditPaste_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuEditPaste.Click
    Dim BitMapFormat As DataFormats.Format = DataFormats.GetFormat(DataFormats.Bitmap)
    Dim TextFormat As DataFormats.Format = DataFormats.GetFormat(DataFormats.Text)
    If Clipboard.ContainsImage Then
      RichTextBox1.Paste(BitMapFormat)
    ElseIf Clipboard.ContainsText Then
      RichTextBox1.Paste(TextFormat)
    End If

  End Sub

  Private Sub mnuEditFind_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuEditFind.Click
    RichTextBox1.DeselectAll()
    Dim sSearchText As String = "", bMatchCase As Boolean, bWholeWord As Boolean, bSearchDown As Boolean
    If dlgFind.GetFindParam(sSearchText, bMatchCase, bWholeWord, bSearchDown) Then
      FindInRTF(RichTextBox1, sSearchText, bMatchCase, bWholeWord, bSearchDown)
      mPrevSearch = sSearchText
      mMatchCase = bMatchCase
      mWholeWord = bWholeWord
      mSearchDown = bSearchDown
    End If
  End Sub

  Private Sub mnuEditFindNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuEditFindNext.Click
    If mPrevSearch = "" Then
      Dim sSearchText As String = "", bMatchCase As Boolean, bWholeWord As Boolean, bSearchDown As Boolean
      If dlgFind.GetFindParam(sSearchText, bMatchCase, bWholeWord, bSearchDown) Then
        FindInRTF(RichTextBox1, sSearchText, bMatchCase, bWholeWord, bSearchDown)
        mPrevSearch = sSearchText
        mMatchCase = bMatchCase
        mWholeWord = bWholeWord
        mSearchDown = bSearchDown
      End If
    Else
      FindNextInRTF(RichTextBox1, mPrevSearch, mMatchCase, mWholeWord, mSearchDown)
    End If
  End Sub

  Private Sub RichTextBox1_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles RichTextBox1.KeyDown
    'RichTextBox1.DeselectAll()

  End Sub

  Private Sub RichTextBox1_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles RichTextBox1.KeyUp
    If e.Modifiers = Keys.Control And e.KeyCode = Keys.F Then
      Dim sSearchText As String = "", bMatchCase As Boolean, bWholeWord As Boolean, bSearchDown As Boolean
      If dlgFind.GetFindParam(sSearchText, bMatchCase, bWholeWord, bSearchDown) Then
        FindInRTF(RichTextBox1, sSearchText, bMatchCase, bWholeWord, bSearchDown)
        mPrevSearch = sSearchText
        mMatchCase = bMatchCase
        mWholeWord = bWholeWord
        mSearchDown = bSearchDown
      End If
    ElseIf e.KeyCode = Keys.F3 Then
      If mPrevSearch = "" Then
        Dim sSearchText As String = "", bMatchCase As Boolean, bWholeWord As Boolean, bSearchDown As Boolean
        If dlgFind.GetFindParam(sSearchText, bMatchCase, bWholeWord, bSearchDown) Then
          FindInRTF(RichTextBox1, sSearchText, bMatchCase, bWholeWord, bSearchDown)
          mPrevSearch = sSearchText
          mMatchCase = bMatchCase
          mWholeWord = bWholeWord
          mSearchDown = bSearchDown
        End If
      Else
        FindNextInRTF(RichTextBox1, mPrevSearch, mMatchCase, mWholeWord, mSearchDown)
      End If
    End If
  End Sub

  Private Sub mnuEditCopyToEXCEL_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuEditCopyToEXCEL.Click
    Dim CopiedStr As String, StartVal As Integer
    Clipboard.Clear()
    CopiedStr = RichTextBox1.SelectedText
    If Trim$(CopiedStr) = "" Then
      Call MsgBox("You did not highlight anything to copy.", vbInformation)
    Else
      CopiedStr = Sp2Tab(CopiedStr)
      'Check if there are more than 256 columns
      Dim OneLine As String, LineLen As Integer
      StartVal = InStr(CopiedStr, vbCrLf)
      If StartVal > 0 Then
        OneLine = Strings.Left(CopiedStr, StartVal - 1)
        LineLen = Len(OneLine)
        OneLine = Replace(OneLine, vbTab, "")
        If LineLen - Len(OneLine) > 255 Then 'more than 256 columns
          If MsgBox("There are more than 256 columns. Do you want to transpose to fit the data to an excel sheet?", vbYesNo) = vbYes Then
            CopiedStr = TransStrMat(CopiedStr, vbCrLf)
          End If
        End If
      End If
      Clipboard.SetText(CopiedStr)
    End If

  End Sub

  Private Sub mnuEditCopyNColToExcel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuEditCopyNColToExcel.Click
    Dim NumCol As Integer
    Dim CopiedStr As String

    NumCol = Val(InputBox("How many rightmost columns to copy?", "Input", 2))
    If NumCol = 0 Then Exit Sub

    Clipboard.Clear()
    CopiedStr = RichTextBox1.SelectedText
    CopiedStr = Sp2Tab(CopiedStr)
    CopiedStr = GetRightMostCols(CopiedStr, NumCol)
    Clipboard.SetText(CopiedStr)

  End Sub

  Private Sub mnuEditChangeFont_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuEditChangeFont.Click
    FontDialog1.ShowDialog()
    RichTextBox1.Font = FontDialog1.Font
  End Sub

  Private Sub mnuEditChangeColor_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuEditChangeColor.Click
    ColorDialog1.ShowDialog()
    RichTextBox1.ForeColor = ColorDialog1.Color
  End Sub

  Private Sub mnuFileFastqToFasPlus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileFastqToFasPlus.Click
    Dim sFastqFile() As String
    Dim sFasFileOrDir As String = ""
    Dim sOut As String = ""
    Dim I As Integer, NumFastQFile As Integer
    Dim bNoAmbiguousNuc As Boolean = False

    RichTextBox1.Text = "The job is running. This display will be updated when the job is finished." & vbCrLf
    If dlgFastqToSeqGr.GetFastqToSeqGrParam(sFastqFile, sFasFileOrDir, NumFastQFile, bNoAmbiguousNuc) Then
      Dim NumUniqueSeq As Integer, NumUniqueGrSize As Integer, UniqueGrSize() As Double, FreqGrSize() As Double
      ToolStripStatusLabel1.ForeColor = Color.Red
      ToolStripStatusLabel1.Text = "Working..."
      If NumFastQFile = 1 Then
        ToolStripStatusLabel2.Text = sFastqFile(0)
      End If
      Application.DoEvents()
      Try
        If NumFastQFile = 1 Then
          If FastqToFasPlus(sFastqFile(0), sFasFileOrDir, sOut, NumUniqueSeq, NumUniqueGrSize, UniqueGrSize, FreqGrSize, bNoAmbiguousNuc, ToolStripProgressBar1) Then
            RichTextBox1.Text = sOut
#If TARGET = "LINUX" Then
            Call frmZDGraphics.DrawGraph(UniqueGrSize, FreqGrSize, NumUniqueGrSize, 1, "Group size", "Count", frmZDGraphics.enumChartType.Bar)
#Else
            Call frmGraphics.DrawGraph(UniqueGrSize, FreqGrSize, NumUniqueGrSize, "Group size", "Count", DataVisualization.Charting.SeriesChartType.Column)
#End If
          Else
            RichTextBox1.Text = "Error when running FastqToFasPlus."
          End If
        Else
          Dim sb As New StringBuilder
          If Strings.Right(sFasFileOrDir, 1) <> Path.DirectorySeparatorChar Then
            sFasFileOrDir = sFasFileOrDir & Path.DirectorySeparatorChar
          End If

          ToolStripProgressBar1.Minimum = 0
          ToolStripProgressBar1.Maximum = NumFastQFile
          For I = 0 To NumFastQFile - 1
            ToolStripStatusLabel2.Text = sFastqFile(I)
            If FastqToFasPlus(sFastqFile(I), sFasFileOrDir & Path.GetFileNameWithoutExtension(sFastqFile(I)) & ".fasP", sOut, NumUniqueSeq, NumUniqueGrSize, UniqueGrSize, FreqGrSize, bNoAmbiguousNuc, ToolStripProgressBar1) Then
              sb.Append(sOut & CRCR)
            Else
              sb.Append("Error when running FastqToFasPlus on " & sFastqFile(I), CRCR)
            End If
          Next
          RichTextBox1.Text = sb.ToString
          sb.Clear()
          sb = Nothing
        End If
      Catch ex As Exception
        MsgBox("Error Encountered!" & CRCR & ex.ToString & CRCR & mErrReport, vbInformation, "Error")
      End Try
      ToolStripStatusLabel2.Text = ""
      ToolStripStatusLabel1.ForeColor = Color.Black
      ToolStripStatusLabel1.Text = "Ready"
    End If

  End Sub

  Private Sub mnuFileFastqToFastqPlus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileFastqToFastqPlus.Click
    Dim sFastqFile As String = ""
    Dim sFastqPlusFile As String = ""
    Dim ReadLen As Integer
    Dim sOut As String = ""

    RichTextBox1.Text = "The job is running. This display will be updated when the job is finished." & vbCrLf
    If dlgFastqToFastqPlus.GetFastqToFastqPlusParam(sFastqFile, sFastqPlusFile, ReadLen) Then
      Dim NumUniqueSeq As Integer, NumUniqueGrSize As Integer, UniqueGrSize() As Double, FreqGrSize() As Double
      ToolStripStatusLabel1.ForeColor = Color.Red
      ToolStripStatusLabel1.Text = "Working..."
      ToolStripStatusLabel2.Text = sFastqFile
      Application.DoEvents()

      'Try
      If FastqToFastqPlus(sFastqFile, sFastqPlusFile, ReadLen, sOut, NumUniqueSeq, NumUniqueGrSize, UniqueGrSize, FreqGrSize, ToolStripProgressBar1) Then
        RichTextBox1.Text = sOut
#If TARGET = "LINUX" Then

        Call frmZDGraphics.DrawGraph(UniqueGrSize, FreqGrSize, NumUniqueGrSize, 1, "Group size", "Count", frmZDGraphics.enumChartType.Bar)
#Else
        Call frmGraphics.DrawGraph(UniqueGrSize, FreqGrSize, NumUniqueGrSize, "Group size", "Count", DataVisualization.Charting.SeriesChartType.Column)
#End If
      Else
        RichTextBox1.Text = "Error when running FastqToFasPlus."
      End If
      'Catch ex As Exception
      '  MsgBox("Error Encountered!" & CRCR & ex.ToString & CRCR & mErrReport, vbInformation, "Error")
      'End Try
      ToolStripStatusLabel2.Text = ""
      ToolStripStatusLabel1.ForeColor = Color.Black
      ToolStripStatusLabel1.Text = "Ready"
    End If

  End Sub


  Private Sub mnuToolsOption_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuToolsOption.Click
    dlgOption.ShowDialog()
  End Sub



  'This is for Mac and Linux packaging, used only by me. The current NCBI directory is always for WIN64, which is also backed up 
  '  in E:\MolBio\NCBI\ForARSDA\NCBI
  'The corresponding NCBI files for Mac and Ubuntu are in E:\MolBio\NCBI\ForARSDA directory named
  '  NCBI_Mac and NCBI_Ubuntu
  Private Sub Test4ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Test4ToolStripMenuItem.Click
    Dim sUser As String = Environment.UserName
    If sUser = "xxia" Then

#If TARGET <> "LINUX" Then
      call msgbox("You forgot to set TARGET to LINUX")
#End If
      Dim I As Integer
      Dim sHomeDir As String = "C:\Users\xxia\Documents\Visual Studio 2013\Projects\ARSDA\ARSDA\bin\x64\Release"
      Dim sNCBITarget As String = "C:\Users\xxia\Documents\Visual Studio 2013\Projects\ARSDA\ARSDA\bin\x64\Release\NCBI"
      Dim sNCBI As String = "E:\MolBio\NCBI\ForARSDA\NCBI"
      Dim sMac As String = "E:\MolBio\NCBI\ForARSDA\NCBI_Mac"
      Dim sLinux As String = "E:\MolBio\NCBI\ForARSDA\NCBI_Ubuntu"

      Dim FileListNCBI() As String = Directory.GetFiles(sNCBITarget, "*")
      Dim FileListNCBI_Mac() As String = Directory.GetFiles(sMac, "*")
      Dim FileListNCBI_Linux() As String = Directory.GetFiles(sLinux, "*")
      Dim sFileName1 As String

      'Package Mac
      For i = 0 To UBound(FileListNCBI)
        File.Delete(FileListNCBI(i))
      Next

      For i = 0 To UBound(FileListNCBI_Mac)
        sFileName1 = Path.GetFileName(FileListNCBI_Mac(i))
        File.Copy(FileListNCBI_Mac(I), sNCBITarget & "\" & sFileName1)
      Next

      If RunExeAndWait("d:\bin\7za.exe", " a ARSDA_Mac.zip *", sHomeDir, False) Then
        Call MsgBox("ARSDA_Mac.zip has been generated.")
        File.Copy("ARSDA_Mac.zip", "Y:\ARSDA_Mac.zip", True)
      Else
        Stop
      End If


      'Now package Ubuntu
      For I = 0 To UBound(FileListNCBI_Linux)
        sFileName1 = Path.GetFileName(FileListNCBI_Linux(I))
        File.Copy(FileListNCBI_Linux(I), sNCBITarget & "\" & sFileName1, True)
      Next

      If RunExeAndWait("d:\bin\7za.exe", " a ARSDA_Linux64.zip *", sHomeDir, False) Then
        Call MsgBox("ARSDA_Linux64.zip has been generated.")
        File.Copy("ARSDA_Linux64.zip", "Y:\ARSDA_Linux64.zip", True)
      Else
        Stop
      End If

      'Now put WIN64 .exe files back
      For Each f As String In Directory.GetFiles(sNCBITarget, "*")
        File.Delete(f)
      Next

      For I = 0 To UBound(FileListNCBI)
        sFileName1 = Path.GetFileName(FileListNCBI(I))
        File.Copy(sNCBI & "\" & sFileName1, FileListNCBI(I))
      Next
      Call MsgBox("WIN64 .exe files have been restored to NCBI.")

      'Now package source
      ChDrive("C")
      sHomeDir = "C:\Users\xxia\Documents\Visual Studio 2013\Projects\ARSDA"
      ChDir(sHomeDir)
      If RunExeAndWait("d:\bin\7za.exe", " a ARSDA_Src.zip *", sHomeDir, False) Then
        Call MsgBox("ARSDA_Linux64.zip is generated.")
        File.Copy("ARSDA_Src.zip", "Y:\ARSDA_Src.zip", True)
        Call MsgBox("ARSDA_Src.zip has been generated.")
      Else
        Stop
      End If

    Else
      Call MsgBox("Todo: Ribosome profiling data analysis")
    End If


    'frmTest.ShowDialog()
  End Sub

  Private Sub mnuToolsTiming_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    Dim I As Integer
    Dim Watch As Stopwatch
    Dim sSeq = "NAGACGATNNAGACGATNNACGT"
    Dim NumN As Integer
    Dim sOut As String

    Watch = Stopwatch.StartNew()
    For I = 0 To 100000
      NumN = sSeq.Count(Function(x) x = "N")
    Next
    Watch.Stop()
    sOut = Watch.Elapsed.TotalMilliseconds & " NumN = " & NumN & vbCrLf
    Watch.Start()
    For I = 0 To 100000
      NumN = sSeq.Length - Replace(sSeq, "N", "").Length
    Next
    sOut = sOut & Watch.Elapsed.TotalMilliseconds & " NumN = " & NumN
    MsgBox(sOut)
  End Sub

  Private Sub mnuToolsTiming_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuToolsTiming.Click
    Dim I As Integer, J As Integer
    Dim Watch As Stopwatch
    Dim sSeq = "ACGTTCAGACGTTCAGACGTTCAGACGTTCAG"
    Dim NumN As Integer
    Dim sOut As String
    Dim SeqByte() As Byte
    Dim tmpByte() As Byte, tmpByte2() As Byte

    Mid(sSeq, 10, 4) = "aaaa"
    MsgBox(sSeq)
    Exit Sub
    '--------

    Watch = Stopwatch.StartNew()
    NumN = 1000000
    ReDim SeqByte(63)
    For I = 0 To NumN
      tmpByte = Encoding.ASCII.GetBytes(sSeq)
      tmpByte2 = Encoding.ASCII.GetBytes(sSeq)
      Buffer.BlockCopy(tmpByte, 0, SeqByte, 0, 32)
      Buffer.BlockCopy(tmpByte2, 0, SeqByte, 32, 32)
    Next
    Watch.Stop()
    sOut = Watch.Elapsed.TotalMilliseconds & "Seqbyte = " & Encoding.ASCII.GetString(SeqByte) & vbCrLf

    Watch = Stopwatch.StartNew()
    For I = 0 To NumN
      SeqByte = Encoding.ASCII.GetBytes(sSeq)
      tmpByte2 = Encoding.ASCII.GetBytes(sSeq)
      ReDim Preserve SeqByte(63)
      Buffer.BlockCopy(tmpByte, 0, SeqByte, 32, 32)
    Next
    Watch.Stop()
    sOut = sOut & Watch.Elapsed.TotalMilliseconds & "Seqbyte = " & Encoding.ASCII.GetString(SeqByte) & vbCrLf
    MsgBox(sOut)
    Exit Sub
    '--------
    Watch = Stopwatch.StartNew()
    For I = 0 To 100000
      SeqByte = Encoding.ASCII.GetBytes(sSeq)
      For J = 0 To 63
        If SeqByte(J) = 78 Then
          NumN = J
          Exit For
        End If
      Next
    Next
    Watch.Stop()
    sOut = Watch.Elapsed.TotalMilliseconds & "ToByte: NumN = " & NumN & vbCrLf

    Watch = Stopwatch.StartNew()
    For I = 0 To 100000
      NumN = sSeq.Count(Function(x) x = "N")
    Next
    Watch.Stop()
    sOut = sOut & Watch.Elapsed.TotalMilliseconds & "Function: NumN = " & NumN & vbCrLf

    Watch.Start()
    For I = 0 To 100000
      NumN = sSeq.Length - Replace(sSeq, "N", "").Length
    Next
    Watch.Stop()
    sOut = sOut & Watch.Elapsed.TotalMilliseconds & ".Length -Replace: NumN = " & NumN & vbCrLf

    Watch.Start()
    For I = 0 To 100000
      NumN = InStr(sSeq, "N")
    Next
    Watch.Stop()
    sOut = sOut & Watch.Elapsed.TotalMilliseconds & "Instr: N occurs at " & NumN & vbCrLf

    Watch.Start()
    For I = 0 To 100000
      NumN = sSeq.IndexOf("N"c)
    Next
    Watch.Stop()
    sOut = sOut & Watch.Elapsed.TotalMilliseconds & "sSeq.IndexOf: N occurs at " & NumN & " by indexOf" & vbCrLf

    Watch.Start()
    For I = 0 To 100000
      NumN = sSeq.Length
    Next
    Watch.Stop()
    sOut = sOut & Watch.Elapsed.TotalMilliseconds & "sSeq.Length: with sSeq.Length" & vbCrLf

    Watch.Start()
    For I = 0 To 100000
      NumN = Len(sSeq)
    Next
    Watch.Stop()
    sOut = sOut & Watch.Elapsed.TotalMilliseconds & "Len(sSeq): with Len(sSeq)" & vbCrLf

    MsgBox(sOut)

  End Sub

  Private Sub mnuFileLoadTextFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileLoadTextFile.Click
    Dim sTextFile As String = GetOpenFileName("Open text file", "txt,out,fas,fasta,fastq,fq,fastaP,fastqP,bat", OpenFileDialog1, sInputDir)
    If sTextFile <> "" Then
      RichTextBox1.Text = File.ReadAllText(sTextFile)
    End If
  End Sub

  Private Sub mnuFileFastqInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileFastqInfo.Click
    Dim sFastqFile As String = "", sDir As String
    Dim bPlotBaseQual As Boolean, bPlotSeqQual As Boolean, bPlotSeqLen As Boolean

    If Not dlgFastqInfo.GetFastqInfoParam(sFastqFile, bPlotBaseQual, bPlotSeqQual, bPlotSeqLen) Then
      Exit Sub
    End If

    RichTextBox1.Text = "Working on " & sFastqFile & ". This is a slow process and the window will be updated once the job is finished."
    ToolStripStatusLabel1.ForeColor = Color.Red
    ToolStripStatusLabel1.Text = "Working..."
    ToolStripStatusLabel2.Text = sFastqFile

    sDir = Path.GetDirectoryName(sFastqFile)
    Try
      Dim FreqSeqLen() As Double, MinSeqLen As Integer, MaxSeqLen As Integer
      Dim MinQualCh As Integer, MaxQualCh As Integer, FreqBaseQuality() As Double, FreqSeqQuality() As Integer
      Dim NucFreqBySite(,) As Integer, NucFreqBySitePoor(,) As Integer, TotalNumSeq As Integer
      Dim MinSeqQuality As Integer, MaxSeqQuality As Integer
      Dim MeanQualBySiteAndNuc(,) As Double, StdQualBySiteAndNuc(,) As Double
      Dim MinSeqQualityPoor As Integer, MaxSeqQualityPoor As Integer, FreqSeqQualityPoor() As Integer
      Dim MeanQualBySiteAndNucPoor(,) As Double, StdQualBySiteAndNucPoor(,) As Double
      Dim NumSeqPoor As Integer

      If FastqInfo(sFastqFile, TotalNumSeq, MinSeqLen, MaxSeqLen, FreqSeqLen, MinQualCh, MaxQualCh, FreqBaseQuality, MinSeqQuality, MaxSeqQuality, FreqSeqQuality, MeanQualBySiteAndNuc, StdQualBySiteAndNuc, NucFreqBySite, _
                   MinSeqQualityPoor, MaxSeqQualityPoor, FreqSeqQualityPoor, MeanQualBySiteAndNucPoor, StdQualBySiteAndNucPoor, NucFreqBySitePoor, NumSeqPoor, ToolStripStatusLabel2, ToolStripProgressBar1) Then
        Dim I As Integer, UppInd As Integer
        Dim sb As New StringBuilder
        Dim UniqueQualCh() As Double

        'Basic info
        sb.Append("1. Basic Informationn from file: " & sFastqFile & CRCR)
        sb.Append("Total number of sequences: " & TotalNumSeq & CRCR)
        If MinSeqLen < MaxSeqLen Then
          Dim UniqueSeqLen() As Double
          sb.Append("Frequency distribution of read lengths." & CRCR)
          sb.Append("SeqLen         Count" & vbCrLf)
          UppInd = MaxSeqLen - MinSeqLen
          ReDim UniqueSeqLen(UppInd)
          For I = MinSeqLen To MaxSeqLen
            If FreqSeqLen(I) > 0 Then
              sb.Append(I.ToString.PadLeft(6) & FreqSeqLen(I).ToString.PadLeft(14) & vbCrLf)
            End If
            UniqueSeqLen(I - MinSeqLen) = I
            FreqSeqLen(I - MinSeqLen) = FreqSeqLen(I)
          Next
          ReDim Preserve FreqSeqLen(UppInd)
          If bPlotSeqLen Then
#If TARGET = "LINUX" Then
            Call frmZDGraphics.DrawGraph(UniqueSeqLen, FreqSeqLen, UppInd + 1, 1, "Sequence length", "Count", frmZDGraphics.enumChartType.Bar)
#Else
            Call frmGraphics.DrawGraph(UniqueSeqLen, FreqSeqLen, UppInd + 1, "Sequence length", "Count", DataVisualization.Charting.SeriesChartType.Column)
#End If
          End If
        Else
          sb.Append("Sequence lengths are all equal to : " & MaxSeqLen & vbCrLf)
        End If

        'Nuc-based quality info
        sb.Append(vbCrLf & "2. Nucleotide-based quality information (An 'N' always have the lowerest quality character, e.g., 33, and is not included in the following quality report)" & CRCR)
        sb.Append("Frequency distribution of base qualities." & CRCR)
        sb.Append("Quality         Count" & vbCrLf)
        UppInd = MaxQualCh - MinQualCh

        ReDim UniqueQualCh(UppInd)
        For I = MinQualCh To MaxQualCh
          If FreqBaseQuality(I) > 0 Then
            sb.Append(I.ToString.PadLeft(7) & FreqBaseQuality(I).ToString.PadLeft(14) & vbCrLf)
          End If
          UniqueQualCh(I - MinQualCh) = I
          FreqBaseQuality(I - MinQualCh) = FreqBaseQuality(I)
        Next
        ReDim Preserve FreqBaseQuality(UppInd)
        sb.Append(vbCrLf & "Base quality by sites and nucleotides for sequences without those containing unresolved 'N'" & CRCR)
        sb.Append("                              N                                          Mean                              STD" & vbCrLf)
        sb.Append("      --------------------------------------------------  --------------------------------  --------------------------------" & vbCrLf)
        sb.Append("Site            A            C            G            T         A       C       G       T         A       C       G       T" & vbCrLf)
        For I = 0 To MaxSeqLen - 1
          sb.Append((I + 1).ToString.PadLeft(4) & NucFreqBySite(0, I).ToString.PadLeft(13) & NucFreqBySite(1, I).ToString.PadLeft(13) & NucFreqBySite(2, I).ToString.PadLeft(13) & NucFreqBySite(3, I).ToString.PadLeft(13) & FormatNumber(MeanQualBySiteAndNuc(0, I), 2).PadLeft(10) & FormatNumber(MeanQualBySiteAndNuc(1, I), 2).PadLeft(8) & FormatNumber(MeanQualBySiteAndNuc(2, I), 2).PadLeft(8) & FormatNumber(MeanQualBySiteAndNuc(3, I), 2).PadLeft(8) & FormatNumber(StdQualBySiteAndNuc(0, I), 2).PadLeft(10) & FormatNumber(StdQualBySiteAndNuc(1, I), 2).PadLeft(8) & FormatNumber(StdQualBySiteAndNuc(2, I), 2).PadLeft(8) & FormatNumber(StdQualBySiteAndNuc(3, I), 2).PadLeft(8) & vbCrLf)
        Next

        sb.Append(vbCrLf & "Base quality by sites and nucleotides for the " & NumSeqPoor & " sequences containing unresolved 'N':" & CRCR)

        sb.Append("                              N                                          Mean                              STD" & vbCrLf)
        sb.Append("      --------------------------------------------------  --------------------------------  --------------------------------" & vbCrLf)
        sb.Append("Site            A            C            G            T         A       C       G       T         A       C       G       T" & vbCrLf)
        For I = 0 To MaxSeqLen - 1
          sb.Append((I + 1).ToString.PadLeft(4) & NucFreqBySitePoor(0, I).ToString.PadLeft(13) & NucFreqBySitePoor(1, I).ToString.PadLeft(13) & NucFreqBySitePoor(2, I).ToString.PadLeft(13) & NucFreqBySitePoor(3, I).ToString.PadLeft(13) & FormatNumber(MeanQualBySiteAndNucPoor(0, I), 2).PadLeft(10) & FormatNumber(MeanQualBySiteAndNucPoor(1, I), 2).PadLeft(8) & FormatNumber(MeanQualBySiteAndNucPoor(2, I), 2).PadLeft(8) & FormatNumber(MeanQualBySiteAndNucPoor(3, I), 2).PadLeft(8) & FormatNumber(StdQualBySiteAndNuc(0, I), 2).PadLeft(10) & FormatNumber(StdQualBySiteAndNuc(1, I), 2).PadLeft(8) & FormatNumber(StdQualBySiteAndNuc(2, I), 2).PadLeft(8) & FormatNumber(StdQualBySiteAndNuc(3, I), 2).PadLeft(8) & vbCrLf)
        Next

        If bPlotBaseQual Then
#If TARGET = "LINUX" Then
          Call frmZDGraphics.DrawGraph(UniqueQualCh, FreqBaseQuality, UppInd + 1, 1, "Read quality index", "Count", frmZDGraphics.enumChartType.Bar, "Freq. distr. of base qualities")
#Else
          Call frmGraphics.DrawGraph(UniqueQualCh, FreqBaseQuality, UppInd + 1, "Read quality index", "Count", DataVisualization.Charting.SeriesChartType.Column, "Freq. distr. of base qualities")
#End If
        End If

        sb.Append(vbCrLf & "3. Sequence-based quality information." & vbCrLf)
        sb.Append("(A sequence quality (SQ) is computed for each sequence as a mean of its base qualities.)" & CRCR)
        sb.Append("Lowest sequence quality: " & MinSeqQuality & vbCrLf)
        sb.Append("Highest sequence quality: " & MaxSeqQuality & CRCR)
        sb.Append("Frequency distribution of sequency qualities (SQ)." & vbCrLf)
        sb.Append("Quality         Count" & vbCrLf)
        UppInd = MaxSeqQuality - MinSeqQuality
        Dim UniqueMeanQual(UppInd)
        For I = MinSeqQuality To MaxSeqQuality
          If FreqSeqQuality(I) > 0 Then
            sb.Append(I.ToString.PadLeft(7) & FreqSeqQuality(I).ToString.PadLeft(14) & vbCrLf)
          End If
          UniqueMeanQual(I - MinSeqQuality) = I
          FreqSeqQuality(I - MinSeqQuality) = FreqSeqQuality(I)
        Next
        ReDim Preserve FreqSeqQuality(UppInd)
        If bPlotSeqQual Then
#If TARGET = "LINUX" Then
          Call frmZDGraphics.DrawGraph(UniqueMeanQual, FreqSeqQuality, UppInd + 1, 1, "Seq. quality", "Count", frmZDGraphics.enumChartType.Bar, "Freq. distr. of seq. qualities")
#Else
          Call frmGraphics.DrawGraph(UniqueMeanQual, FreqSeqQuality, UppInd + 1, "Seq. quality", "Count", DataVisualization.Charting.SeriesChartType.Column, "Freq. distr. of seq. qualities")
#End If

          MsgBox("You will see another equivalent plot for sequences containing unresolved 'N'", vbInformation)
          UppInd = MaxSeqQualityPoor - MinSeqQualityPoor
          Dim UniqueMeanQualPoor(UppInd)
          For I = MinSeqQualityPoor To MaxSeqQualityPoor
            UniqueMeanQualPoor(I - MinSeqQualityPoor) = I
            FreqSeqQualityPoor(I - MinSeqQualityPoor) = FreqSeqQualityPoor(I)
          Next
          ReDim Preserve FreqSeqQualityPoor(UppInd)
#If TARGET = "LINUX" Then
          Call frmZDGraphics.DrawGraph(UniqueMeanQualPoor, FreqSeqQualityPoor, UppInd + 1, 1, "Seq. quality", "Count", frmZDGraphics.enumChartType.Bar, "Same graph but for N-containing sequences")
#Else
          Call frmGraphics.DrawGraph(UniqueMeanQualPoor, FreqSeqQualityPoor, UppInd + 1, "Seq. quality", "Count", DataVisualization.Charting.SeriesChartType.Column, "Same graph but for N-containing sequences")
#End If
        End If
        RichTextBox1.Text = sb.ToString
      End If
    Catch ex As Exception
      MsgBox("Error Encountered!" & CRCR & ex.ToString & CRCR & mErrReport, vbInformation, "Error")
    End Try
    ToolStripStatusLabel2.Text = ""
    ToolStripStatusLabel1.ForeColor = Color.Black
    ToolStripStatusLabel1.Text = "Ready"
  End Sub

  Private Sub mnuFilePairedFastqToPairFasPlus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFilePairedFastqToPairFasPlus.Click
    Dim sFastqFile1 As String = "", sFastqFile2 As String = ""
    Dim sFasFile1 As String = "", sFasFile2 As String = ""
    Dim ReadLen As Integer
    Dim sOut As String = ""
    Dim lFreeMem As Long

    If dlgPairedFastq2PairedFasPlus.GetPairedFastqToPairedFasParam(sFastqFile1, sFastqFile2, sFasFile1, sFasFile2, ReadLen) Then

      Dim NumUniqueSeq As Integer, NumUniqueGrSize As Integer, UniqueGrSize() As Integer, FreqGrSize() As Integer
      RichTextBox1.Text = "You are running a lengthy process. This window will be updated when the job is finished." & vbCrLf
      ToolStripStatusLabel1.ForeColor = Color.Red
      ToolStripStatusLabel1.Text = "Working..."
      ToolStripStatusLabel2.Text = sFastqFile1 & "+" & sFastqFile2
      Application.DoEvents()
      Try
        lFreeMem = GetAvailablePhysicalMem()
      Catch ex As Exception
        MsgBox("Error Encountered in getting system memory!" & CRCR & ex.ToString, vbInformation, "Error")
        lFreeMem = 1000000000
      End Try
      If lFreeMem < 30064771072 Then
        If FastqToFasPlusPairedBig(sFastqFile1, sFastqFile2, sFasFile1, sFasFile2, sOut, ReadLen, NumUniqueGrSize, UniqueGrSize, FreqGrSize, ToolStripStatusLabel2, ToolStripProgressBar1) Then
          RichTextBox1.Text = sOut
          'Call frmGraphics.DrawGraph(UniqueGrSize, FreqGrSize, NumUniqueGrSize, "Group size", "Count", DataVisualization.Charting.SeriesChartType.Column)

        Else
          RichTextBox1.Text = "Error when running FastqToFasPlus."
        End If
      Else
        If FastqToFasPlusPaired(sFastqFile1, sFastqFile2, sFasFile1, sFasFile2, sOut, NumUniqueSeq, NumUniqueGrSize, UniqueGrSize, FreqGrSize, ReadLen, ToolStripStatusLabel2, ToolStripProgressBar1) Then
          RichTextBox1.Text = sOut

#If TARGET = "LINUX" Then
          Call frmZDGraphics.DrawGraph(UniqueGrSize, FreqGrSize, NumUniqueGrSize, 1, "Group size", "Count", frmZDGraphics.enumChartType.Bar)
#Else
          Call frmGraphics.DrawGraph(UniqueGrSize, FreqGrSize, NumUniqueGrSize, "Group size", "Count", DataVisualization.Charting.SeriesChartType.Column)
#End If

        Else
          RichTextBox1.Text = "Error when running FastqToFasPlus."
        End If
      End If
      ToolStripStatusLabel2.Text = ""
      ToolStripStatusLabel1.ForeColor = Color.Black
      ToolStripStatusLabel1.Text = "Ready"
    End If

  End Sub

  Private Sub AboutARSDA_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutARSDA.Click
    frmAbout.ShowDialog()
  End Sub

  Private Sub mnuAnaBLAST_Click(sender As System.Object, e As System.EventArgs) Handles mnuAnaBLAST.Click
    Dim sFasFileQuery As String, sBlastDB As String, sBlastDbDir As String, sOutFileBLAST As String
    Dim Evalue As Double
    Dim WordLen As Integer, NumCPU As Integer, MaxTarget As Integer
    Dim sStrand As String
    Dim bUngapped As Boolean
    Dim sErr As String = "", sTmp As String
    Dim iTmp As Integer
    Dim sArg As String
    Dim bSuccess As Boolean

    If dlgBlastFasToGE.GetBlastFasGEParam(sBlastDB, sBlastDbDir, sFasFileQuery, sOutFileBLAST, Evalue, WordLen, sStrand, bUngapped, MaxTarget, NumCPU, False, True) Then
      ToolStripStatusLabel1.ForeColor = Color.Red
      ToolStripStatusLabel1.Text = "working"
      ToolStripStatusLabel2.Text = sFasFileQuery
      sTmp = "Local BLAST to matching/aligning query sequences against sequences in BLAST database." & CRCR
      sTmp = sTmp & "Once the job is finished, this display window will be updated with BLAST output."
      RichTextBox1.Text = sTmp

      Try
        'sBlastnOutfile: intermediate file containing the comma-delimited blastn_vdb output (without column annotation)
        'Query,DbSeq,%match,matchLen,NumMismatch,GO,q.start,q.end,dbSeqStart,dbSeqEnd,evalue,bitScore
        'thrL,gnl|SRA|SRR1536586.6379132.1,100.00,49,0,0,18,66,1,49,2e-018,91.6
        'thrL,gnl|SRA|SRR1536586.6356742.1,100.00,49,0,0,18,66,1,49,2e-018,91.6
        '...
        'thrL,gnl|SRA|SRR1536586.4527718.1,100.00,36,0,0,31,66,1,36,3e-011,67.6
        'thrA,gnl|SRA|SRR1536586.6502929.1,100.00,50,0,0,1822,1871,1,50,3e-017,93.5
        'thrA,gnl|SRA|SRR1536586.6502478.1,100.00,50,0,0,2360,2409,1,50,3e-017,93.5
        'THe above output is produced by
        'blastn -db SRR1536586 -query testblast.fas -evalue 0.0000000001 -word_size 18 -ungapped -strand both -max_target_seqs 1000000 -outfmt 10 -num_threads NumCPU -out testBlast.out
        If Strings.Left(sBlastDB, 1) = Chr(34) Then 'multiple blast db
          iTmp = InStr(sBlastDB, " ")
          If iTmp > 0 Then
            sTmp = Strings.Left(sBlastDB, iTmp - 1)
          End If
          iTmp = InStrRev(sTmp, Path.DirectorySeparatorChar)
          If iTmp > 0 Then
            sTmp = Mid(sTmp, iTmp + 1)
          End If
          iTmp = InStr(sTmp, ".")
          If iTmp > 0 Then
            sTmp = Strings.Left(sTmp, iTmp - 1)
          End If
          sOutFileBLAST = sFasFileQuery & "_MultBlastDb_blast.out"
        Else
          sOutFileBLAST = sFasFileQuery & "_" & sBlastDB & "_blast.out"
        End If

        ToolStripStatusLabel2.Text = "BLASTing..."
        sArg = " -db " & sBlastDB & " -query " & sFasFileQuery & " -evalue " & Evalue & " -word_size " & WordLen & IIf(bUngapped, " -ungapped", "") & " -strand " & sStrand & " -max_target_seqs " & MaxTarget & " -outfmt 10 -num_threads " & NumCPU & " -out " & sOutFileBLAST
        bSuccess = RunExeAndWait(BLASTn, sArg, sBlastDbDir, False)

        If bSuccess Then ' 
          If File.Exists(sOutFileBLAST) Then
            If FileLen(sOutFileBLAST) < 10 Then
              RichTextBox1.Text = "Warning:" & CRCR & "The match/align file: " & sOutFileBLAST & " is empty. You may have set the E-value too small."
              Exit Sub
            End If
          Else
            RichTextBox1.Text = "Warning:" & CRCR & "No match found. You may have set the E-value too small."
            Exit Sub
          End If
        Else
          RichTextBox1.Text = "blastn failed to run."
          Exit Sub
        End If

        RichTextBox1.Text = "The following has been saved to file " & sOutFileBLAST & CRCR & "Query,DbSeq,%match,matchLen,NumMismatch,GO,q.start,q.end,dbSeqStart,dbSeqEnd,evalue,bitScore" & vbCrLf & File.ReadAllText(sOutFileBLAST)
      Catch ex As Exception
        If sErr <> "" Then
          MsgBox("Error Encountered!" & CRCR & "1. " & sErr & CRCR & "2. " & ex.ToString & CRCR & mErrReport, vbInformation, "Error")
        Else
          MsgBox("Error Encountered!" & CRCR & ex.ToString & CRCR & mErrReport, vbInformation, "Error")
        End If
      End Try

      ToolStripStatusLabel2.Text = ""
      ToolStripStatusLabel1.ForeColor = Color.Black
      ToolStripStatusLabel1.Text = "Ready"
    End If

  End Sub

  Private Sub mnuFileFas2FasPlus_Click(sender As Object, e As EventArgs) Handles mnuFileFas2FasPlus.Click
    Dim sInFasFile() As String
    Dim sFasFileOrDir As String = ""
    Dim sOut As String = ""
    Dim I As Integer, NumFasFile As Integer
    Dim bNoAmbiguousNuc As Boolean = False

    'Use the same dialog and function as the "Fastq to Fas+", but change the image and the lable.text
    RichTextBox1.Text = "The job is running. This display will be updated when the job is finished." & vbCrLf
    If dlgFastqToSeqGr.GetFastqToSeqGrParam(sInFasFile, sFasFileOrDir, NumFasFile, bNoAmbiguousNuc, True) Then
      Dim NumUniqueSeq As Integer, NumUniqueGrSize As Integer, UniqueGrSize() As Integer, FreqGrSize() As Integer
      ToolStripStatusLabel1.ForeColor = Color.Red
      ToolStripStatusLabel1.Text = "Working..."
      If NumFasFile = 1 Then
        ToolStripStatusLabel2.Text = sInFasFile(0)
      End If
      Application.DoEvents()
      Try
        If NumFasFile = 1 Then
          If FasToFasPlus(sInFasFile(0), sFasFileOrDir, sOut, NumUniqueSeq, NumUniqueGrSize, UniqueGrSize, FreqGrSize, bNoAmbiguousNuc, ToolStripProgressBar1) Then
            RichTextBox1.Text = sOut
#If TARGET = "LINUX" Then
            Call frmZDGraphics.DrawGraph(UniqueGrSize, FreqGrSize, NumUniqueGrSize, 1, "Group size", "Count", frmZDGraphics.enumChartType.Bar)
#Else
            Call frmGraphics.DrawGraph(UniqueGrSize, FreqGrSize, NumUniqueGrSize, "Group size", "Count", DataVisualization.Charting.SeriesChartType.Column)
#End If
          Else
            RichTextBox1.Text = "Error when running FasToFasPlus."
          End If
        Else
          Dim sb As New StringBuilder
          If Strings.Right(sFasFileOrDir, 1) <> Path.DirectorySeparatorChar Then
            sFasFileOrDir = sFasFileOrDir & Path.DirectorySeparatorChar
          End If

          ToolStripProgressBar1.Minimum = 0
          ToolStripProgressBar1.Maximum = NumFasFile
          For I = 0 To NumFasFile - 1
            ToolStripStatusLabel2.Text = sInFasFile(I)
            If FasToFasPlus(sInFasFile(I), sFasFileOrDir & Path.GetFileNameWithoutExtension(sInFasFile(I)) & ".fasP", sOut, NumUniqueSeq, NumUniqueGrSize, UniqueGrSize, FreqGrSize, bNoAmbiguousNuc, ToolStripProgressBar1) Then
              sb.Append(sOut & CRCR)
            Else
              sb.Append("Error when running FasToFasPlus on " & sInFasFile(I), CRCR)
            End If
          Next
          RichTextBox1.Text = sb.ToString
          sb.Clear()
          sb = Nothing
        End If
      Catch ex As Exception
        MsgBox("Error Encountered!" & CRCR & ex.ToString & CRCR & mErrReport, vbInformation, "Error")
      End Try
      ToolStripStatusLabel2.Text = ""
      ToolStripStatusLabel1.ForeColor = Color.Black
      ToolStripStatusLabel1.Text = "Ready"
    End If


  End Sub

  Private Sub FileRTrimSeq_Click(sender As Object, e As EventArgs) Handles FileRTrimSeq.Click

    Dim sInFile As String
    Dim sOutFile As String
    Dim LimitLen As Integer
    Dim bRidN As Boolean

    If Not dlgRTrim.RTrimParam(sInFile, sOutFile, LimitLen, bRidN) Then
      Exit Sub
    End If

    'Process the file in chunks
    Dim I As Integer, J As Integer, lFileLen As Long, UppInd As Integer, TotalNumSeq As Integer
    Dim lChunkLen As Integer, lFreeMem As Long
    Dim sChunk As String, LineArray() As String
    Dim tmpByte() As Byte
    Dim sb As New StringBuilder

    Try
      lFreeMem = GetAvailablePhysicalMem()
    Catch ex As Exception
      MsgBox("Error Encountered!" & CRCR & ex.ToString, vbInformation, "Error")
      lFreeMem = 2000000000
    End Try

    lFileLen = FileLen(sInFile)
    lChunkLen = lFreeMem \ 1000
    If lChunkLen > lFileLen Then
      sChunk = File.ReadAllText(sInFile)
      sChunk = Replace(sChunk, vbCrLf, vbLf)
      LineArray = Split(sChunk, vbLf)
      sChunk = ""
      UppInd = UBound(LineArray)

      With ToolStripProgressBar1
        .Minimum = 0
        .Maximum = UppInd
      End With
      For I = 1 To UppInd - 1 Step 2
        LineArray(I) = Strings.Left(LineArray(I), LimitLen)
        ToolStripProgressBar1.Value = I
      Next
      File.WriteAllText(sOutFile, Join(LineArray, vbCrLf))
      TotalNumSeq = (UppInd + 1) \ 2
    Else
      Dim fs As New FileStream(sInFile, FileMode.Open, FileAccess.Read)
      Dim NumByteRead As Integer, lNumChunk As Integer, lRemainLen As Integer, NumTrailingLine As Integer
      Dim sRemain As String = ""
      Dim tmpUppInd As Integer

      lNumChunk = lFileLen \ lChunkLen
      lRemainLen = lFileLen Mod lChunkLen

      ToolStripProgressBar1.Minimum = 0
      ToolStripProgressBar1.Maximum = lNumChunk
      For I = 0 To lNumChunk - 1
        ReDim tmpByte(lChunkLen - 1)
        NumByteRead = fs.Read(tmpByte, 0, lChunkLen)
        sChunk = sRemain & Encoding.ASCII.GetString(tmpByte)
        sChunk = Replace(sChunk, vbCrLf, vbLf)
        LineArray = Split(sChunk, vbLf) 'Now the last line could be the @ID line, the seq line, the +line or the quality line. Also, iif(lastCh = vblf, Last line is empty,Not empty)
        sChunk = ""
        UppInd = UBound(LineArray)
        NumTrailingLine = (UppInd + 1) Mod 2
        Select Case NumTrailingLine
          '>Seq
          'AACC...
          '>Seq
          'AACC...
          'Seq
          'AACC...
          'Last line in sChunk could be either before the end or at the end
          '...|>Seq     : NumTrailingLine = 1 
          '...\n>Se|q   : NumTrailingLine = 1
          '|AACC...     : NumTrailingLine = 0
          'AA|CC...     : NumTrailingLine = 0
          Case 0
            sRemain = LineArray(UppInd - 1) & vbLf & LineArray(UppInd)
            tmpUppInd = UppInd - 2
          Case 1
            sRemain = LineArray(UppInd)
            tmpUppInd = UppInd - 1
        End Select
        If bRidN Then
          For J = 1 To tmpUppInd - 1 Step 2
            If InStr(LineArray(J), "N") = 0 Then
              LineArray(J) = Strings.Left(LineArray(J), LimitLen)
              ToolStripProgressBar1.Value = I
            End If
          Next
        Else
          For J = 1 To tmpUppInd - 1 Step 2
            LineArray(J) = Strings.Left(LineArray(J), LimitLen)
            ToolStripProgressBar1.Value = I
          Next
        End If
        File.AppendAllText(sOutFile, Join(LineArray, vbCrLf))
        TotalNumSeq = TotalNumSeq + (tmpUppInd + 1) \ 2
      Next
      If lRemainLen > 0 Then
        ReDim tmpByte(lRemainLen - 1)
        NumByteRead = fs.Read(tmpByte, 0, lRemainLen)
        sChunk = sRemain & Encoding.ASCII.GetString(tmpByte)
        sChunk = Replace(sChunk, vbCrLf, vbLf)
        LineArray = Split(sChunk, vbLf)
        sChunk = ""
        UppInd = UBound(LineArray)
        If bRidN Then
          If InStr(LineArray(J), "N") = 0 Then
            For J = 1 To UppInd - 1 Step 2
              LineArray(J) = Strings.Left(LineArray(J), LimitLen)
            Next
          End If
        Else
          For J = 1 To UppInd - 1 Step 2
            LineArray(J) = Strings.Left(LineArray(J), LimitLen)
          Next
        End If
        File.AppendAllText(sOutFile, Join(LineArray, vbCrLf))
        TotalNumSeq = TotalNumSeq + (UppInd + 1) \ 2
      End If
    End If
    ToolStripProgressBar1.Value = 0

    'Text output
    If bRidN Then
      sb.Append("The sequences in the input file: " & sInFile & " have been right-trimmed to " & LimitLen & " nt, and sequences containing ambiguous bases are excluded. The resulting sequences are saved in FASTA format to " & sOutFile & CRCR)
    Else
      sb.Append("The sequences in the input file: " & sInFile & " have been right-trimmed to " & LimitLen & " nt, and saved in FASTA format to " & sOutFile & CRCR)
    End If
    sb.Append("Total number of sequences in input file " & sInFile & ": " & TotalNumSeq & vbCrLf)
    RichTextBox1.Text = sb.ToString
    sb.Clear()
  End Sub

  
  
  Private Sub DumpBLASTDBToFASTAToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DumpBLASTDBToFASTAToolStripMenuItem.Click
    Dim sBlastDB As String = GetOpenFileName("Open BLAST database", "nin,pin", OpenFileDialog1, sResultDir)
    Dim sFasFile As String = GetSaveFileName("Open FASTA file", "fasta,fas,ffn,faa,fna,frn,fastaP,fasP", SaveFileDialog1, sInputDir)
    Dim sWorkDir As String = Path.GetDirectoryName(sBlastDB)
    sBlastDB = Path.GetFileNameWithoutExtension(sBlastDB)
    Dim sArg As String = " -db " & sBlastDB & " -entry all -out " & sFasFile
    Try
      If RunExeAndWait(BLASTdbcmd, sArg, sWorkDir, False) Then
        Call MsgBox("Sequences in BLAST database " & sBlastDB & " has been dumped to FASTA file " & sFasFile)
      Else
        Call MsgBox("Error encountered with BLAST database " & sBlastDB)
      End If
    Catch ex As Exception
      Call MsgBox("Error encountered with BLAST database " & sBlastDB)

    End Try
  End Sub
End Class
