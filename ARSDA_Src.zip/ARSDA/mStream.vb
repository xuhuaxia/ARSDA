﻿Module mStream
  'IO.FileStream: .close
  'IO.StreamReader: .read, .readline, .ReadToEnd, .peek, .close
  'IO.StreamWriter: .Write, .WriteLine, .Flush, .AutoFlush = True, .close
End Module
