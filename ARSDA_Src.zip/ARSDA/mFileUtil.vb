﻿Imports System.IO
Imports System.Text
Imports System.Collections
Module mFileUtil
  'FileSystemWatcher component
  'IO.FileInfo: .LastWriteTime, .LastAccessTime, .CreationTime (use with DateTime), .Extension, .Name, .FullName, .Length, .Attribute, .Atributes,
  '   .directoryName, .Delete, .CopyTo, .MoveTo, .IsReadOnly
  'IO.DirectoryIndo: .Name, .FullName, .Parent, .Root, .GetDirectories, .GetFiles, .GetFiles, .CreateSubDirectory, .MoveTo, .Delete
  'OpenFileDialog
  'SaveFileDialog
  'FileExist to File.Exists
  'DirExist to Directory.Exists
  'GetSubDir: Directory.GetDirectories(sDir)
  'fs.position is 0-based
  ' Change the extension of a file name
  ' if the last argument is True,it adds the extension even if the file doesn't have one
  'ChFileExt function is not needed in VB.net because the existence of Path.ChangeExtension(sFileName,sNewExtension): if sNewExtension is null, file extension in sFileName
  '  will be removed. If sFileName has no extension, then sNewExtension will be the new extension.
  'GetFileBaseName function is not needed becasue Path.GetFileNameWithoutExtension
  'http://msdn.microsoft.com/en-us/library/0b485hf7(v=vs.90).aspx
  Public Function GetOpenFileName(ByVal DialogTitleText As String, ByVal sCommaDelimitedFileType As String, ByVal OpenFileDialog1 As OpenFileDialog, ByVal sDir As String, Optional ByVal DefaultOutFileBase As String = "") As String
    Dim sFilter As String

    If InStr(sCommaDelimitedFileType, ",") > 0 Then
      sFilter = "FILES (*." & Replace(sCommaDelimitedFileType, ",", ";*.") & ")|*." & Replace(sCommaDelimitedFileType, ",", ";*.")
    Else
      sFilter = UCase$(sCommaDelimitedFileType) & " Files (*." & sCommaDelimitedFileType & ")|*." & sCommaDelimitedFileType
    End If

    OpenFileDialog1.Title = DialogTitleText
    OpenFileDialog1.FileName = DefaultOutFileBase
    OpenFileDialog1.InitialDirectory = sDir
    OpenFileDialog1.Multiselect = False
    OpenFileDialog1.Filter = sFilter
    OpenFileDialog1.ShowDialog()
    Return OpenFileDialog1.FileName

  End Function

  Public Function GetAccessDbFileName(ByVal OpenFiledialog1 As OpenFileDialog) As String
    With openfiledialog1
      .DefaultExt = "accdb"
      .DereferenceLinks = True
      .Filter = "Access files (*.accdb)|*.accdb"
      .Multiselect = False
      .Title = "Open Access Database file"
      .ValidateNames = True

      If .ShowDialog = Windows.Forms.DialogResult.OK Then
        Try
          Return .FileName
        Catch fileException As Exception
          Throw fileException
        End Try
      Else
        Return ""
      End If
    End With
  End Function

  Public Function GetSaveFileName(ByVal DialogTitleText As String, ByVal sCommaDelimitedFileType As String, ByVal SaveFileDialog1 As SaveFileDialog, ByVal sDir As String, Optional ByVal DefaultOutFileBase As String = "") As String
    Dim sFilter As String

    If InStr(sCommaDelimitedFileType, ",") > 0 Then
      sFilter = "FILES (*." & Replace(sCommaDelimitedFileType, ",", ";*.") & ")|*." & Replace(sCommaDelimitedFileType, ",", ";*.")
    Else
      sFilter = UCase$(sCommaDelimitedFileType) & " Files (*." & sCommaDelimitedFileType & ")|*." & sCommaDelimitedFileType
    End If

    SaveFileDialog1.Title = DialogTitleText
    SaveFileDialog1.FileName = DefaultOutFileBase
    SaveFileDialog1.InitialDirectory = sDir
    SaveFileDialog1.Filter = sFilter
    SaveFileDialog1.ShowDialog()
    Return SaveFileDialog1.FileName

  End Function

  Public Function GetFileArray(ByVal OpenFileDialog1 As OpenFileDialog, ByVal sCommadelimitedFileType As String, ByVal sDir As String) As String()
    Dim sFilter As String

    If InStr(sCommadelimitedFileType, ",") > 0 Then
      sFilter = "FILES (*." & Replace(sCommadelimitedFileType, ",", ";*.") & ")|*." & Replace(sCommadelimitedFileType, ",", ";*.")
    Else
      sFilter = UCase$(sCommadelimitedFileType) & " Files (*." & sCommadelimitedFileType & ")|*." & sCommadelimitedFileType
    End If

    OpenFileDialog1.InitialDirectory = sDir
    OpenFileDialog1.Multiselect = True
    OpenFileDialog1.Filter = sFilter
    OpenFileDialog1.ShowDialog()
    Return OpenFileDialog1.FileNames

  End Function

  Public Function GetOneLine(ByVal sFileName As String) As String
    Dim Reader As StreamReader = File.OpenText(sFileName)
    Dim OneLine As String = Reader.ReadLine
    Reader.Close()
    Return OneLine
  End Function

  Public Sub GetFileArrayQuiet(ByVal sDir As String, ByVal sCommaDelimitedType As String, ByRef FileArray() As String, ByRef lNumFile As Integer)
    Dim I As Integer
    Dim sFileTypeArray() As String
    Dim fileList As System.Collections.ObjectModel.ReadOnlyCollection(Of String)

    sFileTypeArray = Split(sCommaDelimitedType, ",")
    For I = 0 To UBound(sFileTypeArray)
      sFileTypeArray(I) = "*." & sFileTypeArray(I)
    Next
    fileList = My.Computer.FileSystem.GetFiles(My.Computer.FileSystem.CurrentDirectory, FileIO.SearchOption.SearchTopLevelOnly, sFileTypeArray)
    lNumFile = fileList.Count
    ReDim FileArray(lNumFile - 1)
    For I = 0 To lNumFile - 1
      FileArray(I) = fileList(I)
    Next
  End Sub


  Function GetFNOnly(ByRef InFileName As String) As String
    Dim FindAt As Integer
    Dim sTmpFile As String
    FindAt = InStrRev(InFileName, Path.DirectorySeparatorChar)
    If FindAt = 0 Then
      sTmpFile = InFileName
    Else
      sTmpFile = Mid$(InFileName, FindAt + 1)
    End If
    FindAt = InStrRev(sTmpFile, ".")
    If FindAt > 0 Then
      GetFNOnly = Left$(sTmpFile, FindAt - 1)
    Else
      GetFNOnly = sTmpFile
    End If
  End Function


  'StartAt = 1 to start from the beginning
  Function GetFileTextLen(ByRef sFileName As String, ByVal StartAt As Integer, ByVal StrLen As Integer) As String
    Dim nFile As Short
    Dim sOut As String
    nFile = FreeFile()
    sOut = Space(StrLen)
    FileGet(nFile, sOut)
    FileClose(nFile)
    Return sOut
  End Function


  'The calling function issue:
  '1. Open sFileName for Binary Access Read Lock Write As #FileNum
  '2. Close #FileNum statement after finishing reading

  Function GetFileTextLen2(ByVal FileNum As Short, ByVal StartAt As Integer, ByVal StrLen As Integer) As String
    GetFileTextLen2 = Space(StrLen)
    FileGet(FileNum, GetFileTextLen2, StartAt)
  End Function




  Function IfUnix(ByRef InLine As String) As Boolean

    If InStr(InLine, vbLf) > 0 Then
      IfUnix = InStr(InLine, vbCr) = 0
    Else
      IfUnix = False
    End If
  End Function


  ''@B Read2NumArrayFile

  Sub Read2NumArrayFile(ByRef sFileName As String, ByRef DynArray1 As Object, ByRef DynArray2 As Object, ByRef OutNumRows As Integer, ByVal bByVBTab As Boolean, ByVal bHasHeading As Boolean, Optional ByRef sHeading As Object = 0)

    Dim I As Integer, FindAt As Integer, StartInd As Integer
    Dim sFileStr As String, LineArray() As String

    sFileStr = System.IO.File.ReadAllText(sFileName)
    If Not bByVBTab Then
      sFileStr = Sp2Tab(sFileStr)
    End If

    LineArray = Split(sFileStr, GetLineEnd(sFileStr))
    For I = UBound(LineArray) To 0 Step -1
      If (Trim(LineArray(I))) <> "" Then
        Exit For
      End If
    Next I
    ReDim Preserve LineArray(I)

    If bHasHeading Then
      sHeading = Split(LineArray(0), vbTab)
      StartInd = 1
      OutNumRows = UBound(LineArray)
    Else
      OutNumRows = UBound(LineArray) + 1
    End If

    ReDim DynArray1(OutNumRows - 1), DynArray2(OutNumRows - 1)
    For I = StartInd To UBound(LineArray)
      FindAt = InStr(LineArray(I), vbTab)
      DynArray1(I - StartInd) = Trim(Left(LineArray(I), FindAt - 1))
      DynArray2(I - StartInd) = Trim(Mid(LineArray(I), FindAt + 1))
    Next I
  End Sub

  ''@E Read2NumArrayFile

  'Get columns of data into arrays.

  Sub Read3NumArrayFileTabDelimited(ByRef sFileName As String, ByRef DynArray1 As Object, ByRef DynArray2 As Object, ByRef DynArray3 As Object, ByRef OutNumRows As Integer)

    Dim I As Integer, UpperBound As Integer
    Dim sFileStr As String, LineArray() As String, Fields() As String

    sFileStr = System.IO.File.ReadAllText(sFileName)
    LineArray = Split(sFileStr, GetLineEnd(sFileStr))

    UpperBound = UBound(LineArray)

    For I = UpperBound To 0 Step -1
      If Trim(LineArray(I)) <> "" Then
        UpperBound = I
        Exit For
      End If
    Next I
    ReDim DynArray1(UpperBound)
    ReDim DynArray2(UpperBound)
    ReDim DynArray3(UpperBound)

    For I = 0 To UpperBound
      Fields = Split(LineArray(I), vbTab)
      DynArray1(I) = CDbl(Fields(0))
      DynArray2(I) = Fields(1)
      DynArray3(I) = Fields(2)
    Next I
    OutNumRows = UpperBound + 1
  End Sub

  Function NormalizePath(ByRef sPath As String) As String

    NormalizePath = sPath
    If Right(sPath, 1) <> Path.DirectorySeparatorChar Then Return sPath & Path.DirectorySeparatorChar
  End Function

  Function GetFileByte(ByVal sFileName As String) As Byte()
    Return System.IO.File.ReadAllBytes(sFileName)
  End Function

  Function GetFileText(ByVal sFileName As String) As String
    Return System.IO.File.ReadAllText(sFileName)
  End Function

  Function GetFileByteLen(ByVal sFileName As String, ByVal StartAt As Integer, ByVal NumBytes As Integer) As Byte()
    Dim Bytes() As Byte = New Byte(NumBytes - 1) {}
    Try
      Using fsSource As FileStream = New FileStream(sFileName, _
          FileMode.Open, FileAccess.Read)
        ' Read the source file into a byte array.
        fsSource.Position = StartAt
        Dim n As Integer = fsSource.Read(Bytes, 0, NumBytes)
        fsSource.Close()
      End Using
    Catch ioEx As FileNotFoundException
      Call MsgBox("Error in GetFileByteLen" & vbCrLf & ioEx.Message, MsgBoxStyle.AbortRetryIgnore, "Error!")
    End Try
    Return Bytes
  End Function

  'The calling function issue:
  '1. Creating a FileStream for reading: fs
  '2. Close the FileStream after finishing reading: fs.Close()
  Function GetFileByteLen2(ByRef fs As FileStream, ByVal StartAt As Integer, _
    ByVal NumByte As Integer) As Byte()
    Dim tmpByteArray() As Byte
    ReDim tmpByteArray(NumByte)
    fs.Position = StartAt 'Is this necessary as fs has fs.stream.position? Kept just in case the consecutive readings may not be continuous
    fs.Read(tmpByteArray, 0, NumByte)
    Return tmpByteArray
  End Function

  Sub SaveFileByte(ByVal InByteArray() As Byte, ByVal lArrayLen As Integer, _
  ByVal sFileName As String, Optional ByVal Offset As Integer = 0)
    Try
      Using fs As New FileStream(sFileName, FileMode.Create, FileAccess.Write)
        fs.Write(InByteArray, Offset, lArrayLen)
      End Using
    Catch ex As Exception
      Call MsgBox("Error in SaveFileByte" & vbCrLf & ex.Message, MsgBoxStyle.AbortRetryIgnore, "Error!")
    End Try
  End Sub


  Function Cat(ByRef sDest As String, ByRef sInputFiles() As String) As Boolean
    Dim I As Integer
    Dim sFileStr As String
    Dim sw As StreamWriter = File.CreateText(sDest)
    For I = 0 To UBound(sInputFiles)
      sFileStr = System.IO.File.ReadAllText(sInputFiles(I))
      sw.Write(sFileStr)
    Next
    sw.Flush()
    sw.Close()
    Return True
  End Function



  Function GetAttrDescr(ByRef sFileName As String) As String

    Dim Result As String, attr As Integer


    attr = GetAttr(sFileName)


    If attr And vbDirectory Then Result = Result & " Directory"
    If attr And vbReadOnly Then Result = Result & " ReadOnly"
    If attr And vbHidden Then Result = Result & " Hidden"
    If attr And vbSystem Then Result = Result & " System"
    If attr And vbArchive Then Result = Result & " Archive"


    GetAttrDescr = Mid(Result, 2)
  End Function


  Function IsTextFile(ByRef FileStr As String, ByVal Ch2Test As Integer) As Boolean

    Dim I As Integer, tmpStr As String, ByteArray() As Byte
    tmpStr = Left(FileStr, Ch2Test)
    ByteArray = Encoding.ASCII.GetBytes(tmpStr)

    IsTextFile = True
    For I = 0 To Ch2Test - 1
      If ByteArray(I) > 126 Then
        IsTextFile = False
        Exit Function
      End If
    Next I
  End Function


  'Short DOS file name with "~" to long file name
  'e.g.,
  'a="C:\Progra~1\DAMBE\VertebrateMtCOI.pml":print longfilename((a))

  Public Function LongFileName(ByVal short_name As String) As String
    Dim pos As Short
    Dim Result As String
    Dim long_name As String


    If Mid(short_name, 2, 1) = ":" Then
      Result = Left(short_name, 2)
      pos = 3
    Else
      Result = ""
      pos = 1
    End If


    Do While pos > 0

      pos = InStr(pos + 1, short_name, Path.DirectorySeparatorChar)


      If pos = 0 Then
        long_name = Dir(short_name, vbNormal + _
        vbHidden + vbSystem + vbDirectory)
      Else
        long_name = Dir(Left(short_name, pos - 1), vbNormal + vbHidden + vbSystem + _
        vbDirectory)
      End If
      Result = Result & Path.DirectorySeparatorChar & long_name
    Loop

    LongFileName = Result
  End Function


  'vbNormal 0 Normal (default).
  'vbReadOnly 1 Read-only.
  'vbHidden 2 Hidden.
  'ReadOnly and Hidden: vbHidden + vbReadOnly
  'vbSystem 4 System file.
  'vbArchive 32 File has changed since last backup.

  Sub ChangeFileAttribute(ByRef sFile As String, ByVal Attrib As FileAttributes)

    Call SetAttr(sFile, Attrib)
  End Sub



  Function GetSpecialFolder2(ByVal UserProfile0Windows1Temp2MyDoc3ComSpec4OS5Path6PathExt7 As Integer) As String
    'The Environ$ function is use to receive the value of an environment variable.
    'For example,when you put the WINDIR command (Windows),you would have obtained the folder where Windows is installed (C:\Windows\).
    'These variables can use in batch file,through the Run utility and in a programming environment such as VB and VBA.
    'Typing % UserProfile%,it will bring in the current user file.
    'Typing % UserProfile%\My Documents" it will bring in the My Documents folder.
    'Typing %WinDir% for the Windows folder... or%tmp% to access temporary files,etc ...
    'System variables
    'ComSpec variable path for the command prompt.
    'FP_NO_HOST_CHECK?
    'NUMBER_OF_PROCESSORS?
    'OS Returns OS in use.
    'Path?
    'PATHEXT?

    Select Case UserProfile0Windows1Temp2MyDoc3ComSpec4OS5Path6PathExt7
      Case 0
        Return Environ("USERPROFILE") & Path.DirectorySeparatorChar
      Case 1
        Return Environ("WinDir") & Path.DirectorySeparatorChar
      Case 2
        Return Environ("Temp") & Path.DirectorySeparatorChar
      Case 3
        Return Environ("USERPROFILE") & "\My Documents\"
      Case 4
        Return Environ("ComSpec") & Path.DirectorySeparatorChar
      Case 5
        Return Environ("OS") & Path.DirectorySeparatorChar
      Case 6
        Return Environ("Path") & Path.DirectorySeparatorChar
      Case Else '7
        Return Environ("PathExt") & Path.DirectorySeparatorChar
    End Select
  End Function

  Public Function GetFileList(ByVal targetDirectory As String, ByVal sCommaDelimitedType As String) As String()
    Dim I As Integer = 0, CC As Integer = 0
    Dim fileEntries As String() = Directory.GetFiles(targetDirectory)
    Dim sType As String = sCommaDelimitedType & ","
    Dim sTmp As String

    sType = UCase(sType)
    For I = 0 To UBound(fileEntries)
      sTmp = UCase(RightOfChar(fileEntries(I), ".") & ",")
      If InStr(sType, sTmp) > 0 Then
        fileEntries(CC) = fileEntries(I)
        CC = CC + 1
      End If
    Next I
    ReDim Preserve fileEntries(CC - 1)
    Return fileEntries
  End Function

End Module
