﻿Imports System.Windows.Forms

Public Class dlgFind
  Private mDone As Boolean, mSearchText As String, mMatchCase As Boolean, mWholeWord As Boolean, mSearchDown As Boolean
  Function GetFindParam(ByRef sSearchText As String, ByRef bMatchCase As Boolean, ByRef bWholeWord As Boolean, ByRef bSearchDown As Boolean) As Boolean
    Me.ShowDialog()
    If mDone Then
      sSearchText = mSearchText
      bMatchCase = mMatchCase
      bWholeWord = mWholeWord
      bSearchDown = mSearchDown
      Return True
    Else
      Return False
    End If
  End Function

  Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
    mSearchText = txtSearchText.Text
    If mSearchText.Length = 0 Then
      MsgBox("Please enter your search text")
      txtSearchText.Focus()
      Exit Sub
    End If
    mMatchCase = chkMatchCase.Checked
    mWholeWord = chkMatchWholeWord.Checked
    mSearchDown = rbDown.Checked
    mDone = True
    Me.DialogResult = System.Windows.Forms.DialogResult.OK
    Me.Close()
  End Sub

  Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
    Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Close()
  End Sub

  Private Sub dlgFind_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    Me.ActiveControl = txtSearchText
  End Sub
End Class
