﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class dlgFastqInfo
  Inherits System.Windows.Forms.Form

  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> _
  Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    Try
      If disposing AndAlso components IsNot Nothing Then
        components.Dispose()
      End If
    Finally
      MyBase.Dispose(disposing)
    End Try
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> _
  Private Sub InitializeComponent()
    Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
    Me.OK_Button = New System.Windows.Forms.Button()
    Me.Cancel_Button = New System.Windows.Forms.Button()
    Me.btnBrowse = New System.Windows.Forms.Button()
    Me.chkBaseQual = New System.Windows.Forms.CheckBox()
    Me.txtFastqFile = New System.Windows.Forms.TextBox()
    Me.Label1 = New System.Windows.Forms.Label()
    Me.chkSeqQual = New System.Windows.Forms.CheckBox()
    Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
    Me.PictureBox1 = New System.Windows.Forms.PictureBox()
    Me.chkPlotSeqLen = New System.Windows.Forms.CheckBox()
    Me.TableLayoutPanel1.SuspendLayout()
    CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.SuspendLayout()
    '
    'TableLayoutPanel1
    '
    Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.TableLayoutPanel1.ColumnCount = 2
    Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.Controls.Add(Me.OK_Button, 0, 0)
    Me.TableLayoutPanel1.Controls.Add(Me.Cancel_Button, 1, 0)
    Me.TableLayoutPanel1.Location = New System.Drawing.Point(501, 474)
    Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
    Me.TableLayoutPanel1.RowCount = 1
    Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.Size = New System.Drawing.Size(146, 29)
    Me.TableLayoutPanel1.TabIndex = 0
    '
    'OK_Button
    '
    Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
    Me.OK_Button.Location = New System.Drawing.Point(3, 3)
    Me.OK_Button.Name = "OK_Button"
    Me.OK_Button.Size = New System.Drawing.Size(67, 23)
    Me.OK_Button.TabIndex = 0
    Me.OK_Button.Text = "OK"
    '
    'Cancel_Button
    '
    Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
    Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Cancel_Button.Location = New System.Drawing.Point(76, 3)
    Me.Cancel_Button.Name = "Cancel_Button"
    Me.Cancel_Button.Size = New System.Drawing.Size(67, 23)
    Me.Cancel_Button.TabIndex = 1
    Me.Cancel_Button.Text = "Cancel"
    '
    'btnBrowse
    '
    Me.btnBrowse.Location = New System.Drawing.Point(573, 375)
    Me.btnBrowse.Name = "btnBrowse"
    Me.btnBrowse.Size = New System.Drawing.Size(75, 23)
    Me.btnBrowse.TabIndex = 10
    Me.btnBrowse.Text = "Browse"
    Me.btnBrowse.UseVisualStyleBackColor = True
    '
    'chkBaseQual
    '
    Me.chkBaseQual.AutoSize = True
    Me.chkBaseQual.Checked = True
    Me.chkBaseQual.CheckState = System.Windows.Forms.CheckState.Checked
    Me.chkBaseQual.Location = New System.Drawing.Point(12, 415)
    Me.chkBaseQual.Name = "chkBaseQual"
    Me.chkBaseQual.Size = New System.Drawing.Size(177, 17)
    Me.chkBaseQual.TabIndex = 9
    Me.chkBaseQual.Text = "Graphic display of base qualities"
    Me.chkBaseQual.UseVisualStyleBackColor = True
    '
    'txtFastqFile
    '
    Me.txtFastqFile.Location = New System.Drawing.Point(12, 378)
    Me.txtFastqFile.Name = "txtFastqFile"
    Me.txtFastqFile.Size = New System.Drawing.Size(555, 20)
    Me.txtFastqFile.TabIndex = 8
    '
    'Label1
    '
    Me.Label1.AutoSize = True
    Me.Label1.Location = New System.Drawing.Point(13, 362)
    Me.Label1.Name = "Label1"
    Me.Label1.Size = New System.Drawing.Size(114, 13)
    Me.Label1.TabIndex = 7
    Me.Label1.Text = "Input FASTQ file name"
    '
    'chkSeqQual
    '
    Me.chkSeqQual.AutoSize = True
    Me.chkSeqQual.Checked = True
    Me.chkSeqQual.CheckState = System.Windows.Forms.CheckState.Checked
    Me.chkSeqQual.Location = New System.Drawing.Point(12, 447)
    Me.chkSeqQual.Name = "chkSeqQual"
    Me.chkSeqQual.Size = New System.Drawing.Size(316, 17)
    Me.chkSeqQual.TabIndex = 11
    Me.chkSeqQual.Text = "Graphic display of frequency distribution of sequence qualities"
    Me.chkSeqQual.UseVisualStyleBackColor = True
    '
    'OpenFileDialog1
    '
    Me.OpenFileDialog1.FileName = "OpenFileDialog1"
    '
    'PictureBox1
    '
    Me.PictureBox1.Image = Global.ARSDA.My.Resources.Resources.FastqInfo
    Me.PictureBox1.Location = New System.Drawing.Point(12, 12)
    Me.PictureBox1.Name = "PictureBox1"
    Me.PictureBox1.Size = New System.Drawing.Size(636, 337)
    Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
    Me.PictureBox1.TabIndex = 6
    Me.PictureBox1.TabStop = False
    '
    'chkPlotSeqLen
    '
    Me.chkPlotSeqLen.AutoSize = True
    Me.chkPlotSeqLen.Checked = True
    Me.chkPlotSeqLen.CheckState = System.Windows.Forms.CheckState.Checked
    Me.chkPlotSeqLen.Location = New System.Drawing.Point(12, 481)
    Me.chkPlotSeqLen.Name = "chkPlotSeqLen"
    Me.chkPlotSeqLen.Size = New System.Drawing.Size(365, 17)
    Me.chkPlotSeqLen.TabIndex = 12
    Me.chkPlotSeqLen.Text = "If sequence lengths differ, plot frequency distribution of sequence length"
    Me.chkPlotSeqLen.UseVisualStyleBackColor = True
    '
    'dlgFastqInfo
    '
    Me.AcceptButton = Me.OK_Button
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.CancelButton = Me.Cancel_Button
    Me.ClientSize = New System.Drawing.Size(659, 515)
    Me.Controls.Add(Me.chkPlotSeqLen)
    Me.Controls.Add(Me.chkSeqQual)
    Me.Controls.Add(Me.btnBrowse)
    Me.Controls.Add(Me.chkBaseQual)
    Me.Controls.Add(Me.txtFastqFile)
    Me.Controls.Add(Me.Label1)
    Me.Controls.Add(Me.PictureBox1)
    Me.Controls.Add(Me.TableLayoutPanel1)
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "dlgFastqInfo"
    Me.ShowInTaskbar = False
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
    Me.Text = "Sequence Information of an Input FASTQ File"
    Me.TableLayoutPanel1.ResumeLayout(False)
    CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
  Friend WithEvents OK_Button As System.Windows.Forms.Button
  Friend WithEvents Cancel_Button As System.Windows.Forms.Button
  Friend WithEvents btnBrowse As System.Windows.Forms.Button
  Friend WithEvents chkBaseQual As System.Windows.Forms.CheckBox
  Friend WithEvents txtFastqFile As System.Windows.Forms.TextBox
  Friend WithEvents Label1 As System.Windows.Forms.Label
  Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
  Friend WithEvents chkSeqQual As System.Windows.Forms.CheckBox
  Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
  Friend WithEvents chkPlotSeqLen As System.Windows.Forms.CheckBox

End Class
