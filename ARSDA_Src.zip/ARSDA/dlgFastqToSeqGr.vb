﻿Imports System.Windows.Forms
Imports System.IO

Public Class dlgFastqToSeqGr
  Private mDone As Boolean, mFastqFile() As String, mFasFileOrDir As String, mNoAmbiguousNuc 'Dir if mNumFastqFile > 1
  Private mNumFastqFile As Integer
  Private mFasInput As Boolean
  Public Function GetFastqToSeqGrParam(ByRef sFastqFile() As String, ByRef sFasFileOrDir As String, ByRef iNumFastqFile As Integer, ByRef bNoAmbiguousNuc As Boolean, Optional ByVal bFasInput As Boolean = False) As Boolean
    'bFasInput = True: Fas file as input, false: Fastq file as input
    mDone = False
    mFasInput = bFasInput
    Me.ShowDialog()
    If mDone Then
      sFastqFile = mFastqFile
      sFasFileOrDir = mFasFileOrDir
      iNumFastqFile = mNumFastqFile
      bNoAmbiguousNuc = mNoAmbiguousNuc
      Return True
    Else
      Return False
    End If
  End Function
  Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
    If chkMultFile.Checked Then
      mFasFileOrDir = txtFasFile.Text
      If Not Directory.Exists(mFasFileOrDir) Then
        MsgBox("Your specified output directory: " & mFasFileOrDir & " does not exist.", vbInformation)
        Exit Sub
      End If
    Else
      ReDim mFastqFile(0)
      mNumFastqFile = 1
      mFastqFile(0) = txtFastqFile.Text
      If Not File.Exists(mFastqFile(0)) Then
        MsgBox("The input FASTQ file " & mFastqFile(0) & " does not exist.", vbOKOnly)
        txtFastqFile.Focus()
        Exit Sub
      End If
      mFasFileOrDir = txtFasFile.Text
      If Trim(mFasFileOrDir) = "" Then
        MsgBox("Please enter name for the output FASTA file.", vbOKOnly)
        txtFasFile.Focus()
        Exit Sub
      End If
    End If
    mNoAmbiguousNuc = chkNoAmbigousSeq.Checked
    mDone = True
    Me.DialogResult = System.Windows.Forms.DialogResult.OK
    Me.Close()
  End Sub

  Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
    Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Close()
  End Sub

  Private Sub btnBrowseFastq_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseFastq.Click
    Dim sFilter As String, sDialog As String
    If mFasInput Then
      sFilter = "fasta,fas,fasp"
      sDialog = "Open FASTA file"
    Else
      sFilter = "fastq,fq"
      sDialog = "Open FASTQ file"
    End If
    If chkMultFile.Checked Then
      If Directory.Exists(txtFastqFile.Text) Then
        mFastqFile = GetFileArray(OpenFileDialog1, sFilter, txtFastqFile.Text)
      Else
        mFastqFile = GetFileArray(OpenFileDialog1, sFilter, sInputDir)
      End If
      mNumFastqFile = UBound(mFastqFile) + 1
      txtFastqFile.Text = mNumFastqFile & " files to process."
      If mNumFastqFile > 0 Then
        txtFasFile.Text = Path.GetDirectoryName(mFastqFile(0))
      End If
    Else
      If Directory.Exists(txtFastqFile.Text) Then
        txtFastqFile.Text = GetOpenFileName(sDialog, sFilter, OpenFileDialog1, txtFastqFile.Text)
      Else
        txtFastqFile.Text = GetOpenFileName(sDialog, sFilter, OpenFileDialog1, sInputDir)
      End If
      txtFasFile.Text = Path.ChangeExtension(txtFastqFile.Text, ".fas")
    End If
  End Sub

  Private Sub BrowseFasta_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BrowseFasta.Click
    If chkMultFile.Checked Then
      If Trim(txtFastqFile.Text) = "" Then
        MsgBox("Choose one or more FASTQ files first.", vbInformation)
        Exit Sub
      Else
        Dim sPath As String
        If mNumFastqFile > 0 Then
          sPath = Path.GetDirectoryName(mFastqFile(0))
        End If
        With FolderBrowserDialog1
          .SelectedPath = sPath
        End With
        End If
        If (FolderBrowserDialog1.ShowDialog() = DialogResult.OK) Then
          txtFasFile.Text = FolderBrowserDialog1.SelectedPath
        End If
    Else
        If Trim(txtFastqFile.Text) = "" Then
          MsgBox("Please choose one or more FASTQ files first.", vbInformation)
          Exit Sub
        Else
          Dim sFN As String = GetFNOnly(txtFastqFile.Text)
          Dim sPath As String = Path.GetDirectoryName(txtFastqFile.Text)
          txtFasFile.Text = GetSaveFileName("Save to...", "fas", SaveFileDialog1, sPath, sFN)
        End If
    End If
  End Sub

  Private Sub dlgFastqToSeqGr_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    If mFasInput Then
      lblFastqFile.Text = "Input fasta file:"
      'PictureBox1.Image = My.Resources.ResourceManager.GetObject("Fas2FasPlus")
      PictureBox1.Image = My.Resources.Resources.Fas2FasPlus
    Else
      lblFastqFile.Text = "Input fastq file:"
      PictureBox1.Image = My.Resources.Resources.Fastq2SeqGroup
    End If
  End Sub

End Class
