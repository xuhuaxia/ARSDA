﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class dlgPairedFastq2PairedFasPlus
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
    Me.OK_Button = New System.Windows.Forms.Button()
    Me.Cancel_Button = New System.Windows.Forms.Button()
    Me.lblInfo = New System.Windows.Forms.Label()
    Me.btnBrowseFasPlusFile2 = New System.Windows.Forms.Button()
    Me.btnBrowseFastq1 = New System.Windows.Forms.Button()
    Me.txtFasPlusFile1 = New System.Windows.Forms.TextBox()
    Me.lblFasPlusFile2 = New System.Windows.Forms.Label()
    Me.txtFastqFile1 = New System.Windows.Forms.TextBox()
    Me.lblFastqFile1 = New System.Windows.Forms.Label()
    Me.PictureBox1 = New System.Windows.Forms.PictureBox()
    Me.lblFasPlusFile1 = New System.Windows.Forms.Label()
    Me.btnBrowseFasPlusFile1 = New System.Windows.Forms.Button()
    Me.txtFasPlusFile2 = New System.Windows.Forms.TextBox()
    Me.lblFastqFile2 = New System.Windows.Forms.Label()
    Me.btnBrowseFastqFile2 = New System.Windows.Forms.Button()
    Me.txtFastqFile2 = New System.Windows.Forms.TextBox()
    Me.lblReadLen = New System.Windows.Forms.Label()
    Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
    Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
    Me.txtReadLen = New System.Windows.Forms.TextBox()
    Me.lblReadLenInfo = New System.Windows.Forms.Label()
    Me.TableLayoutPanel1.SuspendLayout()
    CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.SuspendLayout()
    '
    'TableLayoutPanel1
    '
    Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.TableLayoutPanel1.ColumnCount = 2
    Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.Controls.Add(Me.OK_Button, 0, 0)
    Me.TableLayoutPanel1.Controls.Add(Me.Cancel_Button, 1, 0)
    Me.TableLayoutPanel1.Location = New System.Drawing.Point(605, 601)
    Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
    Me.TableLayoutPanel1.RowCount = 1
    Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.Size = New System.Drawing.Size(146, 29)
    Me.TableLayoutPanel1.TabIndex = 0
    '
    'OK_Button
    '
    Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
    Me.OK_Button.Location = New System.Drawing.Point(3, 3)
    Me.OK_Button.Name = "OK_Button"
    Me.OK_Button.Size = New System.Drawing.Size(67, 23)
    Me.OK_Button.TabIndex = 0
    Me.OK_Button.Text = "OK"
    '
    'Cancel_Button
    '
    Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
    Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Cancel_Button.Location = New System.Drawing.Point(76, 3)
    Me.Cancel_Button.Name = "Cancel_Button"
    Me.Cancel_Button.Size = New System.Drawing.Size(67, 23)
    Me.Cancel_Button.TabIndex = 1
    Me.Cancel_Button.Text = "Cancel"
    '
    'lblInfo
    '
    Me.lblInfo.AutoSize = True
    Me.lblInfo.Location = New System.Drawing.Point(12, 620)
    Me.lblInfo.Name = "lblInfo"
    Me.lblInfo.Size = New System.Drawing.Size(297, 13)
    Me.lblInfo.TabIndex = 42
    Me.lblInfo.Text = "Note: Sequences containing unresolved nuc. will be removed"
    '
    'btnBrowseFasPlusFile2
    '
    Me.btnBrowseFasPlusFile2.Location = New System.Drawing.Point(673, 545)
    Me.btnBrowseFasPlusFile2.Name = "btnBrowseFasPlusFile2"
    Me.btnBrowseFasPlusFile2.Size = New System.Drawing.Size(75, 23)
    Me.btnBrowseFasPlusFile2.TabIndex = 40
    Me.btnBrowseFasPlusFile2.Text = "Browse"
    Me.btnBrowseFasPlusFile2.UseVisualStyleBackColor = True
    '
    'btnBrowseFastq1
    '
    Me.btnBrowseFastq1.Location = New System.Drawing.Point(673, 439)
    Me.btnBrowseFastq1.Name = "btnBrowseFastq1"
    Me.btnBrowseFastq1.Size = New System.Drawing.Size(75, 23)
    Me.btnBrowseFastq1.TabIndex = 39
    Me.btnBrowseFastq1.Text = "Browse"
    Me.btnBrowseFastq1.UseVisualStyleBackColor = True
    '
    'txtFasPlusFile1
    '
    Me.txtFasPlusFile1.Location = New System.Drawing.Point(118, 511)
    Me.txtFasPlusFile1.Name = "txtFasPlusFile1"
    Me.txtFasPlusFile1.Size = New System.Drawing.Size(549, 20)
    Me.txtFasPlusFile1.TabIndex = 38
    '
    'lblFasPlusFile2
    '
    Me.lblFasPlusFile2.AutoSize = True
    Me.lblFasPlusFile2.Location = New System.Drawing.Point(12, 554)
    Me.lblFasPlusFile2.Name = "lblFasPlusFile2"
    Me.lblFasPlusFile2.Size = New System.Drawing.Size(98, 13)
    Me.lblFasPlusFile2.TabIndex = 37
    Me.lblFasPlusFile2.Text = "Out FASTA+_2 file:"
    '
    'txtFastqFile1
    '
    Me.txtFastqFile1.Location = New System.Drawing.Point(118, 441)
    Me.txtFastqFile1.Name = "txtFastqFile1"
    Me.txtFastqFile1.Size = New System.Drawing.Size(549, 20)
    Me.txtFastqFile1.TabIndex = 36
    '
    'lblFastqFile1
    '
    Me.lblFastqFile1.AutoSize = True
    Me.lblFastqFile1.Location = New System.Drawing.Point(12, 444)
    Me.lblFastqFile1.Name = "lblFastqFile1"
    Me.lblFastqFile1.Size = New System.Drawing.Size(100, 13)
    Me.lblFastqFile1.TabIndex = 35
    Me.lblFastqFile1.Text = "Input FASTQ_1 file:"
    '
    'PictureBox1
    '
    Me.PictureBox1.Image = Global.ARSDA.My.Resources.Resources.FastqPairedToFasPaired
    Me.PictureBox1.Location = New System.Drawing.Point(3, 12)
    Me.PictureBox1.Name = "PictureBox1"
    Me.PictureBox1.Size = New System.Drawing.Size(749, 405)
    Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
    Me.PictureBox1.TabIndex = 41
    Me.PictureBox1.TabStop = False
    '
    'lblFasPlusFile1
    '
    Me.lblFasPlusFile1.AutoSize = True
    Me.lblFasPlusFile1.Location = New System.Drawing.Point(12, 516)
    Me.lblFasPlusFile1.Name = "lblFasPlusFile1"
    Me.lblFasPlusFile1.Size = New System.Drawing.Size(98, 13)
    Me.lblFasPlusFile1.TabIndex = 43
    Me.lblFasPlusFile1.Text = "Out FASTA+_1 file:"
    '
    'btnBrowseFasPlusFile1
    '
    Me.btnBrowseFasPlusFile1.Location = New System.Drawing.Point(673, 511)
    Me.btnBrowseFasPlusFile1.Name = "btnBrowseFasPlusFile1"
    Me.btnBrowseFasPlusFile1.Size = New System.Drawing.Size(75, 23)
    Me.btnBrowseFasPlusFile1.TabIndex = 44
    Me.btnBrowseFasPlusFile1.Text = "Browse"
    Me.btnBrowseFasPlusFile1.UseVisualStyleBackColor = True
    '
    'txtFasPlusFile2
    '
    Me.txtFasPlusFile2.Location = New System.Drawing.Point(118, 547)
    Me.txtFasPlusFile2.Name = "txtFasPlusFile2"
    Me.txtFasPlusFile2.Size = New System.Drawing.Size(549, 20)
    Me.txtFasPlusFile2.TabIndex = 45
    '
    'lblFastqFile2
    '
    Me.lblFastqFile2.AutoSize = True
    Me.lblFastqFile2.Location = New System.Drawing.Point(12, 478)
    Me.lblFastqFile2.Name = "lblFastqFile2"
    Me.lblFastqFile2.Size = New System.Drawing.Size(100, 13)
    Me.lblFastqFile2.TabIndex = 46
    Me.lblFastqFile2.Text = "Input FASTQ_2 file:"
    '
    'btnBrowseFastqFile2
    '
    Me.btnBrowseFastqFile2.Location = New System.Drawing.Point(673, 473)
    Me.btnBrowseFastqFile2.Name = "btnBrowseFastqFile2"
    Me.btnBrowseFastqFile2.Size = New System.Drawing.Size(75, 23)
    Me.btnBrowseFastqFile2.TabIndex = 47
    Me.btnBrowseFastqFile2.Text = "Browse"
    Me.btnBrowseFastqFile2.UseVisualStyleBackColor = True
    '
    'txtFastqFile2
    '
    Me.txtFastqFile2.Location = New System.Drawing.Point(118, 475)
    Me.txtFastqFile2.Name = "txtFastqFile2"
    Me.txtFastqFile2.Size = New System.Drawing.Size(549, 20)
    Me.txtFastqFile2.TabIndex = 48
    '
    'lblReadLen
    '
    Me.lblReadLen.AutoSize = True
    Me.lblReadLen.Location = New System.Drawing.Point(12, 588)
    Me.lblReadLen.Name = "lblReadLen"
    Me.lblReadLen.Size = New System.Drawing.Size(68, 13)
    Me.lblReadLen.TabIndex = 50
    Me.lblReadLen.Text = "Read length:"
    '
    'OpenFileDialog1
    '
    Me.OpenFileDialog1.FileName = "OpenFileDialog1"
    '
    'txtReadLen
    '
    Me.txtReadLen.Location = New System.Drawing.Point(118, 585)
    Me.txtReadLen.Name = "txtReadLen"
    Me.txtReadLen.Size = New System.Drawing.Size(42, 20)
    Me.txtReadLen.TabIndex = 51
    Me.txtReadLen.Text = "50"
    Me.txtReadLen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
    '
    'lblReadLenInfo
    '
    Me.lblReadLenInfo.AutoSize = True
    Me.lblReadLenInfo.Location = New System.Drawing.Point(166, 588)
    Me.lblReadLenInfo.Name = "lblReadLenInfo"
    Me.lblReadLenInfo.Size = New System.Drawing.Size(336, 13)
    Me.lblReadLenInfo.TabIndex = 52
    Me.lblReadLenInfo.Text = "(Shorter sequences will be excluded and longer sequences truncated)"
    '
    'dlgPairedFastq2PairedFasPlus
    '
    Me.AcceptButton = Me.OK_Button
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.CancelButton = Me.Cancel_Button
    Me.ClientSize = New System.Drawing.Size(763, 642)
    Me.Controls.Add(Me.lblReadLenInfo)
    Me.Controls.Add(Me.txtReadLen)
    Me.Controls.Add(Me.lblReadLen)
    Me.Controls.Add(Me.txtFastqFile2)
    Me.Controls.Add(Me.btnBrowseFastqFile2)
    Me.Controls.Add(Me.lblFastqFile2)
    Me.Controls.Add(Me.txtFasPlusFile2)
    Me.Controls.Add(Me.btnBrowseFasPlusFile1)
    Me.Controls.Add(Me.lblFasPlusFile1)
    Me.Controls.Add(Me.lblInfo)
    Me.Controls.Add(Me.PictureBox1)
    Me.Controls.Add(Me.btnBrowseFasPlusFile2)
    Me.Controls.Add(Me.btnBrowseFastq1)
    Me.Controls.Add(Me.txtFasPlusFile1)
    Me.Controls.Add(Me.lblFasPlusFile2)
    Me.Controls.Add(Me.txtFastqFile1)
    Me.Controls.Add(Me.lblFastqFile1)
    Me.Controls.Add(Me.TableLayoutPanel1)
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "dlgPairedFastq2PairedFasPlus"
    Me.ShowInTaskbar = False
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
    Me.Text = "Paired FASTQ to Paired FasPlus"
    Me.TableLayoutPanel1.ResumeLayout(False)
    CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
  Friend WithEvents OK_Button As System.Windows.Forms.Button
  Friend WithEvents Cancel_Button As System.Windows.Forms.Button
  Friend WithEvents lblInfo As System.Windows.Forms.Label
  Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
  Friend WithEvents btnBrowseFasPlusFile2 As System.Windows.Forms.Button
  Friend WithEvents btnBrowseFastq1 As System.Windows.Forms.Button
  Friend WithEvents txtFasPlusFile1 As System.Windows.Forms.TextBox
  Friend WithEvents lblFasPlusFile2 As System.Windows.Forms.Label
  Friend WithEvents txtFastqFile1 As System.Windows.Forms.TextBox
  Friend WithEvents lblFastqFile1 As System.Windows.Forms.Label
  Friend WithEvents lblFasPlusFile1 As System.Windows.Forms.Label
  Friend WithEvents btnBrowseFasPlusFile1 As System.Windows.Forms.Button
  Friend WithEvents txtFasPlusFile2 As System.Windows.Forms.TextBox
  Friend WithEvents lblFastqFile2 As System.Windows.Forms.Label
  Friend WithEvents btnBrowseFastqFile2 As System.Windows.Forms.Button
  Friend WithEvents txtFastqFile2 As System.Windows.Forms.TextBox
  Friend WithEvents lblReadLen As System.Windows.Forms.Label
  Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
  Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
  Friend WithEvents txtReadLen As System.Windows.Forms.TextBox
  Friend WithEvents lblReadLenInfo As System.Windows.Forms.Label

End Class
