﻿Imports System.Windows.Forms
Imports System.IO

Public Class dlgFastqToFas
  Private mDone As Boolean, mFastqFile As String, mFasFile As String
  Public Function GetFastqToFasParam(ByRef sFastqFile As String, ByRef sFasFile As String) As Boolean
    mDone = False
    Me.ShowDialog()
    If mDone Then
      sFastqFile = mFastqFile
      sFasFile = mFasFile
      Return True
    Else
      Return False
    End If

  End Function
  Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
    mFastqFile = txtFastqFile.Text
    If Not File.Exists(mFastqFile) Then
      MsgBox("The input FASTQ file " & mFastqFile & " does not exist.", vbOKOnly)
      txtFastqFile.Focus()
      Exit Sub
    End If
    mFasFile = txtFasFile.Text
    If Trim(mFasFile) = "" Then
      MsgBox("Please enter name for the output FASTA file.", vbOKOnly)
      txtFasFile.Focus()
      Exit Sub
    End If
    mDone = True
    Me.DialogResult = System.Windows.Forms.DialogResult.OK
    Me.Close()
  End Sub

  Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
    Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Close()
  End Sub

  Private Sub btnBrowseFastq_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseFastq.Click
    If Directory.Exists(txtFastqFile.Text) Then
      txtFastqFile.Text = GetOpenFileName("Open FASTQ file", "fastq,fq,fastqP,fqP", OpenFileDialog1, txtFastqFile.Text)
    Else
      txtFastqFile.Text = GetOpenFileName("Open FASTQ file", "fastq,fq,fastqP,fqP", OpenFileDialog1, sInputDir)
    End If
  End Sub

  Private Sub BrowseFasta_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BrowseFasta.Click
    If Trim(txtFastqFile.Text) = "" Then
      txtFasFile.Text = GetSaveFileName("Save to...", "fas,fasP", SaveFileDialog1, sNewDataDir)
    Else
      Dim sFN As String = GetFNOnly(txtFastqFile.Text)
      Dim sPath As String = Path.GetDirectoryName(txtFastqFile.Text)
      txtFasFile.Text = GetSaveFileName("Save to...", "fas,fasP", SaveFileDialog1, sPath, sFN)
    End If
  End Sub

End Class
