﻿Imports System.Windows.Forms
Imports System.IO

Public Class dlgPairedFastq2PairedFasPlus

  Private mDone As Boolean, mFastqFile1 As String, mFastqFile2 As String, mFasFile1 As String, mFasFile2 As String
  Private mReadLen As Integer 'Only those with SeqQual greater than the cutoff will be kept.
  Public Function GetPairedFastqToPairedFasParam(ByRef sFastqFile1 As String, ByRef sFastqFile2 As String, _
                                                 ByRef sFasFile1 As String, ByRef sFasFile2 As String, ByRef iReadLen As Integer) As Boolean
    mDone = False

    Me.ShowDialog()
    If mDone Then
      sFastqFile1 = mFastqFile1
      sFastqFile2 = mFastqFile2
      sFasFile1 = mFasFile1
      sFasFile2 = mFasFile2
      iReadLen = mReadLen
      Return True
    Else
      Return False
    End If

  End Function

  Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
    mFastqFile1 = txtFastqFile1.Text
    If Not File.Exists(mFastqFile1) Then
      MsgBox("The input FASTQ file " & mFastqFile1 & " does not exist.", vbOKOnly)
      txtFastqFile1.Focus()
      Exit Sub
    End If
    mFastqFile2 = txtFastqFile2.Text
    If Not File.Exists(mFastqFile2) Then
      MsgBox("The input FASTQ file " & mFastqFile2 & " does not exist.", vbOKOnly)
      txtFastqFile2.Focus()
      Exit Sub
    End If
    mFasFile1 = txtFasPlusFile1.Text
    If Trim(mFasFile1) = "" Then
      MsgBox("Please enter name for the output FASTA file.", vbOKOnly)
      txtFasPlusFile1.Focus()
      Exit Sub
    End If
    mFasFile2 = txtFasPlusFile2.Text
    If Trim(mFasFile2) = "" Then
      MsgBox("Please enter name for the output FASTA file.", vbOKOnly)
      txtFasPlusFile2.Focus()
      Exit Sub
    End If
    mReadLen = Val(txtReadLen.Text)
    If mReadLen < 50 Then
      If MsgBox("Are you sure that the read length is only " & mReadLen & "?", vbYesNo) = vbNo Then
        txtReadLen.Focus()
        Exit Sub
      End If
    End If
    mDone = True
    Me.DialogResult = System.Windows.Forms.DialogResult.OK
    Me.Close()
  End Sub

  Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
    Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Close()
  End Sub

  Private Sub btnBrowseFastq_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseFastq1.Click
    If Directory.Exists(txtFastqFile1.Text) Then
      txtFastqFile1.Text = GetOpenFileName("Open FASTQ file", "fastq,fq", OpenFileDialog1, txtFastqFile1.Text)
    Else
      txtFastqFile1.Text = GetOpenFileName("Open FASTQ file", "fastq,fq", OpenFileDialog1, sInputDir)
    End If
  End Sub


  Private Sub btnBrowseFasPlusFile1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseFasPlusFile1.Click
    If Trim(txtFastqFile1.Text) = "" Then
      txtFasPlusFile1.Text = GetSaveFileName("Save to...", "fasP,fastaP", SaveFileDialog1, sNewDataDir)
    Else
      Dim sFN As String = GetFNOnly(txtFastqFile1.Text)
      Dim sPath As String = Path.GetDirectoryName(txtFastqFile1.Text)
      txtFasPlusFile1.Text = GetSaveFileName("Save to...", "fasP,fastaP", SaveFileDialog1, sPath, sFN)
    End If

  End Sub

  Private Sub btnBrowseFasPlusFile2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseFasPlusFile2.Click
    If Trim(txtFastqFile2.Text) = "" Then
      txtFasPlusFile2.Text = GetSaveFileName("Save to...", "fasP,fastaP", SaveFileDialog1, sNewDataDir)
    Else
      Dim sFN As String = GetFNOnly(txtFastqFile2.Text)
      Dim sPath As String = Path.GetDirectoryName(txtFastqFile2.Text)
      txtFasPlusFile2.Text = GetSaveFileName("Save to...", "fasP,fastaP", SaveFileDialog1, sPath, sFN)
    End If

  End Sub

  Private Sub btnBrowseFastqFile2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseFastqFile2.Click
    If Directory.Exists(txtFastqFile2.Text) Then
      txtFastqFile2.Text = GetOpenFileName("Open FASTQ file", "fastq,fq", OpenFileDialog1, txtFastqFile2.Text)
    Else
      txtFastqFile2.Text = GetOpenFileName("Open FASTQ file", "fastq,fq", OpenFileDialog1, sInputDir)
    End If
  End Sub
End Class
