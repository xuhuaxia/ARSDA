﻿Imports System.Windows.Forms
Imports System.IO

Public Class dlgFastqToFastqPlus

  Private mDone As Boolean, mFastqFile As String, mFastqPlusFile As String, mReadLen As Integer
  Public Function GetFastqToFastqPlusParam(ByRef sFastqFile As String, ByRef sFastqPlusFile As String, ByRef iReadLen As Integer) As Boolean
    mDone = False
    Me.ShowDialog()
    If mDone Then
      sFastqFile = mFastqFile
      sFastqPlusFile = mFastqPlusFile
      iReadLen = mReadLen
      Return True
    Else
      Return False
    End If

  End Function
  Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
    mFastqFile = txtFastqFile.Text
    If Not File.Exists(mFastqFile) Then
      MsgBox("The input FASTQ file " & mFastqFile & " does not exist.", vbOKOnly)
      txtFastqFile.Focus()
      Exit Sub
    End If
    mFastqPlusFile = txtFastqPlusFile.Text
    If Trim(mFastqPlusFile) = "" Then
      MsgBox("Please enter name for the output FASTA file.", vbOKOnly)
      txtFastqPlusFile.Focus()
      Exit Sub
    End If
    mReadLen = Val(txtReadLen.Text)
    If mReadLen < 50 Then
      If MsgBox("Are you sure that the read length is only " & mReadLen & "?", vbYesNo) = vbNo Then
        txtReadLen.Focus()
        Exit Sub
      End If
    End If
    mDone = True
    Me.DialogResult = System.Windows.Forms.DialogResult.OK
    Me.Close()
  End Sub

  Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
    Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Close()
  End Sub

  Private Sub btnBrowseFastq_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseFastq.Click
    If Directory.Exists(txtFastqFile.Text) Then
      txtFastqFile.Text = GetOpenFileName("Open FASTQ file", "fastq,fq", OpenFileDialog1, txtFastqFile.Text)
    Else
      txtFastqFile.Text = GetOpenFileName("Open FASTQ file", "fastq,fq", OpenFileDialog1, sInputDir)
    End If
    txtFastqPlusFile.Text = Path.ChangeExtension(txtFastqFile.Text, ".fastqP")
  End Sub

  Private Sub BrowseFastqPlus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BrowseFastqPlus.Click
    If Trim(txtFastqFile.Text) = "" Then
      txtFastqPlusFile.Text = GetSaveFileName("Save to...", "fastqP", SaveFileDialog1, sNewDataDir)
    Else
      Dim sFN As String = GetFNOnly(txtFastqFile.Text)
      Dim sPath As String = Path.GetDirectoryName(txtFastqFile.Text)
      txtFastqPlusFile.Text = GetSaveFileName("Save to...", "fastqP", SaveFileDialog1, sPath, sFN)
    End If

  End Sub

End Class
