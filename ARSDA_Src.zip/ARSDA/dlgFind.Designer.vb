﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class dlgFind
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
    Me.OK_Button = New System.Windows.Forms.Button()
    Me.Cancel_Button = New System.Windows.Forms.Button()
    Me.lblFindWhat = New System.Windows.Forms.Label()
    Me.txtSearchText = New System.Windows.Forms.TextBox()
    Me.chkMatchWholeWord = New System.Windows.Forms.CheckBox()
    Me.chkMatchCase = New System.Windows.Forms.CheckBox()
    Me.frDirection = New System.Windows.Forms.GroupBox()
    Me.rbDown = New System.Windows.Forms.RadioButton()
    Me.rbUp = New System.Windows.Forms.RadioButton()
    Me.TableLayoutPanel1.SuspendLayout()
    Me.frDirection.SuspendLayout()
    Me.SuspendLayout()
    '
    'TableLayoutPanel1
    '
    Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.TableLayoutPanel1.ColumnCount = 2
    Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.Controls.Add(Me.OK_Button, 0, 0)
    Me.TableLayoutPanel1.Controls.Add(Me.Cancel_Button, 1, 0)
    Me.TableLayoutPanel1.Location = New System.Drawing.Point(277, 61)
    Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
    Me.TableLayoutPanel1.RowCount = 1
    Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.Size = New System.Drawing.Size(146, 29)
    Me.TableLayoutPanel1.TabIndex = 0
    '
    'OK_Button
    '
    Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
    Me.OK_Button.Location = New System.Drawing.Point(3, 3)
    Me.OK_Button.Name = "OK_Button"
    Me.OK_Button.Size = New System.Drawing.Size(67, 23)
    Me.OK_Button.TabIndex = 2
    Me.OK_Button.Text = "Find next"
    '
    'Cancel_Button
    '
    Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
    Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Cancel_Button.Location = New System.Drawing.Point(76, 3)
    Me.Cancel_Button.Name = "Cancel_Button"
    Me.Cancel_Button.Size = New System.Drawing.Size(67, 23)
    Me.Cancel_Button.TabIndex = 1
    Me.Cancel_Button.Text = "Cancel"
    '
    'lblFindWhat
    '
    Me.lblFindWhat.AutoSize = True
    Me.lblFindWhat.Location = New System.Drawing.Point(1, 7)
    Me.lblFindWhat.Name = "lblFindWhat"
    Me.lblFindWhat.Size = New System.Drawing.Size(56, 13)
    Me.lblFindWhat.TabIndex = 1
    Me.lblFindWhat.Text = "Find what:"
    '
    'txtSearchText
    '
    Me.txtSearchText.Location = New System.Drawing.Point(54, 4)
    Me.txtSearchText.Name = "txtSearchText"
    Me.txtSearchText.Size = New System.Drawing.Size(366, 20)
    Me.txtSearchText.TabIndex = 0
    '
    'chkMatchWholeWord
    '
    Me.chkMatchWholeWord.AutoSize = True
    Me.chkMatchWholeWord.Location = New System.Drawing.Point(4, 43)
    Me.chkMatchWholeWord.Name = "chkMatchWholeWord"
    Me.chkMatchWholeWord.Size = New System.Drawing.Size(113, 17)
    Me.chkMatchWholeWord.TabIndex = 3
    Me.chkMatchWholeWord.Text = "Match whole word"
    Me.chkMatchWholeWord.UseVisualStyleBackColor = True
    '
    'chkMatchCase
    '
    Me.chkMatchCase.AutoSize = True
    Me.chkMatchCase.Location = New System.Drawing.Point(4, 77)
    Me.chkMatchCase.Name = "chkMatchCase"
    Me.chkMatchCase.Size = New System.Drawing.Size(82, 17)
    Me.chkMatchCase.TabIndex = 4
    Me.chkMatchCase.Text = "Match case"
    Me.chkMatchCase.UseVisualStyleBackColor = True
    '
    'frDirection
    '
    Me.frDirection.Controls.Add(Me.rbDown)
    Me.frDirection.Controls.Add(Me.rbUp)
    Me.frDirection.Location = New System.Drawing.Point(139, 43)
    Me.frDirection.Name = "frDirection"
    Me.frDirection.Size = New System.Drawing.Size(120, 51)
    Me.frDirection.TabIndex = 5
    Me.frDirection.TabStop = False
    Me.frDirection.Text = "Direction"
    '
    'rbDown
    '
    Me.rbDown.AutoSize = True
    Me.rbDown.Checked = True
    Me.rbDown.Location = New System.Drawing.Point(61, 24)
    Me.rbDown.Name = "rbDown"
    Me.rbDown.Size = New System.Drawing.Size(53, 17)
    Me.rbDown.TabIndex = 1
    Me.rbDown.TabStop = True
    Me.rbDown.Text = "Down"
    Me.rbDown.UseVisualStyleBackColor = True
    '
    'rbUp
    '
    Me.rbUp.AutoSize = True
    Me.rbUp.Location = New System.Drawing.Point(7, 24)
    Me.rbUp.Name = "rbUp"
    Me.rbUp.Size = New System.Drawing.Size(39, 17)
    Me.rbUp.TabIndex = 0
    Me.rbUp.Text = "Up"
    Me.rbUp.UseVisualStyleBackColor = True
    '
    'dlgFind
    '
    Me.AcceptButton = Me.OK_Button
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.CancelButton = Me.Cancel_Button
    Me.ClientSize = New System.Drawing.Size(435, 102)
    Me.Controls.Add(Me.frDirection)
    Me.Controls.Add(Me.chkMatchCase)
    Me.Controls.Add(Me.chkMatchWholeWord)
    Me.Controls.Add(Me.txtSearchText)
    Me.Controls.Add(Me.lblFindWhat)
    Me.Controls.Add(Me.TableLayoutPanel1)
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "dlgFind"
    Me.ShowInTaskbar = False
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
    Me.Text = "Find text"
    Me.TableLayoutPanel1.ResumeLayout(False)
    Me.frDirection.ResumeLayout(False)
    Me.frDirection.PerformLayout()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
  Friend WithEvents OK_Button As System.Windows.Forms.Button
  Friend WithEvents Cancel_Button As System.Windows.Forms.Button
  Friend WithEvents lblFindWhat As System.Windows.Forms.Label
  Friend WithEvents txtSearchText As System.Windows.Forms.TextBox
  Friend WithEvents chkMatchWholeWord As System.Windows.Forms.CheckBox
  Friend WithEvents chkMatchCase As System.Windows.Forms.CheckBox
  Friend WithEvents frDirection As System.Windows.Forms.GroupBox
  Friend WithEvents rbDown As System.Windows.Forms.RadioButton
  Friend WithEvents rbUp As System.Windows.Forms.RadioButton

End Class
