﻿Imports System.Text
Imports System.Text.RegularExpressions

Module StrUtil
  Public Const CRCR = vbCrLf & vbCrLf  ' As String  'vbcrlf
  'x.Padleft(width), x.PadRight(width)
  'x.Insert(startAt, sInsert), x.Remove(startAt, length)
  'x.tolower,x.toupper
  'string.join, split

  'Strings.Left, Strings.Right
  'Function Encoding.ascii.getstring(ByVal ByteArray() As Byte) As String
  '  Return System.Text.Encoding.ASCII.GetString(ByteArray)
  'End Function

  'Function Encoding.ascii.getbytes(ByVal sText As String) As Byte()
  '  Return System.Text.Encoding.ASCII.GetBytes(sText)
  'End Function

  Function FmtStr(ByVal S As String, ByVal iWidth As Short, ByVal bLeft As Boolean) As String

    If bLeft Then
      Return LSet(S, iWidth)
    Else
      Return RSet(S, iWidth)
    End If

  End Function


  Function NumChInStr(ByVal Str1 As String, ByVal Ch1 As String) As Integer
    Dim ByteArray() As Byte, ChByte As Short
    Dim I As Integer, CC As Integer
    ChByte = Asc(Ch1)
    ByteArray = Encoding.ascii.getbytes(Str1)
    For I = 0 To UBound(ByteArray)
      If ByteArray(I) = ChByte Then CC = CC + 1
    Next I
    Return CC
  End Function

  Function NF(ByVal varNumber As Object, ByVal Width As Integer, ByVal DigAftPnt As Integer) As String
    Return RSet(FormatNumber(varNumber, DigAftPnt, , , vbFalse), Width)
  End Function



  Function NFInt(ByVal IntNum As Integer, ByVal Width As Short) As String
    Return RSet(CStr(IntNum), Width)
  End Function
  Sub FilterIndex(ByRef Txt As String, ByRef FilterString As String, ByRef Index() As Integer)



    Dim C As String, TxtLength As Integer, Count As Integer, TmpIndex(100) As Integer, I As Integer, J As Integer
    Count = 1
    TxtLength = Len(Txt)

    For I = 1 To TxtLength
      C = Mid(Txt, I, 1)


      If InStr(FilterString, C) Then
        TmpIndex(Count) = I
        Count = Count + 1
      End If
    Next I
    ReDim Index(Count - 1)
    For J = 1 To Count - 1
      Index(J) = TmpIndex(J)
    Next J
  End Sub



  Sub LineParser2(ByRef Line As String, ByRef NumParameter As Object, ByRef ParameterArray As Object, ByRef DelimitChar As String)


    Dim LineLen As Integer, C As String, InParameter As Boolean
    Dim I As Integer
    For I = 0 To UBound(ParameterArray)
      ParameterArray(I) = ""
    Next I
    NumParameter = 0
    InParameter = False
    Line = Trim(Line)
    LineLen = Len(Line)
    For I = 1 To LineLen
      C = Mid(Line, I, 1)
      If (C <> DelimitChar) Then
        If Not InParameter Then
          NumParameter = NumParameter + 1
          InParameter = True
        End If
        ParameterArray(NumParameter - 1) = ParameterArray(NumParameter - 1) & C
      Else
        InParameter = False
      End If
    Next I
  End Sub

  Sub LineParser3(ByRef Line As String, ByRef NumParameter As Integer, ByRef DynamicArray As Object, ByRef DelimitCh As String)


    If Len(Line) = 0 Then
      NumParameter = 0
      Exit Sub
    End If
    If InStr(Line, DelimitCh) = 0 Then
      NumParameter = 1
      ReDim DynamicArray(0)
      DynamicArray(0) = Line
      Exit Sub
    End If

    Dim ByteArray() As Byte, start() As Integer, length() As Integer, DelimitByte As Byte
    Dim I As Integer, LineLen As Integer, InGap As Boolean, MaxParameter As Integer
    MaxParameter = 20
    NumParameter = 0
    ReDim start(MaxParameter - 1), length(MaxParameter - 1)
    DelimitByte = Asc(DelimitCh)
    ByteArray = Encoding.ascii.getbytes(Line)
    LineLen = Len(Line)
    InGap = True
    For I = 0 To LineLen - 1
      If ByteArray(I) = DelimitByte Then
        If Not InGap Then

          length(NumParameter) = I - start(NumParameter)
          NumParameter = NumParameter + 1
          If NumParameter >= MaxParameter Then
            MaxParameter = MaxParameter + 20
            ReDim Preserve start(MaxParameter), length(MaxParameter)
          End If
          InGap = True
        End If
      Else
        If InGap Then

          InGap = False
          start(NumParameter) = I
        End If
      End If
    Next I

    If InGap = False Then
      length(NumParameter) = I - start(NumParameter)
      NumParameter = NumParameter + 1
    End If
    If NumParameter > 0 Then
      ReDim DynamicArray(NumParameter - 1)
    End If
    For I = 0 To NumParameter - 1
      DynamicArray(I) = Mid(Line, start(I) + 1, length(I))
    Next I
  End Sub



  Sub Split2(ByRef Line As String, ByRef DelimiterCh As String, ByRef NumParameter As Object, ByRef ParameterArray As Object)

    Dim tmpStr As String, RetVal As Integer
    Line = Trim(Line)
    If Left(Line, 1) = DelimiterCh Then
      Line = Right(Line, Len(Line) - 1)
    End If
    tmpStr = DelimiterCh & DelimiterCh
    RetVal = InStr(Line, tmpStr)
    Do While RetVal > 0
      Line = Replace(Line, tmpStr, DelimiterCh)
      RetVal = InStr(Line, tmpStr)
    Loop
    ParameterArray = Split(Line, DelimiterCh)
    NumParameter = UBound(ParameterArray) + 1
  End Sub



  ' Put quotes around a string and double any embedded Chr(34)
  '
  ' convert all control characters into embedded VB constants
  ' or CHR() functions
  '
  ' This function is useful,for example,when you are writing a MsgBox wizard.
  ' Tipically,such a wizard would let the user enter a string in a multiline
  ' textbox control,and would later have to convert it into a quoted string in
  ' order to produce the actual MsgBox code. Just putting quotes around the
  ' string doesn't work,because you have to account for embedded quotes and
  ' control characters.

  Function QuoteString(ByVal source As String) As String


    Dim Index As Short
    Dim acode As Short
    Dim Result As String = ""
    Dim openQuotes As Boolean

    For Index = 1 To Len(source)
      acode = Asc(Mid(source, Index, 1))
      If acode >= 32 Then
        If openQuotes = False Then
          Result = Result & """"
          openQuotes = True
        End If
        Result = Result & Chr(acode)

        If acode = 34 Then Result = Result & Chr(acode)
      Else
        If openQuotes Then
          Result = Result & """ & "
          openQuotes = False
        End If
        Select Case acode
          Case 0
            Result = Result & "vbNullChar & "
          Case 13
            Result = Result & "vbCr & "
          Case 10
            Result = Result & "vbLf & "
          Case 9
            Result = Result & "vbTab & "
          Case Else
            Result = Result & "Chr(" & CStr(acode) & ") & "
        End Select
      End If
    Next


    If openQuotes Then
      Result = Result & """"
    ElseIf Right(Result, 3) = " & " Then
      Result = Left(Result, Len(Result) - 3)
    End If


    Do
      Index = InStr(Result, "vbCr & vbLf")
      If Index = 0 Then Exit Do
      Result = Left(Result, Index - 1) & "vbCrLf" & Mid(Result, Index + 11)
    Loop


    If Len(Result) = 0 Then Result = """"""

    QuoteString = Result

  End Function




  ' A variant of the Split function,that offers the following improvements
  '   You can pass a list of valid delimiters to the second argument
  '   (however,only single-char delimiters are accepted)
  '   Differently from the regular Split function,consecutive occurrences
  '   of delimiters are ignored (in this case Split creates empty
  '   elements in the result array)


  Function SplitTbl(ByRef Text As String, Optional ByRef DelimiterTbl As String = " ") As String()

    Dim Index As Integer, startIndex As Integer
    Dim itemCount As Integer
    Dim Result() As String
    ReDim Result(10)

    For Index = 1 To Len(Text)
      If InStr(DelimiterTbl, Mid(Text, Index, 1)) Then

        If startIndex Then

          If itemCount > UBound(Result) Then

            ReDim Preserve Result(itemCount + 10)
          End If
          Result(itemCount) = Mid(Text, startIndex, Index - startIndex)
          itemCount = itemCount + 1
          startIndex = 0
        End If
      Else

        If startIndex = 0 Then


          startIndex = Index
        End If
      End If
    Next


    If startIndex Then

      If itemCount > UBound(Result) Then

        ReDim Preserve Result(itemCount + 10)
      End If
      Result(itemCount) = Mid(Text, startIndex, Index - startIndex)
      itemCount = itemCount + 1
    End If

    If itemCount > 0 Then

      ReDim Preserve Result(itemCount - 1)
      SplitTbl = Result
    Else


      SplitTbl = Split("")
    End If

  End Function




  Function IsSameChar(ByRef String1 As String, ByRef StrLen As Short) As Boolean

    Dim I As Integer
    Dim StrByte() As Byte
    StrByte = Encoding.ascii.getbytes(String1)
    IsSameChar = True
    For I = 0 To Len(String1) - 1
      If StrByte(I) <> StrByte(0) Then
        IsSameChar = False
        Exit Function
      End If
    Next I
  End Function




  Function LeftOfChar(ByRef InLine As String, ByRef Character As String) As String

    Dim tmpVal As Short
    tmpVal = Val(InStr(InLine, Character))
    If tmpVal > 0 Then
      LeftOfChar = Left(InLine, tmpVal - 1)
    Else
      LeftOfChar = ""
    End If
  End Function

  Function RightOfChar(ByRef TrimedInLine As String, ByRef Character As String) As String

    Dim ChPos As Integer
    ChPos = InStrRev(TrimedInLine, Character)
    If ChPos = 0 Then
      RightOfChar = ""
    Else
      RightOfChar = Mid(TrimedInLine, ChPos + 1)
    End If
  End Function



  Function MidTrim(ByRef InLine As String, ByRef OutChar As String) As Object

    MidTrim = Replace(InLine, OutChar, "")
  End Function



  'Replace one or more space by a tab
  Function SpLineEnd2Tab(ByRef sInString As String) As String
    '\p{Sc}: Match a currency symbol. {Sc} denotes any character that is a member of the Unicode Symbol, Currency category.
    '\s?: Match zero or one white-space character.
    '(\p{Sc}\s?)?: Match zero or one occurrence of the combination of a currency symbol followed by zero or one white-space character. This is the first capturing group.
    '\d+: Match one or more decimal digits.
    '\.?: Match zero or one occurrence of a period (used as a decimal separator character).
    '((?<=\.)\d+)?: If a period is the previous character, match one or more decimal digits. This pattern can be matched either zero or one time.
    '(\d+\.?((?<=\.)\d+)?): Match the pattern of one or more decimal digits followed by an optional period and additional decimal digits. This is the second capturing group. The call to the Replace(String, String) method replaces the entire match with the value of this captured group.
    '(?(1)|\s?\p{Sc})?: If the first captured group exists, match an empty string. Otherwise, match zero or one white-space character followed by a currency symbol.
    Dim pattern As String = "\s+"
    Dim replacement As String = vbTab
    Dim rgx As New Regex(pattern)
    Return rgx.Replace(sInString, replacement)
  End Function


  Function Sp2Tab(ByRef sInString As String) As String

    Dim I As Integer, tmpByte() As Byte, NewByte() As Byte, NewIndex As Integer = 1
    Dim UppDim As Integer
    UppDim = Len(sInString) - 1
    ReDim NewByte(UppDim)
    tmpByte = Encoding.ASCII.GetBytes(sInString)
    If tmpByte(0) = Keys.Space Then
      NewByte(0) = Keys.Tab
    Else
      NewByte(0) = tmpByte(0)
    End If
    For I = 1 To UBound(tmpByte)
      Select Case tmpByte(I)
        Case Keys.Space
          If NewByte(NewIndex - 1) <> Keys.Tab Then
            NewByte(NewIndex) = Keys.Tab
            NewIndex = NewIndex + 1
          End If
        Case Else
          NewByte(NewIndex) = tmpByte(I)
          NewIndex = NewIndex + 1
      End Select
    Next I
    ReDim Preserve NewByte(NewIndex - 1)
    Sp2Tab = Encoding.ASCII.GetString(NewByte)
  End Function



  Function GetRightMostCols(ByRef sTabedStr As String, ByVal NumColFromRight As Integer) As String
    Dim I As Integer, J As Integer, k As Integer, TabCount As Integer
    Dim LineArray() As String
    Dim LineEnd As String
    Dim LineByte() As Byte
    Dim NumTab2Stop As Integer

    NumTab2Stop = NumColFromRight - 1

    LineEnd = GetLineEnd(sTabedStr)
    LineArray = Split(sTabedStr, LineEnd)
    sTabedStr = ""

    For I = 0 To UBound(LineArray)
      LineArray(I) = Trim(LineArray(I))
      LineByte = Encoding.ascii.getbytes(LineArray(I))
      If Len(LineArray(I)) > 0 Then
        TabCount = 0
        For J = Len(LineArray(I)) - 1 To 0 Step -1
          If LineByte(J) = Keys.Tab Then
            TabCount = TabCount + 1
            If TabCount = NumTab2Stop Then
              For k = 0 To J - 1
                If LineByte(k) = Keys.Tab Then
                  LineByte(k) = Keys.Space
                End If
              Next k
              Exit For
            End If
          End If
        Next J
        LineArray(I) = Encoding.ascii.getstring(LineByte)
      End If
    Next I
    GetRightMostCols = Join(LineArray, LineEnd)
  End Function


  'If poly-sCh exists,keep only a single sCh,e.g. "   ab  d  " to " ab d "

  Sub CompactStr(ByRef sInString As String, ByRef sCh As String)

    Dim OldLen As Integer, StartLen As Integer, UppLen As Integer, LowLen As Integer
    Dim FindStr As String
    Dim I As Integer
    StartLen = 10
    OldLen = Len(sInString)
    LowLen = 1
    Do
      FindStr = StrDup(StartLen, sCh)
      sInString = Replace(sInString, FindStr, sCh)
      If Len(sInString) < OldLen Then
        OldLen = Len(sInString)
        LowLen = StartLen
        If UppLen = 0 Then
          UppLen = 2 * StartLen
        Else
          StartLen = (UppLen + LowLen) \ 2
        End If
      Else
        UppLen = StartLen
        StartLen = (UppLen + LowLen) \ 2
      End If
    Loop Until UppLen - LowLen < 2

    For I = LowLen To 2 Step -1
      sInString = Replace(sInString, StrDup(I, sCh), sCh)
    Next I
  End Sub



  Function CompactStrOld(ByRef sInString As String, ByVal InByte As Byte) As String


    Dim I As Integer, tmpByte() As Byte, NewByte() As Byte, NewIndex As Integer
    Dim UppDim As Integer
    UppDim = Len(sInString) - 1
    ReDim NewByte(UppDim)
    tmpByte = Encoding.ascii.getbytes(sInString)
    If tmpByte(0) = InByte Then
      NewByte(NewIndex) = InByte
      NewIndex = NewIndex + 1
    End If
    For I = 0 To UBound(tmpByte)
      Select Case tmpByte(I)
        Case InByte
          If NewByte(NewIndex - 1) <> InByte Then
            NewByte(NewIndex) = InByte
            NewIndex = NewIndex + 1
          End If
        Case Else
          NewByte(NewIndex) = tmpByte(I)
          NewIndex = NewIndex + 1
      End Select
    Next I
    ReDim Preserve NewByte(NewIndex - 1)
    CompactStrOld = Encoding.ascii.getstring(NewByte)
  End Function




  Function GetLine(ByRef InString As String, ByRef CurrentPos As Object, ByRef LineEndChar As String) As String

    Dim EndVal As Integer
    EndVal = InStr(CurrentPos, InString, LineEndChar)
    GetLine = Mid(InString, CurrentPos, EndVal - CurrentPos)
  End Function



  Function GetLine2(ByRef InString As String, ByRef CurrentPos As Object, ByRef LineEndChar As String, Optional ByRef LenEndCh As Short = 0) As String

    Dim EndVal As Integer, tmpStr As String
    If CurrentPos = 0 Then
      Call RaiseErr("GetLine2", "CurrentPos=0")
      GetLine2 = ""
      Exit Function
    End If
    EndVal = InStr(CurrentPos, InString, LineEndChar)
    If EndVal = 0 Then
      GetLine2 = ""
      CurrentPos = 0
      Exit Function
    Else
      Do
        GetLine2 = Mid(InString, CurrentPos, EndVal - CurrentPos)
        tmpStr = Trim(GetLine2)
        If Len(tmpStr) > 0 Then
          CurrentPos = EndVal + LenEndCh
          Exit Function
        Else
          CurrentPos = EndVal + LenEndCh
          EndVal = InStr(CurrentPos, InString, LineEndChar)
        End If
      Loop Until EndVal = 0
      CurrentPos = 0
    End If
  End Function



  Function TitleFmt(ByRef InString As String) As String

    Dim I As Integer
    If InString <> "" Then
      Mid(InString, 1, 1) = UCase(Mid(InString, 1, 1))
      For I = 1 To Len(InString) - 1
        If Mid(InString, I, 2) = vbCrLf Then Mid(InString, I + 2, 1) = UCase(Mid(InString, I + 2, 1))
        If Mid(InString, I, 1) = " " Then Mid(InString, I + 1, 1) = UCase(Mid(InString, I + 1, 1))
      Next
    End If
    Return InString
  End Function



  Function CheckSum32(ByRef A As String) As Integer


    Const MAXULONG = 4294967295
    Const MaxLong = 2147483647
    Dim Sum As Decimal
    Dim I As Short
    Dim J As Short
    J = 0
    For I = 1 To Len(A)

      Sum = Sum + (Asc(Mid(A, I, 1)) * 256 ^ J)

      If Sum > MAXULONG Then Sum = Sum - (MAXULONG + 1)

      If J < 3 Then
        J = J + 1
      Else
        J = 0
      End If
    Next

    If Sum > MaxLong Then Sum = Sum - (MAXULONG + 1)
    CheckSum32 = Sum
  End Function





  Function CRC16(ByRef B As String) As Integer


    Dim iPower() As String = {1, 2, 4, 8, 16, 32, 64, 128}
    Dim I As Integer, J As Integer, TestBit As Short, ByteVal As Short
    Dim CRC As Integer
    Dim ByteArray() As Byte
    ByteArray = Encoding.ascii.getbytes(B)

    CRC = 0
    For I = 0 To UBound(ByteArray)
      ByteVal = ByteArray(I)
      For J = 7 To 0 Step -1
        TestBit = ((CRC And 32768) = 32768) Xor ((ByteVal And iPower(J)) = iPower(J))
        CRC = ((CRC And 32767) * 2)
        If TestBit Then CRC = CRC Xor &H1021
      Next J
    Next I
    CRC16 = CRC
  End Function



  Function CRC32(ByRef B As String) As Integer


    Dim iPower() As String = {1, 2, 4, 8, 16, 32, 64, 128}
    Dim CRC As Integer
    Dim I As Integer, J As Integer, TestBit As Boolean
    Dim ByteVal As Byte
    Dim ByteArray() As Byte
    ByteArray = Encoding.ascii.getbytes(B)

    CRC = 0
    For I = 0 To UBound(ByteArray)
      ByteVal = ByteArray(I)
      For J = 7 To 0 Step -1
        TestBit = ((CRC And 32768) = 32768) Xor ((ByteVal And iPower(J)) = iPower(J))
        CRC = ((CRC And 32767) * 2)
        If TestBit Then CRC = CRC Xor &H8005
      Next J
    Next I
    CRC32 = CRC
  End Function



  Function TrimNum(ByRef InString As String) As String


    Dim I As Integer, ByteArray() As Byte, TmpArray() As Byte
    Dim StrLen As Integer, Count As Integer
    StrLen = Len(InString)
    ByteArray = Encoding.ascii.getbytes(InString)
    ReDim TmpArray(StrLen - 1)
    For I = 0 To StrLen - 1
      If ByteArray(I) > 57 Then
        TmpArray(Count) = ByteArray(I)
        Count = Count + 1
      ElseIf ByteArray(I) = 45 Then
        TmpArray(Count) = ByteArray(I)
        Count = Count + 1
      ElseIf ByteArray(I) = 46 Then
        TmpArray(Count) = ByteArray(I)
        Count = Count + 1
      ElseIf ByteArray(I) = 42 Then
        TmpArray(Count) = 63
        Count = Count + 1
      End If
    Next I
    ReDim Preserve TmpArray(Count - 1)
    TrimNum = Encoding.ascii.getstring(TmpArray)
  End Function




  Sub TrimNumByte(ByVal InOutStrByte() As Byte, ByRef NewLen As Integer)


    Dim I As Integer
    Dim MaxInd As Integer
    MaxInd = UBound(InOutStrByte)
    NewLen = 0
    For I = 0 To MaxInd
      If InOutStrByte(I) > 57 Then
        InOutStrByte(NewLen) = InOutStrByte(I)
        NewLen = NewLen + 1
      End If
    Next I
    ReDim Preserve InOutStrByte(NewLen - 1)
  End Sub


  Sub TrimTo1Sp(ByRef sInOutText As String)
    Dim I As Integer, J As Integer, CC As Integer, UppInd As Integer
    Dim InByte() As Byte, OutByte() As Byte

    InByte = Encoding.ASCII.GetBytes(sInOutText)
    UppInd = UBound(InByte)
    ReDim OutByte(UppInd)

    For I = 0 To UppInd
      OutByte(CC) = InByte(I)
      CC = CC + 1
      If InByte(I) = 32 Then 'space
        For J = I + 1 To UppInd
          If InByte(J) <> 32 Then
            OutByte(CC) = InByte(J)
            CC = CC + 1
            I = J
            Exit For
          End If
        Next
      End If
    Next
    ReDim Preserve OutByte(CC - 1)
    sInOutText = Encoding.ASCII.GetString(OutByte)
  End Sub

  Sub TrimSpCrLf(ByVal InOutByte() As Byte, ByVal InOutNumByte As Integer)

    Dim I As Integer, CC As Integer
    For I = 0 To InOutNumByte - 1
      Select Case InOutByte(I)
        Case 32, 13, 10
        Case Else
          InOutByte(CC) = InOutByte(I)
          CC = CC + 1
      End Select
    Next I
    ReDim Preserve InOutByte(CC - 1)
    InOutNumByte = CC
  End Sub



  Sub ReplaceParenthesis(ByVal InByte() As Byte, ByVal NumByte As Integer, ByVal NewByte As Byte)

    Dim I As Integer
    For I = 0 To NumByte - 1
      If InByte(I) = 40 Then
        InByte(I) = NewByte
      ElseIf InByte(I) = 41 Then
        InByte(I) = NewByte
      End If
    Next I
  End Sub



  Sub ReplaceParenthesis2(ByRef InSeqName() As String, ByVal lNumSeq As Integer, ByVal NewByte As Byte)

    Dim I As Integer, J As Integer
    Dim NameByte() As Byte
    For I = 0 To lNumSeq - 1
      NameByte = Encoding.ascii.getbytes(InSeqName(I))
      For J = 0 To Len(InSeqName(I)) - 1
        If NameByte(J) = 40 Then
          NameByte(J) = NewByte
        ElseIf NameByte(J) = 41 Then
          NameByte(J) = NewByte
        End If
      Next J
      InSeqName(I) = Encoding.ascii.getstring(NameByte)
    Next I
  End Sub



  Sub TrimParenthesis(ByVal InOutByte() As Byte, ByVal InOutNumByte As Integer)

    Dim I As Integer, CC As Integer
    For I = 0 To InOutNumByte - 1
      Select Case InOutByte(I)
        Case 40, 41
        Case Else
          InOutByte(CC) = InOutByte(I)
          CC = CC + 1
      End Select
    Next I
    ReDim Preserve InOutByte(CC - 1)
    InOutNumByte = CC
  End Sub


  'e.g.,StartCh = Asc("!") and EndCh = Asc(";"). The EndCh may be followed by vbCrLf (LineEndLen = 2) or vbCr or vbLf (LineEndLen =1) that also needs to be removed

  Sub TrimWithStartStopCh(ByRef sInOut As String, ByVal lLen As Integer, ByVal StartCh As Byte, ByVal EndCh As Byte, Optional ByVal bRidTrailingLineEnd As Boolean = False, Optional ByVal LineEndLen As Byte = 0)

    Dim SeqByte() As Byte
    Dim I As Integer, J As Integer, CC As Integer
    SeqByte = Encoding.ascii.getbytes(sInOut)
    For I = 0 To UBound(SeqByte)
      If SeqByte(I) = StartCh Then
        For J = I + 1 To lLen - 1
          If SeqByte(J) = EndCh Then
            If bRidTrailingLineEnd Then
              I = J + LineEndLen
            Else
              I = J
            End If
            Exit For
          End If
        Next J
      Else
        SeqByte(CC) = SeqByte(I)
        CC = CC + 1
      End If
    Next I
    ReDim Preserve SeqByte(CC - 1)
    sInOut = Encoding.ascii.getstring(SeqByte)
  End Sub

  Function InStrArray(ByRef StrArray As Object, ByRef SearchStr As String) As Boolean

    InStrArray = InStr(1, vbNullChar & Join(StrArray, vbNullChar) & vbNullChar, vbNullChar & SearchStr & vbNullChar) > 0
  End Function



  'After calling the function,LineEnd of the FileStr is of length 1,i.e.,either vbCr or vbLf

  Function GetLineEnd(ByRef FileStr As Object) As String

    If InStr(FileStr, vbCrLf) > 0 Then
      FileStr = Replace(FileStr, vbCrLf, vbLf)
      FileStr = Replace(FileStr, vbCr, vbLf)
      GetLineEnd = vbLf
    ElseIf InStr(FileStr, vbCr) > 0 Then
      FileStr = Replace(FileStr, vbLf, vbCr)
      GetLineEnd = vbCr
    ElseIf InStr(FileStr, vbLf) > 0 Then
      GetLineEnd = vbLf
    Else
      GetLineEnd = ""
    End If
  End Function




  Function TransStrMat(ByRef InString As String, ByRef LineEnd As String) As String







    Dim RowArray As Object
    Dim MatVar As Object
    Dim I As Integer, J As Integer
    Dim NumRow As Integer, NumCol As Integer
    RowArray = Split(InString, LineEnd)
    InString = ""
    If RowArray(UBound(RowArray)) = "" Then
      NumRow = UBound(RowArray)
    Else
      NumRow = UBound(RowArray) + 1
    End If
    ReDim MatVar(NumRow - 1)
    For I = 0 To NumRow - 1
      MatVar(I) = Split(RowArray(I), vbTab)
    Next I
    NumCol = UBound(MatVar(0)) + 1
    For J = 0 To NumCol - 1
      For I = 0 To NumRow - 1
        InString = InString & MatVar(I)(J) & vbTab
      Next I
      InString = InString & LineEnd
    Next J
    TransStrMat = InString
  End Function

  Public Function CondenseSpTab(ByRef InString As String) As String

    CondenseSpTab = Replace(InString, vbTab & " ", " ")
    CondenseSpTab = Replace(InString, " " & vbTab, " ")
    CondenseSpTab = Replace(InString, vbTab, " ")
  End Function



  Public Function KMPSearch(ByVal sTextByte() As Byte, ByVal sPatternByte() As Byte, ByRef lPatternLen As Integer, ByRef lTextLen As Integer) As Integer















    Dim I As Integer
    Dim J As Integer
    Dim lNext() As Integer
    ReDim lNext(lPatternLen)

    Call initNext(sPatternByte, lNext, lPatternLen)
    Do
      If (J = -1) Then
        I = I + 1
        J = J + 1
      ElseIf (sTextByte(I) = sPatternByte(J)) Then
        I = I + 1
        J = J + 1
      Else
        J = lNext(J)
      End If
    Loop While ((J < lPatternLen) And (I < lTextLen))

    If (J >= lPatternLen) Then
      KMPSearch = (I - lPatternLen)
    Else
      KMPSearch = -1
    End If
  End Function



  Public Function KMPSearchFrom(ByVal sTextByte() As Byte, ByVal sPatternByte() As Byte, ByRef lPatternLen As Integer, ByRef lTextLen As Integer, ByRef lNext() As Integer, ByVal lFrom As Integer) As Integer




    Dim J As Integer

    Do
      If (J = -1) Then
        lFrom = lFrom + 1
        J = J + 1
      ElseIf (sTextByte(lFrom) = sPatternByte(J)) Then
        lFrom = lFrom + 1
        J = J + 1
      Else
        J = lNext(J)
      End If
    Loop While ((J < lPatternLen) And (lFrom < lTextLen))

    If (J >= lPatternLen) Then
      KMPSearchFrom = (lFrom - lPatternLen)
    Else
      KMPSearchFrom = -1
    End If
  End Function



  Public Function KMPSearchFrom2(ByVal sTextByte() As Byte, ByVal sPatternByte() As Byte, ByRef lPatternLen As Integer, ByRef lTextLen As Integer, ByVal lFrom As Integer) As Integer


    Dim J As Integer
    Dim lNext() As Integer
    ReDim lNext(lPatternLen)
    Call initNext(sPatternByte, lNext, lPatternLen)
    Do
      If (J = -1) Then
        lFrom = lFrom + 1
        J = J + 1
      ElseIf (sTextByte(lFrom) = sPatternByte(J)) Then
        lFrom = lFrom + 1
        J = J + 1
      Else
        J = lNext(J)
      End If
    Loop While ((J < lPatternLen) And (lFrom < lTextLen))

    If (J >= lPatternLen) Then
      KMPSearchFrom2 = (lFrom - lPatternLen)
    Else
      KMPSearchFrom2 = -1
    End If
  End Function



  Public Function KMPSearchFromTo(ByVal sTextByte() As Byte, ByVal sPatternByte() As Byte, ByRef lPatternLen As Integer, ByVal lFrom As Integer, ByVal lTo As Integer) As Integer


    Dim J As Integer

    Dim lNext() As Integer
    ReDim lNext(lPatternLen)
    Call initNext(sPatternByte, lNext, lPatternLen)
    Do
      If (J = -1) Then
        lFrom = lFrom + 1
        J = J + 1
      ElseIf (sTextByte(lFrom) = sPatternByte(J)) Then
        lFrom = lFrom + 1
        J = J + 1
      Else
        J = lNext(J)
      End If
    Loop While ((J < lPatternLen) And (lFrom < lTo))

    If (J >= lPatternLen) Then
      KMPSearchFromTo = (lFrom - lPatternLen)
    Else
      KMPSearchFromTo = -1
    End If
  End Function


  '                           012345678
  'If searching for "AAA" in "AAAAAAAAA",return only three matches at 0,3,and 6,respectively

  Public Function KMPSearchM(ByVal sTextByte() As Byte, ByVal sPatternByte() As Byte, ByVal lPatternLen As Integer, ByVal lTextLen As Integer, ByRef NumMatch As Integer, ByRef dynMatchAt() As Integer) As Boolean


    Dim I As Integer, J As Integer
    Dim MaxMatch As Integer
    MaxMatch = 100
    Dim lNext() As Integer
    ReDim lNext(lPatternLen)
    ReDim dynMatchAt(MaxMatch)

    NumMatch = 0
    Call initNext(sPatternByte, lNext, lPatternLen)
    Do
      J = 0
      Do
        If (J = -1) Then
          I = I + 1
          J = J + 1
        ElseIf (sTextByte(I) = sPatternByte(J)) Then
          I = I + 1
          J = J + 1
        Else
          J = lNext(J)
        End If
      Loop While ((J < lPatternLen) And (I < lTextLen))
      If J >= lPatternLen Then
        dynMatchAt(NumMatch) = I - lPatternLen
        NumMatch = NumMatch + 1
        If NumMatch > MaxMatch Then
          MaxMatch = MaxMatch + 100
          ReDim Preserve dynMatchAt(MaxMatch)
        End If
      Else
        Exit Do
      End If

    Loop Until I = lTextLen
    If NumMatch > 0 Then
      ReDim Preserve dynMatchAt(NumMatch - 1)
    End If
    KMPSearchM = True
  End Function




  Public Sub initNext(ByVal PatternByte() As Byte, ByRef lNext() As Integer, ByRef lPatternLen As Integer)





    Dim I As Integer, J As Integer, M As Integer
    J = -1
    lNext(0) = -1
    M = lPatternLen - 1

    Do
      If (J = -1) Then
        I = I + 1
        J = J + 1
        lNext(I) = J
      ElseIf (PatternByte(I) = PatternByte(J)) Then
        I = I + 1
        J = J + 1
        lNext(I) = J
      Else
        J = lNext(J)
      End If
    Loop While (I < M)
  End Sub





  Public Sub kDiffMatching(ByVal PatternByte() As Byte, ByVal lPatternLen As Integer, ByVal TextByte() As Byte, ByVal lTextLen As Integer, ByRef dynMatchStartAt() As Integer, ByRef NumMatch As Integer, ByVal NumMisMatch As Integer)


















    Dim I As Integer, J As Integer, P As Integer
    Dim Add As Integer, lSub As Integer, Swap As Integer
    Dim MatD(,) As Integer
    ReDim MatD(lPatternLen, lTextLen)


    For I = 0 To lPatternLen
      MatD(I, 0) = I
    Next I
    For J = 0 To lTextLen
      MatD(0, lTextLen) = 0
    Next J


    For J = 1 To lTextLen
      For I = 1 To lPatternLen
        If PatternByte(I - 1) = TextByte(J - 1) Then
          P = 0
        Else
          P = 1
        End If





        lSub = MatD(I, J - 1) + 1
        Add = MatD(I - 1, J) + 1
        Swap = MatD(I - 1, J - 1) + P
        If ((lSub < Swap) And (lSub < Add)) Then
          MatD(I, J) = lSub
        ElseIf ((Add < lSub) And (Add < Swap)) Then
          MatD(I, J) = Add
        Else
          MatD(I, J) = Swap
        End If
      Next I
    Next J



    ReDim dynMatchStartAt(lTextLen - 1)
    For J = 1 To lTextLen - 1
      If MatD(lPatternLen, J) <= NumMisMatch Then
        dynMatchStartAt(NumMatch) = J - lPatternLen
        NumMatch = NumMatch + 1
      End If
    Next J
    ReDim Preserve dynMatchStartAt(NumMatch - 1)
  End Sub



  Function CamelCase(ByVal Text As String) As String

    Dim I As Integer



    For I = Len(Text) To 1 Step -1
      If InStr(1, "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", Mid(Text, I, 1), vbTextCompare) = 0 Then
        Mid(Text, I, 1) = " "
      End If
    Next

    CamelCase = Replace(StrConv(Text, vbProperCase), " ", "")
  End Function




  'Function FindInString1ChInPattern(ByVal SearchStartFromBase0 As Integer, ByRef sInStr As String, ByRef sPattern As String, ByRef FindAt As Integer, ByRef bFindLineEnd As Boolean, Optional ByVal LineEnd As Byte = 0, Optional ByRef PreviousLineEnd As Integer = 0, Optional ByRef NextLineEnd As Integer = 0) As Boolean

  '  Dim I As Integer, J As Integer, k As Integer, InStrLen As Integer, PatternLen As Integer
  '  Dim ByteArrayInStr() As Byte, ByteArrayPattern() As Byte

  '  InStrLen = Len(sInStr)
  '  PatternLen = Len(sPattern)
  '  ByteArrayInStr = Encoding.ascii.getbytes(sInStr)
  '  ByteArrayPattern = Encoding.ascii.getbytes(sPattern)

  '  For I = SearchStartFromBase0 To InStrLen - 1
  '    For J = 0 To PatternLen - 1
  '      If ByteArrayInStr(I) = ByteArrayPattern(J) Then
  '        FindInString1ChInPattern = True
  '        FindAt = I
  '        If bFindLineEnd Then
  '          bFindLineEnd = False
  '          PreviousLineEnd = 0
  '          NextLineEnd = 0
  '          For k = I To SearchStartFromBase0 Step -1
  '            If ByteArrayInStr(k) = LineEnd Then
  '              PreviousLineEnd = k
  '              bFindLineEnd = True
  '            End If
  '          Next k
  '          For k = I + 1 To InStrLen - 1
  '            If ByteArrayInStr(k) = LineEnd Then
  '              NextLineEnd = k
  '            End If
  '          Next k
  '        End If
  '        Exit Function
  '      End If
  '    Next J
  '  Next I
  'End Function



  Function FindInWord1ChInPattern(ByRef sWord As String, ByRef sPattern As String) As Boolean


    Dim I As Integer, J As Integer, WordLen As Integer, PatternLen As Integer
    Dim ByteArrayWord() As Byte, ByteArrayPattern() As Byte

    WordLen = Len(sWord)
    PatternLen = Len(sPattern)
    ByteArrayWord = Encoding.ascii.getbytes(sWord)
    ByteArrayPattern = Encoding.ascii.getbytes(sPattern)

    For I = 0 To WordLen - 1
      For J = 0 To PatternLen - 1
        If ByteArrayWord(I) = ByteArrayPattern(J) Then
          FindInWord1ChInPattern = True
          Exit Function
        End If
      Next J
    Next I
    FindInWord1ChInPattern = False
  End Function



  Function RidRightChar(ByRef TxtStr As String, ByVal NumOff As Integer) As String

    Dim StrLen As Integer
    StrLen = Len(TxtStr)
    RidRightChar = Left(TxtStr, StrLen - NumOff)
  End Function



  Function RidLeftChar(ByRef TxtStr As String, ByVal NumOff As Object) As String

    Dim StrLen As Integer
    StrLen = Len(TxtStr)
    RidLeftChar = Right(TxtStr, StrLen - NumOff)
  End Function


  'Boyer-Moore algorithm,crude implementation. Does not seem faster than KMP ---------------
  'Skip(255) for any asc character string: MaxAsc = 255
  'For Nuc or AA seq,Skip(90),with 90 being the asc code of "Z": MaxAsc = 90
  'Return length of sPattern

  Private Function BMSetup(ByVal sPattern As String, ByVal MaxAsc As Byte, ByVal Skip() As Byte, ByVal PatByte() As Byte) As Short


    Dim k As Short
    ReDim Skip(MaxAsc)

    BMSetup = Len(sPattern)
    If BMSetup > 0 Then
      PatByte = Encoding.ascii.getbytes(sPattern)
      For k = 0 To MaxAsc
        Skip(k) = BMSetup - 1
      Next k
      For k = 0 To BMSetup - 2
        Skip(PatByte(k)) = BMSetup - k - 1
      Next k
    End If

  End Function


  'Keep the Setup function separate because Setup may need to be run only once and
  '   BMSearch multiple times against different Texts
  'Return the location at the start of the match in the string,0 when no match (This implies
  '  that BMSearch should not return the index in the byte array)

  Public Function BMSearch(ByRef TextByte() As Byte, ByVal lTextLen As Integer, ByVal lPatLen As Integer, ByVal Skip() As Byte, ByVal PatByte() As Byte) As Integer


    Dim I As Integer
    Dim J As Short
    Dim k As Integer

    BMSearch = 0
    k = lPatLen - 1
    Do While k < lTextLen
      J = lPatLen - 1
      I = k
      Do While TextByte(I) = PatByte(J)
        If J = 0 Then
          BMSearch = I + 1
          Exit Function
        End If
        J = J - 1
        I = I - 1
      Loop
      k = k + Skip(TextByte(k))
    Loop

  End Function

  'Boyer-Moore algorithm--------End---------------




  'e.g.,File1 contains:
  ' GeneName SeqLen CAI
  'and File2 contains
  ' GeneName MFE
  'Both sorted with GeneName but each file misses some genes in the other
  'The purpose is to extract lines sharing the same GeneName so as to have
  ' GeneName SeqLen CAI MFE
  '
  'The two files are save from EXCEL into tab-delimited format and should not contain missing values
  '
  'In the case above,ColID1 and ColID2 are both equal to 1 (i.e.,GeneName)
  'There should be no column headings
  'If bgetUnique,then get the unique rows in the 1st list.

  Sub AlignArrays(ByRef sArray1() As String, ByRef sArray2() As String, ByVal UpperInd1 As Integer, ByVal UpperInd2 As Integer, ByVal ColID1 As Integer, ByVal ColID2 As Integer, ByRef sOut As String, Optional ByVal bGetUnique As Boolean = False)

    Dim I As Integer, CC As Integer, lPtr As Integer
    Dim sLine As String
    Dim sField() As String, sID1() As String, sID2() As String
    Dim lInd As Integer

    ColID1 = ColID1 - 1
    ColID2 = ColID2 - 1

    sOut = Space(Len(sArray1(0)) * (UpperInd1 + 1) + Len(sArray1(0)) * (UpperInd1 + 1) + (UpperInd1 + UpperInd2))

    ReDim sID1(UpperInd1)
    For I = 0 To UpperInd1
      sField = Split(sArray1(I), vbTab)
      sID1(I) = Trim(sField(ColID1))
    Next I

    ReDim sID2(UpperInd2)
    For I = 0 To UpperInd2
      sField = Split(sArray2(I), vbTab)
      sID2(I) = Trim(sField(ColID2))
    Next I

    Call QuickSort2ArrayA(sID2, sArray2, 0, UpperInd2)
    lPtr = 1
    If bGetUnique Then
      Dim TmpArray() As String
      TmpArray = sArray1
      CC = 0
      For I = 0 To UpperInd1
        lInd = FindOneInSortedStrArray(sID2, UpperInd2 + 1, sID1(I))
        If lInd > UpperInd2 Then
          sArray1(CC) = sArray1(I)
          CC = CC + 1
        End If
      Next I
      If CC > 0 Then
        ReDim Preserve sArray1(CC - 1)
        sOut = "Unique in List1" & vbCrLf & Join(sArray1, vbCrLf) & CRCR
      End If

      sArray1 = TmpArray
      Erase TmpArray
      Call QuickSort2ArrayA(sID1, sArray1, 0, UpperInd1)
      CC = 0
      For I = 0 To UpperInd2
        lInd = FindOneInSortedStrArray(sID1, UpperInd1 + 1, sID2(I))
        If lInd > UpperInd1 Then
          sArray2(CC) = sArray2(I)
          CC = CC + 1
        End If
      Next I
      If CC > 0 Then
        ReDim Preserve sArray2(CC - 1)
        sOut = sOut & "Unique in List2" & vbCrLf & Join(sArray2, vbCrLf)
      End If
    Else
      For I = 0 To UpperInd1
        lInd = FindOneInSortedStrArray(sID2, UpperInd2 + 1, sID1(I))
        If lInd <= UpperInd2 Then
          sLine = sArray1(I) & vbTab & sArray2(lInd) & vbCrLf
          Mid(sOut, lPtr) = sLine
          lPtr = lPtr + Len(sLine)
        End If
      Next I
    End If
  End Sub



  Function ToParagraph(ByRef sIn As String, ByVal lLineLen As Integer) As String

    Dim I As Integer, SumLen As Integer, NumWord As Integer, Ptr As Integer
    Dim sWordArray() As String
    Dim sOut As String

    sWordArray = Split(Trim(sIn), " ")
    NumWord = UBound(sWordArray) + 1
    sOut = Space(Len(sIn) + 2 * NumWord)
    Ptr = 1
    For I = 0 To NumWord - 2
      Mid(sOut, Ptr) = sWordArray(I)
      Ptr = Ptr + Len(sWordArray(I)) + 1
      SumLen = SumLen + Len(sWordArray(I)) + 1
      If SumLen + Len(sWordArray(I + 1)) > lLineLen Then
        SumLen = 0
        Mid(sOut, Ptr) = vbCrLf
        Ptr = Ptr + 2
      End If
    Next I
    If SumLen + Len(sWordArray(I)) > lLineLen Then
      Mid(sOut, Ptr) = vbCrLf & sWordArray(I)
      Ptr = Ptr + Len(sWordArray(I)) + 3
    Else
      Mid(sOut, Ptr) = sWordArray(I)
      Ptr = Ptr + Len(sWordArray(I)) + 1
    End If
    sOut = Left(sOut, Ptr)
    ToParagraph = sOut
  End Function



  Function Str2SortedSymbol(ByRef sIn As String, ByRef lFreq() As Integer, ByRef lNumSymbol As Integer, ByRef sSortedSymbol As String) As Boolean

    Dim I As Integer, CC As Integer, Freq() As Integer
    Dim SeqByte() As Byte, SortedByte() As Byte
    ReDim Freq(255), SortedByte(255)

    SeqByte = Encoding.ascii.getbytes(sIn)
    For I = 0 To Len(sIn) - 1
      Freq(SeqByte(I)) = Freq(SeqByte(I)) + 1
    Next I

    CC = 0
    For I = 0 To 255
      If Freq(I) > 0 Then
        SortedByte(CC) = I
        CC = CC + 1
      End If
    Next I

    ReDim Preserve SortedByte(CC - 1)
    lNumSymbol = CC
    ReDim lFreq(CC - 1)
    For I = 0 To lNumSymbol - 1
      lFreq(I) = Freq(SortedByte(I))
    Next I
    sSortedSymbol = Encoding.ascii.getstring(SortedByte)
    Str2SortedSymbol = True
  End Function

  '
  ''For sequences with no gaps
  ''e.g.,find poly-A in nuc sequences,or poly-Ala in aa sequences
  ''Output:
  ''SeqName  SeqLen  ExpN  ObsN  FindAt
  ''ExpN is the same as BLAST E-value
  ''Exclude sequences shorter than lMinSeqLen
  ''Use KMPSearchM:
  ''                           012345678
  'Sub FindPolyX(sSeq() As String,sName() As String,ByVal lNumSeq As Integer,ByVal Ch As Byte,ByVal lLenCh As Integer,'ByVal lMinSeqLen As Integer,sOut As String,ProgressBar1 As ProgressBar,Optional ByVal PseudoCount As Integer = 10)
  '  'Ch is 65 if poly-A
  '
  '  Dim I As Integer,J As Integer,K As Integer,II As Integer,Ptr As Integer,LineLen As Integer
  '  Dim sTmp As String,sTmp2 As String
  '  Dim SeqByte() As Byte,POLY() As Byte
  '  Dim GlobalP As Double,P As Double,NumMatchOp As Integer 'E = NumMatchOp*p
  '  Dim NumCh() As Integer,SumNumCh As Integer,SumLen As Integer
  '  Dim SeqLen() As Integer,MatchAt() As Integer,ObsN As Integer,SumObsN As Integer,NewObsN As Integer
  '  Dim SeqByteArray() As Object
  '  Dim SumExpN As Double,ExpN As Double
  '  Dim ExpNumCh As Double
  '  Dim bSort As Boolean
  '
  '  ReDim POLY(lLenCh - 1)
  '  ReDim SeqByteArray(lNumSeq - 1),SeqLen(lNumSeq - 1),NumCh(lNumSeq - 1)
  '
  '  For I = 0 To lLenCh - 1
  '    POLY(I) = Ch
  '  Next I
  '
  '  For I = 0 To lNumSeq - 1
  '    SeqByte = StrConv(sSeq(I),vbFromUnicode)
  '    SeqLen(I) = Len(sSeq(I))
  '    SumLen = SumLen + SeqLen(I)
  '    For J = 0 To SeqLen(I) - 1
  '      If SeqByte(J) = Ch Then
  '        NumCh(I) = NumCh(I) + 1
  '      End If
  '    Next J
  '    SumNumCh = SumNumCh + NumCh(I)
  '    SeqByteArray(I) = SeqByte
  '  Next I
  '
  '  GlobalP = CDbl(SumNumCh) / CDbl(SumLen)
  '  ExpNumCh = PseudoCount * GlobalP
  '  'p = p ^ lLenCh
  '
  '  sOut = "====================================================================================================================" & vbCrLf
  '  sOut = sOut & "SeqName                         SeqLen        ExpN    ObsN  FindAt" & vbCrLf
  '  sOut = sOut & "--------------------------------------------------------------------------------------------------------------------" & vbCrLf
  '
  '  With ProgressBar1
  '    .Minimum = 0
  '    .Maximum = lNumSeq
  '  End With
  '
  '  Ptr = Len(sOut) + 1
  '  sOut = sOut & Space(150 * (lNumSeq + 1))
  '
  '  For I = 0 To lNumSeq - 1
  '    If SeqLen(I) >= lMinSeqLen Then
  '      NumMatchOp = SeqLen(I) - lLenCh + 1
  '      If NumMatchOp < 1 Then
  '        ExpN = 0
  '        ObsN = 0
  '        sTmp = FmtStr(sName(I),30,True) & NF(SeqLen(I),8,0) & NF(ExpN,12,6) & NF(ObsN,8,0) & "  "
  '      Else
  '        P = (ExpNumCh + NumCh(I)) / (SeqLen(I) + PseudoCount)
  '        P = P ^ lLenCh
  '        ExpN = NumMatchOp * P
  '        SumExpN = SumExpN + ExpN
  '        sTmp = FmtStr(sName(I),30,True) & NF(SeqLen(I),8,0) & NF(ExpN,12,6)
  '        SeqByte = SeqByteArray(I)
  '        If KMPSearchM(SeqByte(),POLY(),lLenCh,SeqLen(I),ObsN,MatchAt()) Then
  '          If ObsN = 0 Then
  '            sTmp = sTmp & NF(ObsN,8,0)
  '          Else
  '            NewObsN = ObsN
  '            ReDim Preserve MatchAt(100 * ObsN)
  '            For J = 1 To ObsN - 1
  '              If MatchAt(J) - MatchAt(J - 1) = lLenCh Then
  '                For K = MatchAt(J - 1) + 1 To MatchAt(J) - 1
  '                  MatchAt(NewObsN) = K
  '                  NewObsN = NewObsN + 1
  '                Next K
  '              Else '> lLenCh
  '                K = MatchAt(J - 1) + lLenCh
  '                II = 1
  '                Do While SeqByte(K) = Ch
  '                  MatchAt(NewObsN) = MatchAt(J - 1) + II
  '                  NewObsN = NewObsN + 1
  '                  K = K + 1
  '                  II = II + 1
  '                Loop
  '              End If
  '            Next J
  '            If MatchAt(ObsN - 1) + lLenCh < SeqLen(I) Then
  '              K = MatchAt(ObsN - 1) + lLenCh
  '              II = 1
  '              Do While SeqByte(K) = Ch
  '                MatchAt(NewObsN) = MatchAt(ObsN - 1) + II
  '                NewObsN = NewObsN + 1
  '                K = K + 1
  '                II = II + 1
  '                If K = SeqLen(I) Then Exit Do
  '              Loop
  '            End If
  '            If NewObsN <> ObsN Then
  '              ObsN = NewObsN
  '              Call QuickSortA(MatchAt(),0,NewObsN - 1)
  '            End If
  '            SumObsN = SumObsN + ObsN
  '            Select Case ObsN
  '              Case 1
  '                sTmp2 = MatchAt(0)
  '              Case Is > 1
  '                sTmp2 = ""
  '                For J = 0 To ObsN - 2
  '                  sTmp2 = sTmp2 & MatchAt(J) & ","
  '                Next J
  '                sTmp2 = sTmp2 & MatchAt(J)
  '            End Select
  '            sTmp = sTmp & NF(ObsN,8,0) & "  " & sTmp2
  '          End If
  '        End If
  '      End If
  '      sTmp = sTmp & vbCrLf
  '      Mid(sOut,Ptr) = sTmp
  '      Ptr = Ptr + Len(sTmp)
  '    End If
  '    ProgressBar1.Value = I
  '  Next I
  '  Mid(sOut,Ptr) = "====================================================================================================================" & vbCrLf
  '  Ptr = Ptr + 118
  '  sTmp = "Observed Total: " & FormatNumber(SumObsN,0) & vbCrLf
  '  sTmp = sTmp & "Expected Total: " & FormatNumber(SumExpN,5) & vbCrLf
  '  Mid(sOut,Ptr) = sTmp
  '  Ptr = Ptr + Len(sTmp)
  '  sOut = Left(sOut,Ptr - 1)
  '  ProgressBar1.Value = 0
  'End Sub

  'For sequences with no gaps
  'e.g.,find poly-A in nuc sequences,or poly-Ala in aa sequences
  'if input is 'A,6,10' will find "AAAAAA",not ".AAAAAA. where "." could be A's as well
  '
  'Output:
  'SeqName  SeqLen  ObsN  FindAt
  'Exclude sequences shorter than lMinSeqLen
  'Use KMPSearchM:

  Sub FindPolyX(ByRef sSeq() As String, ByRef sName() As String, ByVal lNumSeq As Integer, ByVal ch As Byte, ByVal lLenCh As Integer, ByVal lMinSeqLen As Integer, ByRef sOut As String, ByRef ProgressBar1 As ProgressBar)



    Dim I As Integer, J As Integer, Ptr As Integer, CC As Integer
    Dim sTmp As String, sTmp2 As String = ""
    Dim SeqByte() As Byte, POLY() As Byte
    Dim SeqLen() As Integer, MatchAt() As Integer, ObsN As Integer, SumObsN As Integer
    Dim SeqByteArray() As Object

    ReDim POLY(lLenCh - 1)
    ReDim SeqByteArray(lNumSeq - 1), SeqLen(lNumSeq - 1)

    For I = 0 To lLenCh - 1
      POLY(I) = ch
    Next I

    For I = 0 To lNumSeq - 1
      SeqByte = Encoding.ascii.getbytes(sSeq(I))
      SeqLen(I) = Len(sSeq(I))
      SeqByteArray(I) = SeqByte
    Next I

    sOut = "========================================================================================================" & vbCrLf
    sOut = sOut & "SeqName                         SeqLen    ObsN  FindAt" & vbCrLf
    sOut = sOut & "--------------------------------------------------------------------------------------------------------" & vbCrLf

    With ProgressBar1
      .Minimum = 0
      .Maximum = lNumSeq
    End With

    Ptr = Len(sOut) + 1
    sOut = sOut & Space(138 * (lNumSeq + 1))

    For I = 0 To lNumSeq - 1
      If SeqLen(I) >= lMinSeqLen Then
        SeqByte = SeqByteArray(I)
        If KMPSearchM(SeqByte, POLY, lLenCh, SeqLen(I), ObsN, MatchAt) Then

          CC = 0
          For J = 0 To ObsN - 1
            If SeqByte(MatchAt(J) - 1) <> ch And SeqByte(MatchAt(J) + lLenCh) <> ch Then
              MatchAt(CC) = MatchAt(J)
              CC = CC + 1
            End If
          Next J
          ObsN = CC

          If ObsN > 0 Then
            sTmp = FmtStr(sName(I), 30, True) & NF(SeqLen(I), 8, 0) & NF(ObsN, 8, 0) & "  "
            SumObsN = SumObsN + ObsN
            Select Case ObsN
              Case 1
                sTmp2 = MatchAt(0)
              Case Is > 1
                sTmp2 = ""
                For J = 0 To ObsN - 2
                  sTmp2 = sTmp2 & MatchAt(J) & ","
                Next J
                sTmp2 = sTmp2 & MatchAt(J)
            End Select
            sTmp = sTmp & "  " & sTmp2 & vbCrLf
            Mid(sOut, Ptr) = sTmp
            Ptr = Ptr + Len(sTmp)
          End If
        End If
      End If
      ProgressBar1.Value = I
    Next I
    Mid(sOut, Ptr) = "========================================================================================================" & vbCrLf
    Ptr = Ptr + 106
    sTmp = "Observed Total: " & FormatNumber(SumObsN, 0) & vbCrLf
    Mid(sOut, Ptr) = sTmp
    Ptr = Ptr + Len(sTmp)
    sOut = Left(sOut, Ptr - 1)
    ProgressBar1.Value = 0
  End Sub


  'For sequences with no gaps
  'e.g.,find poly-A in nuc sequences,or poly-Ala in aa sequences
  'if input is 'A,6,10' will find "AAAAAA",not ".AAAAAA. where "." could be A's as well
  'Find from the longest poly-X,if found,stop (i.e.,do not try to find shorter ones)
  'Output:
  'SeqName  SeqLen  ObsN  FindAt
  'Exclude sequences shorter than lMinSeqLen
  'Use KMPSearchM:

  Sub FindPolyXMult(ByRef sSeq() As String, ByRef sName() As String, ByVal lNumSeq As Integer, ByVal ch As Byte, ByVal lLenChMin As Integer, ByVal lLenChMax As Object, ByVal lMinSeqLen As Integer, ByRef sOut As String, ByRef ProgressBar1 As ProgressBar)



    Dim I As Integer, J As Integer, JJ As Integer, Ptr As Integer, CC As Integer
    Dim sTmp As String, sTmp2 As String = ""
    Dim SeqByte() As Byte, POLY() As Byte
    Dim SeqLen() As Integer, MatchAt() As Integer, ObsN As Integer
    Dim SeqByteArray() As Object

    ReDim SeqByteArray(lNumSeq - 1), SeqLen(lNumSeq - 1)

    For I = 0 To lNumSeq - 1
      SeqByte = Encoding.ascii.getbytes(sSeq(I))
      SeqLen(I) = Len(sSeq(I))
      SeqByteArray(I) = SeqByte
    Next I

    sOut = "========================================================================================================" & vbCrLf
    sOut = sOut & "SeqName                         SeqLen    ObsN LenCh  FindAt" & vbCrLf
    sOut = sOut & "--------------------------------------------------------------------------------------------------------" & vbCrLf

    With ProgressBar1
      .Minimum = 0
      .Maximum = lNumSeq
    End With

    Ptr = Len(sOut) + 1
    sOut = sOut & Space(138 * (lNumSeq + 1) * (lLenChMax - lLenChMin + 1))

    For I = 0 To lNumSeq - 1
      If SeqLen(I) >= lMinSeqLen Then
        SeqByte = SeqByteArray(I)

        For JJ = lLenChMax To lLenChMin Step -1
          ReDim POLY(JJ - 1)
          For J = 0 To JJ - 1
            POLY(J) = ch
          Next J
          If KMPSearchM(SeqByte, POLY, JJ, SeqLen(I), ObsN, MatchAt) Then

            If ObsN > 0 Then
              CC = 0
              For J = 0 To ObsN - 1
                If MatchAt(J) = 0 Then
                  If SeqByte(MatchAt(J) + JJ) <> ch Then
                    MatchAt(CC) = MatchAt(J)
                    CC = CC + 1
                  End If
                ElseIf MatchAt(J) + JJ = SeqLen(I) - 1 Then
                  If SeqByte(MatchAt(J) - 1) <> ch Then
                    MatchAt(CC) = MatchAt(J)
                    CC = CC + 1
                  End If
                Else
                  If SeqByte(MatchAt(J) - 1) <> ch And SeqByte(MatchAt(J) + JJ) <> ch Then
                    MatchAt(CC) = MatchAt(J)
                    CC = CC + 1
                  End If
                End If
              Next J
              ObsN = CC

              sTmp = FmtStr(sName(I), 30, True) & NF(SeqLen(I), 8, 0) & NF(ObsN, 8, 0) & NF(JJ, 6, 0)
              Select Case ObsN
                Case 1
                  sTmp2 = MatchAt(0)
                Case Is > 1
                  sTmp2 = ""
                  For J = 0 To ObsN - 2
                    sTmp2 = sTmp2 & MatchAt(J) & ","
                  Next J
                  sTmp2 = sTmp2 & MatchAt(J)
              End Select
              sTmp = sTmp & "  " & sTmp2 & vbCrLf
              Mid(sOut, Ptr) = sTmp
              Ptr = Ptr + Len(sTmp)
              Exit For
            End If
          End If
        Next JJ
      End If
      ProgressBar1.Value = I
    Next I
    Mid(sOut, Ptr) = "========================================================================================================" & vbCrLf
    Ptr = Ptr + 106
    sOut = Left(sOut, Ptr - 1)
    ProgressBar1.Value = 0
  End Sub


  'For sequences with no gaps
  'e.g.,find broken poly-A in nuc sequences,or poly-Ala in aa sequences
  'Input:
  'Ch: e.g.,'A'
  'lLenCh: Length of string to be found
  'BrokenAt: e.g.,if Ch = 'A',lLench = 12 and BrokenAt = 3,then find BAABAAAAAAAAAB where B is not A
  'Output:
  'SeqName  SeqLen  ObsN  FindAt
  'Exclude sequences shorter than lMinSeqLen
  'Use KMPSearchM:

  Sub FindPolyXBroken(ByRef sSeq() As String, ByRef sName() As String, ByVal lNumSeq As Integer, ByVal ch As Byte, ByVal lLenCh As Integer, ByVal BrokenAt As Integer, ByVal lMinSeqLen As Integer, ByVal Nuc1AA2 As Integer, ByRef sOut As String, ByRef ProgressBar1 As ProgressBar)



    Dim I As Integer, J As Integer, JJ As Integer, Ptr As Integer, CC As Integer
    Dim sTmp As String
    Dim SeqByte() As Byte, POLY() As Byte
    Dim SeqLen() As Integer, MatchAt() As Integer, ObsN As Integer, SumObsN As Integer
    Dim SeqByteArray() As Object
    Dim sCh As String
    Dim CodeByte() As Byte

    ReDim POLY(lLenCh - 1)
    ReDim SeqByteArray(lNumSeq - 1), SeqLen(lNumSeq - 1)

    If Nuc1AA2 = 1 Then
      CodeByte = Encoding.ascii.getbytes("ACGU")
    Else
      CodeByte = Encoding.ascii.getbytes("ARNDCQEGHILKMFPSTWYV")
    End If

    For I = 0 To lLenCh - 1
      POLY(I) = ch
    Next I

    For I = 0 To lNumSeq - 1
      SeqByte = Encoding.ascii.getbytes(sSeq(I))
      SeqLen(I) = Len(sSeq(I))
      SeqByteArray(I) = SeqByte
    Next I

    With ProgressBar1
      .Minimum = 0
      .Maximum = lNumSeq
    End With

    Ptr = Len(sOut) + 1
    POLY(BrokenAt - 1) = 78
    sOut = "Search for " & Encoding.ascii.getstring(POLY) & vbCrLf
    sOut = sOut & "============================================================================================================" & vbCrLf
    sOut = sOut & "SeqName                         SeqLen    ObsN Code  FindAt" & vbCrLf
    sOut = sOut & "------------------------------------------------------------------------------------------------------------" & vbCrLf
    Ptr = Len(sOut) + 1
    sOut = sOut & Space(138 * (lNumSeq + 1) * (UBound(CodeByte) + 1))
    SumObsN = 0
    For JJ = 0 To UBound(CodeByte)
      If CodeByte(JJ) <> ch Then
        sCh = "    " & Chr(CodeByte(JJ))
        POLY(BrokenAt - 1) = CodeByte(JJ)
        For I = 0 To lNumSeq - 1
          If SeqLen(I) >= lMinSeqLen Then
            SeqByte = SeqByteArray(I)
            If KMPSearchM(SeqByte, POLY, lLenCh, SeqLen(I), ObsN, MatchAt) Then
              CC = 0
              For J = 0 To ObsN - 1
                If SeqByte(MatchAt(J) - 1) <> ch And SeqByte(MatchAt(J) + lLenCh) <> ch Then
                  MatchAt(CC) = MatchAt(J)
                  CC = CC + 1
                End If
              Next J
              ObsN = CC
              If ObsN > 0 Then
                sTmp = FmtStr(sName(I), 30, True) & NF(SeqLen(I), 8, 0)
                sTmp = sTmp & NF(ObsN, 8, 0) & sCh
                sTmp = sTmp & "  " & MatchAt(0)
                For J = 1 To ObsN - 1
                  sTmp = sTmp & "," & MatchAt(J)
                Next J
                sTmp = sTmp & vbCrLf
                Mid(sOut, Ptr) = sTmp
                Ptr = Ptr + Len(sTmp)
                SumObsN = SumObsN + ObsN
              End If
            End If
          End If
          ProgressBar1.Value = I
        Next I
      End If
    Next JJ
    Mid(sOut, Ptr) = "============================================================================================================" & vbCrLf
    Ptr = Ptr + 110
    sTmp = "Observed Total: " & FormatNumber(SumObsN, 0) & CRCR
    Mid(sOut, Ptr) = sTmp
    Ptr = Ptr + Len(sTmp)
    sOut = Left(sOut, Ptr - 1)
    ProgressBar1.Value = 0
  End Sub



  Function GetLongestStrInArray(ByRef sStrArray() As String, ByVal ArrayDim As Integer) As Integer

    Dim TmpLen As Integer, TmpLen2 As Integer, I As Integer
    TmpLen = Len(sStrArray(0))
    If ArrayDim = 1 Then
      GetLongestStrInArray = TmpLen
    Else
      For I = 1 To ArrayDim - 1
        TmpLen2 = Len(sStrArray(I))
        If TmpLen2 > TmpLen Then
          TmpLen = TmpLen2
        End If
      Next I
      GetLongestStrInArray = TmpLen
    End If
  End Function




  Function GetShortestStrInArray(ByRef SeqArray As Object, ByVal ArrayDim As Integer, Optional ByRef Index As Integer = 0) As Integer

    Dim TmpLen As Integer, I As Integer
    GetShortestStrInArray = Len(SeqArray(0))
    Index = 0
    For I = 1 To ArrayDim - 1
      TmpLen = Len(SeqArray(I))
      If TmpLen < GetShortestStrInArray Then
        GetShortestStrInArray = TmpLen
        Index = I
      End If
    Next I
  End Function



  Function IsStrIdentical(ByRef sStrArray() As String, ByRef sStrIDArray() As String, ByVal InNumSeq As Integer, ByRef IdenticalStrID As String) As Boolean


    Dim I As Integer, J As Integer, Count As Integer, Ptr As Integer, MaxLen As Integer
    Dim sTmp As String

    MaxLen = 100000
    IdenticalStrID = Space(MaxLen)
    Ptr = 1
    For I = 0 To InNumSeq - 1
      For J = 0 To I - 1
        If sStrArray(I) = sStrArray(J) Then
          sTmp = sStrIDArray(J) & ".." & sStrIDArray(I) & vbCrLf
          Mid(IdenticalStrID, Ptr) = sTmp
          Ptr = Ptr + Len(sTmp)
          If Ptr > MaxLen - 100 Then
            IdenticalStrID = IdenticalStrID & Space(100000)
            MaxLen = MaxLen + 100000
          End If
          Count = Count + 1
        End If
      Next J
    Next I
    If Count > 0 Then
      IdenticalStrID = Left(IdenticalStrID, Ptr - 1)
      Return True
    Else
      Return False
    End If
  End Function



  Function IsStrIDIdentical(ByRef sStrArray() As String, ByVal InNumSeq As Integer, ByRef sOut As String) As Boolean


    Dim I As Integer, J As Integer, Count As Integer
    For I = 1 To InNumSeq - 1
      For J = 0 To I - 1
        If sStrArray(I) = sStrArray(J) Then
          sOut = sOut & "Item " & I + 1 & " : Item " & J + 1 & vbCrLf
          Count = Count + 1
        End If
      Next J
    Next I
    If Count > 0 Then
      Return True
    Else
      Return False
    End If
  End Function




  Function FilterStr(ByRef Txt As String, ByRef FilterString As String) As String


    Dim I As Integer, TxtLength As Integer, FilterLen As Integer, CC As Integer
    Dim tmpByte() As Byte, FilterStrByte() As Byte
    tmpByte = Encoding.ascii.getbytes(Txt)
    TxtLength = Len(Txt)
    FilterStrByte = Encoding.ascii.getbytes(FilterString)
    FilterLen = Len(FilterString)
    Call ShellSortA(FilterStrByte, 0, UBound(FilterStrByte))

    For I = 0 To TxtLength - 1
      If FindOneInSortedNumArray(FilterStrByte, FilterLen, tmpByte(I)) < FilterLen Then
        tmpByte(CC) = tmpByte(I)
        CC = CC + 1
      End If
    Next I
    ReDim Preserve tmpByte(CC - 1)
    FilterStr = Encoding.ascii.getstring(tmpByte)
  End Function



  Function FilterStr2(ByRef Txt As String, ByRef SortedFilterStr As String) As String


    Dim I As Integer, TxtLength As Integer, FilterLen As Integer, CC As Integer
    Dim tmpByte() As Byte, FilterStrByte() As Byte
    tmpByte = Encoding.ascii.getbytes(Txt)
    TxtLength = Len(Txt)
    FilterStrByte = Encoding.ascii.getbytes(SortedFilterStr)
    FilterLen = Len(SortedFilterStr)

    For I = 0 To TxtLength - 1
      If FindOneInSortedNumArray(FilterStrByte, FilterLen, tmpByte(I)) < FilterLen Then
        tmpByte(CC) = tmpByte(I)
        CC = CC + 1
      End If
    Next I
    ReDim Preserve tmpByte(CC - 1)
    FilterStr2 = Encoding.ascii.getstring(tmpByte)
  End Function




  Function FilterStr3(ByRef sIn As String, ByRef sFilter As String) As String

    Dim I As Integer, J As Integer, CC As Integer, FilterInd As Integer
    Dim InByte() As Byte
    Dim FilterByte() As Byte
    Dim bKeep As Boolean

    FilterInd = Len(sFilter) - 1
    InByte = Encoding.ascii.getbytes(sIn)
    FilterByte = Encoding.ascii.getbytes(sFilter)

    For I = 0 To Len(sIn) - 1
      bKeep = True
      For J = 0 To FilterInd
        If InByte(I) = FilterByte(J) Then
          bKeep = False
          Exit For
        End If
      Next J
      If bKeep Then
        InByte(CC) = InByte(I)
        CC = CC + 1
      End If
    Next I
    ReDim Preserve InByte(CC - 1)
    FilterStr3 = Encoding.ascii.getstring(InByte)
  End Function

  Function GetUniqueHashCodeOfFileContent(ByVal sFileName As String)
    Dim FI As New System.IO.FileInfo(sFileName)
    Dim SHA As New System.Security.Cryptography.SHA512Managed()
    Dim sb As System.Text.StringBuilder
    Dim data As Byte()
    Dim i As Integer
    Using fs As New IO.FileStream(FI.FullName, IO.FileMode.Open)
      data = SHA.ComputeHash(fs)
      fs.Flush()
      fs.Close()
    End Using
    sb = New System.Text.StringBuilder
    ' Loop through each byte of the hashed data 
    ' and format each one as a hexadecimal string.
    For i = 0 To data.Length - 1
      sb.Append(data(i).ToString("x2"))
    Next i
    Return sb.ToString()
  End Function

  Function GetUniqueHashCodeOfString(ByVal sText As String) As String
    Dim SHA As New System.Security.Cryptography.SHA512Managed()
    Dim data As Byte() = SHA.ComputeHash(Encoding.UTF8.GetBytes(sText))
    Dim sb As System.Text.StringBuilder
    sb = New System.Text.StringBuilder
    ' Loop through each byte of the hashed data 
    ' and format each one as a hexadecimal string.
    For i = 0 To data.Length - 1
      sb.Append(data(i).ToString("x2"))
    Next i
    Return sb.ToString()
  End Function
End Module
