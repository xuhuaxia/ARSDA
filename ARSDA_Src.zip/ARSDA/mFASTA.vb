﻿Imports System.IO
Imports System.Text
Module mFASTA
  Sub OutFasFile(ByRef sFasFile As String, ByVal sSeq() As String, ByVal sName() As String, _
  ByVal iNumSeq As Integer, ByVal iSeqLen() As Integer, ByVal ProgressBar1 As ToolStripProgressBar, Optional ByVal bIsNuc As Boolean = True)

    Dim I As Integer
    Dim sTmp As String, ResStr As String
    Dim sb As New StringBuilder

    If bIsNuc Then
      ResStr = " bases"
    Else
      ResStr = " AA"
    End If

    ProgressBar1.Minimum = 0
    ProgressBar1.Maximum = iNumSeq
    If iNumSeq < 10000 Then
      For I = 0 To iNumSeq - 1
        sTmp = ">" & sName(I) & " " & iSeqLen(I) & ResStr & vbCrLf
        sb.Append(sTmp)
        sb.Append(sSeq(I) & vbCrLf)
        ProgressBar1.Value = I
      Next
      File.WriteAllText(sFasFile, sb.ToString)
    Else
      sTmp = ">" & sName$(0) & " " & iSeqLen(0) & ResStr & vbCrLf & sSeq(0) & vbCrLf
      File.WriteAllText(sFasFile, sTmp)

      For I = 1 To iNumSeq - 1
        sTmp = ">" & sName(I) & " " & iSeqLen(I) & ResStr & vbCrLf
        sb.Append(sTmp)
        sb.Append(sSeq(I))
        If I Mod 10000 = 0 Then
          File.AppendAllText(sFasFile, sb.ToString)
          sb.Clear()
        End If
        ProgressBar1.Value = I
      Next
      File.AppendAllText(sFasFile, sb.ToString)
    End If
    ProgressBar1.Value = 0
    sb = Nothing
  End Sub

  'For output 1 fasta file, use OutFasFile
  Sub OutFasFileN(ByVal sFasFile As String, ByVal iNumOutFile As Integer, ByVal sSeq() As String, ByVal sName() As String, _
                  ByVal iNumSeq As Integer, ByVal iSeqLen() As Integer, ByVal ProgressBar1 As ToolStripProgressBar, Optional ByVal bIsNuc As Boolean = True)
    'iNumOutFile: number of fasta files to save to, each is suffixed as Name1.fas, Name2.fas, etc.
    'Is user likely to input iNumOutFile > iNumSeq? Unlikely, ignore
    Dim I As Integer, J As Integer, StartInd As Integer
    Dim sTmp As String, ResStr As String
    Dim sFN As String = GetFNOnly(sFasFile) & "_"
    Dim sb As New StringBuilder
    Dim NumSeqPerFile As Integer, RemainNumSeq As Integer

    NumSeqPerFile = iNumSeq \ iNumOutFile
    RemainNumSeq = iNumSeq Mod iNumOutFile
    If RemainNumSeq > 0 Then
      NumSeqPerFile = NumSeqPerFile + 1
    End If
    If bIsNuc Then
      ResStr = " bases"
    Else
      ResStr = " AA"
    End If

    ProgressBar1.Minimum = 0
    ProgressBar1.Maximum = iNumSeq
    For I = 0 To iNumOutFile - IIf(RemainNumSeq = 0, 1, 2)
      StartInd = I * NumSeqPerFile
      For J = StartInd To StartInd + NumSeqPerFile - 1
        sTmp = ">" & sName(J) & " " & iSeqLen(J) & ResStr & vbCrLf
        sb.Append(sTmp)
        sb.Append(sSeq(J) & vbCrLf)
      Next
      File.WriteAllText(sFN & I & ".fas", sb.ToString)
      sb.Clear()
    Next
    If RemainNumSeq > 0 Then 'writing the last file
      StartInd = I * NumSeqPerFile
      For J = StartInd To iNumSeq - 1
        sTmp = ">" & sName(J) & " " & iSeqLen(J) & ResStr & vbCrLf
        sb.Append(sTmp)
        sb.Append(sSeq(J) & vbCrLf)
      Next
      File.WriteAllText(sFN & I & ".fas", sb.ToString)
      sb.Clear()
    End If
    ProgressBar1.Value = 0
    sb = Nothing
  End Sub

  'Sub ReadFasStr(ByVal FileStr As String, ByRef SeqArray() As String, ByRef SeqNameArray() As String, ByRef iNumSeq As Integer, ByRef iSeqLen() As Integer)
  '  Dim StartAt As Integer, StartAt2 As Integer
  '  Dim InLine As String, LineEnd As String, LineEndLen As Integer
  '  Dim I As Integer
  '  Dim MaxNumSeq As Integer
  '  MaxNumSeq = 100
  '  ReDim SeqArray(MaxNumSeq - 1), SeqNameArray(MaxNumSeq - 1)
  '  LineEnd = GetLineEnd(FileStr)
  '  LineEndLen = Len(LineEnd)
  '  StartAt = InStr(FileStr, ">") + 1
  '  Do Until StartAt = 1
  '    InLine = GetLine2(FileStr, StartAt, LineEnd, LineEndLen)
  '    If InStr(InLine, " ") > 0 Then
  '      SeqNameArray(I) = LeftOfChar(InLine, " ")
  '    Else
  '      SeqNameArray(I) = InLine
  '    End If
  '    StartAt2 = StartAt
  '    StartAt = InStr(StartAt2, FileStr, ">") + 1
  '    If StartAt > 1 Then
  '      SeqArray(I) = Mid$(FileStr, StartAt2, StartAt - StartAt2 - 1)
  '    Else
  '      SeqArray(I) = Right$(FileStr, Len(FileStr) - StartAt2 + 1)
  '    End If
  '    I = I + 1
  '    If I = MaxNumSeq Then
  '      MaxNumSeq = MaxNumSeq + 100
  '      ReDim Preserve SeqArray(MaxNumSeq - 1), SeqNameArray(MaxNumSeq - 1)
  '    End If
  '  Loop
  '  iNumSeq = I
  '  For I = 0 To iNumSeq - 1
  '    SeqArray(I) = Replace(SeqArray(I), LineEnd, "")
  '    SeqArray(I) = Replace(SeqArray(I), " ", "")
  '    iSeqLen(I) = Len(SeqArray(I))
  '  Next I
  '  ReDim Preserve SeqArray(iNumSeq - 1), SeqNameArray(iNumSeq - 1), iSeqLen(iNumSeq - 1)
  'End Sub


End Module
