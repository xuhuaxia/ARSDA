﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Text
Imports System.Windows.Forms
Imports Microsoft.Glee.Drawing

Public Class frmCanvas
  Private mViewer As Microsoft.Glee.GraphViewerGdi.GViewer
  Private mGraph As Microsoft.Glee.Drawing.Graph
  Private Sub frmCanvas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    mViewer = New Microsoft.Glee.GraphViewerGdi.GViewer()
    mGraph = New Microsoft.Glee.Drawing.Graph("graph")
    Call Test()
  End Sub

  Private Sub OpenTreeFileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnuFileOpenTreeFile.Click

  End Sub


  Private Sub mnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
    mViewer = Nothing
    mGraph = Nothing
    Me.Close()
  End Sub

  Private Sub Test()
    Dim I As Integer
    Dim sNode1 As String = "Circle"
    Dim sNode2 As String = "Home"
    Dim sNode3 As String = "Diamond"
    Dim sNode4 As String = "Standard"
    Dim nodeTmp As Microsoft.Glee.Drawing.Node

    mGraph.AddEdge(sNode1, sNode2)
    mGraph.AddEdge(sNode2, sNode1)
    mGraph.AddEdge(sNode2, sNode2)
    mGraph.AddEdge(sNode1, sNode3)
    mGraph.AddEdge(sNode1, sNode4)
    mGraph.AddEdge(sNode4, sNode1)
    mGraph.AddEdge(sNode2, "Node 0")
    For I = 0 To 3
      mGraph.AddEdge("Node " + I.ToString, "Node " + (I + 1).ToString)
    Next
    For I = 0 To 3
      mGraph.AddEdge("Node " + (I + 1).ToString, "Node " + I.ToString)
    Next

    'modify attributes
    nodeTmp = mGraph.FindNode(sNode1)
    nodeTmp.Attr.Fillcolor = Microsoft.Glee.Drawing.Color.SeaGreen
    nodeTmp.Attr.Shape = Microsoft.Glee.Drawing.Shape.DoubleCircle

    nodeTmp = mGraph.FindNode(sNode2)
    nodeTmp.Attr.Fillcolor = Microsoft.Glee.Drawing.Color.Azure
    nodeTmp.Attr.Shape = Microsoft.Glee.Drawing.Shape.House

    nodeTmp = mGraph.FindNode(sNode3)
    nodeTmp.Attr.Fillcolor = Microsoft.Glee.Drawing.Color.Brown
    nodeTmp.Attr.Shape = Microsoft.Glee.Drawing.Shape.Diamond


    'Bind the graph to the viewer
    mViewer.Graph = mGraph

    'associate the viewer with the form
    Me.SuspendLayout()
    mViewer.Dock = System.Windows.Forms.DockStyle.Fill
    Me.Controls.Add(mViewer)
    Me.ResumeLayout()

  End Sub
End Class