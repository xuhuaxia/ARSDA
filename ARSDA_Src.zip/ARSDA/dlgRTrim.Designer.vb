﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class dlgRTrim
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
    Me.OK_Button = New System.Windows.Forms.Button()
    Me.Cancel_Button = New System.Windows.Forms.Button()
    Me.BrowseFasta = New System.Windows.Forms.Button()
    Me.btnBrowseFastq = New System.Windows.Forms.Button()
    Me.txtOutFasFile = New System.Windows.Forms.TextBox()
    Me.txtInFile = New System.Windows.Forms.TextBox()
    Me.lblFastqFile = New System.Windows.Forms.Label()
    Me.lblFastaFile = New System.Windows.Forms.Label()
    Me.chkRidN = New System.Windows.Forms.CheckBox()
    Me.lblLimitLen = New System.Windows.Forms.Label()
    Me.txtLimitLen = New System.Windows.Forms.TextBox()
    Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
    Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
    Me.TableLayoutPanel1.SuspendLayout()
    Me.SuspendLayout()
    '
    'TableLayoutPanel1
    '
    Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.TableLayoutPanel1.ColumnCount = 2
    Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.Controls.Add(Me.OK_Button, 0, 0)
    Me.TableLayoutPanel1.Controls.Add(Me.Cancel_Button, 1, 0)
    Me.TableLayoutPanel1.Location = New System.Drawing.Point(382, 142)
    Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
    Me.TableLayoutPanel1.RowCount = 1
    Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.Size = New System.Drawing.Size(146, 29)
    Me.TableLayoutPanel1.TabIndex = 0
    '
    'OK_Button
    '
    Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
    Me.OK_Button.Location = New System.Drawing.Point(3, 3)
    Me.OK_Button.Name = "OK_Button"
    Me.OK_Button.Size = New System.Drawing.Size(67, 23)
    Me.OK_Button.TabIndex = 0
    Me.OK_Button.Text = "OK"
    '
    'Cancel_Button
    '
    Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
    Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Cancel_Button.Location = New System.Drawing.Point(76, 3)
    Me.Cancel_Button.Name = "Cancel_Button"
    Me.Cancel_Button.Size = New System.Drawing.Size(67, 23)
    Me.Cancel_Button.TabIndex = 1
    Me.Cancel_Button.Text = "Cancel"
    '
    'BrowseFasta
    '
    Me.BrowseFasta.Location = New System.Drawing.Point(446, 73)
    Me.BrowseFasta.Name = "BrowseFasta"
    Me.BrowseFasta.Size = New System.Drawing.Size(75, 23)
    Me.BrowseFasta.TabIndex = 21
    Me.BrowseFasta.Text = "Browse"
    Me.BrowseFasta.UseVisualStyleBackColor = True
    '
    'btnBrowseFastq
    '
    Me.btnBrowseFastq.Location = New System.Drawing.Point(446, 23)
    Me.btnBrowseFastq.Name = "btnBrowseFastq"
    Me.btnBrowseFastq.Size = New System.Drawing.Size(75, 23)
    Me.btnBrowseFastq.TabIndex = 20
    Me.btnBrowseFastq.Text = "Browse"
    Me.btnBrowseFastq.UseVisualStyleBackColor = True
    '
    'txtOutFasFile
    '
    Me.txtOutFasFile.Location = New System.Drawing.Point(12, 76)
    Me.txtOutFasFile.Name = "txtOutFasFile"
    Me.txtOutFasFile.Size = New System.Drawing.Size(428, 20)
    Me.txtOutFasFile.TabIndex = 19
    '
    'txtInFile
    '
    Me.txtInFile.Location = New System.Drawing.Point(12, 25)
    Me.txtInFile.Name = "txtInFile"
    Me.txtInFile.Size = New System.Drawing.Size(428, 20)
    Me.txtInFile.TabIndex = 18
    '
    'lblFastqFile
    '
    Me.lblFastqFile.AutoSize = True
    Me.lblFastqFile.Location = New System.Drawing.Point(9, 9)
    Me.lblFastqFile.Name = "lblFastqFile"
    Me.lblFastqFile.Size = New System.Drawing.Size(116, 13)
    Me.lblFastqFile.TabIndex = 17
    Me.lblFastqFile.Text = "Input FASTA file name:"
    '
    'lblFastaFile
    '
    Me.lblFastaFile.AutoSize = True
    Me.lblFastaFile.Location = New System.Drawing.Point(12, 60)
    Me.lblFastaFile.Name = "lblFastaFile"
    Me.lblFastaFile.Size = New System.Drawing.Size(121, 13)
    Me.lblFastaFile.TabIndex = 22
    Me.lblFastaFile.Text = "Output FASTA file name"
    '
    'chkRidN
    '
    Me.chkRidN.AutoSize = True
    Me.chkRidN.Checked = True
    Me.chkRidN.CheckState = System.Windows.Forms.CheckState.Checked
    Me.chkRidN.Location = New System.Drawing.Point(12, 151)
    Me.chkRidN.Name = "chkRidN"
    Me.chkRidN.Size = New System.Drawing.Size(226, 17)
    Me.chkRidN.TabIndex = 23
    Me.chkRidN.Text = "Exclude reads with ambiguous nucleotides"
    Me.chkRidN.UseVisualStyleBackColor = True
    '
    'lblLimitLen
    '
    Me.lblLimitLen.AutoSize = True
    Me.lblLimitLen.Location = New System.Drawing.Point(12, 117)
    Me.lblLimitLen.Name = "lblLimitLen"
    Me.lblLimitLen.Size = New System.Drawing.Size(139, 13)
    Me.lblLimitLen.TabIndex = 24
    Me.lblLimitLen.Text = "Length limit (minimum = 30): "
    '
    'txtLimitLen
    '
    Me.txtLimitLen.Location = New System.Drawing.Point(157, 114)
    Me.txtLimitLen.Name = "txtLimitLen"
    Me.txtLimitLen.Size = New System.Drawing.Size(59, 20)
    Me.txtLimitLen.TabIndex = 25
    Me.txtLimitLen.Text = "50"
    '
    'OpenFileDialog1
    '
    Me.OpenFileDialog1.FileName = "OpenFileDialog1"
    '
    'dlgRTrim
    '
    Me.AcceptButton = Me.OK_Button
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.CancelButton = Me.Cancel_Button
    Me.ClientSize = New System.Drawing.Size(540, 183)
    Me.Controls.Add(Me.txtLimitLen)
    Me.Controls.Add(Me.lblLimitLen)
    Me.Controls.Add(Me.chkRidN)
    Me.Controls.Add(Me.lblFastaFile)
    Me.Controls.Add(Me.BrowseFasta)
    Me.Controls.Add(Me.btnBrowseFastq)
    Me.Controls.Add(Me.txtOutFasFile)
    Me.Controls.Add(Me.txtInFile)
    Me.Controls.Add(Me.lblFastqFile)
    Me.Controls.Add(Me.TableLayoutPanel1)
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "dlgRTrim"
    Me.ShowInTaskbar = False
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
    Me.Text = "Right-trim reads and exclude ambiguous reads"
    Me.TableLayoutPanel1.ResumeLayout(False)
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
  Friend WithEvents OK_Button As System.Windows.Forms.Button
  Friend WithEvents Cancel_Button As System.Windows.Forms.Button
  Friend WithEvents BrowseFasta As System.Windows.Forms.Button
  Friend WithEvents btnBrowseFastq As System.Windows.Forms.Button
  Friend WithEvents txtOutFasFile As System.Windows.Forms.TextBox
  Friend WithEvents txtInFile As System.Windows.Forms.TextBox
  Friend WithEvents lblFastqFile As System.Windows.Forms.Label
  Friend WithEvents lblFastaFile As System.Windows.Forms.Label
  Friend WithEvents chkRidN As System.Windows.Forms.CheckBox
  Friend WithEvents lblLimitLen As System.Windows.Forms.Label
  Friend WithEvents txtLimitLen As System.Windows.Forms.TextBox
  Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
  Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog

End Class
