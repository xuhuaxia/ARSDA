﻿Imports System.Windows.Forms
Imports System.IO

Public Class dlgOption

  Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
    sInputDir = txtInDir.Text
    If Not Directory.Exists(sInputDir) Then
      MsgBox("The specified input directory: " & sInputDir & " does not exist.")
      txtInDir.Focus()
      Exit Sub
    End If
    sNewDataDir = txtNewDataDir.Text
    If Not Directory.Exists(sNewDataDir) Then
      MsgBox("The specified directory for saving new data: " & sNewDataDir & " does not exist.")
      txtNewDataDir.Focus()
      Exit Sub
    End If
    sResultDir = txtResultDir.Text
    If Not Directory.Exists(sResultDir) Then
      MsgBox("The specified input directory: " & sResultDir & " does not exist.")
      txtResultDir.Focus()
      Exit Sub
    End If

    'Write out to ARSDA.ini
    Dim sOut As String
    sOut = "InputDir=" & sInputDir & vbCrLf & "NewDataDir=" & sNewDataDir & vbCrLf & "ResultDir=" & sResultDir
    File.WriteAllText(Application.StartupPath & "\ARSDA.ini", sOut)
    Me.DialogResult = System.Windows.Forms.DialogResult.OK
    Me.Close()
  End Sub

  Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
    Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Close()
  End Sub

  Private Sub dlgOption_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    txtInDir.Text = sInputDir
    txtNewDataDir.Text = sNewDataDir
    txtResultDir.Text = sResultDir

  End Sub

  Private Sub btnBrowseInDir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseInDir.Click
    With FolderBrowserDialog1
      If Directory.Exists(txtInDir.Text) Then
        .SelectedPath = txtInDir.Text
      Else
        .SelectedPath = sInputDir
      End If
      .Description = "Input directory"
      .ShowDialog()
      txtInDir.Text = .SelectedPath
    End With
  End Sub

  Private Sub btnBrowseNewdataDir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseNewdataDir.Click
    With FolderBrowserDialog1
      If Directory.Exists(txtNewDataDir.Text) Then
        .SelectedPath = txtNewDataDir.Text
      Else
        .SelectedPath = sInputDir
      End If
      .ShowNewFolderButton = True
      .Description = "Directory for new data"
      .ShowDialog()
      txtNewDataDir.Text = .SelectedPath
    End With

  End Sub

  Private Sub btnBrowseResultDir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseResultDir.Click
    With FolderBrowserDialog1
      If Directory.Exists(txtResultDir.Text) Then
        .SelectedPath = txtResultDir.Text
      Else
        .SelectedPath = sInputDir
      End If
      .ShowNewFolderButton = True
      .Description = "Result directory"
      .ShowDialog()
      txtResultDir.Text = .SelectedPath
    End With

  End Sub
End Class
