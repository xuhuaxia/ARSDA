﻿Imports System.IO
Imports System.Xml
Imports System.Text
Module mSRA
  'Uses sratoolkit at Application.StartPath & "\sratoolkit\bin"
  Function GetSraInfo(ByVal sSRAFile As String, ByRef bIsPaired As Boolean, ByRef bIsAligned As Boolean, ByRef sOut As String, ByRef sErr As String, _
                      ByVal iGetFirstNreads As Integer, ByVal bGetQual As Boolean, Optional ByRef NumQualCh As Integer = 0, Optional ByRef QualVal As Double() = Nothing, _
                      Optional ByRef QualCount As Double() = Nothing, Optional ByVal bInferReadQuality As Boolean = False) As Boolean
    Dim I As Integer
    Dim sArg As String
    Dim sTmpFile As String = Path.GetTempFileName
    Dim sDir As String
    Dim sTmp As String, LineArray() As String
    Dim FindAt As Integer
    Dim sb As New StringBuilder

    sDir = Path.GetDirectoryName(sSRAFile)
    'Is paired?
    'fastq-dump -I -X 1 -Z --split-spot SRRFile.sra: 4 lines if not paired, 8 lines if paired
    sArg = " -I -X 1 -Z --split-spot " & sSRAFile & " > " & sTmpFile
    If Not RunExeAndWait(fastqDump, sArg, sDir, False) Then
      sErr = "Error in RunExeAndWait"
      Return False
    End If
    sTmp = File.ReadAllText(sTmpFile)
    Kill(sTmpFile)
    LineArray = Split(sTmp, vbLf)
    If UBound(LineArray) > 6 Then 'Paired
      bIsPaired = True
    Else
      bIsPaired = False
    End If

    'IsAligned? 
    'vdb-dump ./SRR12345.sra | grep "ALIGNMENT_COUNT": if "ALIGNMENT_COUNT" is absent or "ALIGNMENT_COUNT: 0, 0", then not aligned. Check the first 10 reads
    For I = 1 To 10
      sArg = " " & sSRAFile & " -R " & I
      If Not RunExeAndWait(vdbDump, sArg, sDir, False) Then
        sErr = "Error in RunExeAndWait:" & vbCrLf
        Return False
      End If
      FindAt = InStr(sTmp, "ALIGNMENT_COUNT")
      If FindAt > 0 Then
        sTmp = Mid(sTmp, FindAt + 17, 4)
        If InStr(sTmp, "0, 0") = 0 Then
          bIsAligned = True
          Exit For
        End If
      End If
    Next

    sb.Append("Descriptive information from " & sSRAFile & CRCR)
    sb.Append("Paired: " & IIf(bIsPaired, "Yes", "No") & vbCrLf)
    sb.Append("Aligned: " & IIf(bIsAligned, "Yes", "No") & CRCR)

    If iGetFirstNreads > 0 Then
      sTmpFile = Path.GetTempFileName
      sArg = fastqDump & " -X " & iGetFirstNreads & " -Z " & sSRAFile & " > " & sTmpFile
      If RunExeAndWait(fastqDump, sArg, sDir, False) Then
        sTmp = "The first " & iGetFirstNreads & " reads:" & CRCR & File.ReadAllText(sTmpFile)
      End If
    End If

    If Not bGetQual Then
      Return True
    End If
    'Get quality measure and other descriptive stats
    'sratoolkit\bin\sra-stat --quick --xml EcoliSRR1536: will print out the following:
    '  <Run accession="EcoliSRR1536586.sra" spot_count="6503557" base_count="325177850" base_count_bio="325177850">
    '  <Size value="202557306" units="bytes"/>
    '  <QualityCount>
    '    <Quality value="2" count="329423"/>
    '    <Quality value="5" count="17681"/>
    '    <Quality value="6" count="64982"/>
    '    <Quality value="7" count="88477"/>
    '  </QualityCount>
    '</Run>
    Dim sXML As String = ""
    Dim spot_count As Long, base_count As Long, ReadLen As Integer
    sArg = " --quick --xml " & sSRAFile
    If Not RunExeAndWait(sraStat, sArg, sDir, True, sXML) Then
      sErr = "Error in RunExeAndWait: " & vbCrLf
      Return False
    End If

    Dim Reader As XmlReader = XmlReader.Create(New StringReader(sXML))

    ReDim QualVal(93), QualCount(93) 'maximum number of quality characters is 94: from ! to ~

    Do While Reader.Read()
      Select Case Reader.NodeType
        Case XmlNodeType.Element
          If Reader.Name = "Run" Then
            If Reader.HasAttributes Then
              While Reader.MoveToNextAttribute()
                Select Case Reader.Name
                  Case "spot_count"
                    sb.Append("spot_count = " & Reader.Value & vbCrLf)
                    spot_count = Reader.Value
                  Case "base_count"
                    sb.Append("base_count = " & Reader.Value & vbCrLf)
                    base_count = Reader.Value
                End Select
              End While
              ReadLen = base_count \ spot_count
              sb.Append("Read length = " & ReadLen & vbCrLf)
            End If
          ElseIf Reader.Name = "Quality" Then
            Reader.MoveToFirstAttribute()
            QualVal(NumQualCh) = Reader.Value
            Reader.MoveToNextAttribute()
            QualCount(NumQualCh) = Reader.Value
            NumQualCh = NumQualCh + 1
          End If
      End Select
    Loop

    ReDim Preserve QualVal(NumQualCh - 1), QualCount(NumQualCh - 1)
    sb.Append(sTmp)
    sb.Append(CRCR & "Summary statistics of read quality from a total of " & base_count & " bases." & vbCrLf)
    sb.Append("(Lowest quality character is !, i.e., 33, but the quality values in an .SRA file are often presented as (QualityValue - 33), i.e., a value of 2 is in fact 35)" & CRCR)
    sb.Append("Quality".PadLeft(8) & "Count".PadLeft(15) & vbCrLf)
    For I = 0 To NumQualCh - 1
      If QualCount(I) > 0 Then
        sb.Append(QualVal(I).ToString.PadLeft(8) & QualCount(I).ToString.PadLeft(15) & vbCrLf)
      End If
    Next

    If bInferReadQuality Then

    End If
    sOut = sb.ToString
    Return True
  End Function

  Function SRA2FASTQ(ByVal sSRAFile As String, ByVal sOutPath As String, ByVal bPaired As Boolean, ByVal bAligned As Boolean, _
                     ByRef sOut As String) As Boolean
    Dim sArg As String = ""
    Dim sDir As String, sFN As String
    Dim sOldFile As String, sNewFile As String

    sDir = Path.GetDirectoryName(sSRAFile)
    sFN = GetFNOnly(sSRAFile)
    If bPaired Then
      sOldFile = sFN & "_1.fastq"
      If File.Exists(sOldFile) Then
        sNewFile = sFN & "_1_old.fastq"
        Rename(sOldFile, sNewFile)
        sOut = sOut & sOldFile & " has been renamed " & sNewFile
      End If
      sOldFile = sFN & "_2.fastq"
      If File.Exists(sOldFile) Then
        sNewFile = sFN & "_2_old.fastq"
        Rename(sOldFile, sNewFile)
        sOut = sOut & sOldFile & " has been renamed " & sNewFile
      End If
      If bAligned Then
        If MsgBox(sSRAFile & " contains aligned data. Do you wish to dump only aligned reads ('No' to dump all reads)?", vbYesNo) = vbYes Then
          sArg = sArg & " -I --split-files --aligned " & sSRAFile 'Produces two fastq files (--split-files) that contain only aligned reads (--aligned; Note: only for files submitted as aligned data), with a quality offset of 64 (-Q 64) Please see the documentation on vdb-dump if you wish to produce fasta/qual data.
        Else
          sArg = sArg & " -I --split-files " & sSRAFile 'Produces two fastq files (--split-files) containing ".1" and ".2" read suffices (-I) for paired-end data.
        End If
      Else
        sArg = sArg & " -I --split-files " & sSRAFile 'Produces two fastq files (--split-files) containing ".1" and ".2" read suffices (-I) for paired-end data.
      End If
    Else
      sOldFile = sFN & ".fastq"
      If File.Exists(sOldFile) Then
        sNewFile = sFN & "_old.fastq"
        Rename(sOldFile, sNewFile)
        sOut = sOut & sOldFile & " has been renamed " & sNewFile
      End If
      If bAligned Then
        If MsgBox(sSRAFile & " contains aligned data. Do you wish to dump only aligned reads ('No' to dump all reads)?", vbYesNo) = vbYes Then
          sArg = sArg & " --aligned " & sSRAFile 'Produces a fastq file that contains only aligned reads (--aligned; Note: only for files submitted as aligned data), with a quality offset of 64 (-Q 64) Please see the documentation on vdb-dump if you wish to produce fasta/qual data.
        Else
          sArg = sArg & " " & sSRAFile 'Produces a fastq file containing all reads.
        End If
      Else
        sArg = sArg & " " & sSRAFile
      End If
    End If
    sArg = sArg & " --outdir " & sOutPath
    If RunExeAndWait(fastqDump, sArg, sDir, True, sOut) Then
      sOut = sOut & sSRAFile & " has been dumped to " & IIf(bPaired, sFN & "_1.fastq and " & sFN & "_2.fastq.", sFN & ".fastq")
    Else
      sOut = "Error:" & CRCR & sOut & vbCrLf
    End If
    Return True
  End Function

  Function SRA2FASTA(ByVal sSRAFile As String, ByVal bPaired As Boolean, ByVal bAligned As Boolean, _
                     ByRef sOut As String) As Boolean
    Dim sArg As String = ""
    Dim sDir As String, sFN As String, sErr As String
    Dim sOldFile As String, sNewFile As String

    sDir = Path.GetDirectoryName(sSRAFile)
    sFN = GetFNOnly(sSRAFile)
    If bPaired Then
      sOldFile = sFN & "_1.fasta"
      If File.Exists(sOldFile) Then
        sNewFile = sFN & "_1_old.fasta"
        Rename(sOldFile, sNewFile)
        sOut = sOut & sOldFile & " has been renamed " & sNewFile
      End If
      sOldFile = sFN & "_2.fasta"
      If File.Exists(sOldFile) Then
        sNewFile = sFN & "_2_old.fasta"
        Rename(sOldFile, sNewFile)
        sOut = sOut & sOldFile & " has been renamed " & sNewFile
      End If
      If bAligned Then
        If MsgBox(sSRAFile & " contains aligned data. Do you wish to dump only aligned reads ('No' to dump all reads)?", vbYesNo) = vbYes Then
          sArg = sArg & " -I --split-files --aligned --fasta " & sSRAFile 'Produces two fasta files (--split-files) that contain only aligned reads (--aligned; Note: only for files submitted as aligned data), with a quality offset of 64 (-Q 64) Please see the documentation on vdb-dump if you wish to produce fasta/qual data.
        Else
          sArg = sArg & " -I --split-files --fasta " & sSRAFile 'Produces two fasta files (--split-files) containing ".1" and ".2" read suffices (-I) for paired-end data.
        End If
      Else
        sArg = sArg & " -I --split-files --fasta " & sSRAFile 'Produces two fasta files (--split-files) containing ".1" and ".2" read suffices (-I) for paired-end data.
      End If
    Else
      sOldFile = sFN & ".fasta"
      If File.Exists(sOldFile) Then
        sNewFile = sFN & "_old.fasta"
        Rename(sOldFile, sNewFile)
        sOut = sOut & sOldFile & " has been renamed " & sNewFile
      End If
      If bAligned Then
        If MsgBox(sSRAFile & " contains aligned data. Do you wish to dump only aligned reads ('No' to dump all reads)?", vbYesNo) = vbYes Then
          sArg = sArg & " --aligned --fasta " & sSRAFile 'Produces a fasta files containing only aligned reads (--aligned; Note: only for files submitted as aligned data), with a quality offset of 64 (-Q 64) Please see the documentation on vdb-dump if you wish to produce fasta/qual data.
        Else
          sArg = sArg & " --fasta " & sSRAFile 'Produces a fasta file containing all reads.
        End If
      Else
        sArg = sArg & " --fasta " & sSRAFile
      End If
    End If
    If RunExeAndWait(fastqDump, sArg, sDir, True, sOut) Then
      sOut = sOut & sSRAFile & " has been dumped to " & IIf(bPaired, sFN & "_1.fasta and " & sFN & "_2.fasta.", sFN & ".fasta") & CRCR & sOut
    Else
      sOut = "Error:" & CRCR & sOut & CRCR & sErr
    End If
    Return True
  End Function

End Module
