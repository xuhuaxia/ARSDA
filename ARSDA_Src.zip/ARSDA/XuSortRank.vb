﻿Module XuSortRank



  Sub CRankDbl0(ByVal N As Integer, ByRef SortedArray() As Double, ByRef S As Double)




    Dim I As Integer, J As Integer, k As Integer, F As Integer
    Dim Rank As Double
    S = 0
    J = 0
    For I = 1 To N - 1
      If SortedArray(I) > SortedArray(I - 1) Then
        SortedArray(I - 1) = I
      Else
        For J = I + 1 To N - 1
          If SortedArray(J) > SortedArray(J - 1) Then
            Exit For
          End If
        Next J
        Rank = 0.5 * (I + J)
        For k = I To J
          SortedArray(k - 1) = Rank
        Next k
        F = J - I + 1
        S = S + F ^ 3 - F
        I = J
      End If
    Next I
  End Sub





  Sub BubbleSortA(ByRef Array1 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer)




    Dim I As Integer, J As Integer, k As Integer, KK As Integer, F As Integer
    Dim D As Object
    k = LowerInd : KK = UpperInd : F = 1
    While (F <> 0)
      J = KK - 1 : KK = 0
      For I = k To J
        If (Array1(I) > Array1(I + 1)) Then
          D = Array1(I) : Array1(I) = Array1(I + 1) : Array1(I + 1) = D : KK = I
        End If
      Next I
      If (KK = 0) Then F = 0
      J = k + 1 : k = 0
      For I = KK To J Step -1
        If (Array1(I - 1) > Array1(I)) Then
          D = Array1(I) : Array1(I) = Array1(I - 1) : Array1(I - 1) = D : k = I
        End If
      Next I
      If (k = 0) Then F = 0
    End While
  End Sub



  Sub BubbleSortD(ByRef Array1 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer)

    Dim I As Integer, J As Integer, k As Integer, KK As Integer, F As Integer
    Dim D As Object
    k = LowerInd : KK = UpperInd : F = 1
    While (F <> 0)
      J = KK - 1 : KK = 0
      For I = k To J
        If (Array1(I) < Array1(I + 1)) Then
          D = Array1(I) : Array1(I) = Array1(I + 1) : Array1(I + 1) = D : KK = I
        End If
      Next I
      If (KK = 0) Then F = 0
      J = k + 1 : k = 0
      For I = KK To J Step -1
        If (Array1(I - 1) < Array1(I)) Then
          D = Array1(I) : Array1(I) = Array1(I - 1) : Array1(I - 1) = D : k = I
        End If
      Next I
      If (k = 0) Then F = 0
    End While
  End Sub




  Sub BubbleSortArrayMatA(ByRef ArrayX As Object, ByRef YMat As Object, ByVal NumDV As Integer, ByVal LowerInd As Integer, ByVal UpperInd As Integer)

    Dim I As Integer, J As Integer, k As Integer, KK As Integer, F As Integer, II As Integer
    Dim D As Object
    k = LowerInd : KK = UpperInd : F = 1
    While (F <> 0)
      J = KK - 1 : KK = 0
      For I = k To J
        If (ArrayX(I) > ArrayX(I + 1)) Then
          D = ArrayX(I)
          ArrayX(I) = ArrayX(I + 1)
          ArrayX(I + 1) = D
          For II = 0 To NumDV - 1
            D = YMat(I, II)
            YMat(I, II) = YMat(I + 1, II)
            YMat(I + 1, II) = D
          Next II
          KK = I
        End If
      Next I
      If (KK = 0) Then F = 0
      J = k + 1 : k = 0
      For I = KK To J Step -1
        If (ArrayX(I - 1) > ArrayX(I)) Then
          D = ArrayX(I)
          ArrayX(I) = ArrayX(I - 1)
          ArrayX(I - 1) = D
          For II = 0 To NumDV - 1
            D = YMat(I, II)
            YMat(I, II) = YMat(I - 1, II)
            YMat(I - 1, II) = D
          Next II
          k = I
        End If
      Next I
      If (k = 0) Then F = 0
    End While
  End Sub



  Sub BubbleSort2ArrayA(ByRef Array1 As Object, ByRef Array2 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer)

    Dim I As Integer, J As Integer, k As Integer, KK As Integer, F As Integer
    Dim D As Object
    k = LowerInd : KK = UpperInd : F = 1
    While (F <> 0)
      J = KK - 1 : KK = 0
      For I = k To J
        If (Array1(I) > Array1(I + 1)) Then
          D = Array1(I)
          Array1(I) = Array1(I + 1)
          Array1(I + 1) = D
          D = Array2(I)
          Array2(I) = Array2(I + 1)
          Array2(I + 1) = D
          KK = I
        End If
      Next I
      If (KK = 0) Then F = 0
      J = k + 1 : k = 0
      For I = KK To J Step -1
        If (Array1(I - 1) > Array1(I)) Then
          D = Array1(I)
          Array1(I) = Array1(I - 1)
          Array1(I - 1) = D
          D = Array2(I)
          Array2(I) = Array2(I - 1)
          Array2(I - 1) = D
          k = I
        End If
      Next I
      If (k = 0) Then F = 0
    End While
  End Sub



  Sub BubbleSort2ArrayD(ByRef Array1 As Object, ByRef Array2 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer)

    Dim I As Integer, J As Integer, k As Integer, KK As Integer, F As Integer
    Dim D As Object
    k = LowerInd : KK = UpperInd : F = 1
    While (F <> 0)
      J = KK - 1 : KK = 0
      For I = k To J
        If (Array1(I) < Array1(I + 1)) Then
          D = Array1(I)
          Array1(I) = Array1(I + 1)
          Array1(I + 1) = D
          D = Array2(I)
          Array2(I) = Array2(I + 1)
          Array2(I + 1) = D
          KK = I
        End If
      Next I
      If (KK = 0) Then F = 0
      J = k + 1 : k = 0
      For I = KK To J Step -1
        If (Array1(I - 1) < Array1(I)) Then
          D = Array1(I)
          Array1(I) = Array1(I - 1)
          Array1(I - 1) = D
          D = Array2(I)
          Array2(I) = Array2(I - 1)
          Array2(I - 1) = D
          k = I
        End If
      Next I
      If (k = 0) Then F = 0
    End While
  End Sub



  Sub BubbleSort3ArrayA(ByRef Array1 As Object, ByRef Array2 As Object, ByRef Array3 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer)

    Dim I As Integer, J As Integer, k As Integer, KK As Integer, F As Integer
    Dim D As Object
    k = LowerInd : KK = UpperInd : F = 1
    While (F <> 0)
      J = KK - 1 : KK = 0
      For I = k To J
        If (Array1(I) > Array1(I + 1)) Then
          D = Array1(I)
          Array1(I) = Array1(I + 1)
          Array1(I + 1) = D
          D = Array2(I)
          Array2(I) = Array2(I + 1)
          Array2(I + 1) = D
          D = Array3(I)
          Array3(I) = Array3(I + 1)
          Array3(I + 1) = D
          KK = I
        End If
      Next I
      If (KK = 0) Then F = 0
      J = k + 1 : k = 0
      For I = KK To J Step -1
        If (Array1(I - 1) > Array1(I)) Then
          D = Array1(I)
          Array1(I) = Array1(I - 1)
          Array1(I - 1) = D
          D = Array2(I)
          Array2(I) = Array2(I - 1)
          Array2(I - 1) = D
          D = Array3(I)
          Array3(I) = Array3(I - 1)
          Array3(I - 1) = D
          k = I
        End If
      Next I
      If (k = 0) Then F = 0
    End While
  End Sub



  Sub BubbleSort3ArrayD(ByRef Array1 As Object, ByRef Array2 As Object, ByRef Array3 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer)

    Dim I As Integer, J As Integer, k As Integer, KK As Integer, F As Integer
    Dim D As Object
    k = LowerInd : KK = UpperInd : F = 1
    While (F <> 0)
      J = KK - 1 : KK = 0
      For I = k To J
        If (Array1(I) < Array1(I + 1)) Then
          D = Array1(I)
          Array1(I) = Array1(I + 1)
          Array1(I + 1) = D
          D = Array2(I)
          Array2(I) = Array2(I + 1)
          Array2(I + 1) = D
          D = Array3(I)
          Array3(I) = Array3(I + 1)
          Array3(I + 1) = D
          KK = I
        End If
      Next I
      If (KK = 0) Then F = 0
      J = k + 1 : k = 0
      For I = KK To J Step -1
        If (Array1(I - 1) < Array1(I)) Then
          D = Array1(I)
          Array1(I) = Array1(I - 1)
          Array1(I - 1) = D
          D = Array2(I)
          Array2(I) = Array2(I - 1)
          Array2(I - 1) = D
          D = Array3(I)
          Array3(I) = Array3(I - 1)
          Array3(I - 1) = D
          k = I
        End If
      Next I
      If (k = 0) Then F = 0
    End While
  End Sub



  Sub BubbleSort4ArrayA(ByRef Array1 As Object, ByRef Array2 As Object, ByRef Array3 As Object, ByRef Array4 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer)

    Dim I As Integer, J As Integer, k As Integer, KK As Integer, F As Integer
    Dim D As Object
    k = LowerInd : KK = UpperInd : F = 1
    While (F <> 0)
      J = KK - 1 : KK = 0
      For I = k To J
        If (Array1(I) > Array1(I + 1)) Then
          D = Array1(I)
          Array1(I) = Array1(I + 1)
          Array1(I + 1) = D
          D = Array2(I)
          Array2(I) = Array2(I + 1)
          Array2(I + 1) = D
          D = Array3(I)
          Array3(I) = Array3(I + 1)
          Array3(I + 1) = D
          D = Array4(I)
          Array4(I) = Array4(I + 1)
          Array4(I + 1) = D
          KK = I
        End If
      Next I
      If (KK = 0) Then F = 0
      J = k + 1 : k = 0
      For I = KK To J Step -1
        If (Array1(I - 1) > Array1(I)) Then
          D = Array1(I)
          Array1(I) = Array1(I - 1)
          Array1(I - 1) = D
          D = Array2(I)
          Array2(I) = Array2(I - 1)
          Array2(I - 1) = D
          D = Array3(I)
          Array3(I) = Array3(I - 1)
          Array3(I - 1) = D
          D = Array4(I)
          Array4(I) = Array4(I - 1)
          Array4(I - 1) = D
          k = I
        End If
      Next I
      If (k = 0) Then F = 0
    End While
  End Sub



  Sub BubbleSort4ArrayD(ByRef Array1 As Object, ByRef Array2 As Object, ByRef Array3 As Object, ByRef Array4 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer)

    Dim I As Integer, J As Integer, k As Integer, KK As Integer, F As Integer
    Dim D As Object
    k = LowerInd : KK = UpperInd : F = 1
    While (F <> 0)
      J = KK - 1 : KK = 0
      For I = k To J
        If (Array1(I) < Array1(I + 1)) Then
          D = Array1(I)
          Array1(I) = Array1(I + 1)
          Array1(I + 1) = D
          D = Array2(I)
          Array2(I) = Array2(I + 1)
          Array2(I + 1) = D
          D = Array3(I)
          Array3(I) = Array3(I + 1)
          Array3(I + 1) = D
          D = Array4(I)
          Array4(I) = Array4(I + 1)
          Array4(I + 1) = D
          KK = I
        End If
      Next I
      If (KK = 0) Then F = 0
      J = k + 1 : k = 0
      For I = KK To J Step -1
        If (Array1(I - 1) < Array1(I)) Then
          D = Array1(I)
          Array1(I) = Array1(I - 1)
          Array1(I - 1) = D
          D = Array2(I)
          Array2(I) = Array2(I - 1)
          Array2(I - 1) = D
          D = Array3(I)
          Array3(I) = Array3(I - 1)
          Array3(I - 1) = D
          D = Array4(I)
          Array4(I) = Array4(I - 1)
          Array4(I - 1) = D
          k = I
        End If
      Next I
      If (k = 0) Then F = 0
    End While
  End Sub




  Sub BubbleSort5ArrayA(ByRef Array1 As Object, ByRef Array2 As Object, ByRef Array3 As Object, ByRef Array4 As Object, ByRef Array5 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer)

    Dim I As Integer, J As Integer, k As Integer, KK As Integer, F As Integer
    Dim D As Object
    k = LowerInd : KK = UpperInd : F = 1
    While (F <> 0)
      J = KK - 1 : KK = 0
      For I = k To J
        If (Array1(I) > Array1(I + 1)) Then
          D = Array1(I)
          Array1(I) = Array1(I + 1)
          Array1(I + 1) = D
          D = Array2(I)
          Array2(I) = Array2(I + 1)
          Array2(I + 1) = D
          D = Array3(I)
          Array3(I) = Array3(I + 1)
          Array3(I + 1) = D
          D = Array4(I)
          Array4(I) = Array4(I + 1)
          Array4(I + 1) = D
          D = Array5(I)
          Array5(I) = Array5(I + 1)
          Array5(I + 1) = D
          KK = I
        End If
      Next I
      If (KK = 0) Then F = 0
      J = k + 1 : k = 0
      For I = KK To J Step -1
        If (Array1(I - 1) > Array1(I)) Then
          D = Array1(I)
          Array1(I) = Array1(I - 1)
          Array1(I - 1) = D
          D = Array2(I)
          Array2(I) = Array2(I - 1)
          Array2(I - 1) = D
          D = Array3(I)
          Array3(I) = Array3(I - 1)
          Array3(I - 1) = D
          D = Array4(I)
          Array4(I) = Array4(I - 1)
          Array4(I - 1) = D
          D = Array5(I)
          Array5(I) = Array5(I - 1)
          Array5(I - 1) = D
          k = I
        End If
      Next I
      If (k = 0) Then F = 0
    End While
  End Sub



  Sub BubbleSort5ArrayD(ByRef Array1 As Object, ByRef Array2 As Object, ByRef Array3 As Object, ByRef Array4 As Object, ByRef Array5 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer)

    Dim I As Integer, J As Integer, k As Integer, KK As Integer, F As Integer
    Dim D As Object
    k = LowerInd : KK = UpperInd : F = 1
    While (F <> 0)
      J = KK - 1 : KK = 0
      For I = k To J
        If (Array1(I) < Array1(I + 1)) Then
          D = Array1(I)
          Array1(I) = Array1(I + 1)
          Array1(I + 1) = D
          D = Array2(I)
          Array2(I) = Array2(I + 1)
          Array2(I + 1) = D
          D = Array3(I)
          Array3(I) = Array3(I + 1)
          Array3(I + 1) = D
          D = Array4(I)
          Array4(I) = Array4(I + 1)
          Array4(I + 1) = D
          D = Array5(I)
          Array5(I) = Array5(I + 1)
          Array5(I + 1) = D
          KK = I
        End If
      Next I
      If (KK = 0) Then F = 0
      J = k + 1 : k = 0
      For I = KK To J Step -1
        If (Array1(I - 1) < Array1(I)) Then
          D = Array1(I)
          Array1(I) = Array1(I - 1)
          Array1(I - 1) = D
          D = Array2(I)
          Array2(I) = Array2(I - 1)
          Array2(I - 1) = D
          D = Array3(I)
          Array3(I) = Array3(I - 1)
          Array3(I - 1) = D
          D = Array4(I)
          Array4(I) = Array4(I - 1)
          Array4(I - 1) = D
          D = Array5(I)
          Array5(I) = Array5(I - 1)
          Array5(I - 1) = D
          k = I
        End If
      Next I
      If (k = 0) Then F = 0
    End While
  End Sub



  Sub BubbleSort6ArrayA(ByRef Array1 As Object, ByRef Array2 As Object, ByRef Array3 As Object, ByRef Array4 As Object, ByRef Array5 As Object, ByRef Array6 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer)

    Dim I As Integer, J As Integer, k As Integer, KK As Integer, F As Integer
    Dim D As Object
    k = LowerInd : KK = UpperInd : F = 1
    While (F <> 0)
      J = KK - 1 : KK = 0
      For I = k To J
        If (Array1(I) > Array1(I + 1)) Then
          D = Array1(I)
          Array1(I) = Array1(I + 1)
          Array1(I + 1) = D
          D = Array2(I)
          Array2(I) = Array2(I + 1)
          Array2(I + 1) = D
          D = Array3(I)
          Array3(I) = Array3(I + 1)
          Array3(I + 1) = D
          D = Array4(I)
          Array4(I) = Array4(I + 1)
          Array4(I + 1) = D
          D = Array5(I)
          Array5(I) = Array5(I + 1)
          Array5(I + 1) = D
          D = Array6(I)
          Array6(I) = Array6(I + 1)
          Array6(I + 1) = D
          KK = I
        End If
      Next I
      If (KK = 0) Then F = 0
      J = k + 1 : k = 0
      For I = KK To J Step -1
        If (Array1(I - 1) > Array1(I)) Then
          D = Array1(I)
          Array1(I) = Array1(I - 1)
          Array1(I - 1) = D
          D = Array2(I)
          Array2(I) = Array2(I - 1)
          Array2(I - 1) = D
          D = Array3(I)
          Array3(I) = Array3(I - 1)
          Array3(I - 1) = D
          D = Array4(I)
          Array4(I) = Array4(I - 1)
          Array4(I - 1) = D
          D = Array5(I)
          Array5(I) = Array5(I - 1)
          Array5(I - 1) = D
          D = Array6(I)
          Array6(I) = Array6(I - 1)
          Array6(I - 1) = D
          k = I
        End If
      Next I
      If (k = 0) Then F = 0
    End While
  End Sub



  Sub BubbleSort6ArrayD(ByRef Array1 As Object, ByRef Array2 As Object, ByRef Array3 As Object, ByRef Array4 As Object, ByRef Array5 As Object, ByRef Array6 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer)

    Dim I As Integer, J As Integer, k As Integer, KK As Integer, F As Integer
    Dim D As Object
    k = LowerInd : KK = UpperInd : F = 1
    While (F <> 0)
      J = KK - 1 : KK = 0
      For I = k To J
        If (Array1(I) < Array1(I + 1)) Then
          D = Array1(I)
          Array1(I) = Array1(I + 1)
          Array1(I + 1) = D
          D = Array2(I)
          Array2(I) = Array2(I + 1)
          Array2(I + 1) = D
          D = Array3(I)
          Array3(I) = Array3(I + 1)
          Array3(I + 1) = D
          D = Array4(I)
          Array4(I) = Array4(I + 1)
          Array4(I + 1) = D
          D = Array5(I)
          Array5(I) = Array5(I + 1)
          Array5(I + 1) = D
          D = Array6(I)
          Array6(I) = Array6(I + 1)
          Array6(I + 1) = D
          KK = I
        End If
      Next I
      If (KK = 0) Then F = 0
      J = k + 1 : k = 0
      For I = KK To J Step -1
        If (Array1(I - 1) < Array1(I)) Then
          D = Array1(I)
          Array1(I) = Array1(I - 1)
          Array1(I - 1) = D
          D = Array2(I)
          Array2(I) = Array2(I - 1)
          Array2(I - 1) = D
          D = Array3(I)
          Array3(I) = Array3(I - 1)
          Array3(I - 1) = D
          D = Array4(I)
          Array4(I) = Array4(I - 1)
          Array4(I - 1) = D
          D = Array5(I)
          Array5(I) = Array5(I - 1)
          Array5(I - 1) = D
          D = Array6(I)
          Array6(I) = Array6(I - 1)
          Array6(I - 1) = D
          k = I
        End If
      Next I
      If (k = 0) Then F = 0
    End While
  End Sub



  Sub QuickSortA(ByRef Array1 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer)

    Dim I As Integer
    If (UpperInd - LowerInd > 20) Then
      I = Split4QSortA(Array1, LowerInd, UpperInd)
      Call QuickSortA(Array1, LowerInd, I - 1)
      Call QuickSortA(Array1, I + 1, UpperInd)
    Else
      Call BubbleSortA(Array1, LowerInd, UpperInd)
    End If
  End Sub



  Sub QuickSortD(ByRef Array1 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer)

    Dim I As Integer
    If (UpperInd - LowerInd > 20) Then
      I = Split4QSortD(Array1, LowerInd, UpperInd)
      Call QuickSortD(Array1, LowerInd, I - 1)
      Call QuickSortD(Array1, I + 1, UpperInd)
    Else
      Call BubbleSortD(Array1, LowerInd, UpperInd)
    End If
  End Sub


  'Sort an array and the associated matrix

  Sub QuickSortArrayMatA(ByRef ArrayX As Object, ByRef YMat As Object, ByVal NumDV As Integer, ByVal LowerInd As Integer, ByVal UpperInd As Integer)

    Dim I As Integer
    If (UpperInd - LowerInd > 20) Then
      I = Split4QSortArrayMatA(ArrayX, YMat, NumDV, LowerInd, UpperInd)
      Call QuickSortArrayMatA(ArrayX, YMat, NumDV, LowerInd, I - 1)
      Call QuickSortArrayMatA(ArrayX, YMat, NumDV, I + 1, UpperInd)
    Else
      Call BubbleSortArrayMatA(ArrayX, YMat, NumDV, LowerInd, UpperInd)
    End If
  End Sub




  Sub QuickSort2ArrayA(ByRef Array1 As Object, ByRef Array2 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer)

    Dim I As Integer
    If (UpperInd - LowerInd > 20) Then
      I = Split4QSort2A(Array1, Array2, LowerInd, UpperInd)
      Call QuickSort2ArrayA(Array1, Array2, LowerInd, I - 1)
      Call QuickSort2ArrayA(Array1, Array2, I + 1, UpperInd)
    Else
      Call BubbleSort2ArrayA(Array1, Array2, LowerInd, UpperInd)
    End If
  End Sub



  Sub QuickSort2ArrayD(ByRef Array1 As Object, ByRef Array2 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer)

    Dim I As Integer
    If (UpperInd - LowerInd > 20) Then
      I = Split4QSort2D(Array1, Array2, LowerInd, UpperInd)
      Call QuickSort2ArrayD(Array1, Array2, LowerInd, I - 1)
      Call QuickSort2ArrayD(Array1, Array2, I + 1, UpperInd)
    Else
      Call BubbleSort2ArrayD(Array1, Array2, LowerInd, UpperInd)
    End If
  End Sub



  Sub QuickSort3ArrayA(ByRef Array1 As Object, ByRef Array2 As Object, ByRef Array3 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer)

    Dim I As Integer
    If (UpperInd - LowerInd > 20) Then
      I = Split4QSort3A(Array1, Array2, Array3, LowerInd, UpperInd)
      Call QuickSort3ArrayA(Array1, Array2, Array3, LowerInd, I - 1)
      Call QuickSort3ArrayA(Array1, Array2, Array3, I + 1, UpperInd)
    Else
      Call BubbleSort3ArrayA(Array1, Array2, Array3, LowerInd, UpperInd)
    End If
  End Sub



  Sub QuickSort3ArrayD(ByRef Array1 As Object, ByRef Array2 As Object, ByRef Array3 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer)

    Dim I As Integer
    If (UpperInd - LowerInd > 20) Then
      I = Split4QSort3D(Array1, Array2, Array3, LowerInd, UpperInd)
      Call QuickSort3ArrayD(Array1, Array2, Array3, LowerInd, I - 1)
      Call QuickSort3ArrayD(Array1, Array2, Array3, I + 1, UpperInd)
    Else
      Call BubbleSort3ArrayD(Array1, Array2, Array3, LowerInd, UpperInd)
    End If
  End Sub




  Sub QuickSort4ArrayA(ByRef Array1 As Object, ByRef Array2 As Object, ByRef Array3 As Object, ByRef Array4 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer)

    Dim I As Integer
    If (UpperInd - LowerInd > 20) Then
      I = Split4QSort4A(Array1, Array2, Array3, Array4, LowerInd, UpperInd)
      Call QuickSort4ArrayA(Array1, Array2, Array3, Array4, LowerInd, I - 1)
      Call QuickSort4ArrayA(Array1, Array2, Array3, Array4, I + 1, UpperInd)
    Else
      Call BubbleSort4ArrayA(Array1, Array2, Array3, Array4, LowerInd, UpperInd)
    End If
  End Sub



  Sub QuickSort4ArrayD(ByRef Array1 As Object, ByRef Array2 As Object, ByRef Array3 As Object, ByRef Array4 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer)

    Dim I As Integer
    If (UpperInd - LowerInd > 20) Then
      I = Split4QSort4D(Array1, Array2, Array3, Array4, LowerInd, UpperInd)
      Call QuickSort4ArrayD(Array1, Array2, Array3, Array4, LowerInd, I - 1)
      Call QuickSort4ArrayD(Array1, Array2, Array3, Array4, I + 1, UpperInd)
    Else
      Call BubbleSort4ArrayD(Array1, Array2, Array3, Array4, LowerInd, UpperInd)
    End If
  End Sub




  Sub QuickSort5ArrayA(ByRef Array1 As Object, ByRef Array2 As Object, ByRef Array3 As Object, ByRef Array4 As Object, ByRef Array5 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer)

    Dim I As Integer
    If (UpperInd - LowerInd > 20) Then
      I = Split4QSort5A(Array1, Array2, Array3, Array4, Array5, LowerInd, UpperInd)
      Call QuickSort5ArrayA(Array1, Array2, Array3, Array4, Array5, LowerInd, I - 1)
      Call QuickSort5ArrayA(Array1, Array2, Array3, Array4, Array5, I + 1, UpperInd)
    Else
      Call BubbleSort5ArrayA(Array1, Array2, Array3, Array4, Array5, LowerInd, UpperInd)
    End If
  End Sub



  Sub QuickSort5ArrayD(ByRef Array1 As Object, ByRef Array2 As Object, ByRef Array3 As Object, ByRef Array4 As Object, ByRef Array5 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer)

    Dim I As Integer
    If (UpperInd - LowerInd > 20) Then
      I = Split4QSort5D(Array1, Array2, Array3, Array4, Array5, LowerInd, UpperInd)
      Call QuickSort5ArrayD(Array1, Array2, Array3, Array4, Array5, LowerInd, I - 1)
      Call QuickSort5ArrayD(Array1, Array2, Array3, Array4, Array5, I + 1, UpperInd)
    Else
      Call BubbleSort5ArrayD(Array1, Array2, Array3, Array4, Array5, LowerInd, UpperInd)
    End If
  End Sub



  Sub QuickSort6ArrayA(ByRef Array1 As Object, ByRef Array2 As Object, ByRef Array3 As Object, ByRef Array4 As Object, ByRef Array5 As Object, ByRef Array6 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer)

    Dim I As Integer
    If (UpperInd - LowerInd > 20) Then
      I = Split4QSort6A(Array1, Array2, Array3, Array4, Array5, Array6, LowerInd, UpperInd)
      Call QuickSort6ArrayA(Array1, Array2, Array3, Array4, Array5, Array6, LowerInd, I - 1)
      Call QuickSort6ArrayA(Array1, Array2, Array3, Array4, Array5, Array6, I + 1, UpperInd)
    Else
      Call BubbleSort6ArrayA(Array1, Array2, Array3, Array4, Array5, Array6, LowerInd, UpperInd)
    End If
  End Sub



  Sub QuickSort6ArrayD(ByRef Array1 As Object, ByRef Array2 As Object, ByRef Array3 As Object, ByRef Array4 As Object, ByRef Array5 As Object, ByRef Array6 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer)

    Dim I As Integer
    If (UpperInd - LowerInd > 20) Then
      I = Split4QSort6D(Array1, Array2, Array3, Array4, Array5, Array6, LowerInd, UpperInd)
      Call QuickSort6ArrayD(Array1, Array2, Array3, Array4, Array5, Array6, LowerInd, I - 1)
      Call QuickSort6ArrayD(Array1, Array2, Array3, Array4, Array5, Array6, I + 1, UpperInd)
    Else
      Call BubbleSort6ArrayD(Array1, Array2, Array3, Array4, Array5, Array6, LowerInd, UpperInd)
    End If
  End Sub




  Private Function Split4QSortA(ByRef Array1 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer) As Integer

    Dim I As Integer, J As Integer, k As Integer, L As Integer
    Dim T As Object
    I = LowerInd : J = UpperInd : k = (I + J) / 2
    If ((Array1(I) >= Array1(J)) And (Array1(J) >= Array1(k))) Then
      L = J
    ElseIf ((Array1(I) >= Array1(k)) And (Array1(k) >= Array1(J))) Then
      L = k
    Else
      L = I
    End If
    T = Array1(L) : Array1(L) = Array1(I)
    While (I <> J)
      While ((I < J) And (Array1(J) >= T))
        J = J - 1
      End While
      If (I < J) Then
        Array1(I) = Array1(J) : I = I + 1
        While ((I < J) And (Array1(I) <= T))
          I = I + 1
        End While
        If (I < J) Then
          Array1(J) = Array1(I) : J = J - 1
        End If
      End If
    End While
    Array1(I) = T : Split4QSortA = I
  End Function


  'NumDV = NumCol in YMat

  Private Function Split4QSortArrayMatA(ByRef ArrayX As Object, ByRef YMat As Object, ByVal NumDV As Integer, ByVal LowerInd As Integer, ByVal UpperInd As Integer) As Integer

    Dim I As Integer, J As Integer, k As Integer, L As Integer
    Dim T As Object, T2() As Object
    ReDim T2(NumDV - 1)

    I = LowerInd : J = UpperInd : k = (I + J) / 2
    If ((ArrayX(I) >= ArrayX(J)) And (ArrayX(J) >= ArrayX(k))) Then
      L = J
    ElseIf ((ArrayX(I) >= ArrayX(k)) And (ArrayX(k) >= ArrayX(J))) Then
      L = k
    Else
      L = I
    End If
    T = ArrayX(L) : ArrayX(L) = ArrayX(I)
    For k = 0 To NumDV - 1
      T2(k) = YMat(L, k) : YMat(L, k) = YMat(I, k)
    Next k
    While (I <> J)
      While ((I < J) And (ArrayX(J) >= T))
        J = J - 1
      End While
      If (I < J) Then
        ArrayX(I) = ArrayX(J)

        For k = 0 To NumDV - 1
          YMat(I, k) = YMat(J, k)
        Next k
        I = I + 1
        While ((I < J) And (ArrayX(I) <= T))
          I = I + 1
        End While
        If (I < J) Then
          ArrayX(J) = ArrayX(I)

          For k = 0 To NumDV - 1
            YMat(J, k) = YMat(I, k)
          Next k
          J = J - 1
        End If
      End If
    End While
    ArrayX(I) = T

    For k = 0 To NumDV - 1
      YMat(I, k) = T2(k)
    Next k
    Split4QSortArrayMatA = I
  End Function



  Private Function Split4QSort2A(ByRef Array1 As Object, ByRef Array2 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer) As Integer

    Dim I As Integer, J As Integer, k As Integer, L As Integer
    Dim T As Object, T2 As Object
    I = LowerInd : J = UpperInd : k = (I + J) / 2
    If ((Array1(I) >= Array1(J)) And (Array1(J) >= Array1(k))) Then
      L = J
    ElseIf ((Array1(I) >= Array1(k)) And (Array1(k) >= Array1(J))) Then
      L = k
    Else
      L = I
    End If
    T = Array1(L) : Array1(L) = Array1(I)
    T2 = Array2(L) : Array2(L) = Array2(I)
    While (I <> J)
      While ((I < J) And (Array1(J) >= T))
        J = J - 1
      End While
      If (I < J) Then
        Array1(I) = Array1(J)
        Array2(I) = Array2(J)
        I = I + 1
        While ((I < J) And (Array1(I) <= T))
          I = I + 1
        End While
        If (I < J) Then
          Array1(J) = Array1(I)
          Array2(J) = Array2(I)
          J = J - 1
        End If
      End If
    End While
    Array1(I) = T
    Array2(I) = T2
    Split4QSort2A = I
  End Function




  Private Function Split4QSort3A(ByRef Array1 As Object, ByRef Array2 As Object, ByRef Array3 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer) As Integer

    Dim I As Integer, J As Integer, k As Integer, L As Integer
    Dim T As Object, T2 As Object, T3 As Object
    I = LowerInd : J = UpperInd : k = (I + J) / 2
    If ((Array1(I) >= Array1(J)) And (Array1(J) >= Array1(k))) Then
      L = J
    ElseIf ((Array1(I) >= Array1(k)) And (Array1(k) >= Array1(J))) Then
      L = k
    Else
      L = I
    End If
    T = Array1(L) : Array1(L) = Array1(I)
    T2 = Array2(L) : Array2(L) = Array2(I)
    T3 = Array3(L) : Array3(L) = Array3(I)
    While (I <> J)
      While ((I < J) And (Array1(J) >= T))
        J = J - 1
      End While
      If (I < J) Then
        Array1(I) = Array1(J)
        Array2(I) = Array2(J)
        Array3(I) = Array3(J)
        I = I + 1
        While ((I < J) And (Array1(I) <= T))
          I = I + 1
        End While
        If (I < J) Then
          Array1(J) = Array1(I)
          Array2(J) = Array2(I)
          Array3(J) = Array3(I)
          J = J - 1
        End If
      End If
    End While
    Array1(I) = T
    Array2(I) = T2
    Array3(I) = T3
    Split4QSort3A = I
  End Function



  Private Function Split4QSort4A(ByRef Array1 As Object, ByRef Array2 As Object, ByRef Array3 As Object, ByRef Array4 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer) As Integer

    Dim I As Integer, J As Integer, k As Integer, L As Integer
    Dim T As Object, T2 As Object, T3 As Object, T4 As Object
    I = LowerInd : J = UpperInd : k = (I + J) / 2
    If ((Array1(I) >= Array1(J)) And (Array1(J) >= Array1(k))) Then
      L = J
    ElseIf ((Array1(I) >= Array1(k)) And (Array1(k) >= Array1(J))) Then
      L = k
    Else
      L = I
    End If
    T = Array1(L) : Array1(L) = Array1(I)
    T2 = Array2(L) : Array2(L) = Array2(I)
    T3 = Array3(L) : Array3(L) = Array3(I)
    T4 = Array4(L) : Array4(L) = Array4(I)
    While (I <> J)
      While ((I < J) And (Array1(J) >= T))
        J = J - 1
      End While
      If (I < J) Then
        Array1(I) = Array1(J)
        Array2(I) = Array2(J)
        Array3(I) = Array3(J)
        Array4(I) = Array4(J)
        I = I + 1
        While ((I < J) And (Array1(I) <= T))
          I = I + 1
        End While
        If (I < J) Then
          Array1(J) = Array1(I)
          Array2(J) = Array2(I)
          Array3(J) = Array3(I)
          Array4(J) = Array4(I)
          J = J - 1
        End If
      End If
    End While
    Array1(I) = T
    Array2(I) = T2
    Array3(I) = T3
    Array4(I) = T4
    Split4QSort4A = I
  End Function



  Private Function Split4QSort5A(ByRef Array1 As Object, ByRef Array2 As Object, ByRef Array3 As Object, ByRef Array4 As Object, ByRef Array5 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer) As Integer

    Dim I As Integer, J As Integer, k As Integer, L As Integer
    Dim T As Object, T2 As Object, T3 As Object, T4 As Object, T5 As Object
    I = LowerInd : J = UpperInd : k = (I + J) / 2
    If ((Array1(I) >= Array1(J)) And (Array1(J) >= Array1(k))) Then
      L = J
    ElseIf ((Array1(I) >= Array1(k)) And (Array1(k) >= Array1(J))) Then
      L = k
    Else
      L = I
    End If
    T = Array1(L) : Array1(L) = Array1(I)
    T2 = Array2(L) : Array2(L) = Array2(I)
    T3 = Array3(L) : Array3(L) = Array3(I)
    T4 = Array4(L) : Array4(L) = Array4(I)
    T5 = Array5(L) : Array5(L) = Array5(I)
    While (I <> J)
      While ((I < J) And (Array1(J) >= T))
        J = J - 1
      End While
      If (I < J) Then
        Array1(I) = Array1(J)
        Array2(I) = Array2(J)
        Array3(I) = Array3(J)
        Array4(I) = Array4(J)
        Array5(I) = Array5(J)
        I = I + 1
        While ((I < J) And (Array1(I) <= T))
          I = I + 1
        End While
        If (I < J) Then
          Array1(J) = Array1(I)
          Array2(J) = Array2(I)
          Array3(J) = Array3(I)
          Array4(J) = Array4(I)
          Array5(J) = Array5(I)
          J = J - 1
        End If
      End If
    End While
    Array1(I) = T
    Array2(I) = T2
    Array3(I) = T3
    Array4(I) = T4
    Array5(I) = T5
    Split4QSort5A = I
  End Function



  Private Function Split4QSort6A(ByRef Array1 As Object, ByRef Array2 As Object, ByRef Array3 As Object, ByRef Array4 As Object, ByRef Array5 As Object, ByRef Array6 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer) As Integer

    Dim I As Integer, J As Integer, k As Integer, L As Integer
    Dim T As Object, T2 As Object, T3 As Object, T4 As Object, T5 As Object, T6 As Object
    I = LowerInd : J = UpperInd : k = (I + J) / 2
    If ((Array1(I) >= Array1(J)) And (Array1(J) >= Array1(k))) Then
      L = J
    ElseIf ((Array1(I) >= Array1(k)) And (Array1(k) >= Array1(J))) Then
      L = k
    Else
      L = I
    End If
    T = Array1(L) : Array1(L) = Array1(I)
    T2 = Array2(L) : Array2(L) = Array2(I)
    T3 = Array3(L) : Array3(L) = Array3(I)
    T4 = Array4(L) : Array4(L) = Array4(I)
    T5 = Array5(L) : Array5(L) = Array5(I)
    T6 = Array6(L) : Array6(L) = Array6(I)
    While (I <> J)
      While ((I < J) And (Array1(J) >= T))
        J = J - 1
      End While
      If (I < J) Then
        Array1(I) = Array1(J)
        Array2(I) = Array2(J)
        Array3(I) = Array3(J)
        Array4(I) = Array4(J)
        Array5(I) = Array5(J)
        Array6(I) = Array6(J)
        I = I + 1
        While ((I < J) And (Array1(I) <= T))
          I = I + 1
        End While
        If (I < J) Then
          Array1(J) = Array1(I)
          Array2(J) = Array2(I)
          Array3(J) = Array3(I)
          Array4(J) = Array4(I)
          Array5(J) = Array5(I)
          Array6(J) = Array6(I)
          J = J - 1
        End If
      End If
    End While
    Array1(I) = T
    Array2(I) = T2
    Array3(I) = T3
    Array4(I) = T4
    Array5(I) = T5
    Array6(I) = T6
    Split4QSort6A = I
  End Function



  Private Function Split4QSortD(ByRef Array1 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer) As Integer

    Dim I As Integer, J As Integer, k As Integer, L As Integer
    Dim T As Object
    I = LowerInd : J = UpperInd : k = (I + J) / 2
    If ((Array1(I) <= Array1(J)) And (Array1(J) <= Array1(k))) Then
      L = J
    ElseIf ((Array1(I) <= Array1(k)) And (Array1(k) <= Array1(J))) Then
      L = k
    Else
      L = I
    End If
    T = Array1(L) : Array1(L) = Array1(I)
    While (I <> J)
      While ((I < J) And (Array1(J) <= T))
        J = J - 1
      End While
      If (I < J) Then
        Array1(I) = Array1(J) : I = I + 1
        While ((I < J) And (Array1(I) >= T))
          I = I + 1
        End While
        If (I < J) Then
          Array1(J) = Array1(I) : J = J - 1
        End If
      End If
    End While
    Array1(I) = T : Split4QSortD = I
  End Function



  Private Function Split4QSort2D(ByRef Array1 As Object, ByRef Array2 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer) As Integer

    Dim I As Integer, J As Integer, k As Integer, L As Integer
    Dim T As Object, T2 As Object
    I = LowerInd : J = UpperInd : k = (I + J) / 2
    If ((Array1(I) <= Array1(J)) And (Array1(J) <= Array1(k))) Then
      L = J
    ElseIf ((Array1(I) <= Array1(k)) And (Array1(k) <= Array1(J))) Then
      L = k
    Else
      L = I
    End If
    T = Array1(L) : Array1(L) = Array1(I)
    T2 = Array2(L) : Array2(L) = Array2(I)
    While (I <> J)
      While ((I < J) And (Array1(J) <= T))
        J = J - 1
      End While
      If (I < J) Then
        Array1(I) = Array1(J)
        Array2(I) = Array2(J)
        I = I + 1
        While ((I < J) And (Array1(I) >= T))
          I = I + 1
        End While
        If (I < J) Then
          Array1(J) = Array1(I)
          Array2(J) = Array2(I)
          J = J - 1
        End If
      End If
    End While
    Array1(I) = T
    Array2(I) = T2
    Split4QSort2D = I
  End Function



  Private Function Split4QSort3D(ByRef Array1 As Object, ByRef Array2 As Object, ByRef Array3 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer) As Integer

    Dim I As Integer, J As Integer, k As Integer, L As Integer
    Dim T As Object, T2 As Object, T3 As Object
    I = LowerInd : J = UpperInd : k = (I + J) / 2
    If ((Array1(I) <= Array1(J)) And (Array1(J) <= Array1(k))) Then
      L = J
    ElseIf ((Array1(I) <= Array1(k)) And (Array1(k) <= Array1(J))) Then
      L = k
    Else
      L = I
    End If
    T = Array1(L) : Array1(L) = Array1(I)
    T2 = Array2(L) : Array2(L) = Array2(I)
    T3 = Array3(L) : Array3(L) = Array3(I)
    While (I <> J)
      While ((I < J) And (Array1(J) <= T))
        J = J - 1
      End While
      If (I < J) Then
        Array1(I) = Array1(J)
        Array2(I) = Array2(J)
        Array3(I) = Array3(J)
        I = I + 1
        While ((I < J) And (Array1(I) >= T))
          I = I + 1
        End While
        If (I < J) Then
          Array1(J) = Array1(I)
          Array2(J) = Array2(I)
          Array3(J) = Array3(I)
          J = J - 1
        End If
      End If
    End While
    Array1(I) = T
    Array2(I) = T2
    Array3(I) = T3
    Split4QSort3D = I
  End Function



  Private Function Split4QSort4D(ByRef Array1 As Object, ByRef Array2 As Object, ByRef Array3 As Object, ByRef Array4 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer) As Integer

    Dim I As Integer, J As Integer, k As Integer, L As Integer
    Dim T As Object, T2 As Object, T3 As Object, T4 As Object
    I = LowerInd : J = UpperInd : k = (I + J) / 2
    If ((Array1(I) <= Array1(J)) And (Array1(J) <= Array1(k))) Then
      L = J
    ElseIf ((Array1(I) <= Array1(k)) And (Array1(k) <= Array1(J))) Then
      L = k
    Else
      L = I
    End If
    T = Array1(L) : Array1(L) = Array1(I)
    T2 = Array2(L) : Array2(L) = Array2(I)
    T3 = Array3(L) : Array3(L) = Array3(I)
    T4 = Array4(L) : Array4(L) = Array4(I)
    While (I <> J)
      While ((I < J) And (Array1(J) <= T))
        J = J - 1
      End While
      If (I < J) Then
        Array1(I) = Array1(J)
        Array2(I) = Array2(J)
        Array3(I) = Array3(J)
        Array4(I) = Array4(J)
        I = I + 1
        While ((I < J) And (Array1(I) >= T))
          I = I + 1
        End While
        If (I < J) Then
          Array1(J) = Array1(I)
          Array2(J) = Array2(I)
          Array3(J) = Array3(I)
          Array4(J) = Array4(I)
          J = J - 1
        End If
      End If
    End While
    Array1(I) = T
    Array2(I) = T2
    Array3(I) = T3
    Array4(I) = T4
    Split4QSort4D = I
  End Function



  Private Function Split4QSort5D(ByRef Array1 As Object, ByRef Array2 As Object, ByRef Array3 As Object, ByRef Array4 As Object, ByRef Array5 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer) As Integer

    Dim I As Integer, J As Integer, k As Integer, L As Integer
    Dim T As Object, T2 As Object, T3 As Object, T4 As Object, T5 As Object
    I = LowerInd : J = UpperInd : k = (I + J) / 2
    If ((Array1(I) <= Array1(J)) And (Array1(J) <= Array1(k))) Then
      L = J
    ElseIf ((Array1(I) <= Array1(k)) And (Array1(k) <= Array1(J))) Then
      L = k
    Else
      L = I
    End If
    T = Array1(L) : Array1(L) = Array1(I)
    T2 = Array2(L) : Array2(L) = Array2(I)
    T3 = Array3(L) : Array3(L) = Array3(I)
    T4 = Array4(L) : Array4(L) = Array4(I)
    T5 = Array5(L) : Array5(L) = Array5(I)
    While (I <> J)
      While ((I < J) And (Array1(J) <= T))
        J = J - 1
      End While
      If (I < J) Then
        Array1(I) = Array1(J)
        Array2(I) = Array2(J)
        Array3(I) = Array3(J)
        Array4(I) = Array4(J)
        Array5(I) = Array5(J)
        I = I + 1
        While ((I < J) And (Array1(I) >= T))
          I = I + 1
        End While
        If (I < J) Then
          Array1(J) = Array1(I)
          Array2(J) = Array2(I)
          Array3(J) = Array3(I)
          Array4(J) = Array4(I)
          Array5(J) = Array5(I)
          J = J - 1
        End If
      End If
    End While
    Array1(I) = T
    Array2(I) = T2
    Array3(I) = T3
    Array4(I) = T4
    Array5(I) = T5
    Split4QSort5D = I
  End Function



  Private Function Split4QSort6D(ByRef Array1 As Object, ByRef Array2 As Object, ByRef Array3 As Object, ByRef Array4 As Object, ByRef Array5 As Object, ByRef Array6 As Object, ByVal LowerInd As Integer, ByVal UpperInd As Integer) As Integer

    Dim I As Integer, J As Integer, k As Integer, L As Integer
    Dim T As Object, T2 As Object, T3 As Object, T4 As Object, T5 As Object, T6 As Object
    I = LowerInd : J = UpperInd : k = (I + J) / 2
    If ((Array1(I) <= Array1(J)) And (Array1(J) <= Array1(k))) Then
      L = J
    ElseIf ((Array1(I) <= Array1(k)) And (Array1(k) <= Array1(J))) Then
      L = k
    Else
      L = I
    End If
    T = Array1(L) : Array1(L) = Array1(I)
    T2 = Array2(L) : Array2(L) = Array2(I)
    T3 = Array3(L) : Array3(L) = Array3(I)
    T4 = Array4(L) : Array4(L) = Array4(I)
    T5 = Array5(L) : Array5(L) = Array5(I)
    T6 = Array6(L) : Array6(L) = Array6(I)
    While (I <> J)
      While ((I < J) And (Array1(J) <= T))
        J = J - 1
      End While
      If (I < J) Then
        Array1(I) = Array1(J)
        Array2(I) = Array2(J)
        Array3(I) = Array3(J)
        Array4(I) = Array4(J)
        Array5(I) = Array5(J)
        Array6(I) = Array6(J)
        I = I + 1
        While ((I < J) And (Array1(I) >= T))
          I = I + 1
        End While
        If (I < J) Then
          Array1(J) = Array1(I)
          Array2(J) = Array2(I)
          Array3(J) = Array3(I)
          Array4(J) = Array4(I)
          Array5(J) = Array5(I)
          Array6(J) = Array6(I)
          J = J - 1
        End If
      End If
    End While
    Array1(I) = T
    Array2(I) = T2
    Array3(I) = T3
    Array4(I) = T4
    Array5(I) = T5
    Array6(I) = T6
    Split4QSort6D = I
  End Function




  Sub FindInSortedStrArray(ByRef SortedStrArray() As String, ByVal N As Integer, ByRef LowerStrBound As String, ByRef UpperStrBound As String, ByRef NumFound As Integer, ByRef LowerInd As Integer)



    Dim I As Integer, J As Integer, k As Integer, L As Integer
    I = 1
    J = N
    Do While (I <= J)
      k = Int((I + J) / 2)
      If SortedStrArray(k - 1) >= LowerStrBound Then
        If SortedStrArray(k - 1) <= UpperStrBound Then
          I = k - 1
          J = 0
          For L = I To 0 Step -1
            If SortedStrArray(I) < LowerStrBound Then
              LowerInd = L + 1
              Exit For
            Else
              J = J + 1
            End If
          Next L

          I = I + 1
          For L = k To N - 1
            If SortedStrArray(k) > UpperStrBound Then
              Exit For
            Else
              J = J + 1
            End If
          Next L
          NumFound = J
          Exit Sub
        End If
      End If
      If (SortedStrArray(k - 1) > UpperStrBound) Then
        J = k - 1
      Else
        I = k + 1
      End If
    Loop
  End Sub



  Function FindOneInSortedStrArray(ByRef P As Object, ByRef N As Integer, ByRef SearchItem As String, Optional ByVal StartInd As Integer = 0) As Integer




    Dim I As Integer, J As Integer, k As Integer
    I = StartInd
    J = N - 1
    Do While (I <= J)
      k = Int((I + J) / 2)
      If P(k) = SearchItem Then
        FindOneInSortedStrArray = k
        Exit Function
      End If
      If (P(k) > SearchItem) Then
        J = k - 1
      Else
        I = k + 1
      End If
    Loop

    FindOneInSortedStrArray = N
  End Function




  Sub FindInSortedNumArray(ByRef InArray As Object, ByVal N As Integer, ByVal MinVal As Double, ByVal MaxVal As Double, ByRef NumFound As Integer, ByRef LowerInd As Integer)


    Dim I As Integer, J As Integer, k As Integer

    I = 1
    J = N
    Do While (I <= J)
      k = Int((I + J) / 2)
      If (InArray(k - 1) >= MinVal) Then
        If (InArray(k - 1) <= MaxVal) Then
          I = k - 1
          J = 0
          For L = I To 0 Step -1
            If InArray(L) < MinVal Then
              LowerInd = L + 1
              Exit For
            Else
              J = J + 1
            End If
          Next L
          I = I + 1
          For L = k To N - 1
            If InArray(L) > MaxVal Then
              Exit For
            Else
              J = J + 1
            End If
          Next L
          NumFound = J
          Exit Sub
        End If
      End If
      If (InArray(k - 1) > MaxVal) Then
        J = k - 1
      Else
        I = k + 1
      End If
    Loop
  End Sub



  'Return N if not found,minimum StartAt is 1.

  Function FindOneInSortedNumArray(ByRef InArray As Object, ByVal N As Integer, ByVal FindVal As Object, Optional ByVal StartAt As Integer = 1) As Integer


    Dim I As Integer, J As Integer, k As Integer
    I = StartAt
    J = N
    Do While (I <= J)
      k = Int((I + J) / 2)
      If InArray(k - 1) = FindVal Then
        FindOneInSortedNumArray = k - 1
        Exit Function
      ElseIf (InArray(k - 1) > FindVal) Then
        J = k - 1
      Else
        I = k + 1
      End If
    Loop

    FindOneInSortedNumArray = N
  End Function


  'Given a ascending-sorted numeric array and a number (FindVal),find FindVal in the array and return its index. If
  '  FindVal is not found,return the index of the largest number than is smaller than FindVal

  Function IndinSortedNumArray(ByRef InArray As Object, ByVal N As Integer, ByVal FindVal As Object, Optional ByVal StartAt As Integer = 1) As Integer


    Dim I As Integer, J As Integer, k As Integer
    I = StartAt
    J = N
    Do While (I <= J)
      k = Int((I + J) / 2)
      If InArray(k - 1) = FindVal Then
        IndinSortedNumArray = k - 1
        Exit Function
      ElseIf (InArray(k - 1) > FindVal) Then
        J = k - 1
      Else
        I = k + 1
      End If
    Loop

    IndinSortedNumArray = J
  End Function



  Sub ShellSortA(ByRef InArray As Object, ByRef LowerIndex As Integer, ByRef UpperIndex As Integer)


    Dim I As Integer, J As Integer, k As Integer
    Dim T As Object
    k = Int((UpperIndex - LowerIndex + 1) / 2)
    Do While (k > 0)
      For J = k To UpperIndex - LowerIndex
        T = InArray(J + LowerIndex)
        I = J - k
        Do While (I >= 0)
          If InArray(I + LowerIndex) <= T Then
            Exit Do
          End If
          InArray(I + k + LowerIndex) = InArray(I + LowerIndex) : I = I - k
        Loop
        InArray(I + k + LowerIndex) = T
      Next J
      k = Int(k / 2)
    Loop
  End Sub



  Sub ShellSortD(ByRef InArray As Object, ByRef LowerIndex As Integer, ByRef UpperIndex As Integer)


    Dim I As Integer, J As Integer, k As Integer
    Dim T As Object
    k = Int((UpperIndex - LowerIndex + 1) / 2)
    Do While (k > 0)
      For J = k To UpperIndex - LowerIndex
        T = InArray(J + LowerIndex)
        I = J - k
        Do While (I >= 0)

          If InArray(I + LowerIndex) > T Then
            Exit Do
          End If
          InArray(I + k + LowerIndex) = InArray(I + LowerIndex) : I = I - k
        Loop
        InArray(I + k + LowerIndex) = T
      Next J
      k = Int(k / 2)
    Loop
  End Sub




  Sub ShellSortStr(ByRef sArray() As String, ByRef LowerIndex As Integer, ByRef UpperIndex As Integer)


    Dim I As Integer, J As Integer, k As Integer
    Dim T As String
    k = Int((UpperIndex - LowerIndex + 1) / 2)
    Do While (k > 0)
      For J = k To UpperIndex - LowerIndex
        T = sArray(J + LowerIndex)
        I = J - k
        Do While (I >= 0)
          If sArray(I + LowerIndex) <= T Then
            Exit Do
          End If
          sArray(I + k + LowerIndex) = sArray(I + LowerIndex) : I = I - k
        Loop
        sArray(I + k + LowerIndex) = T
      Next J
      k = Int(k / 2)
    Loop
  End Sub



  Sub ShellSortStrArrayWithLngArray(ByRef sArray() As String, ByRef LowerIndex As Integer, ByRef UpperIndex As Integer, ByRef lArray() As Integer)


    Dim I As Integer, J As Integer, k As Integer
    Dim T As String, L As Integer
    k = Int((UpperIndex - LowerIndex + 1) / 2)
    Do While (k > 0)
      For J = k To UpperIndex - LowerIndex
        T = sArray(J + LowerIndex)
        L = lArray(J + LowerIndex)
        I = J - k
        Do While (I >= 0)
          If sArray(I + LowerIndex) <= T Then
            Exit Do
          End If
          sArray(I + k + LowerIndex) = sArray(I + LowerIndex)
          lArray(I + k + LowerIndex) = lArray(I + LowerIndex)
          I = I - k
        Loop
        sArray(I + k + LowerIndex) = T
        lArray(I + k + LowerIndex) = L
      Next J
      k = Int(k / 2)
    Loop
  End Sub



  Sub ShellSortStrArrayWithLngMat(ByRef sArray() As String, ByRef LowerIndex As Integer, ByRef UpperIndex As Integer, ByRef InMat(,) As Integer, ByRef NumCol As Integer)


    Dim I As Integer, J As Integer, k As Integer, II As Integer
    Dim T As String, OneRow() As Integer
    ReDim OneRow(NumCol - 1)
    k = Int((UpperIndex - LowerIndex + 1) / 2)
    Do While (k > 0)
      For J = k To UpperIndex - LowerIndex
        T = sArray(J + LowerIndex)
        For II = 0 To NumCol - 1
          OneRow(II) = InMat(J + LowerIndex, II)
        Next II
        I = J - k
        Do While (I >= 0)
          If (sArray(I + LowerIndex) <= T) Then Exit Do
          sArray(I + k + LowerIndex) = sArray(I + LowerIndex)
          For II = 0 To NumCol - 1
            InMat(I + k + LowerIndex, II) = InMat(I + LowerIndex, II)
          Next II
          I = I - k
        Loop
        sArray(I + k + LowerIndex) = T
        For II = 0 To NumCol - 1
          InMat(I + k + LowerIndex, II) = OneRow(II)
        Next II
      Next J
      k = Int(k / 2)
    Loop
  End Sub



  Sub ShellSortStrArrayWithLngMatT(ByRef sArray() As String, ByRef LowerIndex As Integer, ByRef UpperIndex As Integer, ByRef InMat(,) As Integer, ByRef NumCol As Integer)



    Dim I As Integer, J As Integer, k As Integer, II As Integer
    Dim T As String, OneRow() As Integer
    ReDim OneRow(NumCol - 1)
    k = Int((UpperIndex - LowerIndex + 1) / 2)
    Do While (k > 0)
      For J = k To UpperIndex - LowerIndex
        T = sArray(J + LowerIndex)
        For II = 0 To NumCol - 1
          OneRow(II) = InMat(II, J + LowerIndex)
        Next II
        I = J - k
        Do While (I >= 0)
          If (sArray(I + LowerIndex) <= T) Then Exit Do
          sArray(I + k + LowerIndex) = sArray(I + LowerIndex)
          For II = 0 To NumCol - 1
            InMat(II, I + k + LowerIndex) = InMat(II, I + LowerIndex)
          Next II
          I = I - k
        Loop
        sArray(I + k + LowerIndex) = T
        For II = 0 To NumCol - 1
          InMat(II, I + k + LowerIndex) = OneRow(II)
        Next II
      Next J
      k = Int(k / 2)
    Loop
  End Sub


  'Sort Array1 together with Array2 and then sort values in Array2 with the same Array1 value

  Sub Sort2Array2Criteria(ByRef Array1 As Object, ByRef Array2 As Object, ByVal N As Integer)

    Dim I As Integer, J As Integer, StartInd As Integer
    Dim SubArray2 As Object
    Dim SubArray2MaxInd As Integer

    Call QuickSort2ArrayA(Array1, Array2, 0, N - 1)

    StartInd = 0
    For I = 1 To N - 1
      If Array1(I) <> Array1(StartInd) Then
        SubArray2MaxInd = I - StartInd - 1
        ReDim SubArray2(SubArray2MaxInd)
        For J = 0 To SubArray2MaxInd
          SubArray2(J) = Array2(StartInd + J)
        Next J
        Call BubbleSortA(SubArray2, 0, SubArray2MaxInd)
        For J = 0 To SubArray2MaxInd
          Array2(StartInd + J) = SubArray2(J)
        Next J
        StartInd = I
      End If
    Next I

    SubArray2MaxInd = I - StartInd - 1
    ReDim SubArray2(SubArray2MaxInd)
    For J = 0 To SubArray2MaxInd
      SubArray2(J) = Array2(StartInd + J)
    Next J
    Call BubbleSortA(SubArray2, 0, SubArray2MaxInd)
    For J = 0 To SubArray2MaxInd
      Array2(StartInd + J) = SubArray2(J)
    Next J
  End Sub


  'Sort Array1 together with Array2 and Array3 and then sort values in Array2 with the same Array1 value together with Array3

  Sub Sort3Array2Criteria(ByRef Array1 As Object, ByRef Array2 As Object, ByRef Array3 As Object, ByVal N As Integer)

    Dim I As Integer, J As Integer, StartInd As Integer
    Dim SubArray2 As Object, SubArray3 As Object
    Dim SubArrayMaxInd As Integer

    Call QuickSort3ArrayA(Array1, Array2, Array3, 0, N - 1)

    StartInd = 0
    For I = 1 To N - 1
      If Array1(I) <> Array1(StartInd) Then
        SubArrayMaxInd = I - StartInd - 1
        ReDim SubArray2(SubArrayMaxInd), SubArray3(SubArrayMaxInd)
        For J = 0 To SubArrayMaxInd
          SubArray2(J) = Array2(StartInd + J)
          SubArray3(J) = Array3(StartInd + J)
        Next J
        Call BubbleSort2ArrayA(SubArray2, SubArray3, 0, SubArrayMaxInd)
        For J = 0 To SubArrayMaxInd
          Array2(StartInd + J) = SubArray2(J)
          Array3(StartInd + J) = SubArray3(J)
        Next J
        StartInd = I
      End If
    Next I

    SubArrayMaxInd = I - StartInd - 1
    ReDim SubArray2(SubArrayMaxInd), SubArray3(SubArrayMaxInd)
    For J = 0 To SubArrayMaxInd
      SubArray2(J) = Array2(StartInd + J)
      SubArray3(J) = Array3(StartInd + J)
    Next J
    Call BubbleSort2ArrayA(SubArray2, SubArray3, 0, SubArrayMaxInd)
    For J = 0 To SubArrayMaxInd
      Array2(StartInd + J) = SubArray2(J)
      Array3(StartInd + J) = SubArray3(J)
    Next J
  End Sub

  'Merge two sorted string arrays
  'Only unique elements are included, i.e., if Array1(Ind1) = Array2(Ind2) then the element will appear in NewArray only once.
  Function MergeTwoSortedStrArray(ByVal Array1() As String, ByVal N1 As Integer, ByVal Array2() As String, ByVal N2 As Integer) As String()
    Dim Ind1 As Integer = 0, Ind2 As Integer = 0, NewInd As Integer = 0
    Dim NewArray() As String
    ReDim NewArray(N1 + N2 - 1)

    Do While Ind1 < N1 And Ind2 < N2
      If Array1(Ind1) = Array2(Ind2) Then
        NewArray(NewInd) = Array1(Ind1)
        Ind1 = Ind1 + 1
        Ind2 = Ind2 + 1
      ElseIf Array1(Ind1) < Array2(Ind2) Then
        NewArray(NewInd) = Array1(Ind1)
        Ind1 = Ind1 + 1
      Else
        NewArray(NewInd) = Array2(Ind2)
        Ind2 = Ind2 + 1
      End If
      NewInd = NewInd + 1
    Loop
    If Ind1 = N1 Then 'elements in Array1 are all in NewArray
      For i = Ind2 To N2 - 1
        NewArray(NewInd) = Array2(i)
        NewInd = NewInd + 1
      Next
    ElseIf Ind2 = N2 Then
      For i = Ind1 To N1 - 1
        NewArray(NewInd) = Array1(i)
        NewInd = NewInd + 1
      Next
    End If
    Return NewArray
  End Function
End Module
