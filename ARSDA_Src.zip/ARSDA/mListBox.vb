﻿Module mListBox
  'Useful statements:
  'listBox1.ClearSelected() 'Unselect all selected items

  'Used for both ListBox and ComboBox
  Sub PopulateListBox(ByRef List1 As Object, ByVal strArray() As String, ByVal lNumItem As Integer, ByVal ListIndex As Integer, _
                      Optional ByVal ListBoxSelectionMode123 As Integer = 0)
    Dim I As Integer
    List1.Items.Clear()
    For I = 0 To lNumItem - 1
      List1.Items.Add(strArray(I))
    Next
    List1.SelectedIndex = ListIndex
    If ListBoxSelectionMode123 > 0 Then
      List1.SelectionMode = ListBoxSelectionMode123
    End If
  End Sub

  Sub RemoveAllAboveSelected(ByRef List1 As ListBox)
    Dim x As Integer
    For x = List1.SelectedIndex - 1 To 0 Step -1
      List1.Items.RemoveAt(x)
    Next x


  End Sub

  Sub FindAllOfMyString(ByVal searchString As String, ByRef ListBox1 As ListBox)
    Dim x As Integer = -1

    ListBox1.SelectionMode = SelectionMode.MultiExtended
    ' Set our intial index variable to -1. 
    ' If the search string is empty exit.
    If searchString.Length <> 0 Then
      ' Loop through and find each item that matches the search string. 
      Do
        ' Retrieve the item based on the previous index found. Starts with -1 which searches start.
        x = ListBox1.FindString(searchString, x)
        ' If no item is found that matches exit. 
        If x <> -1 Then
          ' Since the FindString loops infinitely, determine if we found first item again and exit. 
          If ListBox1.SelectedIndices.Count > 0 Then
            If x = ListBox1.SelectedIndices(0) Then
              'ListBox1.SelectionMode = OriginalSelectionMode
              Return
            End If
          End If
          ' Select the item in the ListBox once it is found.
          ListBox1.SetSelected(x, True)
        End If
      Loop While x <> -1
    End If
    'ListBox1.SelectionMode = OriginalSelectionMode
  End Sub


End Module
