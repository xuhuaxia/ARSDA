﻿Imports System.Windows.Forms
Imports System.IO

Public Class dlgFasToBlastDB
  Private mDone As Boolean, mFasFile() As String, mBlastDbName As String, mOutputDir As String, mIsNuc As Boolean
  Private mMultFile As Boolean
  Private mNumFasFile As Integer
  
  Public Function GetFasToBlastDbParam(ByRef sFasFile() As String, ByRef sBlastDbName As String, ByRef sResultDir As String, _
                                       ByRef bIsNuc As Boolean, ByRef bMultFile As Boolean) As Boolean
    mDone = False
    mMultFile = False
    Me.ShowDialog()

    If mDone Then
      sFasFile = mFasFile
      If Not mMultFile Then
        sBlastDbName = mBlastDbName
      End If
      sResultDir = mOutputDir
      bIsNuc = mIsNuc
      bMultFile = mMultFile
      Return True
    Else
      Return False
    End If

  End Function
  Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click

    If chkMultFile.Checked Then
      moutputDir = txtOutputDir.Text
      If Not Directory.Exists(mOutputDir) Then
        Call MsgBox("Your specified output directory: " & mOutputDir & " does not exist.", vbInformation)
        Exit Sub
      End If
    Else
      ReDim mFasFile(0)
      mNumFasFile = 1
      mFasFile(0) = txtInFasFile.Text
      If Not File.Exists(mFasFile(0)) Then
        MsgBox("The specified input FASTA file " & mFasFile(0) & " does not exist.", vbOKOnly)
        txtInFasFile.Focus()
        Exit Sub
      End If

      mBlastDbName = txtOutBlastDB.Text
      mOutputDir = txtOutputDir.Text
      Dim sPath As String = Path.GetDirectoryName(mOutputDir)
      If Not Directory.Exists(mOutputDir) Then
        MsgBox("The specified directory for " & mOutputDir & " does not exist.", vbOKOnly)
        txtOutputDir.Focus()
        Exit Sub
      End If
    End If

    mIsNuc = rbNuc.Checked
    mMultFile = chkMultFile.Checked
    mDone = True
    Me.DialogResult = System.Windows.Forms.DialogResult.OK
    Me.Close()
  End Sub

  Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
    Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Close()
  End Sub

  Private Sub btnBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowse.Click

    Dim sFilter As String = "fas,fasp,fasta"
    Dim sPath As String = ""
    If chkMultFile.Checked Then
      mFasFile = GetFileArray(OpenFileDialog1, sFilter, sInputDir)
      mNumFasFile = UBound(mFasFile) + 1
      txtInFasFile.Text = Join(mFasFile, "; ")
      txtOutBlastDB.Text = mNumFasFile & " files to process. File Name --> BLAST dabase name"
    Else
      Dim sFasFile As String = txtInFasFile.Text
      If File.Exists(sFasFile) Then
        sPath = Path.GetDirectoryName(sFasFile)
      Else
        sPath = sInputDir
      End If
      sFasFile = GetOpenFileName("Open FASTA file", "fasta,fas,ffn,faa,fna,frn,fastaP,fasP", OpenFileDialog1, sPath)
      If File.Exists(sFasFile) Then
        Dim HasSpaceAt As Integer
        HasSpaceAt = InStr(sFasFile, " ")
        If HasSpaceAt > 0 Then
          Dim sInfo As String
          sInfo = "This function requires input file/path name to have no space. Your input file:" & CRCR
          sInfo = sInfo & sFasFile & CRCR
          sInfo = sInfo & "has space at position " & HasSpaceAt & CRCR
          sInfo = sInfo & "You are advised to rename the file so that it contains no space in it before running this function." & CRCR
          sInfo = sInfo & "Sorry for this inconvenience."
          Call MsgBox(sInfo, vbInformation)
          Exit Sub
        End If

        txtInFasFile.Text = sFasFile
        txtOutBlastDB.Text = Path.GetFileNameWithoutExtension(txtInFasFile.Text)
        txtOutputDir.Text = Path.GetDirectoryName(txtInFasFile.Text)
      End If
    End If
  End Sub

  Private Sub btnBrowseOutBlastDB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseOutDir.Click
    Dim sFasFile As String = txtInFasFile.Text
    Dim sLocalDbDir As String
    If File.Exists(sFasFile) Then
      If Trim(sFasFile) = "" Then
        FolderBrowserDialog1.SelectedPath = CurDir()
      Else
        Dim sPath As String = Path.GetDirectoryName(sFasFile)
        FolderBrowserDialog1.SelectedPath = sPath
      End If
      If (FolderBrowserDialog1.ShowDialog() = DialogResult.OK) Then
        sLocalDbDir = FolderBrowserDialog1.SelectedPath

        Dim HasSpaceAt As Integer
        HasSpaceAt = InStr(sLocalDbDir, " ")
        If HasSpaceAt > 0 Then
          Dim sInfo As String
          sInfo = "This function, as well as the function for BLASTing against the created local BLAST dabase, requires file/path name to have no space. Your input local path:" & CRCR
          sInfo = sInfo & sLocalDbDir & CRCR
          sInfo = sInfo & "has space at position " & HasSpaceAt & CRCR
          sInfo = sInfo & "You are advised to choose a directory with no space in it, e.g., 'C:\Temp'." & CRCR
          sInfo = sInfo & "Sorry for this inconvenience."
          Call MsgBox(sInfo, vbInformation)
          sLocalDbDir = ""
          Exit Sub
        End If

        txtOutputDir.Text = sLocalDbDir
      End If
    End If
  End Sub

  Private Sub dlgFasToBlastDB_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    txtOutputDir.Text = sNewDataDir
  End Sub

End Class
