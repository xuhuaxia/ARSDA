﻿Imports System.Windows.Forms
Imports System.IO
Public Class dlgSraToFAS
  Private mDone As Boolean, mSraFile() As String, mFasDir As String
  Private mNumSraFile As Integer
  Public Function GetSraToFasParam(ByRef sSraFile() As String, ByRef sFasDir As String, ByRef iNumSraFile As Integer) As Boolean
    mDone = False
    Me.ShowDialog()
    If mDone Then
      sSraFile = mSraFile
      sFasDir = mFasDir
      iNumSraFile = mNumSraFile
      Return True
    Else
      Return False
    End If

  End Function

  Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click

    If chkMultfile.Checked Then
      'Do nothing: the mSraFile() has already been populated.
    Else
      'Check if the file name in the input SRA textbox has been changed to some invalid value.
      ReDim mSraFile(0)
      mSraFile(0) = txtSraFile.Text
      mNumSraFile = 1
      If Not File.Exists(mSraFile(0)) Then
        MsgBox("The input SRA file " & mSraFile(0) & " does not exist.")
        txtSraFile.Focus()
        Exit Sub
      End If

    End If
    mFasDir = txtFasDir.Text
    Dim sPath As String = Path.GetDirectoryName(mFasDir)
    If Not Directory.Exists(sPath) Then
      MsgBox("The directory you entered: " & mFasDir & " does not exist.", vbOKOnly)
      txtFasDir.Focus()
      Exit Sub
    End If
    mDone = True
    Me.DialogResult = System.Windows.Forms.DialogResult.OK
    Me.Close()
  End Sub

  Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
    Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Close()
  End Sub

  Private Sub btnBrowseBlastDB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseSRA.Click

    If chkMultfile.Checked Then
      mSraFile = GetFileArray(OpenFileDialog1, "sra", sInputDir)
      mNumSraFile = UBound(mSraFile) + 1
      txtSraFile.Text = mNumSraFile & " files to dump"
    Else
      If Directory.Exists(txtSraFile.Text) Then
        txtSraFile.Text = GetOpenFileName("Open SRA file", "sra", OpenFileDialog1, txtSraFile.Text)
      Else
        txtSraFile.Text = GetOpenFileName("Open SRA file", "sra", OpenFileDialog1, sInputDir)
      End If
    End If
  End Sub

  Private Sub btnBrowseFAS_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowseFAS.Click
    If Trim(txtSraFile.Text) = "" Then
      FolderBrowserDialog1.SelectedPath = sNewDataDir
    Else
      Dim sPath As String = Path.GetDirectoryName(txtSraFile.Text)
      FolderBrowserDialog1.ShowNewFolderButton = True
      FolderBrowserDialog1.SelectedPath = sPath
    End If
    If (FolderBrowserDialog1.ShowDialog() = DialogResult.OK) Then
      txtFasDir.Text = FolderBrowserDialog1.SelectedPath
    End If

  End Sub
End Class
