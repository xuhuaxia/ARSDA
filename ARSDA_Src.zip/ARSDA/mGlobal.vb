﻿Imports System.IO
Module mGlobal
  'Public Const CRCR = vbCrLf & vbCrLf: already in StrUtil.vb
  '-------------------programs in sratoolkit\bin and Blast: will get full path at frmStart_Load---
  'Public fastqDump As String = "fastq-dump.exe"
  ''Public samDump As String = "sam-dump.exe"
  ''Public sraPileup As String = "sra-pileup.exe"
  'Public sraStat As String = "sra-stat.exe"
  'Public vdbDump As String = "vdb-dump.exe"
  'Public blastnVdb As String = "blastn_vdb.exe"
  ''Other programs not used

  'Public BLASTn As String = "blastn.exe"
  'Public BLASTdbcheck As String = "blastdbcheck.exe"
  'Public BLASTdbcmd As String = "blastdbcmd.exe"
  'Public BLASTformatter As String = "blast_formatter.exe"
  'Public makeBLASTdb As String = "makeblastdb.exe"
  'Other programs not used
  Public fastqDump As String = "fastq-dump"
  Public sraStat As String = "sra-stat"
  Public vdbDump As String = "vdb-dump"
  Public blastnVdb As String = "blastn_vdb"

  Public BLASTn As String = "blastn"
  Public BLASTdbcheck As String = "blastdbcheck"
  Public BLASTdbcmd As String = "blastdbcmd"
  Public BLASTformatter As String = "blast_formatter"
  Public makeBLASTdb As String = "makeblastdb"
  Public sInputDir As String
  Public sResultDir As String
  Public sNewDataDir As String
  '-----------------------------------------------------------------------------------------------
End Module
