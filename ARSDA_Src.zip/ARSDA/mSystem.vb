﻿Imports System.Math
Module mSystem
  'This function is not used
  Function GetSystemMemory(ByRef TotalPhysical As Integer, ByRef AvailablePhysical As Integer, ByRef TotalVirtual As Integer, ByRef AvailableVirtual As Integer, _
                           Optional ByVal bToMB As Boolean = True)
    TotalPhysical = My.Computer.Info.TotalPhysicalMemory
    AvailablePhysical = My.Computer.Info.AvailablePhysicalMemory
    TotalVirtual = My.Computer.Info.TotalVirtualMemory
    AvailableVirtual = My.Computer.Info.AvailableVirtualMemory
    If bToMB Then
      Const MB = 1048576 '= 1024 * 1024
      TotalPhysical = TotalPhysical / MB
      AvailablePhysical = AvailablePhysical / MB
      TotalVirtual = TotalVirtual / MB
      AvailableVirtual = AvailableVirtual / MB
    End If

    Return True
  End Function

End Module
