﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class dlgSraFasToGE
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
    Me.OK_Button = New System.Windows.Forms.Button()
    Me.Cancel_Button = New System.Windows.Forms.Button()
    Me.btnBrowseFAS = New System.Windows.Forms.Button()
    Me.btnBrowseSRA = New System.Windows.Forms.Button()
    Me.lblSraFile = New System.Windows.Forms.Label()
    Me.lblFasFile = New System.Windows.Forms.Label()
    Me.txtSraFile = New System.Windows.Forms.TextBox()
    Me.txtFasFile = New System.Windows.Forms.TextBox()
    Me.txtOutfile = New System.Windows.Forms.TextBox()
    Me.lblOutfile = New System.Windows.Forms.Label()
    Me.btnBrowseOutFile = New System.Windows.Forms.Button()
    Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
    Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
    Me.frBlastOpt = New System.Windows.Forms.GroupBox()
    Me.chkUngapped = New System.Windows.Forms.CheckBox()
    Me.cboStrand = New System.Windows.Forms.ComboBox()
    Me.lblStrand = New System.Windows.Forms.Label()
    Me.btnHelp = New System.Windows.Forms.Button()
    Me.udWordLen = New System.Windows.Forms.NumericUpDown()
    Me.udNumCPU = New System.Windows.Forms.NumericUpDown()
    Me.txtNumAln = New System.Windows.Forms.TextBox()
    Me.lblMaxNumMatch = New System.Windows.Forms.Label()
    Me.lblWordLen = New System.Windows.Forms.Label()
    Me.lblEval = New System.Windows.Forms.Label()
    Me.lblNumCPU = New System.Windows.Forms.Label()
    Me.txtEval = New System.Windows.Forms.TextBox()
    Me.PictureBox1 = New System.Windows.Forms.PictureBox()
    Me.TableLayoutPanel1.SuspendLayout()
    Me.frBlastOpt.SuspendLayout()
    CType(Me.udWordLen, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.udNumCPU, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.SuspendLayout()
    '
    'TableLayoutPanel1
    '
    Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.TableLayoutPanel1.ColumnCount = 2
    Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.Controls.Add(Me.OK_Button, 0, 0)
    Me.TableLayoutPanel1.Controls.Add(Me.Cancel_Button, 1, 0)
    Me.TableLayoutPanel1.Location = New System.Drawing.Point(601, 596)
    Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
    Me.TableLayoutPanel1.RowCount = 1
    Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
    Me.TableLayoutPanel1.Size = New System.Drawing.Size(146, 29)
    Me.TableLayoutPanel1.TabIndex = 0
    '
    'OK_Button
    '
    Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
    Me.OK_Button.Location = New System.Drawing.Point(3, 3)
    Me.OK_Button.Name = "OK_Button"
    Me.OK_Button.Size = New System.Drawing.Size(67, 23)
    Me.OK_Button.TabIndex = 0
    Me.OK_Button.Text = "OK"
    '
    'Cancel_Button
    '
    Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
    Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
    Me.Cancel_Button.Location = New System.Drawing.Point(76, 3)
    Me.Cancel_Button.Name = "Cancel_Button"
    Me.Cancel_Button.Size = New System.Drawing.Size(67, 23)
    Me.Cancel_Button.TabIndex = 1
    Me.Cancel_Button.Text = "Cancel"
    '
    'btnBrowseFAS
    '
    Me.btnBrowseFAS.Location = New System.Drawing.Point(669, 464)
    Me.btnBrowseFAS.Name = "btnBrowseFAS"
    Me.btnBrowseFAS.Size = New System.Drawing.Size(75, 23)
    Me.btnBrowseFAS.TabIndex = 2
    Me.btnBrowseFAS.Text = "Browse"
    Me.btnBrowseFAS.UseVisualStyleBackColor = True
    '
    'btnBrowseSRA
    '
    Me.btnBrowseSRA.Location = New System.Drawing.Point(669, 430)
    Me.btnBrowseSRA.Name = "btnBrowseSRA"
    Me.btnBrowseSRA.Size = New System.Drawing.Size(75, 23)
    Me.btnBrowseSRA.TabIndex = 3
    Me.btnBrowseSRA.Text = "Browse"
    Me.btnBrowseSRA.UseVisualStyleBackColor = True
    '
    'lblSraFile
    '
    Me.lblSraFile.AutoSize = True
    Me.lblSraFile.Location = New System.Drawing.Point(6, 435)
    Me.lblSraFile.Name = "lblSraFile"
    Me.lblSraFile.Size = New System.Drawing.Size(72, 13)
    Me.lblSraFile.TabIndex = 4
    Me.lblSraFile.Text = "Input SRA file"
    '
    'lblFasFile
    '
    Me.lblFasFile.AutoSize = True
    Me.lblFasFile.Location = New System.Drawing.Point(6, 469)
    Me.lblFasFile.Name = "lblFasFile"
    Me.lblFasFile.Size = New System.Drawing.Size(84, 13)
    Me.lblFasFile.TabIndex = 5
    Me.lblFasFile.Text = "Input FASTA file"
    '
    'txtSraFile
    '
    Me.txtSraFile.Location = New System.Drawing.Point(86, 431)
    Me.txtSraFile.Name = "txtSraFile"
    Me.txtSraFile.Size = New System.Drawing.Size(577, 20)
    Me.txtSraFile.TabIndex = 6
    '
    'txtFasFile
    '
    Me.txtFasFile.Location = New System.Drawing.Point(86, 465)
    Me.txtFasFile.Name = "txtFasFile"
    Me.txtFasFile.Size = New System.Drawing.Size(577, 20)
    Me.txtFasFile.TabIndex = 7
    '
    'txtOutfile
    '
    Me.txtOutfile.Location = New System.Drawing.Point(86, 499)
    Me.txtOutfile.Name = "txtOutfile"
    Me.txtOutfile.Size = New System.Drawing.Size(577, 20)
    Me.txtOutfile.TabIndex = 20
    '
    'lblOutfile
    '
    Me.lblOutfile.AutoSize = True
    Me.lblOutfile.Location = New System.Drawing.Point(6, 502)
    Me.lblOutfile.Name = "lblOutfile"
    Me.lblOutfile.Size = New System.Drawing.Size(55, 13)
    Me.lblOutfile.TabIndex = 19
    Me.lblOutfile.Text = "Output file"
    '
    'btnBrowseOutFile
    '
    Me.btnBrowseOutFile.Location = New System.Drawing.Point(669, 498)
    Me.btnBrowseOutFile.Name = "btnBrowseOutFile"
    Me.btnBrowseOutFile.Size = New System.Drawing.Size(75, 23)
    Me.btnBrowseOutFile.TabIndex = 18
    Me.btnBrowseOutFile.Text = "Browse"
    Me.btnBrowseOutFile.UseVisualStyleBackColor = True
    '
    'OpenFileDialog1
    '
    Me.OpenFileDialog1.FileName = "OpenFileDialog1"
    '
    'frBlastOpt
    '
    Me.frBlastOpt.Controls.Add(Me.chkUngapped)
    Me.frBlastOpt.Controls.Add(Me.cboStrand)
    Me.frBlastOpt.Controls.Add(Me.lblStrand)
    Me.frBlastOpt.Controls.Add(Me.btnHelp)
    Me.frBlastOpt.Controls.Add(Me.udWordLen)
    Me.frBlastOpt.Controls.Add(Me.udNumCPU)
    Me.frBlastOpt.Controls.Add(Me.txtNumAln)
    Me.frBlastOpt.Controls.Add(Me.lblMaxNumMatch)
    Me.frBlastOpt.Controls.Add(Me.lblWordLen)
    Me.frBlastOpt.Controls.Add(Me.lblEval)
    Me.frBlastOpt.Controls.Add(Me.lblNumCPU)
    Me.frBlastOpt.Controls.Add(Me.txtEval)
    Me.frBlastOpt.Location = New System.Drawing.Point(9, 541)
    Me.frBlastOpt.Name = "frBlastOpt"
    Me.frBlastOpt.Size = New System.Drawing.Size(586, 84)
    Me.frBlastOpt.TabIndex = 21
    Me.frBlastOpt.TabStop = False
    Me.frBlastOpt.Text = "BLAST options"
    '
    'chkUngapped
    '
    Me.chkUngapped.AutoSize = True
    Me.chkUngapped.Location = New System.Drawing.Point(422, 57)
    Me.chkUngapped.Name = "chkUngapped"
    Me.chkUngapped.Size = New System.Drawing.Size(124, 17)
    Me.chkUngapped.TabIndex = 41
    Me.chkUngapped.Text = "Ungapped alignment"
    Me.chkUngapped.UseVisualStyleBackColor = True
    '
    'cboStrand
    '
    Me.cboStrand.FormattingEnabled = True
    Me.cboStrand.Location = New System.Drawing.Point(463, 23)
    Me.cboStrand.Name = "cboStrand"
    Me.cboStrand.Size = New System.Drawing.Size(73, 21)
    Me.cboStrand.TabIndex = 40
    Me.cboStrand.Text = "both"
    '
    'lblStrand
    '
    Me.lblStrand.AutoSize = True
    Me.lblStrand.Location = New System.Drawing.Point(419, 25)
    Me.lblStrand.Name = "lblStrand"
    Me.lblStrand.Size = New System.Drawing.Size(38, 13)
    Me.lblStrand.TabIndex = 39
    Me.lblStrand.Text = "Strand"
    '
    'btnHelp
    '
    Me.btnHelp.Location = New System.Drawing.Point(280, 54)
    Me.btnHelp.Name = "btnHelp"
    Me.btnHelp.Size = New System.Drawing.Size(20, 19)
    Me.btnHelp.TabIndex = 24
    Me.btnHelp.Text = "?"
    Me.btnHelp.UseVisualStyleBackColor = True
    '
    'udWordLen
    '
    Me.udWordLen.Location = New System.Drawing.Point(77, 57)
    Me.udWordLen.Maximum = New Decimal(New Integer() {28, 0, 0, 0})
    Me.udWordLen.Minimum = New Decimal(New Integer() {12, 0, 0, 0})
    Me.udWordLen.Name = "udWordLen"
    Me.udWordLen.Size = New System.Drawing.Size(61, 20)
    Me.udWordLen.TabIndex = 23
    Me.udWordLen.Value = New Decimal(New Integer() {18, 0, 0, 0})
    '
    'udNumCPU
    '
    Me.udNumCPU.Location = New System.Drawing.Point(306, 23)
    Me.udNumCPU.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
    Me.udNumCPU.Name = "udNumCPU"
    Me.udNumCPU.Size = New System.Drawing.Size(53, 20)
    Me.udNumCPU.TabIndex = 22
    Me.udNumCPU.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
    Me.udNumCPU.Value = New Decimal(New Integer() {1, 0, 0, 0})
    '
    'txtNumAln
    '
    Me.txtNumAln.Enabled = False
    Me.txtNumAln.Location = New System.Drawing.Point(306, 55)
    Me.txtNumAln.Name = "txtNumAln"
    Me.txtNumAln.Size = New System.Drawing.Size(53, 20)
    Me.txtNumAln.TabIndex = 20
    Me.txtNumAln.Text = "1000000"
    Me.txtNumAln.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
    '
    'lblMaxNumMatch
    '
    Me.lblMaxNumMatch.AutoSize = True
    Me.lblMaxNumMatch.Location = New System.Drawing.Point(205, 58)
    Me.lblMaxNumMatch.Name = "lblMaxNumMatch"
    Me.lblMaxNumMatch.Size = New System.Drawing.Size(78, 13)
    Me.lblMaxNumMatch.TabIndex = 21
    Me.lblMaxNumMatch.Text = "Max_N_Target"
    '
    'lblWordLen
    '
    Me.lblWordLen.AutoSize = True
    Me.lblWordLen.Location = New System.Drawing.Point(6, 58)
    Me.lblWordLen.Name = "lblWordLen"
    Me.lblWordLen.Size = New System.Drawing.Size(65, 13)
    Me.lblWordLen.TabIndex = 2
    Me.lblWordLen.Text = "Word length"
    '
    'lblEval
    '
    Me.lblEval.AutoSize = True
    Me.lblEval.Location = New System.Drawing.Point(6, 24)
    Me.lblEval.Name = "lblEval"
    Me.lblEval.Size = New System.Drawing.Size(43, 13)
    Me.lblEval.TabIndex = 0
    Me.lblEval.Text = "E-value"
    '
    'lblNumCPU
    '
    Me.lblNumCPU.AutoSize = True
    Me.lblNumCPU.Location = New System.Drawing.Point(205, 24)
    Me.lblNumCPU.Name = "lblNumCPU"
    Me.lblNumCPU.Size = New System.Drawing.Size(91, 13)
    Me.lblNumCPU.TabIndex = 19
    Me.lblNumCPU.Text = "Processors to use"
    '
    'txtEval
    '
    Me.txtEval.Location = New System.Drawing.Point(55, 24)
    Me.txtEval.Name = "txtEval"
    Me.txtEval.Size = New System.Drawing.Size(83, 20)
    Me.txtEval.TabIndex = 1
    Me.txtEval.Text = "0.0000000001"
    Me.txtEval.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
    '
    'PictureBox1
    '
    Me.PictureBox1.Image = Global.ARSDA.My.Resources.Resources.SraFas2GE1
    Me.PictureBox1.Location = New System.Drawing.Point(4, 12)
    Me.PictureBox1.Name = "PictureBox1"
    Me.PictureBox1.Size = New System.Drawing.Size(740, 411)
    Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
    Me.PictureBox1.TabIndex = 1
    Me.PictureBox1.TabStop = False
    '
    'dlgSraFasToGE
    '
    Me.AcceptButton = Me.OK_Button
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.CancelButton = Me.Cancel_Button
    Me.ClientSize = New System.Drawing.Size(759, 637)
    Me.Controls.Add(Me.frBlastOpt)
    Me.Controls.Add(Me.txtOutfile)
    Me.Controls.Add(Me.lblOutfile)
    Me.Controls.Add(Me.btnBrowseOutFile)
    Me.Controls.Add(Me.txtFasFile)
    Me.Controls.Add(Me.txtSraFile)
    Me.Controls.Add(Me.lblFasFile)
    Me.Controls.Add(Me.lblSraFile)
    Me.Controls.Add(Me.btnBrowseSRA)
    Me.Controls.Add(Me.btnBrowseFAS)
    Me.Controls.Add(Me.PictureBox1)
    Me.Controls.Add(Me.TableLayoutPanel1)
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
    Me.MaximizeBox = False
    Me.MinimizeBox = False
    Me.Name = "dlgSraFasToGE"
    Me.ShowInTaskbar = False
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
    Me.Text = "(SRA + FASTA) to gene expression"
    Me.TableLayoutPanel1.ResumeLayout(False)
    Me.frBlastOpt.ResumeLayout(False)
    Me.frBlastOpt.PerformLayout()
    CType(Me.udWordLen, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.udNumCPU, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
  Friend WithEvents OK_Button As System.Windows.Forms.Button
  Friend WithEvents Cancel_Button As System.Windows.Forms.Button
  Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
  Friend WithEvents btnBrowseFAS As System.Windows.Forms.Button
  Friend WithEvents btnBrowseSRA As System.Windows.Forms.Button
  Friend WithEvents lblSraFile As System.Windows.Forms.Label
  Friend WithEvents lblFasFile As System.Windows.Forms.Label
  Friend WithEvents txtSraFile As System.Windows.Forms.TextBox
  Friend WithEvents txtFasFile As System.Windows.Forms.TextBox
  Friend WithEvents txtOutfile As System.Windows.Forms.TextBox
  Friend WithEvents lblOutfile As System.Windows.Forms.Label
  Friend WithEvents btnBrowseOutFile As System.Windows.Forms.Button
  Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
  Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
  Friend WithEvents frBlastOpt As System.Windows.Forms.GroupBox
  Friend WithEvents udWordLen As System.Windows.Forms.NumericUpDown
  Friend WithEvents udNumCPU As System.Windows.Forms.NumericUpDown
  Friend WithEvents txtNumAln As System.Windows.Forms.TextBox
  Friend WithEvents lblMaxNumMatch As System.Windows.Forms.Label
  Friend WithEvents lblWordLen As System.Windows.Forms.Label
  Friend WithEvents lblEval As System.Windows.Forms.Label
  Friend WithEvents lblNumCPU As System.Windows.Forms.Label
  Friend WithEvents txtEval As System.Windows.Forms.TextBox
  Friend WithEvents btnHelp As System.Windows.Forms.Button
  Friend WithEvents chkUngapped As System.Windows.Forms.CheckBox
  Friend WithEvents cboStrand As System.Windows.Forms.ComboBox
  Friend WithEvents lblStrand As System.Windows.Forms.Label

End Class
