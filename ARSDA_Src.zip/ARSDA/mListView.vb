﻿Module mListView
  Sub PopulateListViewWithDataMat(ByRef InMat(,) As Object, ByVal NumVar As Integer, ByVal NumCase As Integer, ByRef sVarName() As String, _
       ByRef ListView1 As ListView, ByVal bEditItem As Boolean, ByVal bColumnReorder As Boolean, ByVal bCheckBox As Boolean, _
       ByVal bFullRowSelect As Boolean, ByVal bGridLine As Boolean, ByVal bHasRowHeader As Boolean, ByVal bSetLocationSize As Boolean, _
       Optional ByVal RowHeader As Object = Nothing, Optional ByVal iLeft As Integer = 0, Optional ByVal iTop As Integer = 0, Optional ByVal iWidth As Integer = 300, Optional ByVal iHeight As Integer = 300, _
       Optional ByVal iSortOrder0None1A2D As Integer = 0, Optional ByVal ViewLargeIcon0Detail1SmallIcon2List3Tile4 As Integer = 1, _
       Optional ByVal bColAlignLeft As Boolean = True)
    ' Create a new ListView control. 
    Dim I As Integer, J As Integer

    ListView1.Clear()
    If bSetLocationSize Then
      ListView1.Bounds = New Rectangle(New Point(iLeft, iTop), New Size(iWidth, iHeight))
    End If
    ListView1.View = ViewLargeIcon0Detail1SmallIcon2List3Tile4 'View.Details
    ' Allow the user to edit item text.
    ListView1.LabelEdit = bEditItem ' True
    ' Allow the user to rearrange columns.
    ListView1.AllowColumnReorder = bColumnReorder ' True
    ' Display check boxes.
    ListView1.CheckBoxes = bCheckBox ' True
    ' Select the item and subitems when selection is made.
    ListView1.FullRowSelect = bFullRowSelect ' True
    ' Display grid lines.
    ListView1.GridLines = bGridLine ' True
    ' Sort the items in the list in ascending order.
    ListView1.Sorting = iSortOrder0None1A2D ' SortOrder.Ascending

    Dim lvItems(NumCase - 1) As ListViewItem

    For I = 0 To NumCase - 1
      lvItems(I) = New ListViewItem(I)
      For J = 0 To NumVar - 1
        lvItems(I).SubItems.Add(InMat(I, J))
      Next
    Next
    If bHasRowHeader Then
      ListView1.Columns.Add("", -2, HorizontalAlignment.Left)
    Else
      ListView1.Columns.Add("Case", 9, HorizontalAlignment.Left)
    End If
    For J = 0 To NumVar - 1
      If bColAlignLeft Then
        ListView1.Columns.Add(sVarName(J), -2, HorizontalAlignment.Left)
      Else
        ListView1.Columns.Add(sVarName(J), -2, HorizontalAlignment.Right)
      End If
      ListView1.Columns(J + 1).Name = sVarName(J) '.Name is the Key of the column for RemoveByKey
    Next
    'Add the items to the ListView.
    ListView1.Items.AddRange(lvItems)
    If bHasRowHeader Then
      For I = 0 To NumCase - 1
        ListView1.Items(I).SubItems(0).Text = RowHeader(I)
      Next
    End If
    ListView1.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent)

    '' Create two ImageList objects. 
    'Dim imageListSmall As New ImageList()
    'Dim imageListLarge As New ImageList()

    '' Initialize the ImageList objects with bitmaps.
    'imageListSmall.Images.Add(Bitmap.FromFile("C:\software\icon\CA.ico"))
    'imageListSmall.Images.Add(Bitmap.FromFile("C:\software\icon\Blast.ico"))
    'imageListLarge.Images.Add(Bitmap.FromFile("C:\software\icon\CA.ico"))
    'imageListLarge.Images.Add(Bitmap.FromFile("C:\software\icon\Blast.ico"))

    ''Assign the ImageList objects to the ListView.
    'listView1.LargeImageList = imageListLarge
    'listView1.SmallImageList = imageListSmall

  End Sub 'PopulateListViewWithDataMat


  'Add a column to the right
  Sub AddVarToListView(ByRef ListView1 As ListView, ByVal sVarName As String, ByVal NumCase As Integer, ByVal NewX() As Double)
    Dim I As Integer
    ListView1.BeginUpdate()
    ListView1.Columns.Add(sVarName)
    ListView1.Columns(ListView1.Columns.Count - 1).Name = sVarName '.Name is the Key of the column for RemoveByKey
    For I = 0 To NumCase - 1
      ListView1.Items(I).SubItems.Add(NewX(I).ToString)
    Next
    ListView1.EndUpdate()
  End Sub

  Sub AddVarToListViewStr(ByRef ListView1 As ListView, ByVal sVarName As String, ByVal NumCase As Integer, ByVal NewX() As String)
    Dim I As Integer
    ListView1.BeginUpdate()
    ListView1.Columns.Add(sVarName)
    ListView1.Columns(ListView1.Columns.Count - 1).Name = sVarName '.Name is the Key of the column for RemoveByKey
    If ListView1.Items.Count > 0 Then
      For I = 0 To NumCase - 1
        ListView1.Items(I).SubItems.Add(NewX(I))
      Next
    Else
      Dim lvItems(NumCase - 1) As ListViewItem
      For I = 0 To NumCase - 1
        lvItems(I) = New ListViewItem
        lvItems(I).SubItems.Add(NewX(I))
      Next
      ListView1.Items.AddRange(lvItems)
    End If
    ListView1.EndUpdate()
  End Sub

  'Add new variables to the right the of original
  Sub AddMultVarToListView(ByRef InMat(,) As Double, ByVal NumVar As Integer, ByVal NumCase As Integer, ByRef sVarName() As String, _
       ByRef ListView1 As ListView)
    ListView1.BeginUpdate()
    Dim I As Integer, J As Integer
    Dim StartColInd As Integer = ListView1.Columns.Count

    For J = 0 To NumVar - 1
      ListView1.Columns.Add(sVarName(J), -2, HorizontalAlignment.Left)
      ListView1.Columns(J + 1).Name = sVarName(J) '.Name is the Key of the column for RemoveByKey
      For I = 0 To NumCase - 1
        ListView1.Items(I).SubItems.Add(InMat(I, J).ToString)
      Next
    Next
    ListView1.EndUpdate()
  End Sub


  Sub GetClickedCellInd(ByVal pListView As ListView, ByVal pMouseX As Integer, ByRef RowInd As Integer, ByRef ColInd As Integer)
    Dim result As Integer = 0

    RowInd = pListView.SelectedIndices(0)
    'Get column rights
    Dim colRights As New List(Of Integer)
    Dim colWidths As New List(Of Integer)
    For Each col As ColumnHeader In pListView.Columns
      colWidths.Add(col.Width)
      Dim colRight As Integer = 0 ' - pListView.Columns.Item(0).Width 'Subtract this if you were collecting lefts instead of rights
      For i As Integer = 0 To colWidths.Count - 1
        colRight += colWidths(i)
      Next
      colRights.Add(colRight)
    Next

    'Which column does the mouse X fall inside?
    For Each colRight As Integer In colRights
      If pMouseX <= colRight Then
        result = ColInd
        Exit For
      End If
      ColInd += 1
    Next
  End Sub

  'Add to the bottom of the original
  Sub AppendListViewWithDataMat(ByRef InMat(,) As Double, ByVal NumVar As Integer, ByVal NumCase As Integer, _
     ByVal bHasRowHeader As Boolean, ByRef ListView1 As ListView, Optional ByVal RowHeader As Object = Nothing)

    ListView1.BeginUpdate()
    Dim lvItems(NumCase - 1) As ListViewItem
    Dim StartRowInd As Integer = ListView1.Items.Count

    For I = 0 To NumCase - 1
      lvItems(I) = New ListViewItem(I.ToString)
      For J = 0 To NumVar - 1
        lvItems(I).SubItems.Add(InMat(I, J).ToString)
      Next
    Next
    'Add the items to the ListView.
    ListView1.Items.AddRange(lvItems)
    If bHasRowHeader Then
      For I = 0 To NumCase - 1
        ListView1.Items(StartRowInd + I).SubItems(0).Text = RowHeader(I)
      Next
    End If
    ListView1.EndUpdate()

  End Sub


End Module
