﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStart
  Inherits System.Windows.Forms.Form

  'Form overrides dispose to clean up the component list.
  <System.Diagnostics.DebuggerNonUserCode()> _
  Protected Overrides Sub Dispose(ByVal disposing As Boolean)
    Try
      If disposing AndAlso components IsNot Nothing Then
        components.Dispose()
      End If
    Finally
      MyBase.Dispose(disposing)
    End Try
  End Sub

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> _
  Private Sub InitializeComponent()
    Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmStart))
    Me.mnuMain = New System.Windows.Forms.MenuStrip()
    Me.mnuFile = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileSRAinfo = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileFastqInfo = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuFileSRAtoFASTQ = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileSRAtoFASTA = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuFileFastqToFastqPlus = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileFastqToFasPlus = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileFas2FasPlus = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFilePairedFastqToPairFasPlus = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileFastqToFas = New System.Windows.Forms.ToolStripMenuItem()
    Me.FileRTrimSeq = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuFileLoadTextFile = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileSaveBuffer = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuFileExit = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuEdit = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuEditUndo = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuEditRedo = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuEditCut = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuEditCopy = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuEditPaste = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripMenuItem8 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuEditSelectAll = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuEditFind = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuEditFindNext = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripMenuItem9 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuEditCopyToEXCEL = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuEditCopyNColToExcel = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripMenuItem10 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuEditChangeFont = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuEditChangeColor = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuDB = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuDbCreateBlast = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuDbInfoBlastDB = New System.Windows.Forms.ToolStripMenuItem()
    Me.DumpBLASTDBToFASTAToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuNCBI = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuNCBIDownloadBlastDB = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuNCBIDownloadSRA = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuAnalysis = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuAnaSraGE = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuAnaBlastGE = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuAnaBLAST = New System.Windows.Forms.ToolStripMenuItem()
    Me.TestToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.Test2ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.Test4ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.Test3ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuTools = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuToolsOption = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuToolsTiming = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuHelp = New System.Windows.Forms.ToolStripMenuItem()
    Me.AboutARSDA = New System.Windows.Forms.ToolStripMenuItem()
    Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
    Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
    Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
    Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
    Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
    Me.ToolStripProgressBar1 = New System.Windows.Forms.ToolStripProgressBar()
    Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
    Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
    Me.FontDialog1 = New System.Windows.Forms.FontDialog()
    Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
    Me.mnuMain.SuspendLayout()
    Me.StatusStrip1.SuspendLayout()
    Me.SuspendLayout()
    '
    'mnuMain
    '
    Me.mnuMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFile, Me.mnuEdit, Me.mnuDB, Me.mnuNCBI, Me.mnuAnalysis, Me.mnuTools, Me.mnuHelp})
    Me.mnuMain.Location = New System.Drawing.Point(0, 0)
    Me.mnuMain.Name = "mnuMain"
    Me.mnuMain.Size = New System.Drawing.Size(935, 24)
    Me.mnuMain.TabIndex = 0
    Me.mnuMain.Text = "MenuStrip1"
    '
    'mnuFile
    '
    Me.mnuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFileSRAinfo, Me.mnuFileFastqInfo, Me.ToolStripMenuItem3, Me.mnuFileSRAtoFASTQ, Me.mnuFileSRAtoFASTA, Me.ToolStripMenuItem4, Me.mnuFileFastqToFastqPlus, Me.mnuFileFastqToFasPlus, Me.mnuFileFas2FasPlus, Me.mnuFilePairedFastqToPairFasPlus, Me.mnuFileFastqToFas, Me.FileRTrimSeq, Me.ToolStripMenuItem1, Me.mnuFileLoadTextFile, Me.mnuFileSaveBuffer, Me.ToolStripMenuItem2, Me.mnuFileExit})
    Me.mnuFile.Name = "mnuFile"
    Me.mnuFile.Size = New System.Drawing.Size(37, 20)
    Me.mnuFile.Text = "File"
    '
    'mnuFileSRAinfo
    '
    Me.mnuFileSRAinfo.Name = "mnuFileSRAinfo"
    Me.mnuFileSRAinfo.Size = New System.Drawing.Size(287, 22)
    Me.mnuFileSRAinfo.Text = "Get .SRA file info"
    '
    'mnuFileFastqInfo
    '
    Me.mnuFileFastqInfo.Name = "mnuFileFastqInfo"
    Me.mnuFileFastqInfo.Size = New System.Drawing.Size(287, 22)
    Me.mnuFileFastqInfo.Text = "Get .FASTQ file info"
    '
    'ToolStripMenuItem3
    '
    Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
    Me.ToolStripMenuItem3.Size = New System.Drawing.Size(284, 6)
    '
    'mnuFileSRAtoFASTQ
    '
    Me.mnuFileSRAtoFASTQ.Name = "mnuFileSRAtoFASTQ"
    Me.mnuFileSRAtoFASTQ.Size = New System.Drawing.Size(287, 22)
    Me.mnuFileSRAtoFASTQ.Text = "Dump .SRA file to FASTQ"
    '
    'mnuFileSRAtoFASTA
    '
    Me.mnuFileSRAtoFASTA.Name = "mnuFileSRAtoFASTA"
    Me.mnuFileSRAtoFASTA.Size = New System.Drawing.Size(287, 22)
    Me.mnuFileSRAtoFASTA.Text = "Dump .SRA file to FASTA"
    '
    'ToolStripMenuItem4
    '
    Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
    Me.ToolStripMenuItem4.Size = New System.Drawing.Size(284, 6)
    '
    'mnuFileFastqToFastqPlus
    '
    Me.mnuFileFastqToFastqPlus.Name = "mnuFileFastqToFastqPlus"
    Me.mnuFileFastqToFastqPlus.Size = New System.Drawing.Size(287, 22)
    Me.mnuFileFastqToFastqPlus.Text = "FASTQ to FASTQ+"
    '
    'mnuFileFastqToFasPlus
    '
    Me.mnuFileFastqToFasPlus.Name = "mnuFileFastqToFasPlus"
    Me.mnuFileFastqToFasPlus.Size = New System.Drawing.Size(287, 22)
    Me.mnuFileFastqToFasPlus.Text = "FASTQ to FASTA+"
    '
    'mnuFileFas2FasPlus
    '
    Me.mnuFileFas2FasPlus.Name = "mnuFileFas2FasPlus"
    Me.mnuFileFas2FasPlus.Size = New System.Drawing.Size(287, 22)
    Me.mnuFileFas2FasPlus.Text = "FASTA to FASTA+"
    '
    'mnuFilePairedFastqToPairFasPlus
    '
    Me.mnuFilePairedFastqToPairFasPlus.Name = "mnuFilePairedFastqToPairFasPlus"
    Me.mnuFilePairedFastqToPairFasPlus.Size = New System.Drawing.Size(287, 22)
    Me.mnuFilePairedFastqToPairFasPlus.Text = "Paired FASTQ files to Paired FASTA+ files"
    '
    'mnuFileFastqToFas
    '
    Me.mnuFileFastqToFas.Name = "mnuFileFastqToFas"
    Me.mnuFileFastqToFas.Size = New System.Drawing.Size(287, 22)
    Me.mnuFileFastqToFas.Text = "FASTQ to FASTA"
    '
    'FileRTrimSeq
    '
    Me.FileRTrimSeq.Name = "FileRTrimSeq"
    Me.FileRTrimSeq.Size = New System.Drawing.Size(287, 22)
    Me.FileRTrimSeq.Text = "RTrim Fasta sequences"
    '
    'ToolStripMenuItem1
    '
    Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
    Me.ToolStripMenuItem1.Size = New System.Drawing.Size(284, 6)
    '
    'mnuFileLoadTextFile
    '
    Me.mnuFileLoadTextFile.Name = "mnuFileLoadTextFile"
    Me.mnuFileLoadTextFile.Size = New System.Drawing.Size(287, 22)
    Me.mnuFileLoadTextFile.Text = "Load text file"
    '
    'mnuFileSaveBuffer
    '
    Me.mnuFileSaveBuffer.Name = "mnuFileSaveBuffer"
    Me.mnuFileSaveBuffer.Size = New System.Drawing.Size(287, 22)
    Me.mnuFileSaveBuffer.Text = "Save display buffer"
    '
    'ToolStripMenuItem2
    '
    Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
    Me.ToolStripMenuItem2.Size = New System.Drawing.Size(284, 6)
    '
    'mnuFileExit
    '
    Me.mnuFileExit.Name = "mnuFileExit"
    Me.mnuFileExit.Size = New System.Drawing.Size(287, 22)
    Me.mnuFileExit.Text = "Exit"
    '
    'mnuEdit
    '
    Me.mnuEdit.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuEditUndo, Me.mnuEditRedo, Me.mnuEditCut, Me.mnuEditCopy, Me.mnuEditPaste, Me.ToolStripMenuItem8, Me.mnuEditSelectAll, Me.mnuEditFind, Me.mnuEditFindNext, Me.ToolStripMenuItem9, Me.mnuEditCopyToEXCEL, Me.mnuEditCopyNColToExcel, Me.ToolStripMenuItem10, Me.mnuEditChangeFont, Me.mnuEditChangeColor})
    Me.mnuEdit.Name = "mnuEdit"
    Me.mnuEdit.Size = New System.Drawing.Size(39, 20)
    Me.mnuEdit.Text = "Edit"
    '
    'mnuEditUndo
    '
    Me.mnuEditUndo.Name = "mnuEditUndo"
    Me.mnuEditUndo.Size = New System.Drawing.Size(243, 22)
    Me.mnuEditUndo.Text = "Undo         Ctrl-Z"
    '
    'mnuEditRedo
    '
    Me.mnuEditRedo.Name = "mnuEditRedo"
    Me.mnuEditRedo.Size = New System.Drawing.Size(243, 22)
    Me.mnuEditRedo.Text = "Redo          "
    '
    'mnuEditCut
    '
    Me.mnuEditCut.Name = "mnuEditCut"
    Me.mnuEditCut.Size = New System.Drawing.Size(243, 22)
    Me.mnuEditCut.Text = "Cut            Ctrl-X"
    '
    'mnuEditCopy
    '
    Me.mnuEditCopy.Name = "mnuEditCopy"
    Me.mnuEditCopy.Size = New System.Drawing.Size(243, 22)
    Me.mnuEditCopy.Text = "Copy         Ctrl-C"
    '
    'mnuEditPaste
    '
    Me.mnuEditPaste.Name = "mnuEditPaste"
    Me.mnuEditPaste.Size = New System.Drawing.Size(243, 22)
    Me.mnuEditPaste.Text = "Paste         Ctrl-V"
    '
    'ToolStripMenuItem8
    '
    Me.ToolStripMenuItem8.Name = "ToolStripMenuItem8"
    Me.ToolStripMenuItem8.Size = New System.Drawing.Size(240, 6)
    '
    'mnuEditSelectAll
    '
    Me.mnuEditSelectAll.Name = "mnuEditSelectAll"
    Me.mnuEditSelectAll.Size = New System.Drawing.Size(243, 22)
    Me.mnuEditSelectAll.Text = "Select All   Ctrl-A"
    '
    'mnuEditFind
    '
    Me.mnuEditFind.Name = "mnuEditFind"
    Me.mnuEditFind.Size = New System.Drawing.Size(243, 22)
    Me.mnuEditFind.Text = "Find            Ctrl-F"
    '
    'mnuEditFindNext
    '
    Me.mnuEditFindNext.Name = "mnuEditFindNext"
    Me.mnuEditFindNext.Size = New System.Drawing.Size(243, 22)
    Me.mnuEditFindNext.Text = "Find All      F3"
    '
    'ToolStripMenuItem9
    '
    Me.ToolStripMenuItem9.Name = "ToolStripMenuItem9"
    Me.ToolStripMenuItem9.Size = New System.Drawing.Size(240, 6)
    '
    'mnuEditCopyToEXCEL
    '
    Me.mnuEditCopyToEXCEL.Name = "mnuEditCopyToEXCEL"
    Me.mnuEditCopyToEXCEL.Size = New System.Drawing.Size(243, 22)
    Me.mnuEditCopyToEXCEL.Text = "Copy to EXCEL"
    '
    'mnuEditCopyNColToExcel
    '
    Me.mnuEditCopyNColToExcel.Name = "mnuEditCopyNColToExcel"
    Me.mnuEditCopyNColToExcel.Size = New System.Drawing.Size(243, 22)
    Me.mnuEditCopyNColToExcel.Text = "Copy N rightmost cols to EXCEL"
    '
    'ToolStripMenuItem10
    '
    Me.ToolStripMenuItem10.Name = "ToolStripMenuItem10"
    Me.ToolStripMenuItem10.Size = New System.Drawing.Size(240, 6)
    '
    'mnuEditChangeFont
    '
    Me.mnuEditChangeFont.Name = "mnuEditChangeFont"
    Me.mnuEditChangeFont.Size = New System.Drawing.Size(243, 22)
    Me.mnuEditChangeFont.Text = "Change font"
    '
    'mnuEditChangeColor
    '
    Me.mnuEditChangeColor.Name = "mnuEditChangeColor"
    Me.mnuEditChangeColor.Size = New System.Drawing.Size(243, 22)
    Me.mnuEditChangeColor.Text = "Change color"
    '
    'mnuDB
    '
    Me.mnuDB.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuDbCreateBlast, Me.mnuDbInfoBlastDB, Me.DumpBLASTDBToFASTAToolStripMenuItem})
    Me.mnuDB.Name = "mnuDB"
    Me.mnuDB.Size = New System.Drawing.Size(67, 20)
    Me.mnuDB.Text = "Database"
    '
    'mnuDbCreateBlast
    '
    Me.mnuDbCreateBlast.Name = "mnuDbCreateBlast"
    Me.mnuDbCreateBlast.Size = New System.Drawing.Size(212, 22)
    Me.mnuDbCreateBlast.Text = "Create BLAST DB"
    '
    'mnuDbInfoBlastDB
    '
    Me.mnuDbInfoBlastDB.Name = "mnuDbInfoBlastDB"
    Me.mnuDbInfoBlastDB.Size = New System.Drawing.Size(212, 22)
    Me.mnuDbInfoBlastDB.Text = "Info of BLAST DB"
    '
    'DumpBLASTDBToFASTAToolStripMenuItem
    '
    Me.DumpBLASTDBToFASTAToolStripMenuItem.Name = "DumpBLASTDBToFASTAToolStripMenuItem"
    Me.DumpBLASTDBToFASTAToolStripMenuItem.Size = New System.Drawing.Size(212, 22)
    Me.DumpBLASTDBToFASTAToolStripMenuItem.Text = "Dump BLAST DB to FASTA"
    '
    'mnuNCBI
    '
    Me.mnuNCBI.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuNCBIDownloadBlastDB, Me.mnuNCBIDownloadSRA})
    Me.mnuNCBI.Name = "mnuNCBI"
    Me.mnuNCBI.Size = New System.Drawing.Size(46, 20)
    Me.mnuNCBI.Text = "NCBI"
    '
    'mnuNCBIDownloadBlastDB
    '
    Me.mnuNCBIDownloadBlastDB.Name = "mnuNCBIDownloadBlastDB"
    Me.mnuNCBIDownloadBlastDB.Size = New System.Drawing.Size(220, 22)
    Me.mnuNCBIDownloadBlastDB.Text = "Download BLAST databases"
    '
    'mnuNCBIDownloadSRA
    '
    Me.mnuNCBIDownloadSRA.Name = "mnuNCBIDownloadSRA"
    Me.mnuNCBIDownloadSRA.Size = New System.Drawing.Size(220, 22)
    Me.mnuNCBIDownloadSRA.Text = "Download .SRA files"
    '
    'mnuAnalysis
    '
    Me.mnuAnalysis.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuAnaSraGE, Me.mnuAnaBlastGE, Me.mnuAnaBLAST, Me.TestToolStripMenuItem, Me.Test2ToolStripMenuItem, Me.Test4ToolStripMenuItem, Me.Test3ToolStripMenuItem})
    Me.mnuAnalysis.Name = "mnuAnalysis"
    Me.mnuAnalysis.Size = New System.Drawing.Size(62, 20)
    Me.mnuAnalysis.Text = "Analysis"
    '
    'mnuAnaSraGE
    '
    Me.mnuAnaSraGE.Name = "mnuAnaSraGE"
    Me.mnuAnaSraGE.Size = New System.Drawing.Size(275, 22)
    Me.mnuAnaSraGE.Text = "Gene expression from SRA database"
    '
    'mnuAnaBlastGE
    '
    Me.mnuAnaBlastGE.Name = "mnuAnaBlastGE"
    Me.mnuAnaBlastGE.Size = New System.Drawing.Size(275, 22)
    Me.mnuAnaBlastGE.Text = "Gene expression from BLAST database"
    '
    'mnuAnaBLAST
    '
    Me.mnuAnaBLAST.Name = "mnuAnaBLAST"
    Me.mnuAnaBLAST.Size = New System.Drawing.Size(275, 22)
    Me.mnuAnaBLAST.Text = "Basic BLAST"
    '
    'TestToolStripMenuItem
    '
    Me.TestToolStripMenuItem.Name = "TestToolStripMenuItem"
    Me.TestToolStripMenuItem.Size = New System.Drawing.Size(275, 22)
    Me.TestToolStripMenuItem.Text = "test"
    '
    'Test2ToolStripMenuItem
    '
    Me.Test2ToolStripMenuItem.Name = "Test2ToolStripMenuItem"
    Me.Test2ToolStripMenuItem.Size = New System.Drawing.Size(275, 22)
    Me.Test2ToolStripMenuItem.Text = "Test2"
    '
    'Test4ToolStripMenuItem
    '
    Me.Test4ToolStripMenuItem.Name = "Test4ToolStripMenuItem"
    Me.Test4ToolStripMenuItem.Size = New System.Drawing.Size(275, 22)
    Me.Test4ToolStripMenuItem.Text = "test3"
    '
    'Test3ToolStripMenuItem
    '
    Me.Test3ToolStripMenuItem.Name = "Test3ToolStripMenuItem"
    Me.Test3ToolStripMenuItem.Size = New System.Drawing.Size(275, 22)
    Me.Test3ToolStripMenuItem.Text = "test3"
    Me.Test3ToolStripMenuItem.Visible = False
    '
    'mnuTools
    '
    Me.mnuTools.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuToolsOption, Me.mnuToolsTiming})
    Me.mnuTools.Name = "mnuTools"
    Me.mnuTools.Size = New System.Drawing.Size(47, 20)
    Me.mnuTools.Text = "Tools"
    '
    'mnuToolsOption
    '
    Me.mnuToolsOption.Name = "mnuToolsOption"
    Me.mnuToolsOption.Size = New System.Drawing.Size(152, 22)
    Me.mnuToolsOption.Text = "Options"
    '
    'mnuToolsTiming
    '
    Me.mnuToolsTiming.Name = "mnuToolsTiming"
    Me.mnuToolsTiming.Size = New System.Drawing.Size(152, 22)
    Me.mnuToolsTiming.Text = "Timing"
    '
    'mnuHelp
    '
    Me.mnuHelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutARSDA})
    Me.mnuHelp.Name = "mnuHelp"
    Me.mnuHelp.Size = New System.Drawing.Size(44, 20)
    Me.mnuHelp.Text = "Help"
    '
    'AboutARSDA
    '
    Me.AboutARSDA.Name = "AboutARSDA"
    Me.AboutARSDA.Size = New System.Drawing.Size(147, 22)
    Me.AboutARSDA.Text = "About ARSDA"
    '
    'OpenFileDialog1
    '
    Me.OpenFileDialog1.FileName = "OpenFileDialog1"
    '
    'StatusStrip1
    '
    Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel2, Me.ToolStripProgressBar1})
    Me.StatusStrip1.Location = New System.Drawing.Point(0, 560)
    Me.StatusStrip1.Name = "StatusStrip1"
    Me.StatusStrip1.Size = New System.Drawing.Size(935, 22)
    Me.StatusStrip1.TabIndex = 2
    Me.StatusStrip1.Text = "StatusStrip1"
    '
    'ToolStripStatusLabel1
    '
    Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
    Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(39, 17)
    Me.ToolStripStatusLabel1.Text = "Ready"
    '
    'ToolStripStatusLabel2
    '
    Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
    Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(25, 17)
    Me.ToolStripStatusLabel2.Text = "File"
    '
    'ToolStripProgressBar1
    '
    Me.ToolStripProgressBar1.Name = "ToolStripProgressBar1"
    Me.ToolStripProgressBar1.Size = New System.Drawing.Size(400, 16)
    '
    'RichTextBox1
    '
    Me.RichTextBox1.Dock = System.Windows.Forms.DockStyle.Fill
    Me.RichTextBox1.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.RichTextBox1.Location = New System.Drawing.Point(0, 24)
    Me.RichTextBox1.Name = "RichTextBox1"
    Me.RichTextBox1.Size = New System.Drawing.Size(935, 536)
    Me.RichTextBox1.TabIndex = 3
    Me.RichTextBox1.Text = ""
    '
    'frmStart
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(935, 582)
    Me.Controls.Add(Me.RichTextBox1)
    Me.Controls.Add(Me.StatusStrip1)
    Me.Controls.Add(Me.mnuMain)
    Me.ForeColor = System.Drawing.Color.Black
    Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
    Me.MainMenuStrip = Me.mnuMain
    Me.Name = "frmStart"
    Me.Text = "ARSDA: analyzing RNA-Seq data"
    Me.mnuMain.ResumeLayout(False)
    Me.mnuMain.PerformLayout()
    Me.StatusStrip1.ResumeLayout(False)
    Me.StatusStrip1.PerformLayout()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents mnuMain As System.Windows.Forms.MenuStrip
  Friend WithEvents mnuFile As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuFileFastqToFas As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuFileSRAtoFASTQ As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents mnuFileSaveBuffer As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents mnuFileExit As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuAnalysis As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents TestToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
  Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
  Friend WithEvents mnuDB As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuDbCreateBlast As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuDbInfoBlastDB As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
  Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
  Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
  Friend WithEvents ToolStripProgressBar1 As System.Windows.Forms.ToolStripProgressBar
  Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
  Friend WithEvents mnuFileSRAinfo As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents Test2ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuFileSRAtoFASTA As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuNCBI As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuNCBIDownloadBlastDB As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuNCBIDownloadSRA As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuEdit As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuEditUndo As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuEditCut As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuEditCopy As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuEditPaste As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripMenuItem8 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents mnuEditSelectAll As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuEditFind As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuEditFindNext As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripMenuItem9 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents mnuEditCopyToEXCEL As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuEditCopyNColToExcel As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripMenuItem10 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents mnuEditChangeFont As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuEditChangeColor As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuEditRedo As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ColorDialog1 As System.Windows.Forms.ColorDialog
  Friend WithEvents FontDialog1 As System.Windows.Forms.FontDialog
  Friend WithEvents mnuFileFastqToFasPlus As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuFileFastqToFastqPlus As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuAnaSraGE As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuAnaBlastGE As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuTools As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuToolsOption As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
  Friend WithEvents Test3ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents Test4ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuToolsTiming As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuFileLoadTextFile As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuFileFastqInfo As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents ToolStripMenuItem4 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents mnuFilePairedFastqToPairFasPlus As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuHelp As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents AboutARSDA As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuAnaBLAST As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuFileFas2FasPlus As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents FileRTrimSeq As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents DumpBLASTDBToFASTAToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
