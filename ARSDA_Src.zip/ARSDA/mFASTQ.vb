﻿Imports System.IO
Imports System.Text
Imports System.Collections

'Store Seq in packed form with each four nucleotides packed into one byte
'Quality() is for computing the average quality of a set of identical sequences in the output
Module mFASTQ
  Private Structure tFastqFile
    Public Count As Integer
    Public Quality() As Single
  End Structure

  'Output just one FAS file
  Function FastqToFas(ByVal sFastqFile As String, ByVal sFasFile As String, ByVal ProgressBar1 As ToolStripProgressBar) As Boolean
    'Process the file in chunks
    Dim I As Integer, J As Integer, UppInd As Integer, TotalNumSeq As Integer = 0
    Dim sSeq As String, sName As String
    Dim lChunkLen As Integer, lFreeMem As Long, lFileLen As Long
    Dim sChunk As String, LineArray() As String
    Dim sb As New StringBuilder

    Try
      lFreeMem = GetAvailablePhysicalMem()
    Catch ex As Exception
      MsgBox("Error Encountered in getting system memory!" & CRCR & ex.ToString, vbInformation, "Error")
      lFreeMem = 2000000000
    End Try
    lFileLen = FileLen(sFastqFile)
    lChunkLen = lFreeMem \ 1000
    If lChunkLen > lFileLen Then
      sChunk = File.ReadAllText(sFastqFile)
      sChunk = Replace(sChunk, vbCrLf, vbLf)
      LineArray = Split(sChunk, vbLf)
      sChunk = ""
      UppInd = UBound(LineArray)

      ProgressBar1.Minimum = 0
      ProgressBar1.Maximum = UppInd
      For I = 0 To UppInd - 3 Step 4
        sName = Mid(LineArray(I), 2)
        sSeq = LineArray(I + 1)
        sb.Append(">" & sName & vbLf)
        sb.Append(sSeq & vbLf)
        ProgressBar1.Value = I
      Next
      ProgressBar1.Value = 0
      File.WriteAllText(sFasFile, sb.ToString)
      sb.Clear()
    Else
      Dim fs As New FileStream(sFastqFile, FileMode.Open, FileAccess.Read)
      Dim NumByteRead As Integer, lNumChunk As Integer, lRemainLen As Integer, NumTrailingLine As Integer
      Dim sRemain As String = ""
      Dim tmpUppInd As Integer
      Dim tmpByte() As Byte

      lNumChunk = lFileLen \ lChunkLen
      lRemainLen = lFileLen Mod lChunkLen

      ProgressBar1.Minimum = 0
      ProgressBar1.Maximum = lNumChunk
      File.WriteAllText(sFasFile, "")
      For I = 0 To lNumChunk - 1
        ReDim tmpByte(lChunkLen - 1)
        NumByteRead = fs.Read(tmpByte, 0, lChunkLen)
        sChunk = sRemain & Encoding.ASCII.GetString(tmpByte)
        sChunk = Replace(sChunk, vbCrLf, vbLf)
        LineArray = Split(sChunk, vbLf)
        sChunk = ""
        UppInd = UBound(LineArray)
        NumTrailingLine = (UppInd + 1) Mod 4
        'ID-line & vbLf : break before vbLF --> NumTrainingLine = 1; after --> NumTrailingLine = 2
        'SeqLine & vbLf : break before vbLF --> NumTrainingLine = 2; after --> NumTrailingLine = 3
        '+Line & vbLf : break before vbLF --> NumTrainingLine = 3; after --> NumTrailingLine = 0
        'Quality-line & vbLf : break before vbLF --> NumTrainingLine = 0; after --> NumTrailingLine = 1

        Select Case NumTrailingLine
          Case 0
            'The last four line may be incomplete:
            'Two scenarios:
            '1. +Line & vbLF --> last line empty
            '2. +Line & vbLf & PartialQualityLine
            'In both cases it is fine to have
            sRemain = LineArray(UppInd - 3) & vbLf & LineArray(UppInd - 2) & vbLf & LineArray(UppInd - 1) & vbLf & LineArray(UppInd)
            tmpUppInd = UppInd - 7
          Case 1
            'Two scenarios:
            '1. last quality line is complete with vblf, in which case LineArray(UppInd)=""
            '2. last line is an incomplete @ID line
            'In both cases, it is fine to have
            sRemain = LineArray(UppInd)
            tmpUppInd = UppInd - 4
          Case 2
            'Two scenarios:
            '1. @ID...vbLf
            '2. @ID...vbLf & PartialSeq
            sRemain = LineArray(UppInd - 1) & vbLf & LineArray(UppInd)
            tmpUppInd = UppInd - 5
          Case 3
            'Two scenarios:
            '1. SeqLine & vbLf --> LineArray(UppInd)=""
            '2. SeqLine & vbLf & Partial +Line
            sRemain = LineArray(UppInd - 2) & vbCrLf & LineArray(UppInd - 1) & vbLf & LineArray(UppInd)
            tmpUppInd = UppInd - 6
        End Select

        For J = 0 To tmpUppInd Step 4
          sName = Mid(LineArray(J), 2)
          sSeq = LineArray(J + 1)
          sb.Append(">" & sName & vbLf)
          sb.Append(sSeq & vbLf)
        Next
        ProgressBar1.Value = I
        Application.DoEvents()
        File.AppendAllText(sFasFile, sb.ToString)
        sb.Clear()
      Next
      If lRemainLen > 0 Then
        ReDim tmpByte(lRemainLen - 1)
        NumByteRead = fs.Read(tmpByte, 0, lRemainLen)
        sChunk = sRemain & Encoding.ASCII.GetString(tmpByte)
        sChunk = Replace(sChunk, vbCrLf, vbLf)
        LineArray = Split(sChunk, vbLf)
        sChunk = ""
        UppInd = UBound(LineArray)
        For J = 0 To UppInd - 3 Step 4
          sName = Mid(LineArray(J), 2)
          sSeq = LineArray(J + 1)
          sb.Append(">" & sName & vbLf)
          sb.Append(sSeq & vbLf)
        Next
      End If
      File.AppendAllText(sFasFile, sb.ToString)
      sb.Clear()
      fs.Close()
    End If
    GC.Collect()
    ProgressBar1.Value = 0
    Return True
  End Function


  'sOut will contain the first 20 sequences
  'Parameters with 'Poor' suffix pertain to those sequences containing unresolved 'N'
  Function FastqInfo(ByVal sFastqFile As String, ByRef iTotalNumSeq As Integer, _
                    ByRef iMinSeqlen As Integer, ByRef iMaxSeqLen As Integer, ByRef FreqSeqLen() As Double, _
                    ByRef iMinQualityCh As Integer, ByRef iMaxQualityCh As Integer, ByRef FreqQualityCh() As Double, _
                    ByRef MinMeanQuality As Integer, ByRef MaxMeanQuality As Integer, ByRef FreqMeanQuality() As Integer, _
                    ByRef MeanQualBySiteAndNuc(,) As Double, ByRef StdQualBySiteAndNuc(,) As Double, ByRef NucFBySitereqBySite(,) As Integer, _
                    ByRef MinMeanQualityPoor As Integer, ByRef MaxMeanQualityPoor As Integer, ByRef FreqMeanQualityPoor() As Integer, _
                    ByRef MeanQualBySiteAndNucPoor(,) As Double, ByRef StdQualBySiteAndNucPoor(,) As Double, ByRef NucFBySitereqBySitePoor(,) As Integer, _
                    ByRef iNumSeqPoor As Integer, ByVal ToolStripLabel1 As ToolStripLabel, ByVal ProgressBar1 As ToolStripProgressBar) As Boolean
    'Process the file in chunks
    Dim I As Integer, J As Integer, lFileLen As Long, UppInd As Integer, NumN As Integer
    Dim sSeq As String
    Dim lChunkLen As Integer, lFreeMem As Long
    Dim sChunk As String, LineArray() As String
    Dim tmpByte() As Byte, QualityByte() As Byte
    Dim SumQualityBySiteAndNuc(84, 600) As Double, SumSqQualityBySiteAndNuc(84, 600) As Double
    Dim SumQualityBySiteAndNucPoor(84, 600) As Double, SumSqQualityBySiteAndNucPoor(84, 600) As Double
    Dim SeqByte() As Byte
    Dim NucFBySite(84, 600) As Double, NucFBySitePoor(84, 600) As Double
    Dim MeanQuality As Integer = 0
    Dim iSeqLen As Integer

    ReDim FreqQualityCh(126), FreqMeanQuality(126), FreqMeanQualityPoor(126) 'The quality characters are from ! to ~ (33 to 126)
    ReDim FreqSeqLen(1000) 'There should be no sequence with length longer than 1000
    ReDim MeanQualBySiteAndNuc(3, 600), StdQualBySiteAndNuc(3, 600), NucFBySitereqBySite(3, 600)
    ReDim MeanQualBySiteAndNucPoor(3, 600), StdQualBySiteAndNucPoor(3, 600), NucFBySitereqBySitePoor(3, 600)
    iMinSeqlen = 100
    iMaxSeqLen = 0

    Try
      lFreeMem = GetAvailablePhysicalMem()
    Catch ex As Exception
      MsgBox("Error Encountered in getting system memory!" & CRCR & ex.ToString, vbInformation, "Error")
      lFreeMem = 2000000000
    End Try

    lFileLen = FileLen(sFastqFile)
    lChunkLen = lFreeMem \ 1000
    iTotalNumSeq = 0
    ToolStripLabel1.Text = "Compiling quality statistics..."
    If lChunkLen > lFileLen Then
      sChunk = File.ReadAllText(sFastqFile)
      sChunk = Replace(sChunk, vbCrLf, vbLf)
      LineArray = Split(sChunk, vbLf)
      sChunk = ""
      UppInd = UBound(LineArray)

      ProgressBar1.Minimum = 0
      ProgressBar1.Maximum = UppInd
      For I = 0 To UppInd - 3 Step 4
        sSeq = LineArray(I + 1)
        SeqByte = Encoding.ASCII.GetBytes(sSeq)
        QualityByte = Encoding.ASCII.GetBytes(LineArray(I + 3))
        iSeqLen = sSeq.Length
        FreqSeqLen(iSeqLen) = FreqSeqLen(iSeqLen) + 1
        MeanQuality = 0
        NumN = sSeq.Count(Function(x) x = "N")
        If NumN = 0 Then
          For J = 0 To iSeqLen - 1
            FreqQualityCh(QualityByte(J)) = FreqQualityCh(QualityByte(J)) + 1
            MeanQuality = MeanQuality + QualityByte(J)
            SumQualityBySiteAndNuc(SeqByte(J), J) = SumQualityBySiteAndNuc(SeqByte(J), J) + QualityByte(J)
            SumSqQualityBySiteAndNuc(SeqByte(J), J) = SumSqQualityBySiteAndNuc(SeqByte(J), J) + CLng(QualityByte(J)) * CLng(QualityByte(J))
            NucFBySite(SeqByte(J), J) = NucFBySite(SeqByte(J), J) + 1
          Next
          MeanQuality = CInt(MeanQuality / iSeqLen + 0.5)
          FreqMeanQuality(MeanQuality) = FreqMeanQuality(MeanQuality) + 1
        Else
          For J = 0 To iSeqLen - 1
            If SeqByte(J) <> 78 Then 'not N
              MeanQuality = MeanQuality + QualityByte(J)
              SumQualityBySiteAndNucPoor(SeqByte(J), J) = SumQualityBySiteAndNucPoor(SeqByte(J), J) + QualityByte(J)
              SumSqQualityBySiteAndNucPoor(SeqByte(J), J) = SumSqQualityBySiteAndNucPoor(SeqByte(J), J) + CLng(QualityByte(J)) * CLng(QualityByte(J))
              NucFBySitePoor(SeqByte(J), J) = NucFBySitePoor(SeqByte(J), J) + 1
            End If
            MeanQuality = CInt(MeanQuality / (iSeqLen - NumN) + 0.5)
            FreqMeanQualityPoor(MeanQuality) = FreqMeanQualityPoor(MeanQuality) + 1
          Next
          iNumSeqPoor = iNumSeqPoor + 1
        End If
        iTotalNumSeq = iTotalNumSeq + 1
        ProgressBar1.Value = I
        Application.DoEvents()
      Next
    Else
      Dim K As Integer
      Dim fs As New FileStream(sFastqFile, FileMode.Open, FileAccess.Read)
      Dim NumByteRead As Integer, lNumChunk As Integer, lRemainLen As Integer, NumTrailingLine As Integer
      Dim sRemain As String = ""
      Dim tmpUppInd As Integer
      lNumChunk = lFileLen \ lChunkLen
      lRemainLen = lFileLen Mod lChunkLen

      ProgressBar1.Minimum = 0
      ProgressBar1.Maximum = lNumChunk
      For I = 0 To lNumChunk - 1
        ReDim tmpByte(lChunkLen - 1)
        NumByteRead = fs.Read(tmpByte, 0, lChunkLen)
        sChunk = sRemain & Encoding.ASCII.GetString(tmpByte)
        sChunk = Replace(sChunk, vbCrLf, vbLf)
        LineArray = Split(sChunk, vbLf)
        sChunk = ""
        UppInd = UBound(LineArray)
        NumTrailingLine = (UppInd + 1) Mod 4
        'ID-line & vbLf : break before vbLF --> NumTrainingLine = 1; after --> NumTrailingLine = 2
        'SeqLine & vbLf : break before vbLF --> NumTrainingLine = 2; after --> NumTrailingLine = 3
        '+Line & vbLf : break before vbLF --> NumTrainingLine = 3; after --> NumTrailingLine = 0
        'Quality-line & vbLf : break before vbLF --> NumTrainingLine = 0; after --> NumTrailingLine = 1

        Select Case NumTrailingLine
          Case 0
            'The last four line may be incomplete:
            'Two scenarios:
            '1. +Line & vbLF --> last line empty
            '2. +Line & vbLf & PartialQualityLine
            'In both cases it is fine to have
            sRemain = LineArray(UppInd - 3) & vbLf & LineArray(UppInd - 2) & vbLf & LineArray(UppInd - 1) & vbLf & LineArray(UppInd)
            tmpUppInd = UppInd - 7
          Case 1
            'Two scenarios:
            '1. last quality line is complete with vblf, in which case LineArray(UppInd)=""
            '2. last line is an incomplete @ID line
            'In both cases, it is fine to have
            sRemain = LineArray(UppInd)
            tmpUppInd = UppInd - 4
          Case 2
            'Two scenarios:
            '1. @ID...vbLf
            '2. @ID...vbLf & PartialSeq
            sRemain = LineArray(UppInd - 1) & vbLf & LineArray(UppInd)
            tmpUppInd = UppInd - 5
          Case 3
            'Two scenarios:
            '1. SeqLine & vbLf --> LineArray(UppInd)=""
            '2. SeqLine & vbLf & Partial +Line
            sRemain = LineArray(UppInd - 2) & vbCrLf & LineArray(UppInd - 1) & vbLf & LineArray(UppInd)
            tmpUppInd = UppInd - 6
        End Select

        For J = 0 To tmpUppInd Step 4
          sSeq = LineArray(J + 1)
          SeqByte = Encoding.ASCII.GetBytes(sSeq)
          QualityByte = Encoding.ASCII.GetBytes(LineArray(J + 3))
          iSeqLen = Len(sSeq)
          FreqSeqLen(iSeqLen) = FreqSeqLen(iSeqLen) + 1
          MeanQuality = 0
          NumN = sSeq.Count(Function(x) x = "N")
          If NumN = 0 Then
            For K = 0 To iSeqLen - 1
              FreqQualityCh(QualityByte(K)) = FreqQualityCh(QualityByte(K)) + 1
              MeanQuality = MeanQuality + QualityByte(K)
              SumQualityBySiteAndNuc(SeqByte(K), K) = SumQualityBySiteAndNuc(SeqByte(K), K) + QualityByte(K)
              SumSqQualityBySiteAndNuc(SeqByte(K), K) = SumSqQualityBySiteAndNuc(SeqByte(K), K) + CLng(QualityByte(K)) * CLng(QualityByte(K))
              NucFBySite(SeqByte(K), K) = NucFBySite(SeqByte(K), K) + 1
            Next
            MeanQuality = CInt(MeanQuality / iSeqLen + 0.5)
            FreqMeanQuality(MeanQuality) = FreqMeanQuality(MeanQuality) + 1
          Else
            For K = 0 To iSeqLen - 1
              MeanQuality = MeanQuality + QualityByte(K)
              SumQualityBySiteAndNucPoor(SeqByte(K), K) = SumQualityBySiteAndNucPoor(SeqByte(K), K) + QualityByte(K)
              SumSqQualityBySiteAndNucPoor(SeqByte(K), K) = SumSqQualityBySiteAndNucPoor(SeqByte(K), K) + CLng(QualityByte(K)) * CLng(QualityByte(K))
              NucFBySitePoor(SeqByte(K), K) = NucFBySitePoor(SeqByte(K), K) + 1
            Next
            MeanQuality = CInt(MeanQuality / iSeqLen + 0.5)
            FreqMeanQualityPoor(MeanQuality) = FreqMeanQualityPoor(MeanQuality) + 1
            iNumSeqPoor = iNumSeqPoor + 1
          End If
          iTotalNumSeq = iTotalNumSeq + 1
        Next
        ProgressBar1.Value = I
        Application.DoEvents()
      Next
      If lRemainLen > 0 Then
        ReDim tmpByte(lRemainLen - 1)
        NumByteRead = fs.Read(tmpByte, 0, lRemainLen)
        sChunk = sRemain & Encoding.ASCII.GetString(tmpByte)
        sChunk = Replace(sChunk, vbCrLf, vbLf)
        LineArray = Split(sChunk, vbLf)
        sChunk = ""
        UppInd = UBound(LineArray)
        For J = 0 To UppInd - 3 Step 4
          sSeq = LineArray(J + 1)
          QualityByte = Encoding.ASCII.GetBytes(LineArray(J + 3))
          SeqByte = Encoding.ASCII.GetBytes(sSeq)
          iSeqLen = sSeq.Length
          FreqSeqLen(iSeqLen) = FreqSeqLen(iSeqLen) + 1
          MeanQuality = 0
          NumN = sSeq.Count(Function(x) x = "N")
          If NumN = 0 Then
            For K = 0 To iSeqLen - 1
              FreqQualityCh(QualityByte(K)) = FreqQualityCh(QualityByte(K)) + 1
              MeanQuality = MeanQuality + QualityByte(K)
              SumQualityBySiteAndNuc(SeqByte(K), K) = SumQualityBySiteAndNuc(SeqByte(K), K) + QualityByte(K)
              SumSqQualityBySiteAndNuc(SeqByte(K), K) = SumSqQualityBySiteAndNuc(SeqByte(K), K) + CLng(QualityByte(K)) * CLng(QualityByte(K))
              NucFBySite(SeqByte(K), K) = NucFBySite(SeqByte(K), K) + 1
            Next
            MeanQuality = CInt(MeanQuality / iSeqLen + 0.5)
            FreqMeanQuality(MeanQuality) = FreqMeanQuality(MeanQuality) + 1
          Else
            For K = 0 To iSeqLen - 1
              MeanQuality = MeanQuality + QualityByte(K)
              SumQualityBySiteAndNucPoor(SeqByte(K), K) = SumQualityBySiteAndNucPoor(SeqByte(K), K) + QualityByte(K)
              SumSqQualityBySiteAndNucPoor(SeqByte(K), K) = SumSqQualityBySiteAndNucPoor(SeqByte(K), K) + CLng(QualityByte(K)) * CLng(QualityByte(K))
              NucFBySitePoor(SeqByte(K), K) = NucFBySitePoor(SeqByte(K), K) + 1
            Next
            MeanQuality = CInt(MeanQuality / iSeqLen + 0.5)
            FreqMeanQualityPoor(MeanQuality) = FreqMeanQualityPoor(MeanQuality) + 1
            iNumSeqPoor = iNumSeqPoor + 1
          End If
          iTotalNumSeq = iTotalNumSeq + 1
        Next
      End If
      fs.Close()
    End If
    ProgressBar1.Value = 0

    'Quality character distribution
    ToolStripLabel1.Text = "Nucleotide-based and sequence-based quality stats..."
    For I = 33 To 126
      If FreqQualityCh(I) > 0 Then
        iMinQualityCh = I
        Exit For
      End If
    Next
    For I = 126 To iMinQualityCh Step -1
      If FreqQualityCh(I) > 0 Then
        iMaxQualityCh = I
        Exit For
      End If
    Next

    'Sequence quality distribution
    For I = iMinQualityCh To iMaxQualityCh
      If FreqMeanQuality(I) > 0 Then
        MinMeanQuality = I
        Exit For
      End If
    Next
    For I = iMaxQualityCh To iMinQualityCh Step -1
      If FreqMeanQuality(I) > 0 Then
        MaxMeanQuality = I
        Exit For
      End If
    Next

    'Sequence quality distribution (those containing N)
    For I = iMinQualityCh To iMaxQualityCh
      If FreqMeanQualityPoor(I) > 0 Then
        MinMeanQualityPoor = I
        Exit For
      End If
    Next
    For I = iMaxQualityCh To iMinQualityCh Step -1
      If FreqMeanQualityPoor(I) > 0 Then
        MaxMeanQualityPoor = I
        Exit For
      End If
    Next

    'Length distribution
    For I = 10 To 1000
      If FreqSeqLen(I) > 0 Then
        iMinSeqlen = I
        Exit For
      End If
    Next
    For I = 1000 To iMinSeqlen Step -1
      If FreqSeqLen(I) > 0 Then
        iMaxSeqLen = I
        Exit For
      End If
    Next

    For I = 0 To iMaxSeqLen - 1
      NucFBySitereqBySite(0, I) = NucFBySite(65, I)
      NucFBySitereqBySite(1, I) = NucFBySite(67, I)
      NucFBySitereqBySite(2, I) = NucFBySite(71, I)
      NucFBySitereqBySite(3, I) = NucFBySite(84, I)
      NucFBySitereqBySitePoor(0, I) = NucFBySitePoor(65, I)
      NucFBySitereqBySitePoor(1, I) = NucFBySitePoor(67, I)
      NucFBySitereqBySitePoor(2, I) = NucFBySitePoor(71, I)
      NucFBySitereqBySitePoor(3, I) = NucFBySitePoor(84, I)

      MeanQualBySiteAndNuc(0, I) = SumQualityBySiteAndNuc(65, I) / NucFBySitereqBySite(0, I)
      MeanQualBySiteAndNuc(1, I) = SumQualityBySiteAndNuc(67, I) / NucFBySitereqBySite(1, I)
      MeanQualBySiteAndNuc(2, I) = SumQualityBySiteAndNuc(71, I) / NucFBySitereqBySite(2, I)
      MeanQualBySiteAndNuc(3, I) = SumQualityBySiteAndNuc(84, I) / NucFBySitereqBySite(3, I)
      'Var = (NumCase * SumX2 - SumX ^ 2) / (NumCase * (NumCase - 1)) which does not use the mean
      'Var = (SumSqX - N * mean^2)/(N-1)
      StdQualBySiteAndNuc(0, I) = (SumSqQualityBySiteAndNuc(65, I) - NucFBySitereqBySite(0, I) * MeanQualBySiteAndNuc(0, I) * MeanQualBySiteAndNuc(0, I)) / (NucFBySitereqBySite(0, I) - 1)
      StdQualBySiteAndNuc(1, I) = (SumSqQualityBySiteAndNuc(67, I) - NucFBySitereqBySite(1, I) * MeanQualBySiteAndNuc(1, I) * MeanQualBySiteAndNuc(1, I)) / (NucFBySitereqBySite(1, I) - 1)
      StdQualBySiteAndNuc(2, I) = (SumSqQualityBySiteAndNuc(71, I) - NucFBySitereqBySite(2, I) * MeanQualBySiteAndNuc(2, I) * MeanQualBySiteAndNuc(2, I)) / (NucFBySitereqBySite(2, I) - 1)
      StdQualBySiteAndNuc(3, I) = (SumSqQualityBySiteAndNuc(84, I) - NucFBySitereqBySite(3, I) * MeanQualBySiteAndNuc(3, I) * MeanQualBySiteAndNuc(3, I)) / (NucFBySitereqBySite(3, I) - 1)
      StdQualBySiteAndNuc(0, I) = Math.Sqrt(StdQualBySiteAndNuc(0, I))
      StdQualBySiteAndNuc(1, I) = Math.Sqrt(StdQualBySiteAndNuc(1, I))
      StdQualBySiteAndNuc(2, I) = Math.Sqrt(StdQualBySiteAndNuc(2, I))
      StdQualBySiteAndNuc(3, I) = Math.Sqrt(StdQualBySiteAndNuc(3, I))

      MeanQualBySiteAndNucPoor(0, I) = SumQualityBySiteAndNucPoor(65, I) / NucFBySitereqBySitePoor(0, I)
      MeanQualBySiteAndNucPoor(1, I) = SumQualityBySiteAndNucPoor(67, I) / NucFBySitereqBySitePoor(1, I)
      MeanQualBySiteAndNucPoor(2, I) = SumQualityBySiteAndNucPoor(71, I) / NucFBySitereqBySitePoor(2, I)
      MeanQualBySiteAndNucPoor(3, I) = SumQualityBySiteAndNucPoor(84, I) / NucFBySitereqBySitePoor(3, I)
      StdQualBySiteAndNucPoor(0, I) = (SumSqQualityBySiteAndNucPoor(65, I) - NucFBySitereqBySitePoor(0, I) * MeanQualBySiteAndNucPoor(0, I) * MeanQualBySiteAndNucPoor(0, I)) / (NucFBySitereqBySitePoor(0, I) - 1)
      StdQualBySiteAndNucPoor(1, I) = (SumSqQualityBySiteAndNucPoor(67, I) - NucFBySitereqBySitePoor(1, I) * MeanQualBySiteAndNucPoor(1, I) * MeanQualBySiteAndNucPoor(1, I)) / (NucFBySitereqBySitePoor(1, I) - 1)
      StdQualBySiteAndNucPoor(2, I) = (SumSqQualityBySiteAndNucPoor(71, I) - NucFBySitereqBySitePoor(2, I) * MeanQualBySiteAndNucPoor(2, I) * MeanQualBySiteAndNucPoor(2, I)) / (NucFBySitereqBySitePoor(2, I) - 1)
      StdQualBySiteAndNucPoor(3, I) = (SumSqQualityBySiteAndNucPoor(84, I) - NucFBySitereqBySitePoor(3, I) * MeanQualBySiteAndNucPoor(3, I) * MeanQualBySiteAndNucPoor(3, I)) / (NucFBySitereqBySitePoor(3, I) - 1)
      StdQualBySiteAndNucPoor(0, I) = Math.Sqrt(StdQualBySiteAndNucPoor(0, I))
      StdQualBySiteAndNucPoor(1, I) = Math.Sqrt(StdQualBySiteAndNucPoor(1, I))
      StdQualBySiteAndNucPoor(2, I) = Math.Sqrt(StdQualBySiteAndNucPoor(2, I))
      StdQualBySiteAndNucPoor(3, I) = Math.Sqrt(StdQualBySiteAndNucPoor(3, I))
    Next
    ToolStripLabel1.Text = ""
    ProgressBar1.Value = 0
    Return True
  End Function

  'Function FastqInfoMultThread(ByVal sFastqFile As String, ByRef iTotalNumSeq As Integer, _
  '                ByRef iMinSeqlen As Integer, ByRef iMaxSeqLen As Integer, ByRef FreqSeqLen() As Integer, _
  '                ByRef iMinQualityCh As Integer, ByRef iMaxQualityCh As Integer, ByRef FreqQualCh() As Integer, _
  '                ByRef MinMeanQuality As Integer, ByRef MaxMeanQuality As Integer, ByRef FreqMeanQuality() As Integer, _
  '                ByRef MeanQualBySiteAndNuc(,) As Double, ByRef StdQualBySiteAndNuc(,) As Double, ByRef NucFBySitereqBySite(,) As Integer, _
  '                ByRef MinMeanQualityPoor As Integer, ByRef MaxMeanQualityPoor As Integer, ByRef FreqMeanQualityPoor() As Integer, _
  '                ByRef MeanQualBySiteAndNucPoor(,) As Double, ByRef StdQualBySiteAndNucPoor(,) As Double, ByRef NucFBySitereqBySitePoor(,) As Integer, _
  '                ByRef iNumSeqPoor As Integer, ByVal ToolStripLabel1 As ToolStripLabel, ByVal ProgressBar1 As ToolStripProgressBar, Optional ByVal iNumThread As Integer = 2) As Boolean
  '  'Process the file in chunks
  '  Dim I As Integer, J As Integer, lFileLen As Long, UppInd As Integer, NumN As Integer
  '  Dim sSeq As String, LineArray() As String
  '  Dim lChunkLen As Integer, lFreeMem As Long
  '  Dim sChunk As String
  '  Dim SumQualityBySiteAndNuc(84, 600) As Double, SumSqQualityBySiteAndNuc(84, 600) As Double 'First dimension up to T
  '  Dim SumQualityBySiteAndNucPoor(84, 600) As Double, SumSqQualityBySiteAndNucPoor(84, 600) As Double
  '  Dim MeanQuality As Integer = 0
  '  Dim tmpByte() As Byte
  '  ReDim FreqQualCh(126), FreqMeanQuality(126), FreqMeanQualityPoor(126) 'The quality characters are from ! to ~ (33 to 126)
  '  ReDim FreqSeqLen(1000) 'There should be no sequence with length longer than 1000
  '  ReDim MeanQualBySiteAndNuc(3, 600), StdQualBySiteAndNuc(3, 600), NucFBySitereqBySite(3, 600)
  '  ReDim MeanQualBySiteAndNucPoor(3, 600), StdQualBySiteAndNucPoor(3, 600), NucFBySitereqBySitePoor(3, 600)
  '  iMinSeqlen = 100
  '  iMaxSeqLen = 0

  '  lFreeMem = My.Computer.Info.AvailablePhysicalMemory
  '  lFileLen = FileLen(sFastqFile)
  '  lChunkLen = lFreeMem \ 1000
  '  iTotalNumSeq = 0
  '  ToolStripLabel1.Text = "Compiling quality statistics..."
  '  Dim K As Integer
  '  Dim fs As New FileStream(sFastqFile, FileMode.Open, FileAccess.Read)
  '  Dim NumByteRead As Integer, lNumChunk As Integer, lRemainLen As Integer, NumTrailingLine As Integer
  '  Dim sRemain As String = ""
  '  Dim tmpUppInd As Integer
  '  lNumChunk = lFileLen \ lChunkLen
  '  lRemainLen = lFileLen Mod lChunkLen

  '  ProgressBar1.Minimum = 0
  '  ProgressBar1.Maximum = lNumChunk
  '  For I = 0 To lNumChunk - 1
  '    ReDim tmpByte(lChunkLen - 1)
  '    NumByteRead = fs.Read(tmpByte, 0, lChunkLen)
  '    sChunk = sRemain & Encoding.ASCII.GetString(tmpByte)
  '    sChunk = Replace(sChunk, vbCrLf, vbLf)
  '    LineArray = Split(sChunk, vbLf)
  '    sChunk = ""
  '    UppInd = UBound(LineArray)
  '    NumTrailingLine = (UppInd + 1) Mod 4
  '    'ID-line & vbLf : break before vbLF --> NumTrainingLine = 1; after --> NumTrailingLine = 2
  '    'SeqLine & vbLf : break before vbLF --> NumTrainingLine = 2; after --> NumTrailingLine = 3
  '    '+Line & vbLf : break before vbLF --> NumTrainingLine = 3; after --> NumTrailingLine = 0
  '    'Quality-line & vbLf : break before vbLF --> NumTrainingLine = 0; after --> NumTrailingLine = 1

  '    Select Case NumTrailingLine
  '      Case 0
  '        'The last four line may be incomplete:
  '        'Two scenarios:
  '        '1. +Line & vbLF --> last line empty
  '        '2. +Line & vbLf & PartialQualityLine
  '        'In both cases it is fine to have
  '        sRemain = LineArray(UppInd - 3) & vbLf & LineArray(UppInd - 2) & vbLf & LineArray(UppInd - 1) & vbLf & LineArray(UppInd)
  '        tmpUppInd = UppInd - 7
  '      Case 1
  '        'Two scenarios:
  '        '1. last quality line is complete with vblf, in which case LineArray(UppInd)=""
  '        '2. last line is an incomplete @ID line
  '        'In both cases, it is fine to have
  '        sRemain = LineArray(UppInd)
  '        tmpUppInd = UppInd - 4
  '      Case 2
  '        'Two scenarios:
  '        '1. @ID...vbLf
  '        '2. @ID...vbLf & PartialSeq
  '        sRemain = LineArray(UppInd - 1) & vbLf & LineArray(UppInd)
  '        tmpUppInd = UppInd - 5
  '      Case 3
  '        'Two scenarios:
  '        '1. SeqLine & vbLf --> LineArray(UppInd)=""
  '        '2. SeqLine & vbLf & Partial +Line
  '        sRemain = LineArray(UppInd - 2) & vbCrLf & LineArray(UppInd - 1) & vbLf & LineArray(UppInd)
  '        tmpUppInd = UppInd - 6
  '    End Select

  '    InfoChunk(LineArray, UppInd, FreqQualCh, SumQualityBySiteAndNucChunk)
  '    For J = 0 To tmpUppInd Step 4
  '      sSeq = LineArray(J + 1)
  '      SeqByte = Encoding.ASCII.GetBytes(sSeq)
  '      QualityByte = Encoding.ASCII.GetBytes(LineArray(J + 3))
  '      iSeqLen = Len(sSeq)
  '      FreqSeqLen(iSeqLen) = FreqSeqLen(iSeqLen) + 1
  '      MeanQuality = 0
  '      NumN = sSeq.Count(Function(x) x = "N")
  '      If NumN = 0 Then
  '        For K = 0 To iSeqLen - 1
  '          FreqQualCh(QualityByte(K)) = FreqQualCh(QualityByte(K)) + 1
  '          MeanQuality = MeanQuality + QualityByte(K)
  '          SumQualityBySiteAndNuc(SeqByte(K), K) = SumQualityBySiteAndNuc(SeqByte(K), K) + QualityByte(K)
  '          SumSqQualityBySiteAndNuc(SeqByte(K), K) = SumSqQualityBySiteAndNuc(SeqByte(K), K) + CLng(QualityByte(K)) * CLng(QualityByte(K))
  '          NucFBySite(SeqByte(K), K) = NucFBySite(SeqByte(K), K) + 1
  '        Next
  '        MeanQuality = CInt(MeanQuality / iSeqLen + 0.5)
  '        FreqMeanQuality(MeanQuality) = FreqMeanQuality(MeanQuality) + 1
  '      Else
  '        For K = 0 To iSeqLen - 1
  '          MeanQuality = MeanQuality + QualityByte(K)
  '          SumQualityBySiteAndNucPoor(SeqByte(K), K) = SumQualityBySiteAndNucPoor(SeqByte(K), K) + QualityByte(K)
  '          SumSqQualityBySiteAndNucPoor(SeqByte(K), K) = SumSqQualityBySiteAndNucPoor(SeqByte(K), K) + CLng(QualityByte(K)) * CLng(QualityByte(K))
  '          NucFBySitePoor(SeqByte(K), K) = NucFBySitePoor(SeqByte(K), K) + 1
  '        Next
  '        MeanQuality = CInt(MeanQuality / iSeqLen + 0.5)
  '        FreqMeanQualityPoor(MeanQuality) = FreqMeanQualityPoor(MeanQuality) + 1
  '        iNumSeqPoor = iNumSeqPoor + 1
  '      End If
  '      iTotalNumSeq = iTotalNumSeq + 1
  '    Next
  '    ProgressBar1.Value = I
  '    Application.DoEvents()
  '  Next
  '  If lRemainLen > 0 Then
  '    ReDim tmpByte(lRemainLen - 1)
  '    NumByteRead = fs.Read(tmpByte, 0, lRemainLen)
  '    sChunk = sRemain & Encoding.ASCII.GetString(tmpByte)
  '    sChunk = Replace(sChunk, vbCrLf, vbLf)
  '    LineArray = Split(sChunk, vbLf)
  '    sChunk = ""
  '    UppInd = UBound(LineArray)
  '    For J = 0 To UppInd - 3 Step 4
  '      sSeq = LineArray(J + 1)
  '      QualityByte = Encoding.ASCII.GetBytes(LineArray(J + 3))
  '      SeqByte = Encoding.ASCII.GetBytes(sSeq)
  '      iSeqLen = sSeq.Length
  '      FreqSeqLen(iSeqLen) = FreqSeqLen(iSeqLen) + 1
  '      MeanQuality = 0
  '      NumN = sSeq.Count(Function(x) x = "N")
  '      If NumN = 0 Then
  '        For K = 0 To iSeqLen - 1
  '          FreqQualCh(QualityByte(K)) = FreqQualCh(QualityByte(K)) + 1
  '          MeanQuality = MeanQuality + QualityByte(K)
  '          SumQualityBySiteAndNuc(SeqByte(K), K) = SumQualityBySiteAndNuc(SeqByte(K), K) + QualityByte(K)
  '          SumSqQualityBySiteAndNuc(SeqByte(K), K) = SumSqQualityBySiteAndNuc(SeqByte(K), K) + CLng(QualityByte(K)) * CLng(QualityByte(K))
  '          NucFBySite(SeqByte(K), K) = NucFBySite(SeqByte(K), K) + 1
  '        Next
  '        MeanQuality = CInt(MeanQuality / iSeqLen + 0.5)
  '        FreqMeanQuality(MeanQuality) = FreqMeanQuality(MeanQuality) + 1
  '      Else
  '        For K = 0 To iSeqLen - 1
  '          MeanQuality = MeanQuality + QualityByte(K)
  '          SumQualityBySiteAndNucPoor(SeqByte(K), K) = SumQualityBySiteAndNucPoor(SeqByte(K), K) + QualityByte(K)
  '          SumSqQualityBySiteAndNucPoor(SeqByte(K), K) = SumSqQualityBySiteAndNucPoor(SeqByte(K), K) + CLng(QualityByte(K)) * CLng(QualityByte(K))
  '          NucFBySitePoor(SeqByte(K), K) = NucFBySitePoor(SeqByte(K), K) + 1
  '        Next
  '        MeanQuality = CInt(MeanQuality / iSeqLen + 0.5)
  '        FreqMeanQualityPoor(MeanQuality) = FreqMeanQualityPoor(MeanQuality) + 1
  '        iNumSeqPoor = iNumSeqPoor + 1
  '      End If
  '      iTotalNumSeq = iTotalNumSeq + 1
  '    Next
  '  End If
  '  fs.Close()
  '  ProgressBar1.Value = 0

  '  'Quality character distribution
  '  ToolStripLabel1.Text = "Nucleotide-based and sequence-based quality stats..."
  '  For I = 33 To 126
  '    If FreqQualCh(I) > 0 Then
  '      iMinQualityCh = I
  '      Exit For
  '    End If
  '  Next
  '  For I = 126 To iMinQualityCh Step -1
  '    If FreqQualCh(I) > 0 Then
  '      iMaxQualityCh = I
  '      Exit For
  '    End If
  '  Next

  '  'Sequence quality distribution
  '  For I = iMinQualityCh To iMaxQualityCh
  '    If FreqMeanQuality(I) > 0 Then
  '      MinMeanQuality = I
  '      Exit For
  '    End If
  '  Next
  '  For I = iMaxQualityCh To iMinQualityCh Step -1
  '    If FreqMeanQuality(I) > 0 Then
  '      MaxMeanQuality = I
  '      Exit For
  '    End If
  '  Next

  '  'Sequence quality distribution (those containing N)
  '  For I = iMinQualityCh To iMaxQualityCh
  '    If FreqMeanQualityPoor(I) > 0 Then
  '      MinMeanQualityPoor = I
  '      Exit For
  '    End If
  '  Next
  '  For I = iMaxQualityCh To iMinQualityCh Step -1
  '    If FreqMeanQualityPoor(I) > 0 Then
  '      MaxMeanQualityPoor = I
  '      Exit For
  '    End If
  '  Next

  '  'Length distribution
  '  For I = 10 To 1000
  '    If FreqSeqLen(I) > 0 Then
  '      iMinSeqlen = I
  '      Exit For
  '    End If
  '  Next
  '  For I = 1000 To iMinSeqlen Step -1
  '    If FreqSeqLen(I) > 0 Then
  '      iMaxSeqLen = I
  '      Exit For
  '    End If
  '  Next

  '  For I = 0 To iMaxSeqLen - 1
  '    NucFBySitereqBySite(0, I) = NucFBySite(65, I)
  '    NucFBySitereqBySite(1, I) = NucFBySite(67, I)
  '    NucFBySitereqBySite(2, I) = NucFBySite(71, I)
  '    NucFBySitereqBySite(3, I) = NucFBySite(84, I)
  '    NucFBySitereqBySitePoor(0, I) = NucFBySitePoor(65, I)
  '    NucFBySitereqBySitePoor(1, I) = NucFBySitePoor(67, I)
  '    NucFBySitereqBySitePoor(2, I) = NucFBySitePoor(71, I)
  '    NucFBySitereqBySitePoor(3, I) = NucFBySitePoor(84, I)

  '    MeanQualBySiteAndNuc(0, I) = SumQualityBySiteAndNuc(65, I) / NucFBySitereqBySite(0, I)
  '    MeanQualBySiteAndNuc(1, I) = SumQualityBySiteAndNuc(67, I) / NucFBySitereqBySite(1, I)
  '    MeanQualBySiteAndNuc(2, I) = SumQualityBySiteAndNuc(71, I) / NucFBySitereqBySite(2, I)
  '    MeanQualBySiteAndNuc(3, I) = SumQualityBySiteAndNuc(84, I) / NucFBySitereqBySite(3, I)
  '    'Var = (NumCase * SumX2 - SumX ^ 2) / (NumCase * (NumCase - 1)) which does not use the mean
  '    'Var = (SumSqX - N * mean^2)/(N-1)
  '    StdQualBySiteAndNuc(0, I) = (SumSqQualityBySiteAndNuc(65, I) - NucFBySitereqBySite(0, I) * MeanQualBySiteAndNuc(0, I) * MeanQualBySiteAndNuc(0, I)) / (NucFBySitereqBySite(0, I) - 1)
  '    StdQualBySiteAndNuc(1, I) = (SumSqQualityBySiteAndNuc(67, I) - NucFBySitereqBySite(1, I) * MeanQualBySiteAndNuc(1, I) * MeanQualBySiteAndNuc(1, I)) / (NucFBySitereqBySite(1, I) - 1)
  '    StdQualBySiteAndNuc(2, I) = (SumSqQualityBySiteAndNuc(71, I) - NucFBySitereqBySite(2, I) * MeanQualBySiteAndNuc(2, I) * MeanQualBySiteAndNuc(2, I)) / (NucFBySitereqBySite(2, I) - 1)
  '    StdQualBySiteAndNuc(3, I) = (SumSqQualityBySiteAndNuc(84, I) - NucFBySitereqBySite(3, I) * MeanQualBySiteAndNuc(3, I) * MeanQualBySiteAndNuc(3, I)) / (NucFBySitereqBySite(3, I) - 1)
  '    StdQualBySiteAndNuc(0, I) = Math.Sqrt(StdQualBySiteAndNuc(0, I))
  '    StdQualBySiteAndNuc(1, I) = Math.Sqrt(StdQualBySiteAndNuc(1, I))
  '    StdQualBySiteAndNuc(2, I) = Math.Sqrt(StdQualBySiteAndNuc(2, I))
  '    StdQualBySiteAndNuc(3, I) = Math.Sqrt(StdQualBySiteAndNuc(3, I))

  '    MeanQualBySiteAndNucPoor(0, I) = SumQualityBySiteAndNucPoor(65, I) / NucFBySitereqBySitePoor(0, I)
  '    MeanQualBySiteAndNucPoor(1, I) = SumQualityBySiteAndNucPoor(67, I) / NucFBySitereqBySitePoor(1, I)
  '    MeanQualBySiteAndNucPoor(2, I) = SumQualityBySiteAndNucPoor(71, I) / NucFBySitereqBySitePoor(2, I)
  '    MeanQualBySiteAndNucPoor(3, I) = SumQualityBySiteAndNucPoor(84, I) / NucFBySitereqBySitePoor(3, I)
  '    StdQualBySiteAndNucPoor(0, I) = (SumSqQualityBySiteAndNucPoor(65, I) - NucFBySitereqBySitePoor(0, I) * MeanQualBySiteAndNucPoor(0, I) * MeanQualBySiteAndNucPoor(0, I)) / (NucFBySitereqBySitePoor(0, I) - 1)
  '    StdQualBySiteAndNucPoor(1, I) = (SumSqQualityBySiteAndNucPoor(67, I) - NucFBySitereqBySitePoor(1, I) * MeanQualBySiteAndNucPoor(1, I) * MeanQualBySiteAndNucPoor(1, I)) / (NucFBySitereqBySitePoor(1, I) - 1)
  '    StdQualBySiteAndNucPoor(2, I) = (SumSqQualityBySiteAndNucPoor(71, I) - NucFBySitereqBySitePoor(2, I) * MeanQualBySiteAndNucPoor(2, I) * MeanQualBySiteAndNucPoor(2, I)) / (NucFBySitereqBySitePoor(2, I) - 1)
  '    StdQualBySiteAndNucPoor(3, I) = (SumSqQualityBySiteAndNucPoor(84, I) - NucFBySitereqBySitePoor(3, I) * MeanQualBySiteAndNucPoor(3, I) * MeanQualBySiteAndNucPoor(3, I)) / (NucFBySitereqBySitePoor(3, I) - 1)
  '    StdQualBySiteAndNucPoor(0, I) = Math.Sqrt(StdQualBySiteAndNucPoor(0, I))
  '    StdQualBySiteAndNucPoor(1, I) = Math.Sqrt(StdQualBySiteAndNucPoor(1, I))
  '    StdQualBySiteAndNucPoor(2, I) = Math.Sqrt(StdQualBySiteAndNucPoor(2, I))
  '    StdQualBySiteAndNucPoor(3, I) = Math.Sqrt(StdQualBySiteAndNucPoor(3, I))
  '  Next
  '  ToolStripLabel1.Text = ""
  '  ProgressBar1.Value = 0
  '  Return True
  'End Function

  'Private Function InfoChunk(ByVal sChunk As String, ByRef sRemain As String)
  '  Dim I As Integer, J As Integer, K As Integer, lFileLen As Long, UppInd As Integer, NumN As Integer
  '  Dim sSeq As String
  '  Dim LineArray() As String
  '  Dim tmpByte() As Byte, QualityByte() As Byte
  '  Dim SumQualityBySiteAndNuc(84, 600) As Double, SumSqQualityBySiteAndNuc(84, 600) As Double
  '  Dim SumQualityBySiteAndNucPoor(84, 600) As Double, SumSqQualityBySiteAndNucPoor(84, 600) As Double
  '  Dim SeqByte() As Byte
  '  Dim NucFBySite(84, 600) As Double, NucFBySitePoor(84, 600) As Double
  '  Dim MeanQuality As Integer = 0
  '  Dim iSeqLen As Integer
  '  Dim NumByteRead As Integer, lNumChunk As Integer, lRemainLen As Integer, NumTrailingLine As Integer
  '  Dim tmpUppInd As Integer

  '  Dim Thread() As System.Threading.Thread
  '  ReDim Thread(iNumThread - 1)

  '  ReDim FreqQualityCh(126), FreqMeanQuality(126), FreqMeanQualityPoor(126) 'The quality characters are from ! to ~ (33 to 126)
  '  ReDim FreqSeqLen(1000) 'There should be no sequence with length longer than 1000
  '  ReDim MeanQualBySiteAndNuc(3, 600), StdQualBySiteAndNuc(3, 600), NucFBySitereqBySite(3, 600)
  '  ReDim MeanQualBySiteAndNucPoor(3, 600), StdQualBySiteAndNucPoor(3, 600), NucFBySitereqBySitePoor(3, 600)

  '  LineArray = Split(sChunk, vbLf)
  '  sChunk = ""
  '  UppInd = UBound(LineArray)
  '  NumTrailingLine = (UppInd + 1) Mod 4
  '  'ID-line & vbLf : break before vbLF --> NumTrainingLine = 1; after --> NumTrailingLine = 2
  '  'SeqLine & vbLf : break before vbLF --> NumTrainingLine = 2; after --> NumTrailingLine = 3
  '  '+Line & vbLf : break before vbLF --> NumTrainingLine = 3; after --> NumTrailingLine = 0
  '  'Quality-line & vbLf : break before vbLF --> NumTrainingLine = 0; after --> NumTrailingLine = 1

  '  Select Case NumTrailingLine
  '    Case 0
  '      'The last four line may be incomplete:
  '      'Two scenarios:
  '      '1. +Line & vbLF --> last line empty
  '      '2. +Line & vbLf & PartialQualityLine
  '      'In both cases it is fine to have
  '      sRemain = LineArray(UppInd - 3) & vbLf & LineArray(UppInd - 2) & vbLf & LineArray(UppInd - 1) & vbLf & LineArray(UppInd)
  '      tmpUppInd = UppInd - 7
  '    Case 1
  '      'Two scenarios:
  '      '1. last quality line is complete with vblf, in which case LineArray(UppInd)=""
  '      '2. last line is an incomplete @ID line
  '      'In both cases, it is fine to have
  '      sRemain = LineArray(UppInd)
  '      tmpUppInd = UppInd - 4
  '    Case 2
  '      'Two scenarios:
  '      '1. @ID...vbLf
  '      '2. @ID...vbLf & PartialSeq
  '      sRemain = LineArray(UppInd - 1) & vbLf & LineArray(UppInd)
  '      tmpUppInd = UppInd - 5
  '    Case 3
  '      'Two scenarios:
  '      '1. SeqLine & vbLf --> LineArray(UppInd)=""
  '      '2. SeqLine & vbLf & Partial +Line
  '      sRemain = LineArray(UppInd - 2) & vbCrLf & LineArray(UppInd - 1) & vbLf & LineArray(UppInd)
  '      tmpUppInd = UppInd - 6
  '  End Select

  '  For J = 0 To tmpUppInd Step 4
  '    sSeq = LineArray(J + 1)
  '    SeqByte = Encoding.ASCII.GetBytes(sSeq)
  '    QualityByte = Encoding.ASCII.GetBytes(LineArray(J + 3))
  '    iSeqLen = Len(sSeq)
  '    FreqSeqLen(iSeqLen) = FreqSeqLen(iSeqLen) + 1
  '    MeanQuality = 0
  '    NumN = sSeq.Count(Function(x) x = "N")
  '    If NumN = 0 Then
  '      For K = 0 To iSeqLen - 1
  '        FreqQualityCh(QualityByte(K)) = FreqQualityCh(QualityByte(K)) + 1
  '        MeanQuality = MeanQuality + QualityByte(K)
  '        SumQualityBySiteAndNuc(SeqByte(K), K) = SumQualityBySiteAndNuc(SeqByte(K), K) + QualityByte(K)
  '        SumSqQualityBySiteAndNuc(SeqByte(K), K) = SumSqQualityBySiteAndNuc(SeqByte(K), K) + CLng(QualityByte(K)) * CLng(QualityByte(K))
  '        NucFBySite(SeqByte(K), K) = NucFBySite(SeqByte(K), K) + 1
  '      Next
  '      MeanQuality = CInt(MeanQuality / iSeqLen + 0.5)
  '      FreqMeanQuality(MeanQuality) = FreqMeanQuality(MeanQuality) + 1
  '    Else
  '      For K = 0 To iSeqLen - 1
  '        MeanQuality = MeanQuality + QualityByte(K)
  '        SumQualityBySiteAndNucPoor(SeqByte(K), K) = SumQualityBySiteAndNucPoor(SeqByte(K), K) + QualityByte(K)
  '        SumSqQualityBySiteAndNucPoor(SeqByte(K), K) = SumSqQualityBySiteAndNucPoor(SeqByte(K), K) + CLng(QualityByte(K)) * CLng(QualityByte(K))
  '        NucFBySitePoor(SeqByte(K), K) = NucFBySitePoor(SeqByte(K), K) + 1
  '      Next
  '      MeanQuality = CInt(MeanQuality / iSeqLen + 0.5)
  '      FreqMeanQualityPoor(MeanQuality) = FreqMeanQualityPoor(MeanQuality) + 1
  '      iNumSeqPoor = iNumSeqPoor + 1
  '    End If
  '    iTotalNumSeq = iTotalNumSeq + 1
  '  Next
  'End Function
  'Be very careful in reading FASTQ in chunks, which essentally has no clear boundary, with both @ and + used as quality characters and can occur at the beginning of a line.
  Function FastqToFasPlus(ByVal sFastqFile As String, ByVal sFasFile As String, ByRef sOut As String, _
                       ByRef iNumUniqueSeq As Integer, ByRef iNumUniqueGrSize As Integer, ByRef dblUniqueGrSize() As Double, ByRef dblFreqGrSize() As Double, _
                       ByVal bNoAmbiguousNuc As Boolean, ByVal ProgressBar1 As ToolStripProgressBar) As Boolean
    'Process the file in chunks
    Dim I As Integer, J As Integer, lFileLen As Long, UppInd As Integer, TotalNumSeq As Integer
    Dim sSeq As String
    Dim lChunkLen As Integer, lFreeMem As Long
    Dim sChunk As String, LineArray() As String
    Dim tmpByte() As Byte
    Dim dictSeq As New Dictionary(Of String, Integer)
    Dim dictFreq As New Dictionary(Of Integer, Integer)
    Dim sb As New StringBuilder
    Dim Value As Integer
    Dim Pair As KeyValuePair(Of String, Integer)
    Dim Pair2 As KeyValuePair(Of Integer, Integer)

    Try
      lFreeMem = GetAvailablePhysicalMem()
    Catch ex As Exception
      MsgBox("Error Encountered in getting system memory!" & CRCR & ex.ToString, vbInformation, "Error")
      lFreeMem = 2000000000
    End Try

    lFileLen = FileLen(sFastqFile)
    lChunkLen = lFreeMem \ 1000
    If lChunkLen > lFileLen Then
      sChunk = File.ReadAllText(sFastqFile)
      sChunk = Replace(sChunk, vbCrLf, vbLf)
      LineArray = Split(sChunk, vbLf)
      sChunk = ""
      UppInd = UBound(LineArray)

      ProgressBar1.Minimum = 0
      ProgressBar1.Maximum = UppInd
      If bNoAmbiguousNuc Then
        For I = 1 To UppInd - 3 Step 4
          If InStr(LineArray(I), "N") = 0 Then
            If dictSeq.TryGetValue(LineArray(I), Value) Then
              dictSeq(LineArray(I)) = Value + 1
            Else
              dictSeq.Add(LineArray(I), 1)
            End If
            ProgressBar1.Value = I
          End If
        Next
      Else
        For I = 1 To UppInd - 3 Step 4
          If dictSeq.TryGetValue(LineArray(I), Value) Then
            dictSeq(LineArray(I)) = Value + 1
          Else
            dictSeq.Add(LineArray(I), 1)
          End If
          ProgressBar1.Value = I
        Next
      End If
    Else
      Dim fs As New FileStream(sFastqFile, FileMode.Open, FileAccess.Read)
      Dim NumByteRead As Integer, lNumChunk As Integer, lRemainLen As Integer, NumTrailingLine As Integer
      Dim sRemain As String = ""
      Dim tmpUppInd As Integer

      lNumChunk = lFileLen \ lChunkLen
      lRemainLen = lFileLen Mod lChunkLen

      ProgressBar1.Minimum = 0
      ProgressBar1.Maximum = lNumChunk
      For I = 0 To lNumChunk - 1
        ReDim tmpByte(lChunkLen - 1)
        NumByteRead = fs.Read(tmpByte, 0, lChunkLen)
        sChunk = sRemain & Encoding.ASCII.GetString(tmpByte)
        sChunk = Replace(sChunk, vbCrLf, vbLf)
        LineArray = Split(sChunk, vbLf) 'Now the last line could be the @ID line, the seq line, the +line or the quality line. Also, iif(lastCh = vblf, Last line is empty,Not empty)
        sChunk = ""
        UppInd = UBound(LineArray)
        NumTrailingLine = (UppInd + 1) Mod 4
        Select Case NumTrailingLine
          Case 0
            'The last four line may be incomplete:
            'Two scenarios:
            '1. +Line & vbLF --> last line empty
            '2. +Line & vbLf & PartialQualityLine
            'In both cases it is fine to have
            sRemain = LineArray(UppInd - 3) & vbLf & LineArray(UppInd - 2) & vbLf & LineArray(UppInd - 1) & vbLf & LineArray(UppInd)
            tmpUppInd = UppInd - 7
          Case 1
            'Two scenarios:
            '1. last quality line is complete with vblf, in which case LineArray(UppInd)=""
            '2. last line is an incomplete @ID line
            'In both cases, it is fine to have
            sRemain = LineArray(UppInd)
            tmpUppInd = UppInd - 4
          Case 2
            'Two scenarios:
            '1. @ID...vbLf
            '2. @ID...vbLf & PartialSeq
            sRemain = LineArray(UppInd - 1) & vbLf & LineArray(UppInd)
            tmpUppInd = UppInd - 5
          Case 3
            'Two scenarios:
            '1. SeqLine & vbLf --> LineArray(UppInd)=""
            '2. SeqLine & vbLf & Partial +Line
            sRemain = LineArray(UppInd - 2) & vbCrLf & LineArray(UppInd - 1) & vbLf & LineArray(UppInd)
            tmpUppInd = UppInd - 6
        End Select

        For J = 0 To tmpUppInd Step 4
          sSeq = LineArray(J + 1)
          If bNoAmbiguousNuc Then
            If InStr(sSeq, "N") = 0 Then
              If dictSeq.TryGetValue(sSeq, Value) Then
                dictSeq(sSeq) = Value + 1
              Else
                dictSeq.Add(sSeq, 1)
              End If
            End If
          Else
            If dictSeq.TryGetValue(sSeq, Value) Then
              dictSeq(sSeq) = Value + 1
            Else
              dictSeq.Add(sSeq, 1)
            End If
          End If
        Next
        ProgressBar1.Value = I
        Application.DoEvents()
      Next
      If lRemainLen > 0 Then
        ReDim tmpByte(lRemainLen - 1)
        NumByteRead = fs.Read(tmpByte, 0, lRemainLen)
        sChunk = sRemain & Encoding.ASCII.GetString(tmpByte)
        sChunk = Replace(sChunk, vbCrLf, vbLf)
        LineArray = Split(sChunk, vbLf)
        sChunk = ""
        UppInd = UBound(LineArray)
        For J = 0 To UppInd - 3 Step 4
          sSeq = LineArray(J + 1)
          If dictSeq.TryGetValue(sSeq, Value) Then
            dictSeq(sSeq) = Value + 1
          Else
            dictSeq.Add(sSeq, 1)
          End If
        Next
      End If
      fs.Close()
    End If
    ProgressBar1.Value = 0

    iNumUniqueSeq = dictSeq.Count
    Dim GroupSize(iNumUniqueSeq) As Integer

    'Output to FAS file. Write every 10000 sequences.
    I = 1
    File.WriteAllText(sFasFile, "")
    For Each Pair In dictSeq
      sb.Append(">SeqGr" & I & "_" & Pair.Value & " " & Pair.Key.Length & vbCrLf & Pair.Key & vbCrLf)
      GroupSize(I) = Pair.Value
      If I Mod 10000 = 0 Then
        File.AppendAllText(sFasFile, sb.ToString)
        sb.Clear()
      End If
      I = I + 1
    Next
    dictSeq.Clear()
    File.AppendAllText(sFasFile, sb.ToString)
    sb.Clear()

    For I = 1 To iNumUniqueSeq 'GroupSize is 1-based
      If dictFreq.TryGetValue(GroupSize(I), Value) Then
        dictFreq(GroupSize(I)) = Value + 1
      Else
        dictFreq.Add(GroupSize(I), 1)
      End If
    Next
    iNumUniqueGrSize = dictFreq.Count
    ReDim dblUniqueGrSize(iNumUniqueGrSize - 1), dblFreqGrSize(iNumUniqueGrSize - 1)
    I = 0
    TotalNumSeq = 0
    For Each Pair2 In dictFreq
      dblUniqueGrSize(I) = Pair2.Key
      dblFreqGrSize(I) = Pair2.Value
      TotalNumSeq = TotalNumSeq + Pair2.Key * Pair2.Value
      I = I + 1
    Next
    Call QuickSort2ArrayA(dblUniqueGrSize, dblFreqGrSize, 0, iNumUniqueGrSize - 1)

    'Text output
    sb.Append("The FASTQ file: " & sFastqFile & " has been saved to " & sFasFile & " with identical sequences saved in the naming format of SeqID_Count." & CRCR)
    sb.Append("Total number of sequences in FASTQ file " & sFastqFile & ": " & TotalNumSeq & vbCrLf)
    sb.Append("Number of unique sequences: " & iNumUniqueSeq & vbCrLf)
    sb.Append("Least abundant: " & dblFreqGrSize(0) & IIf(dblFreqGrSize(0) = 1, " sequence is", " sequences are") & " represented by only " & dblUniqueGrSize(0) & IIf(dblUniqueGrSize(0) = 1, " copy.", " copies.") & vbCrLf)
    sb.Append("Most abundant: " & dblFreqGrSize(iNumUniqueGrSize - 1) & IIf(dblFreqGrSize(iNumUniqueGrSize - 1) = 1, " sequence is", " sequences are") & " represented by " & dblUniqueGrSize(iNumUniqueGrSize - 1) & IIf(dblUniqueGrSize(iNumUniqueGrSize - 1) = 1, " copy.", " copies.") & CRCR)
    sb.Append("GrSize     Freq" & vbCrLf)
    For I = 0 To iNumUniqueGrSize - 1
      sb.Append(dblUniqueGrSize(I).ToString.PadRight(7) & dblFreqGrSize(I).ToString.PadLeft(7) & vbCrLf)
    Next
    sOut = sb.ToString
    sb.Clear()
    Return True
  End Function

  Function FasToFasPlus(ByVal sFasFile As String, ByVal sFasPlusFile As String, ByRef sOut As String, _
                       ByRef iNumUniqueSeq As Integer, ByRef iNumUniqueGrSize As Integer, ByRef dblUniqueGrSize() As Integer, ByRef dblFreqGrSize() As Integer, _
                       ByVal bNoAmbiguousNuc As Boolean, ByVal ProgressBar1 As ToolStripProgressBar) As Boolean
    'Process the file in chunks
    Dim I As Integer, J As Integer, lFileLen As Long, UppInd As Integer, FindAt As Integer, TotalNumSeq As Integer
    Dim sSeq As String
    Dim lChunkLen As Integer, lFreeMem As Long
    Dim sChunk As String, LineArray() As String
    Dim tmpByte() As Byte
    Dim dictSeq As New Dictionary(Of String, Integer)
    Dim dictFreq As New Dictionary(Of Integer, Integer)
    Dim sb As New StringBuilder
    Dim Value As Integer
    Dim Pair As KeyValuePair(Of String, Integer)
    Dim Pair2 As KeyValuePair(Of Integer, Integer)

    Try
      lFreeMem = GetAvailablePhysicalMem()
    Catch ex As Exception
      MsgBox("Error Encountered in getting system memory!" & CRCR & ex.ToString, vbInformation, "Error")
      lFreeMem = 2000000000
    End Try
    lFileLen = FileLen(sFasFile)
    lChunkLen = lFreeMem \ 1000
    If lChunkLen > lFileLen Then
      sChunk = File.ReadAllText(sFasFile)
      sChunk = Replace(sChunk, vbCrLf, vbLf)
      LineArray = Split(sChunk, vbLf & ">")
      'Every elements in LineArray is now made of a SeqName in the first line (ended with vblf) and a sequence which may 
      '  span multiple lines
      'We do not need SeqName, so LineArray(I) will now be processed to contain sequence only
      sChunk = ""
      UppInd = UBound(LineArray)

      For I = 0 To UppInd
        FindAt = InStr(LineArray(I), vbLf)
        LineArray(I) = Mid(LineArray(I), FindAt + 1)
        LineArray(I) = Replace(LineArray(I), vbLf, "")
      Next

      ProgressBar1.Minimum = 0
      ProgressBar1.Maximum = UppInd
      If bNoAmbiguousNuc Then
        For I = 0 To UppInd
          If InStr(LineArray(I), "N") = 0 Then
            If dictSeq.TryGetValue(LineArray(I), Value) Then
              dictSeq(LineArray(I)) = Value + 1
            Else
              dictSeq.Add(LineArray(I), 1)
            End If
            ProgressBar1.Value = I
          End If
        Next
      Else
        For I = 0 To UppInd
          If dictSeq.TryGetValue(LineArray(I), Value) Then
            dictSeq(LineArray(I)) = Value + 1
          Else
            dictSeq.Add(LineArray(I), 1)
          End If
          ProgressBar1.Value = I
        Next
      End If
    Else
      Dim fs As New FileStream(sFasFile, FileMode.Open, FileAccess.Read)
      Dim NumByteRead As Integer, lNumChunk As Integer, lRemainLen As Integer
      Dim sRemain As String = ""

      lNumChunk = lFileLen \ lChunkLen
      lRemainLen = lFileLen Mod lChunkLen

      ProgressBar1.Minimum = 0
      ProgressBar1.Maximum = lNumChunk
      For I = 0 To lNumChunk - 1
        ReDim tmpByte(lChunkLen - 1)
        NumByteRead = fs.Read(tmpByte, 0, lChunkLen)
        sChunk = sRemain & Encoding.ASCII.GetString(tmpByte)
        sChunk = Replace(sChunk, vbCrLf, vbLf)
        LineArray = Split(sChunk, vbLf & ">")
        'Every elements in LineArray is now made of a SeqName in the first line (ended with vblf) and a sequence which may 
        '  span multiple lines
        'We do not need SeqName, so LineArray(I) will be processed to contain sequence only
        'The last element may be incomplete and will be assigned to sRemain to put at beginning of the next chunk
        sChunk = ""
        UppInd = UBound(LineArray)
        sRemain = LineArray(UppInd)
        For J = 0 To UppInd - 1
          sSeq = LineArray(J)
          FindAt = InStr(sSeq, vbLf)
          sSeq = Mid(sSeq, FindAt + 1)
          sSeq = Replace(sSeq, vbLf, "")
          If bNoAmbiguousNuc Then
            If InStr(sSeq, "N") = 0 Then
              If dictSeq.TryGetValue(sSeq, Value) Then
                dictSeq(sSeq) = Value + 1
              Else
                dictSeq.Add(sSeq, 1)
              End If
            End If
          Else
            If dictSeq.TryGetValue(sSeq, Value) Then
              dictSeq(sSeq) = Value + 1
            Else
              dictSeq.Add(sSeq, 1)
            End If
          End If
        Next
        ProgressBar1.Value = I
        Application.DoEvents()
      Next
      If lRemainLen > 0 Then
        ReDim tmpByte(lRemainLen - 1)
        NumByteRead = fs.Read(tmpByte, 0, lRemainLen)
        sChunk = sRemain & Encoding.ASCII.GetString(tmpByte)
        sChunk = Replace(sChunk, vbCrLf, vbLf)
        LineArray = Split(sChunk, vbLf & ">")
        sChunk = ""
        UppInd = UBound(LineArray)
        For J = 0 To UppInd
          sSeq = LineArray(J)
          FindAt = InStr(sSeq, vbLf)
          sSeq = Mid(sSeq, FindAt + 1)
          sSeq = Replace(sSeq, vbLf, "")
          If bNoAmbiguousNuc Then
            If InStr(sSeq, "N") = 0 Then
              If dictSeq.TryGetValue(sSeq, Value) Then
                dictSeq(sSeq) = Value + 1
              Else
                dictSeq.Add(sSeq, 1)
              End If
            End If
          Else
            If dictSeq.TryGetValue(sSeq, Value) Then
              dictSeq(sSeq) = Value + 1
            Else
              dictSeq.Add(sSeq, 1)
            End If
          End If
        Next
      End If
      fs.Close()
    End If
    ProgressBar1.Value = 0

    iNumUniqueSeq = dictSeq.Count
    Dim GroupSize(iNumUniqueSeq) As Integer

    'Output to FAS file. Write every 10000 sequences.
    I = 1
    File.WriteAllText(sFasPlusFile, "")
    For Each Pair In dictSeq
      sb.Append(">SeqGr" & I & "_" & Pair.Value & " " & Pair.Key.Length & vbCrLf & Pair.Key & vbCrLf)
      GroupSize(I) = Pair.Value
      If I Mod 10000 = 0 Then
        File.AppendAllText(sFasPlusFile, sb.ToString)
        sb.Clear()
      End If
      I = I + 1
    Next
    dictSeq.Clear()
    File.AppendAllText(sFasPlusFile, sb.ToString)
    sb.Clear()

    For I = 1 To iNumUniqueSeq 'GroupSize is 1-based
      If dictFreq.TryGetValue(GroupSize(I), Value) Then
        dictFreq(GroupSize(I)) = Value + 1
      Else
        dictFreq.Add(GroupSize(I), 1)
      End If
    Next
    iNumUniqueGrSize = dictFreq.Count
    ReDim dblUniqueGrSize(iNumUniqueGrSize - 1), dblFreqGrSize(iNumUniqueGrSize - 1)
    I = 0
    TotalNumSeq = 0
    For Each Pair2 In dictFreq
      dblUniqueGrSize(I) = Pair2.Key
      dblFreqGrSize(I) = Pair2.Value
      TotalNumSeq = TotalNumSeq + Pair2.Key * Pair2.Value
      I = I + 1
    Next
    Call QuickSort2ArrayA(dblUniqueGrSize, dblFreqGrSize, 0, iNumUniqueGrSize - 1)

    'Text output
    sb.Append("The FAS file: " & sFasFile & " has been saved to " & sFasPlusFile & " with identical sequences saved in the naming format of SeqID_Count." & CRCR)
    sb.Append("Total number of sequences in FASTQ file " & sFasFile & ": " & TotalNumSeq & vbCrLf)
    sb.Append("Number of unique sequences: " & iNumUniqueSeq & vbCrLf)
    sb.Append("Least abundant: " & dblFreqGrSize(0) & IIf(dblFreqGrSize(0) = 1, " sequence is", " sequences are") & " represented by only " & dblUniqueGrSize(0) & IIf(dblUniqueGrSize(0) = 1, " copy.", " copies.") & vbCrLf)
    sb.Append("Most abundant: " & dblFreqGrSize(iNumUniqueGrSize - 1) & IIf(dblFreqGrSize(iNumUniqueGrSize - 1) = 1, "sequence is", "sequences are") & " represented by " & dblUniqueGrSize(iNumUniqueGrSize - 1) & IIf(dblUniqueGrSize(iNumUniqueGrSize - 1) = 1, " copy.", " copies.") & CRCR)
    sb.Append("GrSize     Freq" & vbCrLf)
    For I = 0 To iNumUniqueGrSize - 1
      sb.Append(dblUniqueGrSize(I).ToString.PadRight(7) & dblFreqGrSize(I).ToString.PadLeft(7) & vbCrLf)
    Next
    sOut = sb.ToString
    sb.Clear()
    Return True
  End Function

  Function FastqToFastqPlus(ByVal sFastqFile As String, ByVal sFastqPlusFile As String, ByVal iReadLen As Integer, ByRef sOut As String, _
                     ByRef iNumUniqueSeq As Integer, ByRef iNumUniqueGrSize As Integer, ByRef dblUniqueGrSize() As Double, ByRef dblFreqGrSize() As Double, _
                     ByVal ProgressBar1 As ToolStripProgressBar) As Boolean
    'Process the file in chunks
    Dim I As Integer, J As Integer, lFileLen As Long, UppInd As Integer
    Dim TotalNumSeq As Integer = 0, NumGoodSeq As Integer, NumShortSeq As Integer, NumPoorSeq As Integer = 0 'NumPoorSeq is the number of sequences with ambiguous codes. Such sequences are excluded in the new FastqP file.
    Dim sSeq As String, sAddAA As String = ""
    Dim NumA As Integer 'Number of A to pad to the right to make the sequence length = multiples of 4
    Dim lChunkLen As Integer, lFreeMem As Long
    Dim sChunk As String, LineArray() As String
    Dim tmpByte() As Byte, QualityByte() As Byte
    Dim dictSeq As New Dictionary(Of String, tFastqFile)
    Dim dictFreq As New Dictionary(Of Integer, Integer)
    Dim sb As New StringBuilder
    Dim ValueDictSeq As tFastqFile
    Dim Value2 As Integer
    Dim PairShortFile As KeyValuePair(Of String, tFastqFile)
    Dim PairLongFile As KeyValuePair(Of String, tFastqFile)
    Dim Pair2 As KeyValuePair(Of Integer, Integer)
    Dim GroupSize() As Integer
    Dim PackedLen As Integer, NewLen As Integer

    NumA = 4 - (iReadLen Mod 4)
    Select Case NumA
      Case 1
        sAddAA = "A"
      Case 2
        sAddAA = "AA"
      Case 3
        sAddAA = "AAA"
    End Select
    NewLen = iReadLen + sAddAA.Length
    PackedLen = NewLen \ 4
    Try
      lFreeMem = GetAvailablePhysicalMem()
    Catch ex As Exception
      MsgBox("Error Encountered in getting system memory!" & CRCR & ex.ToString, vbInformation, "Error")
      lFreeMem = 2000000000
    End Try
    lFileLen = FileLen(sFastqFile)
    lChunkLen = lFreeMem \ 1000

    If lChunkLen > lFileLen Then
      sChunk = File.ReadAllText(sFastqFile)
      sChunk = Replace(sChunk, vbCrLf, vbLf)
      LineArray = Split(sChunk, vbLf)
      sChunk = ""
      UppInd = UBound(LineArray)

      ProgressBar1.Minimum = 0
      ProgressBar1.Maximum = UppInd
      For I = 0 To UppInd - 3 Step 4
        sSeq = LineArray(I + 1)
        If sSeq.Length < iReadLen Then
          NumShortSeq = NumShortSeq + 1
        ElseIf InStr(sSeq, "N") > 0 Then
          NumPoorSeq = NumPoorSeq + 1
        Else
          NumGoodSeq = NumGoodSeq + 1
          sSeq = Strings.Left(sSeq, iReadLen)
          QualityByte = Encoding.ASCII.GetBytes(LineArray(I + 3))
          If dictSeq.TryGetValue(sSeq, ValueDictSeq) Then
            ValueDictSeq.Count = ValueDictSeq.Count + 1
            For J = 0 To sSeq.Length - 1
              ValueDictSeq.Quality(J) = ValueDictSeq.Quality(J) + QualityByte(J)
            Next
            dictSeq(sSeq) = ValueDictSeq
          Else
            ValueDictSeq.Count = 1
            ReDim ValueDictSeq.Quality(sSeq.Length - 1)
            For J = 0 To sSeq.Length - 1
              ValueDictSeq.Quality(J) = QualityByte(J)
            Next
            dictSeq.Add(sSeq, ValueDictSeq)
          End If
        End If
        ProgressBar1.Value = I
        Application.DoEvents()
      Next
      iNumUniqueSeq = dictSeq.Count
      ReDim GroupSize(iNumUniqueSeq)

      'Output to FAS file. Write every 10000 sequences.
      ProgressBar1.Maximum = iNumUniqueSeq
      I = 1 'Suffix to SeqGroup
      File.WriteAllText(sFastqPlusFile, "")
      For Each PairShortFile In dictSeq
        sb.Append("@S" & I & "_" & PairShortFile.Value.Count & vbCrLf & PairShortFile.Key & vbCrLf)
        ReDim QualityByte(PairShortFile.Key.Length - 1)
        If PairShortFile.Value.Count = 1 Then
          For J = 0 To PairShortFile.Key.Length - 1
            QualityByte(J) = CByte(PairShortFile.Value.Quality(J))
          Next
        Else
          For J = 0 To PairShortFile.Key.Length - 1
            QualityByte(J) = CByte(PairShortFile.Value.Quality(J) / PairShortFile.Value.Count + 0.5)
          Next
        End If
        sb.Append("+" & vbCrLf & Encoding.ASCII.GetString(QualityByte) & vbCrLf)
        GroupSize(I) = PairShortFile.Value.Count
        If I Mod 10000 = 0 Then
          File.AppendAllText(sFastqPlusFile, sb.ToString)
          sb.Clear()
        End If
        ProgressBar1.Value = I
        I = I + 1
      Next
      dictSeq.Clear()
      File.AppendAllText(sFastqPlusFile, sb.ToString)
      sb.Clear()
      dictSeq = Nothing
    Else
      Dim K As Integer
      Dim fs As New FileStream(sFastqFile, FileMode.Open, FileAccess.Read)
      Dim NumByteRead As Integer, lNumChunk As Integer, lRemainLen As Integer, NumTrailingLine As Integer
      Dim sRemain As String = "", sPackedSeq As String
      Dim tmpUppInd As Integer
      Dim SeqByte() As Byte, OutByte() As Byte

      lNumChunk = lFileLen \ lChunkLen
      lRemainLen = lFileLen Mod lChunkLen

      ProgressBar1.Minimum = 0
      ProgressBar1.Maximum = lNumChunk
      For I = 0 To lNumChunk - 1
        ReDim tmpByte(lChunkLen - 1)
        NumByteRead = fs.Read(tmpByte, 0, lChunkLen)
        sChunk = sRemain & Encoding.ASCII.GetString(tmpByte)
        sChunk = Replace(sChunk, vbCrLf, vbLf)
        LineArray = Split(sChunk, vbLf)
        sChunk = ""
        UppInd = UBound(LineArray)
        NumTrailingLine = (UppInd + 1) Mod 4
        'ID-line & vbLf : break before vbLF --> NumTrainingLine = 1; after --> NumTrailingLine = 2
        'SeqLine & vbLf : break before vbLF --> NumTrainingLine = 2; after --> NumTrailingLine = 3
        '+Line & vbLf : break before vbLF --> NumTrainingLine = 3; after --> NumTrailingLine = 0
        'Quality-line & vbLf : break before vbLF --> NumTrainingLine = 0; after --> NumTrailingLine = 1

        Select Case NumTrailingLine
          Case 0
            'The last four line may be incomplete:
            'Two scenarios:
            '1. +Line & vbLF --> last line empty
            '2. +Line & vbLf & PartialQualityLine
            'In both cases it is fine to have
            sRemain = LineArray(UppInd - 3) & vbLf & LineArray(UppInd - 2) & vbLf & LineArray(UppInd - 1) & vbLf & LineArray(UppInd)
            tmpUppInd = UppInd - 7
          Case 1
            'Two scenarios:
            '1. last quality line is complete with vblf, in which case LineArray(UppInd)=""
            '2. last line is an incomplete @ID line
            'In both cases, it is fine to have
            sRemain = LineArray(UppInd)
            tmpUppInd = UppInd - 4
          Case 2
            'Two scenarios:
            '1. @ID...vbLf
            '2. @ID...vbLf & PartialSeq
            sRemain = LineArray(UppInd - 1) & vbLf & LineArray(UppInd)
            tmpUppInd = UppInd - 5
          Case 3
            'Two scenarios:
            '1. SeqLine & vbLf --> LineArray(UppInd)=""
            '2. SeqLine & vbLf & Partial +Line
            sRemain = LineArray(UppInd - 2) & vbCrLf & LineArray(UppInd - 1) & vbLf & LineArray(UppInd)
            tmpUppInd = UppInd - 6
        End Select

        For J = 0 To tmpUppInd Step 4
          sSeq = LineArray(J + 1)
          If sSeq.Length < iReadLen Then
            NumShortSeq = NumShortSeq + 1
          ElseIf InStr(sSeq, "N") > 0 Then
            NumPoorSeq = NumPoorSeq + 1
          Else
            sSeq = Strings.Left(sSeq, iReadLen)
            SeqByte = Encoding.ASCII.GetBytes(sSeq & sAddAA)
            QualityByte = Encoding.ASCII.GetBytes(LineArray(J + 3))
            If PackNuc(SeqByte, NewLen, OutByte) Then
              sPackedSeq = Encoding.Default.GetString(OutByte)
              If dictSeq.TryGetValue(sPackedSeq, ValueDictSeq) Then
                ValueDictSeq.Count = ValueDictSeq.Count + 1
                For K = 0 To sSeq.Length - 1
                  ValueDictSeq.Quality(K) = ValueDictSeq.Quality(K) + QualityByte(K)
                Next
                dictSeq(sPackedSeq) = ValueDictSeq
              Else
                ValueDictSeq.Count = 1
                ReDim ValueDictSeq.Quality(sSeq.Length - 1)
                For K = 0 To sSeq.Length - 1
                  ValueDictSeq.Quality(K) = QualityByte(K)
                Next
                dictSeq.Add(sPackedSeq, ValueDictSeq)
              End If
            Else
              NumPoorSeq = NumPoorSeq + 1
            End If
          End If
        Next
        ProgressBar1.Value = I
        Application.DoEvents()
      Next
      If lRemainLen > 0 Then
        ReDim tmpByte(lRemainLen - 1)
        NumByteRead = fs.Read(tmpByte, 0, lRemainLen)
        sChunk = sRemain & Encoding.ASCII.GetString(tmpByte)
        sChunk = Replace(sChunk, vbCrLf, vbLf)
        LineArray = Split(sChunk, vbLf)
        sChunk = ""
        UppInd = UBound(LineArray)
        For J = 0 To UppInd - 3 Step 4
          sSeq = LineArray(J + 1)
          If sSeq.Length < iReadLen Then
            NumShortSeq = NumShortSeq + 1
          ElseIf InStr(sSeq, "N") > 0 Then
            NumPoorSeq = NumPoorSeq + 1
          Else
            sSeq = Strings.Left(sSeq, iReadLen)
            SeqByte = Encoding.ASCII.GetBytes(sSeq & sAddAA)
            QualityByte = Encoding.ASCII.GetBytes(LineArray(J + 3))
            If PackNuc(SeqByte, NewLen, OutByte) Then
              sPackedSeq = Encoding.Default.GetString(OutByte)
              If dictSeq.TryGetValue(sPackedSeq, ValueDictSeq) Then
                ValueDictSeq.Count = ValueDictSeq.Count + 1
                For K = 0 To sSeq.Length - 1
                  ValueDictSeq.Quality(K) = ValueDictSeq.Quality(K) + QualityByte(K)
                Next
                dictSeq(sPackedSeq) = ValueDictSeq
              Else
                ValueDictSeq.Count = 1
                ReDim ValueDictSeq.Quality(sSeq.Length - 1)
                For K = 0 To sSeq.Length - 1
                  ValueDictSeq.Quality(K) = QualityByte(K)
                Next
                dictSeq.Add(sPackedSeq, ValueDictSeq)
              End If
            Else
              NumPoorSeq = NumPoorSeq + 1
            End If
          End If
        Next
      End If
      fs.Close()
      iNumUniqueSeq = dictSeq.Count
      ReDim GroupSize(iNumUniqueSeq)

      'Output to FAS file. Write every 10000 sequences.
      ProgressBar1.Maximum = iNumUniqueSeq
      I = 1 'Suffix to SeqGroup
      File.WriteAllText(sFastqPlusFile, "")
      For Each PairLongFile In dictSeq
        OutByte = Encoding.Default.GetBytes(PairLongFile.Key)
        UnpackNuc(OutByte, PackedLen, iReadLen, tmpByte)
        sSeq = Encoding.ASCII.GetString(tmpByte)
        sb.Append("@S" & I & "_" & PairLongFile.Value.Count & vbCrLf & sSeq & vbCrLf)
        ReDim QualityByte(sSeq.Length - 1)
        If PairLongFile.Value.Count = 1 Then
          For J = 0 To sSeq.Length - 1
            QualityByte(J) = CByte(PairLongFile.Value.Quality(J))
          Next
        Else
          For J = 0 To sSeq.Length - 1
            QualityByte(J) = CByte(PairLongFile.Value.Quality(J) / PairLongFile.Value.Count + 0.5)
          Next
        End If
        sb.Append("+" & vbCrLf & Encoding.ASCII.GetString(QualityByte) & vbCrLf)
        GroupSize(I) = PairLongFile.Value.Count
        If I Mod 10000 = 0 Then
          File.AppendAllText(sFastqPlusFile, sb.ToString)
          sb.Clear()
        End If
        ProgressBar1.Value = I
        I = I + 1
      Next
      dictSeq.Clear()
      dictSeq = Nothing
      File.AppendAllText(sFastqPlusFile, sb.ToString)
      sb.Clear()
    End If
    GC.Collect()
    ProgressBar1.Value = 0
    Application.DoEvents()

    For I = 1 To iNumUniqueSeq 'GroupSize is 1-based
      If dictFreq.TryGetValue(GroupSize(I), Value2) Then
        dictFreq(GroupSize(I)) = Value2 + 1
      Else
        dictFreq.Add(GroupSize(I), 1)
      End If
    Next
    iNumUniqueGrSize = dictFreq.Count
    ReDim dblUniqueGrSize(iNumUniqueGrSize - 1), dblFreqGrSize(iNumUniqueGrSize - 1)
    I = 0
    TotalNumSeq = 0
    For Each Pair2 In dictFreq
      dblUniqueGrSize(I) = Pair2.Key
      dblFreqGrSize(I) = Pair2.Value
      TotalNumSeq = TotalNumSeq + Pair2.Key * Pair2.Value
      I = I + 1
    Next
    dictFreq.Clear()
    dictFreq = Nothing
    Call QuickSort2ArrayA(dblUniqueGrSize, dblFreqGrSize, 0, iNumUniqueGrSize - 1)

    'Text output
    sb.Append("The FASTQ file: " & sFastqFile & " has been saved to " & sFastqPlusFile & " with identical sequences saved in the naming format of SeqID_Count." & CRCR)
    sb.Append(NumPoorSeq & " sequences with ambiguous codes are excluded." & vbCrLf)
    sb.Append("Total number of clean sequences in FASTQ file " & sFastqFile & ": " & TotalNumSeq & vbCrLf)
    sb.Append("Number of unique sequences: " & iNumUniqueSeq & vbCrLf)
    sb.Append("Least abundant: " & dblFreqGrSize(0) & IIf(dblFreqGrSize(0) = 1, " sequence is", " sequences are") & " represented by only " & dblUniqueGrSize(0) & IIf(dblUniqueGrSize(0) = 1, " copy.", " copies.") & vbCrLf)
    sb.Append("Most abundant: " & dblFreqGrSize(iNumUniqueGrSize - 1) & IIf(dblFreqGrSize(iNumUniqueGrSize - 1) = 1, " sequence is", " sequences are") & " represented by " & dblUniqueGrSize(iNumUniqueGrSize - 1) & IIf(dblUniqueGrSize(iNumUniqueGrSize - 1) = 1, " copy.", " copies.") & CRCR)
    sb.Append("GrSize     Freq" & vbCrLf)
    For I = 0 To iNumUniqueGrSize - 1
      sb.Append(dblUniqueGrSize(I).ToString.PadRight(7) & dblFreqGrSize(I).ToString.PadLeft(7) & vbCrLf)
    Next
    sOut = sb.ToString
    sb.Clear()
    Return True
  End Function

  Function FastqToFasPlusPaired(ByVal sFastq1File As String, ByVal sFastq2File As String, ByVal sFasPlusFile1 As String, ByVal sFasPlusFile2 As String, ByRef sOut As String, _
                     ByRef iNumUniqueSeq As Integer, ByRef iNumUniqueGrSize As Integer, ByRef dblUniqueGrSize() As Integer, ByRef dblFreqGrSize() As Integer, _
                     ByVal iReadLen As Integer, ByVal ToolStripLabel1 As ToolStripLabel, ByVal ProgressBar1 As ToolStripProgressBar) As Boolean
    'Process the file in chunks
    Dim I As Integer, J As Integer, lFileLen1 As Integer, lFileLen2 As Integer, UppInd As Integer, UppInd1 As Integer, UppInd2 As Integer
    Dim TotalNumSeq As Integer = 0, NumShortSeq As Integer = 0, NumPoorSeq As Integer = 0 'NumPoorSeq is the number of sequences with ambiguous codes. Such sequences are excluded in the new FastqP file.
    Dim sSeq1 As String, sSeq2 As String
    Dim lChunkLen As Integer, lFreeMem As Long
    Dim sChunkFromFile1 As String, sChunkFromFile2 As String, LineArray1() As String, LineArray2() As String
    Dim tmpByte() As Byte
    Dim dictFasFilePaired As New Dictionary(Of String, Integer)
    Dim dictFreq As New Dictionary(Of Integer, Integer)
    Dim sb As New StringBuilder
    Dim sb2 As New StringBuilder
    Dim ValueDict As Integer
    Dim ValuePairDict As KeyValuePair(Of String, Integer)
    Dim GroupSizeCount As Integer
    Dim ValuePairFreq As KeyValuePair(Of Integer, Integer)
    Dim GroupSize() As Integer
    Dim SeqByte() As Byte, OutByte() As Byte
    Dim NewLen As Integer, TrueLen As Integer, PackedLen As Integer
    Dim NumA As Integer 'Number of A to pad to the right to make the sequence length = multiples of 4
    Dim sPackedSeq As String, sAddAA As String = ""

    TrueLen = iReadLen * 2
    NumA = 4 - (TrueLen Mod 4)
    Select Case NumA
      Case 1
        sAddAA = "A"
      Case 2
        sAddAA = "AA"
      Case 3
        sAddAA = "AAA"
    End Select
    NewLen = iReadLen * 2 + sAddAA.Length
    PackedLen = NewLen \ 4

    Try
      lFreeMem = GetAvailablePhysicalMem()
    Catch ex As Exception
      MsgBox("Error Encountered in getting system memory!" & CRCR & ex.ToString, vbInformation, "Error")
      lFreeMem = 2000000000
    End Try

    lFileLen1 = FileLen(sFastq1File)
    lFileLen2 = FileLen(sFastq2File)
    lChunkLen = lFreeMem \ 1000

    ToolStripLabel1.Text = "Populating dictionary..."
    If lChunkLen > lFileLen1 Then
      LineArray1 = File.ReadAllLines(sFastq1File)
      sChunkFromFile1 = ""
      UppInd = UBound(LineArray1)
      LineArray2 = File.ReadAllLines(sFastq2File)

      ProgressBar1.Minimum = 0
      ProgressBar1.Maximum = UppInd
      For I = 0 To UppInd - 3 Step 4
        sSeq1 = LineArray1(I + 1)
        sSeq2 = LineArray2(I + 1)
        If sSeq1.Length < iReadLen Or sSeq2.Length < iReadLen Then
          NumShortSeq = NumShortSeq + 1
        ElseIf InStr(sSeq2, "N") > 0 Or InStr(sSeq1, "N") > 0 Then
          NumPoorSeq = NumPoorSeq + 1
        Else
          SeqByte = Encoding.ASCII.GetBytes(sSeq1 & sSeq2 & sAddAA)
          If PackNuc(SeqByte, NewLen, OutByte) Then
            sPackedSeq = Encoding.Default.GetString(OutByte)
            If dictFasFilePaired.TryGetValue(sPackedSeq, ValueDict) Then
              ValueDict = ValueDict + 1
              dictFasFilePaired(sPackedSeq) = ValueDict
            Else
              ValueDict = 1
              dictFasFilePaired.Add(sPackedSeq, ValueDict)
            End If
          Else
            NumPoorSeq = NumPoorSeq + 1
          End If
        End If
        ProgressBar1.Value = I
        Application.DoEvents()
      Next
      iNumUniqueSeq = dictFasFilePaired.Count
      ReDim GroupSize(iNumUniqueSeq)

      'Output to FAS file. Write every 10000 sequences.
      ProgressBar1.Maximum = iNumUniqueSeq
      I = 1 'Suffix to SeqGroup
      Dim sTmp As String
      ToolStripLabel1.Text = "Writing FASTA+ files..."
      File.WriteAllText(sFasPlusFile1, "")
      File.WriteAllText(sFasPlusFile2, "")
      For Each ValuePairDict In dictFasFilePaired
        OutByte = Encoding.Default.GetBytes(ValuePairDict.Key)
        UnpackNuc(OutByte, PackedLen, TrueLen, tmpByte)
        sSeq2 = Encoding.ASCII.GetString(tmpByte)
        sSeq1 = Strings.Left(sSeq2, iReadLen)
        sSeq2 = Strings.Mid(sSeq2, iReadLen + 1)
        sTmp = ">S" & I & "_" & ValuePairDict.Value
        sb.Append(sTmp & ".1 " & vbLf & sSeq1 & vbLf)
        sb2.Append(sTmp & ".2 " & vbLf & sSeq2 & vbLf)
        GroupSize(I) = ValuePairDict.Value
        If I Mod 10000 = 0 Then
          File.AppendAllText(sFasPlusFile1, sb.ToString)
          File.AppendAllText(sFasPlusFile2, sb2.ToString)
          sb.Clear()
          sb2.Clear()
        End If
        ProgressBar1.Value = I
        I = I + 1
        Application.DoEvents()
      Next
      dictFasFilePaired.Clear()
      File.AppendAllText(sFasPlusFile1, sb.ToString)
      File.AppendAllText(sFasPlusFile2, sb2.ToString)
      sb.Clear()
      sb2.Clear()
      dictFasFilePaired = Nothing
    Else
      Dim fs As New FileStream(sFastq1File, FileMode.Open, FileAccess.Read)
      Dim fs2 As New FileStream(sFastq2File, FileMode.Open, FileAccess.Read)
      Dim NumByteRead As Integer, lNumChunk As Integer, lRemainLen1 As Integer, lRemainLen2 As Integer
      Dim sRemain As String = "", sRemain2 As String = ""
      Dim tmpUppInd As Integer

      If lFileLen1 < lFileLen2 Then
        lNumChunk = lFileLen1 \ lChunkLen
        lRemainLen1 = lFileLen1 Mod lChunkLen
        J = lFileLen2 \ lChunkLen
        J = J - lNumChunk
        lRemainLen2 = J * lChunkLen + (lFileLen2 Mod lChunkLen)
      Else
        lNumChunk = lFileLen2 \ lChunkLen
        lRemainLen2 = lFileLen2 Mod lChunkLen
        J = lFileLen1 \ lChunkLen
        J = J - lNumChunk
        lRemainLen1 = J * lChunkLen + (lFileLen1 Mod lChunkLen)
      End If

      ProgressBar1.Minimum = 0
      ProgressBar1.Maximum = lNumChunk
      For I = 0 To lNumChunk - 1
        ReDim tmpByte(lChunkLen - 1)
        NumByteRead = fs.Read(tmpByte, 0, lChunkLen)
        sChunkFromFile1 = sRemain & Encoding.ASCII.GetString(tmpByte)
        'sChunkFromFile1 = Replace(sChunkFromFile1, vbCrLf, vbLf)
        LineArray1 = Split(sChunkFromFile1, vbLf)
        sChunkFromFile1 = ""

        NumByteRead = fs2.Read(tmpByte, 0, lChunkLen)
        sChunkFromFile2 = sRemain2 & Encoding.ASCII.GetString(tmpByte)
        'sChunkFromFile1 = Replace(sChunkFromFile1, vbCrLf, vbLf)
        LineArray2 = Split(sChunkFromFile2, vbLf)
        sChunkFromFile2 = ""

        UppInd1 = UBound(LineArray1)
        UppInd2 = UBound(LineArray2)
        UppInd = Math.Min(UppInd1, UppInd2)
        tmpUppInd = UppInd \ 4
        tmpUppInd = tmpUppInd * 4
        'e.g., if we have read in 100 (or 101, 102, 103) lines (with the last line potentially incomplete), then UppInd would be 99 (100, 101, 102); 
        'The number of complete sequence sets are 24, (25, 25, 25) -->tmpUppInd = UppInd \ 4
        'The for-Index should then be 92 (=24*4-4), tmpUppInd = tmpUppInd * 4 - 4
        'The number of trailing lines to sRemain are 
        sRemain = ""
        For J = tmpUppInd To UppInd1 - 1
          sRemain = sRemain & LineArray1(J) & vbLf
        Next
        sRemain = sRemain & LineArray1(J)
        sRemain2 = ""
        For J = tmpUppInd To UppInd2 - 1
          sRemain2 = sRemain2 & LineArray2(J) & vbLf
        Next
        sRemain2 = sRemain2 & LineArray2(J)
        For J = 0 To tmpUppInd - 4 Step 4
          sSeq1 = LineArray1(J + 1)
          sSeq2 = LineArray2(J + 1)
          If sSeq1.Length < iReadLen Or sSeq2.Length < iReadLen Then
            NumShortSeq = NumShortSeq + 1
          ElseIf InStr(sSeq1, "N") > 0 Or InStr(sSeq2, "N") > 0 Then
            NumPoorSeq = NumPoorSeq + 1
          Else
            SeqByte = Encoding.ASCII.GetBytes(Strings.Left(sSeq1, iReadLen) & Strings.Left(sSeq2, iReadLen) & sAddAA)
            If PackNuc(SeqByte, NewLen, OutByte) Then
              sPackedSeq = Encoding.Default.GetString(OutByte)
              If dictFasFilePaired.TryGetValue(sPackedSeq, ValueDict) Then
                ValueDict = ValueDict + 1
                dictFasFilePaired(sPackedSeq) = ValueDict
              Else
                ValueDict = 1
                dictFasFilePaired.Add(sPackedSeq, ValueDict)
              End If
            Else
              NumPoorSeq = NumPoorSeq + 1
            End If
          End If
        Next
        ProgressBar1.Value = I
        Application.DoEvents()
      Next
      If lRemainLen1 > 0 Then
        ReDim tmpByte(lRemainLen1 - 1)
        NumByteRead = fs.Read(tmpByte, 0, lRemainLen1)
        sChunkFromFile1 = sRemain & Encoding.ASCII.GetString(tmpByte)
        LineArray1 = Split(sChunkFromFile1, vbLf)
        sChunkFromFile1 = ""

        ReDim tmpByte(lRemainLen2 - 1)
        NumByteRead = fs2.Read(tmpByte, 0, lRemainLen2)
        sChunkFromFile2 = sRemain2 & Encoding.ASCII.GetString(tmpByte)
        LineArray2 = Split(sChunkFromFile2, vbLf)
        sChunkFromFile2 = ""
        Erase tmpByte
        'Now the LineArray1 and LineArray2 must have the same number of lines.
        UppInd = UBound(LineArray1)
        For J = 0 To UppInd - 3 Step 4
          sSeq1 = LineArray1(J + 1)
          sSeq2 = LineArray2(J + 1)
          If sSeq1.Length < iReadLen Or sSeq2.Length < iReadLen Then
            NumShortSeq = NumShortSeq + 1
          ElseIf InStr(sSeq1, "N") > 0 Or InStr(sSeq2, "N") > 0 Then
            NumPoorSeq = NumPoorSeq + 1
          Else
            SeqByte = Encoding.ASCII.GetBytes(Strings.Left(sSeq1, iReadLen) & Strings.Left(sSeq2, iReadLen) & sAddAA)
            If PackNuc(SeqByte, NewLen, OutByte) Then
              sPackedSeq = Encoding.Default.GetString(OutByte)
              If dictFasFilePaired.TryGetValue(sPackedSeq, ValueDict) Then
                ValueDict = ValueDict + 1
                dictFasFilePaired(sPackedSeq) = ValueDict
              Else
                ValueDict = 1
                dictFasFilePaired.Add(sPackedSeq, ValueDict)
              End If
            Else
              NumPoorSeq = NumPoorSeq + 1
            End If
          End If
        Next
      End If
      ProgressBar1.Value = 0
      fs.Close()
      fs2.Close()
      iNumUniqueSeq = dictFasFilePaired.Count
      ReDim GroupSize(iNumUniqueSeq)

      'Output to FAS file. Write every 10000 sequences.
      ProgressBar1.Maximum = iNumUniqueSeq
      I = 1 'Suffix to SeqGroup
      ToolStripLabel1.Text = "Writing FASTA+ files ..."
      File.WriteAllText(sFasPlusFile1, "")
      File.WriteAllText(sFasPlusFile2, "")
      Dim sTmp As String
      For Each ValuePairDict In dictFasFilePaired
        OutByte = Encoding.Default.GetBytes(ValuePairDict.Key)
        UnpackNuc(OutByte, PackedLen, TrueLen, tmpByte)
        sSeq2 = Encoding.ASCII.GetString(tmpByte)
        sSeq1 = Strings.Left(sSeq2, iReadLen)
        sSeq2 = Strings.Mid(sSeq2, iReadLen + 1)
        sTmp = ">S" & I & "_" & ValuePairDict.Value
        sb.Append(sTmp & ".1 " & vbLf & sSeq1 & vbLf)
        sb2.Append(sTmp & ".2 " & vbLf & sSeq2 & vbLf)
        GroupSize(I) = ValuePairDict.Value
        If I Mod 10000 = 0 Then
          File.AppendAllText(sFasPlusFile1, sb.ToString)
          File.AppendAllText(sFasPlusFile2, sb2.ToString)
          sb.Clear()
          sb2.Clear()
        End If
        ProgressBar1.Value = I
        Application.DoEvents()
        I = I + 1
      Next
      dictFasFilePaired.Clear()
      File.AppendAllText(sFasPlusFile1, sb.ToString)
      File.AppendAllText(sFasPlusFile2, sb2.ToString)
      sb.Clear()
      sb2.Clear()
      dictFasFilePaired = Nothing
    End If
    GC.Collect()
    ProgressBar1.Value = 0
    Application.DoEvents()

    ProgressBar1.Maximum = iNumUniqueSeq
    ToolStripLabel1.Text = "Generating data for plotting..."
    For I = 1 To iNumUniqueSeq 'GroupSize is 1-based
      If dictFreq.TryGetValue(GroupSize(I), GroupSizeCount) Then
        dictFreq(GroupSize(I)) = GroupSizeCount + 1
      Else
        dictFreq.Add(GroupSize(I), 1)
      End If
      ProgressBar1.Value = I
    Next
    iNumUniqueGrSize = dictFreq.Count
    ReDim dblUniqueGrSize(iNumUniqueGrSize - 1), dblFreqGrSize(iNumUniqueGrSize - 1)
    I = 0
    TotalNumSeq = 0
    ProgressBar1.Maximum = dictFreq.Count
    For Each ValuePairFreq In dictFreq
      dblUniqueGrSize(I) = ValuePairFreq.Key
      dblFreqGrSize(I) = ValuePairFreq.Value
      TotalNumSeq = TotalNumSeq + ValuePairFreq.Key * ValuePairFreq.Value
      ProgressBar1.Value = I
      I = I + 1
    Next
    dictFreq.Clear()
    dictFreq = Nothing
    Call QuickSort2ArrayA(dblUniqueGrSize, dblFreqGrSize, 0, iNumUniqueGrSize - 1)
    ProgressBar1.Value = 0
    'Text output

    sb.Append("The paired reads in FASTQ files: " & sFastq1File & " and " & sFastq2File & ", have been saved to " & sFasPlusFile1 & " and " & sFasPlusFile2 & ", with identical sequences saved in the naming format of SeqID_Count." & CRCR)
    sb.Append(NumPoorSeq & " paired reads containing ambiguous codes are excluded." & vbCrLf)
    sb.Append(NumShortSeq & " paired reads are shorter than " & iReadLen & " and are excluded." & vbCrLf)
    sb.Append("Total number of clean paired reads in FASTQ files " & sFastq1File & " and " & sFastq2File & ": " & TotalNumSeq & vbCrLf)
    sb.Append("Number of unique paired reads: " & iNumUniqueSeq & vbCrLf)
    sb.Append("Least abundant: " & dblFreqGrSize(0) & " paired reads are represented by only " & dblUniqueGrSize(0) & IIf(dblUniqueGrSize(0) = 1, " copy.", " copies.") & vbCrLf)
    sb.Append("Most abundant: " & dblFreqGrSize(iNumUniqueGrSize - 1) & " paired reads are represented by " & dblUniqueGrSize(iNumUniqueGrSize - 1) & IIf(dblUniqueGrSize(iNumUniqueGrSize - 1) = 1, " copy.", " copies.") & CRCR)
    sb.Append("GrSize     Freq" & vbCrLf)
    For I = 0 To iNumUniqueGrSize - 1
      sb.Append(dblUniqueGrSize(I).ToString.PadRight(7) & dblFreqGrSize(I).ToString.PadLeft(7) & vbCrLf)
    Next
    sOut = sb.ToString
    sb.Clear()
    sb = Nothing
    ToolStripLabel1.Text = ""
    Return True
  End Function



  Function FastqToFasPlusPairedBig(ByVal sFastq1File As String, ByVal sFastq2File As String, ByVal sFasPlusFile1 As String, ByVal sFasPlusFile2 As String, ByRef sOut As String, _
                   ByVal iReadLen As Integer, ByRef iNumUniqueGrSize As Integer, ByVal dblUniqueGrSize() As Integer, ByVal dblFreqGrSize() As Integer, ByVal ToolStripLabel1 As ToolStripLabel, ByVal ProgressBar1 As ToolStripProgressBar) As Boolean
    'Process the file in chunks
    'SeqQualCutOff: Include only sequences whose SeqQual is greater.
    Dim I As Integer, J As Integer, K As Integer, lFileLen1 As Integer, lFileLen2 As Integer, UppInd As Integer, UppInd1 As Integer, UppInd2 As Integer
    Dim sPackedSeqFile As String = Path.GetTempFileName 'concatenated and packed Read1 & Read2 & A_n & Read1 & Read2 & A_n ...
    Dim sTmpOutFile As String = Path.GetTempFileName 'Output file for the C++ function CheckSeqRedundancy in the format of UniqueSeqI Count (Only OutFile << Count << endl;). This file will be read in to generate the following:
    'GroupSize Freq
    '1         4003
    '2         3045
    '...
    Dim NumShortSeq As Integer, NumGoodSeq As Integer = 0, NumGoodSeqInChunk As Integer, NumPoorSeq As Integer = 0 'NumPoorSeq is the number of sequences with ambiguous codes. Such sequences are excluded in the new FastqP file.
    Dim PackedLen As Integer, TrueLen As Integer
    Dim sSeq1 As String, sSeq2 As String
    Dim sPackedSeq() As String, sSortedPackedSeq() As String
    Dim SortedCount() As Integer 'Index sSortedPackedSeq SortedCount
    '                                 0 xyz...                     3
    '                                 1 xyz...                    99
    Dim SortedCountInChunk() As Integer
    Dim lChunkLen As Integer, lFreeMem As Long
    Dim sChunkFromFile1 As String, sChunkFromFile2 As String, LineArray1() As String, LineArray2() As String
    Dim tmpByte() As Byte, tmpByte2() As Byte
    Dim NumByteRead As Integer, iNumUniqueSeq As Integer
    Dim SeqByte() As Byte, OutByte() As Byte
    Dim NewLen As Integer
    Dim NumA As Integer  'Number of A to pad to the right to make the sequence length = multiples of 4
    Dim bInclude As Boolean
    Dim fs As New FileStream(sFastq1File, FileMode.Open, FileAccess.Read)
    Dim fs2 As New FileStream(sFastq2File, FileMode.Open, FileAccess.Read)

    Dim lNumChunk As Integer, lRemainLen1 As Integer, lRemainLen2 As Integer
    Dim sRemain As String = "", sRemain2 As String = ""
    Dim tmpUppInd As Integer

    Try
      lFreeMem = GetAvailablePhysicalMem()
    Catch ex As Exception
      MsgBox("Error Encountered in getting system memory!" & CRCR & ex.ToString, vbInformation, "Error")
      lFreeMem = 2000000000
    End Try
    lFileLen1 = FileLen(sFastq1File)
    lFileLen2 = FileLen(sFastq2File)
    lChunkLen = lFreeMem \ 1000
    TrueLen = iReadLen * 2
    NumA = 4 - (TrueLen Mod 4)
    If NumA = 4 Then NumA = 0
    NewLen = iReadLen * 2 + NumA
    PackedLen = NewLen \ 4

    ReDim SeqByte(NewLen - 1)

    If lFileLen1 < lFileLen2 Then
      lNumChunk = lFileLen1 \ lChunkLen
      lRemainLen1 = lFileLen1 Mod lChunkLen
      J = lFileLen2 \ lChunkLen
      J = J - lNumChunk
      lRemainLen2 = J * lChunkLen + (lFileLen2 Mod lChunkLen)
    Else
      lNumChunk = lFileLen2 \ lChunkLen
      lRemainLen2 = lFileLen2 Mod lChunkLen
      J = lFileLen1 \ lChunkLen
      J = J - lNumChunk
      lRemainLen1 = J * lChunkLen + (lFileLen1 Mod lChunkLen)
    End If


    ProgressBar1.Minimum = 0
    ProgressBar1.Maximum = lNumChunk

    ToolStripLabel1.Text = "Processing file in " & lNumChunk & " chunks..."

    For I = 0 To lNumChunk - 1
      ReDim tmpByte(lChunkLen - 1)
      NumGoodSeqInChunk = 0
      NumByteRead = fs.Read(tmpByte, 0, lChunkLen)
      sChunkFromFile1 = sRemain & Encoding.ASCII.GetString(tmpByte)
      LineArray1 = Split(sChunkFromFile1, vbLf)
      sChunkFromFile1 = ""

      NumByteRead = fs2.Read(tmpByte, 0, lChunkLen)
      sChunkFromFile2 = sRemain2 & Encoding.ASCII.GetString(tmpByte)
      LineArray2 = Split(sChunkFromFile2, vbLf)
      sChunkFromFile2 = ""

      UppInd1 = UBound(LineArray1)
      UppInd2 = UBound(LineArray2)
      UppInd = Math.Min(UppInd1, UppInd2)
      tmpUppInd = UppInd \ 4
      ReDim sPackedSeq(tmpUppInd)
      tmpUppInd = tmpUppInd * 4
      'e.g., if we have read in 100 (or 101, 102, 103) lines (with the last line potentially incomplete), then UppInd would be 99 (100, 101, 102); 
      'The number of complete sequence sets are 24, (25, 25, 25) -->tmpUppInd = UppInd \ 4
      'The for-Index should then be 92 (=24*4-4), tmpUppInd = tmpUppInd * 4 - 4
      'The number of trailing lines to sRemain are 
      sRemain = ""
      For J = tmpUppInd To UppInd1 - 1
        sRemain = sRemain & LineArray1(J) & vbLf
      Next
      sRemain = sRemain & LineArray1(J)
      sRemain2 = ""
      For J = tmpUppInd To UppInd2 - 1
        sRemain2 = sRemain2 & LineArray2(J) & vbLf
      Next
      sRemain2 = sRemain2 & LineArray2(J)
      For J = 0 To tmpUppInd - 4 Step 4
        sSeq1 = LineArray1(J + 1)
        sSeq2 = LineArray2(J + 1)
        If sSeq1.Length < iReadLen Or sSeq2.Length < iReadLen Then
          NumShortSeq = NumShortSeq + 1
        Else
          bInclude = True
          tmpByte2 = Encoding.ASCII.GetBytes(sSeq2) 'sSeq2 is poorer in quality than sSeq1
          For K = 0 To iReadLen - 1
            If tmpByte2(K) = 78 Then
              bInclude = False
              Exit For
            End If
          Next
          If bInclude Then
            tmpByte = Encoding.ASCII.GetBytes(sSeq1) 'Perhaps poor reuse of OutByte
            For K = 0 To iReadLen - 1
              If tmpByte(K) = 78 Then
                bInclude = False
                Exit For
              End If
            Next
          End If
          If bInclude Then
            Buffer.BlockCopy(tmpByte, 0, SeqByte, 0, iReadLen)
            Buffer.BlockCopy(tmpByte2, 0, SeqByte, iReadLen, iReadLen)
            For K = 0 To NumA - 1
              SeqByte(TrueLen + K) = 65
            Next
            If PackNuc(SeqByte, NewLen, OutByte) Then
              sPackedSeq(NumGoodSeqInChunk) = Encoding.Default.GetString(OutByte)
              NumGoodSeqInChunk = NumGoodSeqInChunk + 1
            Else
              NumPoorSeq = NumPoorSeq + 1
            End If
          Else
            NumPoorSeq = NumPoorSeq + 1
          End If
        End If
      Next
      Erase LineArray1, LineArray2
      If NumGoodSeqInChunk > 0 Then
        ReDim Preserve sPackedSeq(NumGoodSeqInChunk - 1)
        ReDim SortedCountInChunk(NumGoodSeqInChunk - 1)
        QuickSortA(sPackedSeq, 0, NumGoodSeqInChunk - 1)
        'Array.Sort(sPackedSeq, 0, NumGoodSeqInChunk - 1) 'Does not seem to work with byte values up to 255.
        K = 0
        SortedCountInChunk(K) = 1
        For J = 1 To NumGoodSeqInChunk - 1
          If sPackedSeq(J) = sPackedSeq(K) Then
            SortedCountInChunk(K) = SortedCountInChunk(K) + 1
          Else
            K = K + 1
            sPackedSeq(K) = sPackedSeq(J)
            SortedCountInChunk(K) = 1
          End If
        Next
        ReDim Preserve sPackedSeq(K)
        If iNumUniqueSeq = 0 Then
          sSortedPackedSeq = sPackedSeq
          SortedCount = SortedCountInChunk
          iNumUniqueSeq = K + 1
        Else
          'Merge the two array
          Dim Ind1 As Integer = 0, Ind2 As Integer = 0, NewInd As Integer = 0
          Dim NewArray() As String, NewCount() As Integer
          ReDim NewArray(iNumUniqueSeq + K), NewCount(iNumUniqueSeq + K)
          K = K + 1

          Do While Ind1 < iNumUniqueSeq And Ind2 < K
            If sSortedPackedSeq(Ind1) = sPackedSeq(Ind2) Then
              NewArray(NewInd) = sSortedPackedSeq(Ind1)
              NewCount(NewInd) = NewCount(NewInd) + SortedCount(Ind1) + SortedCountInChunk(Ind2)
              Ind1 = Ind1 + 1
              Ind2 = Ind2 + 1
            ElseIf sSortedPackedSeq(Ind1) < sPackedSeq(Ind2) Then
              NewArray(NewInd) = sSortedPackedSeq(Ind1)
              NewCount(NewInd) = SortedCount(Ind1)
              Ind1 = Ind1 + 1
            Else
              NewArray(NewInd) = sPackedSeq(Ind2)
              NewCount(NewInd) = SortedCountInChunk(Ind2)
              Ind2 = Ind2 + 1
            End If
            NewInd = NewInd + 1
          Loop
          If Ind1 = iNumUniqueSeq Then 'elements in sSortedPackedSeq are all in NewArray
            For J = Ind2 To K - 1
              NewArray(NewInd) = sPackedSeq(J)
              NewCount(NewInd) = SortedCountInChunk(J)
              NewInd = NewInd + 1
            Next
          ElseIf Ind2 = K Then
            For J = Ind1 To iNumUniqueSeq - 1
              NewArray(NewInd) = sSortedPackedSeq(J)
              NewCount(NewInd) = SortedCount(J)
              NewInd = NewInd + 1
            Next
          End If
          sSortedPackedSeq = NewArray
          SortedCount = NewCount
          iNumUniqueSeq = NewInd
        End If
        NumGoodSeq = NumGoodSeq + NumGoodSeqInChunk
      End If
      ProgressBar1.Value = I
      Application.DoEvents()
    Next

    If lRemainLen1 > 0 Then
      ReDim tmpByte(lRemainLen1 - 1)
      NumGoodSeqInChunk = 0
      NumByteRead = fs.Read(tmpByte, 0, lRemainLen1)
      sChunkFromFile1 = sRemain & Encoding.ASCII.GetString(tmpByte)
      LineArray1 = Split(sChunkFromFile1, vbLf)
      sChunkFromFile1 = ""

      ReDim tmpByte(lRemainLen2 - 1)
      NumByteRead = fs2.Read(tmpByte, 0, lRemainLen2)
      sChunkFromFile2 = sRemain2 & Encoding.ASCII.GetString(tmpByte)
      LineArray2 = Split(sChunkFromFile2, vbLf)
      sChunkFromFile2 = ""
      Erase tmpByte

      'Now the LineArray1 and LineArray2 must have the same number of lines.
      UppInd = UBound(LineArray1)
      ReDim sPackedSeq((UppInd + 1) \ 4 - 1)
      For J = 0 To UppInd - 3 Step 4
        sSeq1 = LineArray1(J + 1)
        sSeq2 = LineArray2(J + 1)
        If sSeq1.Length < iReadLen Or sSeq2.Length < iReadLen Then
          NumShortSeq = NumShortSeq + 1
        Else
          bInclude = True
          tmpByte2 = Encoding.ASCII.GetBytes(sSeq2) 'sSeq2 is poorer in quality than sSeq1
          For K = 0 To iReadLen - 1
            If tmpByte2(K) = 78 Then
              bInclude = False
              Exit For
            End If
          Next
          If bInclude Then
            tmpByte = Encoding.ASCII.GetBytes(sSeq1) 'Perhaps poor reuse of OutByte
            For K = 0 To iReadLen - 1
              If tmpByte(K) = 78 Then
                bInclude = False
                Exit For
              End If
            Next
          End If
          If bInclude Then
            Buffer.BlockCopy(tmpByte, 0, SeqByte, 0, iReadLen)
            Buffer.BlockCopy(tmpByte2, 0, SeqByte, iReadLen, iReadLen)
            For K = 0 To NumA - 1
              SeqByte(TrueLen + K) = 65
            Next
            If PackNuc(SeqByte, NewLen, OutByte) Then
              sPackedSeq(NumGoodSeqInChunk) = Encoding.Default.GetString(OutByte)
              NumGoodSeqInChunk = NumGoodSeqInChunk + 1
            Else
              NumPoorSeq = NumPoorSeq + 1
            End If
          Else
            NumPoorSeq = NumPoorSeq + 1
          End If
        End If
      Next
      Erase LineArray1, LineArray2
      If NumGoodSeqInChunk > 0 Then
        ReDim SortedCountInChunk(NumGoodSeqInChunk - 1)
        ReDim Preserve sPackedSeq(NumGoodSeqInChunk - 1)
        QuickSortA(sPackedSeq, 0, NumGoodSeqInChunk - 1)
        'Array.Sort(sPackedSeq)
        K = 0
        SortedCountInChunk(K) = 1
        For J = 1 To NumGoodSeqInChunk - 1
          If sPackedSeq(J) = sPackedSeq(K) Then
            SortedCountInChunk(K) = SortedCountInChunk(K) + 1
          Else
            K = K + 1
            sPackedSeq(K) = sPackedSeq(J)
            SortedCountInChunk(K) = 1
          End If
        Next
        ReDim Preserve sPackedSeq(K)

        If iNumUniqueSeq = 0 Then
          sSortedPackedSeq = sPackedSeq
          SortedCount = SortedCountInChunk
          iNumUniqueSeq = K + 1
        Else
          'Merge the two array
          Dim Ind1 As Integer = 0, Ind2 As Integer = 0, NewInd As Integer = 0
          Dim NewArray() As String, NewCount() As Integer
          ReDim NewArray(iNumUniqueSeq + K), NewCount(iNumUniqueSeq + K)
          K = K + 1

          Do While Ind1 < iNumUniqueSeq And Ind2 < K
            If sSortedPackedSeq(Ind1) = sPackedSeq(Ind2) Then
              NewArray(NewInd) = sSortedPackedSeq(Ind1)
              NewCount(NewInd) = NewCount(NewInd) + SortedCount(Ind1) + SortedCountInChunk(Ind2)
              Ind1 = Ind1 + 1
              Ind2 = Ind2 + 1
            ElseIf sSortedPackedSeq(Ind1) < sPackedSeq(Ind2) Then
              NewArray(NewInd) = sSortedPackedSeq(Ind1)
              NewCount(NewInd) = SortedCount(Ind1)
              Ind1 = Ind1 + 1
            Else
              NewArray(NewInd) = sPackedSeq(Ind2)
              NewCount(NewInd) = SortedCountInChunk(Ind2)
              Ind2 = Ind2 + 1
            End If
            NewInd = NewInd + 1
          Loop
          If Ind1 = iNumUniqueSeq Then 'elements in sSortedPackedSeq are all in NewArray
            For J = Ind2 To K - 1
              NewArray(NewInd) = sPackedSeq(J)
              NewCount(NewInd) = SortedCountInChunk(J)
              NewInd = NewInd + 1
            Next
          ElseIf Ind2 = K Then
            For J = Ind1 To iNumUniqueSeq - 1
              NewArray(NewInd) = sSortedPackedSeq(J)
              NewCount(NewInd) = SortedCount(J)
              NewInd = NewInd + 1
            Next
          End If
          sSortedPackedSeq = NewArray
          SortedCount = NewCount
          iNumUniqueSeq = NewInd
        End If
        NumGoodSeq = NumGoodSeq + NumGoodSeqInChunk
      End If
    End If
    ProgressBar1.Value = 0
    fs.Close()
    fs2.Close()
    Erase sPackedSeq, SortedCountInChunk

    'Writing FasP file and the stats
    Dim sb As New StringBuilder, sb2 As New StringBuilder
    Dim sTmp As String
    Dim dictFreq As New Dictionary(Of Integer, Integer)
    Dim ValueDictFreq As Integer
    Dim ValuePairDictFreq As KeyValuePair(Of Integer, Integer)

    If File.Exists(sFasPlusFile1) Then
      Kill(sFasPlusFile1)
    End If
    If File.Exists(sFasPlusFile2) Then
      Kill(sFasPlusFile2)
    End If
    ProgressBar1.Maximum = iNumUniqueSeq
    For I = 0 To iNumUniqueSeq - 1
      sTmp = ">S" & I + 1 & "_" & SortedCount(I)
      OutByte = Encoding.Default.GetBytes(sSortedPackedSeq(I))
      UnpackNuc(OutByte, PackedLen, TrueLen, SeqByte)
      sSeq1 = Encoding.ASCII.GetString(SeqByte)
      sb.Append(sTmp & ".1" & vbLf)
      sb.Append(Strings.Left(sSeq1, iReadLen) & vbLf)

      sb2.Append(sTmp & ".2" & vbLf)
      sb2.Append(Strings.Mid(sSeq1, iReadLen + 1) & vbLf)
      If I Mod 10000 = 0 Then
        File.AppendAllText(sFasPlusFile1, sb.ToString)
        File.AppendAllText(sFasPlusFile2, sb2.ToString)
        sb.Clear()
        sb2.Clear()
      End If
      ProgressBar1.Value = I
    Next
    ProgressBar1.Value = 0
    File.AppendAllText(sFasPlusFile1, sb.ToString)
    File.AppendAllText(sFasPlusFile2, sb2.ToString)
    sb.Clear()
    sb2.Clear()
    sb2 = Nothing
    Erase sSortedPackedSeq

    For I = 0 To iNumUniqueSeq - 1
      If dictFreq.TryGetValue(SortedCount(I), ValueDictFreq) Then
        dictFreq(SortedCount(I)) = ValueDictFreq + 1
      Else
        dictFreq.Add(SortedCount(I), 1)
      End If
    Next
    iNumUniqueGrSize = dictFreq.Count
    ReDim dblUniqueGrSize(iNumUniqueGrSize - 1), dblFreqGrSize(iNumUniqueGrSize - 1)

    I = 0
    For Each ValuePairDictFreq In dictFreq
      dblUniqueGrSize(I) = ValuePairDictFreq.Key
      dblFreqGrSize(I) = ValuePairDictFreq.Value
      I = I + 1
    Next
    dictFreq.Clear()
    dictFreq = Nothing
    Call QuickSort2ArrayA(dblUniqueGrSize, dblFreqGrSize, 0, iNumUniqueGrSize - 1)
    Erase SortedCount

    'Output
    ToolStripLabel1.Text = "Finishing ..."
    sb.Append("The paired reads in FASTQ files: " & sFastq1File & " and " & sFastq2File & ", have been saved to " & sFasPlusFile1 & " and " & sFasPlusFile2 & ", with identical sequences saved in the naming format of SeqID_Count." & CRCR)
    If NumPoorSeq > 0 Then
      sb.Append(NumPoorSeq & " paired reads containing ambiguous codes are excluded." & vbCrLf)
    End If
    If NumShortSeq > 0 Then
      sb.Append(NumShortSeq & " paired reads are shorter than " & iReadLen & " and are " & IIf(NumPoorSeq > 0, "also", "") & " excluded." & vbCrLf)
    End If
    sb.Append("Total number of clean paired reads in FASTQ files " & sFastq1File & " and " & sFastq2File & ": " & NumGoodSeq & vbCrLf)
    sb.Append("Number of unique paired reads: " & iNumUniqueSeq & CRCR)
    sb.Append("Size of original FASTQ files:" & vbCrLf & sFastq1File & ": " & lFileLen1 & vbCrLf & sFastq2File & ": " & lFileLen2 & CRCR)
    sb.Append("Size of new FASTA+ files:" & vbCrLf & sFasPlusFile1 & ": " & FileLen(sFasPlusFile1) & vbCrLf & sFasPlusFile2 & ": " & FileLen(sFasPlusFile2) & CRCR)
    sb.Append("Least abundant: " & dblFreqGrSize(0) & " paired reads are represented by only " & dblUniqueGrSize(0) & IIf(dblUniqueGrSize(0) = 1, " copy.", " copies.") & vbCrLf)
    sb.Append("Most abundant: " & dblFreqGrSize(iNumUniqueGrSize - 1) & " paired reads are represented by " & dblUniqueGrSize(iNumUniqueGrSize - 1) & IIf(dblUniqueGrSize(iNumUniqueGrSize - 1) = 1, " copy.", " copies.") & CRCR)
    sb.Append("GrSize     Freq" & vbCrLf)
    For I = 0 To iNumUniqueGrSize - 1
      sb.Append(dblUniqueGrSize(I).ToString.PadRight(7) & dblFreqGrSize(I).ToString.PadLeft(7) & vbCrLf)
    Next
    sOut = sb.ToString
    sb.Clear()
    sb = Nothing
    ToolStripLabel1.Text = ""
    Return True
  End Function



  'LineArray(): Fastq in, PackedSeqOut
  'Exclude Seqs containing "N" and Seqs shorter than iReadLen
  'Seqs that are longer than iReadLen: only the first iReadLen characters are used.
  Private Sub GetPackedSeq(ByVal LineArray() As String, ByRef iNumPoorSeq As Integer, ByRef iNumShort As Integer, _
                           ByVal iReadLen As Integer, ByVal ProgressBar1 As ToolStripProgressBar)
    Dim I As Integer, CC As Integer, UppInd As Integer
    Dim sSeq As String
    Dim SeqByte() As Byte, OutByte() As Byte

    UppInd = UBound(LineArray)
    ProgressBar1.Minimum = 0
    ProgressBar1.Maximum = UppInd
    CC = 0
    For I = 0 To UppInd - 3 Step 4
      sSeq = LineArray(I + 1)
      If sSeq.Length < iReadLen Then
        iNumShort = iNumShort + 1
      Else
        If InStr(sSeq, "N") = 0 Then 'Good sSeq
          SeqByte = Encoding.ASCII.GetBytes(sSeq)
          If PackNuc(SeqByte, iReadLen, OutByte) Then
            LineArray(CC) = Encoding.Default.GetString(OutByte)
            CC = CC + 1
          Else
            iNumPoorSeq = iNumPoorSeq + 1
          End If
          iNumPoorSeq = iNumPoorSeq + 1
        End If
      End If
    Next
    ProgressBar1.Value = 0

  End Sub

End Module
