﻿Imports System.IO
Imports System.Text
Module mDLL
  Private Declare Function ClustalDLL Lib "C:\Cin24h\ClustalDLL\Debug\ClustalDLL.dll" (ByVal lNumOpt As Integer, ByVal sOption As String, ByRef FstArgLen As Integer) As Integer

  'SumMatInd: 
  'AA: Blosum0Pam1Gonnet2ID3
  'Nuc: IUB0Clustal1
  Function DoAlign(ByVal sSeq() As String, ByVal sName() As String, ByVal iNumSeq As Integer, _
                   ByVal bIsAA As Boolean, ByVal SubMatInd As Integer, ByVal TransitionWT As Single, ByVal bDelGap As Boolean, _
                   ByVal bUserTree As Boolean, ByVal sUserTree As String, ByVal bKeepOrder As Boolean, _
                   ByVal PairwiseGO As Single, ByVal PairwiseGE As Single, ByVal GlobalGO As Single, ByVal GlobalGE As Single, _
                   ByRef sOut As String) As Boolean
    Dim I As Integer
    Dim OutFASFile As String, AlnFile As String, AlignedFileStr As String, TreeFile As String
    Dim tmpName() As String
    Dim sArgStr() As String
    Dim sOpt As String
    Dim tmpInd() As Integer
    Dim ArgLen() As Integer
    Dim NumOpt As Integer
    Dim ProtMat() As String = Split("BLOSUM, PAM, GONNET, ID", ",")
    Dim NucMat() As String = Split("IUB,CLUSTALW", ",")

    ReDim tmpName(iNumSeq - 1), tmpInd(iNumSeq - 1)

    For I = 0 To iNumSeq - 1
      tmpName(I) = "S" & I
      tmpInd(I) = I
    Next I

    If bDelGap Then
      For I = 0 To iNumSeq - 1
        sSeq(I) = Replace(sSeq(I), "-", "")
      Next I
    End If

    OutFASFile = Path.GetTempFileName
    AlnFile = Path.GetTempFileName
    TreeFile = Left(OutFASFile, Len(OutFASFile) - 4) & ".dnd"
    Call OutFas(OutFASFile, sSeq, tmpName, iNumSeq)

    'Construct the command parameter string. ClustalDLL requres that the parameter strings are separated by a single space. Search for "  -" and "-" to confirm
    sOpt = OutFASFile
    sOpt = sOpt & " /OUTFILE=" & AlnFile
    If bIsAA Then
      sOpt = sOpt & " /TYPE=PROTEIN"
      sOpt = sOpt & " /PWMATRIX=" & ProtMat(SubMatInd) 'Protein weight matrix=BLOSUM, PAM, GONNET, ID
      sOpt = sOpt & " /MATRIX=" & ProtMat(SubMatInd) ' :Protein weight matrix=BLOSUM, PAM, GONNET, ID or filename
    Else
      sOpt = sOpt & " /TYPE=DNA"
      sOpt = sOpt & " /PWDNAMATRIX=" & NucMat(SubMatInd) ':DNA weight matrix=IUB, CLUSTALW or filename
      sOpt = sOpt & " /DNAMATRIX=" & NucMat(SubMatInd)  ' DNA weight matrix=IUB, CLUSTALW or filename
      sOpt = sOpt & " /TRANSWEIGHT=" & TransitionWT.ToString
    End If
    If bUserTree Then
      sOpt = sOpt & " /USETREE=" & TreeFile
      QuickSort2ArrayD(sName, tmpInd, 0, iNumSeq - 1)
      For I = 0 To iNumSeq - 1
        sUserTree = Replace(sUserTree, sName(I), "S" & tmpInd(I))
      Next
      QuickSort2ArrayD(tmpInd, sName, 0, iNumSeq - 1)
      File.WriteAllText(TreeFile, sUserTree)
    End If
    If bKeepOrder Then
      sOpt = sOpt & " /OUTORDER=INPUT"
    Else
      sOpt = sOpt & " /OUTORDER=ALIGN"
    End If

    '  If optSpeed(0).Value Then
    '    sOpt = sOpt & " /QUICKTREE"
    '  End If

    sOpt = sOpt & " /PWGAPOPEN=" & PairwiseGO ' :gap opening penalty
    sOpt = sOpt & " /PWGAPEXT=" & PairwiseGE ': gap extension penalty

    sOpt = sOpt & " /GAPOPEN=" & GlobalGO
    sOpt = sOpt & " /GAPEXT=" & GlobalGE
    sOpt = sOpt & " /MAXDIV=30"

    sArgStr = Split(sOpt, " ")
    NumOpt = UBound(sArgStr) + 1
    ReDim ArgLen(NumOpt - 1)
    For I = 0 To NumOpt - 1
      ArgLen(I) = Len(sArgStr(I))
    Next I


    If ClustalDLL(NumOpt, sOpt, ArgLen(0)) = 0 Then
      sOut = File.ReadAllText(AlnFile)

      If iNumSeq > 2 And Not bUserTree Then
        sOut = sOut & CRCR & File.ReadAllText(TreeFile)
        'If MsgBox("Do you wish to view the tree used for multiple alignment?", vbInformation + vbYesNo, "Info") = vbYes Then
        '  NewTreeStr = GetNHTree(TreeFile)
        '  For I = iNumSeq - 1 To 0 Step -1
        '    NewTreeStr = Replace(NewTreeStr, "S" & I, mName(I))
        '  Next I
        '  Call Naryform.PlotTree(0, NewTreeStr)
        'End If
      End If

      'If ReadSeqFile(AlnFile, SeqFormat.CLUSTAL, sSeq(), tmpName(), iNumSeq, mAlignedLen, ProgressBar1) Then  'ReadClustal("clustal.aln")
      '  If chkKeepOrder.Value = 0 Then 'otherwise tmpName() and mName are in the same order.
      '    For I = 0 To iNumSeq - 1
      '      lTmp = Val(Mid(tmpName(I), 2))
      '      tmpName(I) = mName(lTmp)
      '    Next I
      '    mName = tmpName
      '  End If
      '  mDone = True
      'Else
      '  Call MsgBox("Error reading aligned file", vbInformation)
      'End If
    Else
      Call MsgBox("Error encountered in alignment", vbOKOnly + vbExclamation, "Error!")
    End If
    'Bug in ClustalDll.Dll: might not have closed the treefile.
    'If FileExist(TreeFile) Then
    '  Kill TreeFile
    'End If
    If File.Exists(OutFASFile) Then
      Kill(OutFASFile)
    End If
    If File.Exists(AlnFile) Then
      Kill(AlnFile)
    End If
    Return True
  End Function
End Module
