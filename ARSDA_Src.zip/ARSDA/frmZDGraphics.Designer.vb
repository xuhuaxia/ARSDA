﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmZDGraphics
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
    Me.components = New System.ComponentModel.Container()
    Me.ZG1 = New ZedGraph.ZedGraphControl()
    Me.frChange = New System.Windows.Forms.GroupBox()
    Me.cboMarkerColor = New System.Windows.Forms.ComboBox()
    Me.lblMarkerColor = New System.Windows.Forms.Label()
    Me.lblMarkerStyle = New System.Windows.Forms.Label()
    Me.cboMarkerStyle = New System.Windows.Forms.ComboBox()
    Me.lblMarkerSize = New System.Windows.Forms.Label()
    Me.udMarkerSize = New System.Windows.Forms.NumericUpDown()
    Me.lblBarWidth = New System.Windows.Forms.Label()
    Me.udBarWidth = New System.Windows.Forms.NumericUpDown()
    Me.lblFontSize = New System.Windows.Forms.Label()
    Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown()
    Me.lblGraphType = New System.Windows.Forms.Label()
    Me.cboGraphType = New System.Windows.Forms.ComboBox()
    Me.GraphMenu = New System.Windows.Forms.MenuStrip()
    Me.mnuFile = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileSave = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileSaveEMF = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileSaveBMP = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuFileExit = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuEdit = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuEditCopyEMF = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuEditCopyBMP = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuCopyData = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuGraph = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuGraphMinX = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuGraphMaxX = New System.Windows.Forms.ToolStripMenuItem()
    Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
    Me.mnuGraphMinY = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuGraphMaxY = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuHelp = New System.Windows.Forms.ToolStripMenuItem()
    Me.mnuHelpGeneral = New System.Windows.Forms.ToolStripMenuItem()
    Me.PrintDialog1 = New System.Windows.Forms.PrintDialog()
    Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
    Me.frChange.SuspendLayout()
    CType(Me.udMarkerSize, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.udBarWidth, System.ComponentModel.ISupportInitialize).BeginInit()
    CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
    Me.GraphMenu.SuspendLayout()
    Me.SuspendLayout()
    '
    'ZG1
    '
    Me.ZG1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
    Me.ZG1.Location = New System.Drawing.Point(1, 27)
    Me.ZG1.Name = "ZG1"
    Me.ZG1.ScrollGrace = 0.0R
    Me.ZG1.ScrollMaxX = 0.0R
    Me.ZG1.ScrollMaxY = 0.0R
    Me.ZG1.ScrollMaxY2 = 0.0R
    Me.ZG1.ScrollMinX = 0.0R
    Me.ZG1.ScrollMinY = 0.0R
    Me.ZG1.ScrollMinY2 = 0.0R
    Me.ZG1.Size = New System.Drawing.Size(803, 450)
    Me.ZG1.TabIndex = 0
    '
    'frChange
    '
    Me.frChange.AutoSize = True
    Me.frChange.Controls.Add(Me.cboMarkerColor)
    Me.frChange.Controls.Add(Me.lblMarkerColor)
    Me.frChange.Controls.Add(Me.lblMarkerStyle)
    Me.frChange.Controls.Add(Me.cboMarkerStyle)
    Me.frChange.Controls.Add(Me.lblMarkerSize)
    Me.frChange.Controls.Add(Me.udMarkerSize)
    Me.frChange.Controls.Add(Me.lblBarWidth)
    Me.frChange.Controls.Add(Me.udBarWidth)
    Me.frChange.Controls.Add(Me.lblFontSize)
    Me.frChange.Controls.Add(Me.NumericUpDown1)
    Me.frChange.Controls.Add(Me.lblGraphType)
    Me.frChange.Controls.Add(Me.cboGraphType)
    Me.frChange.Dock = System.Windows.Forms.DockStyle.Bottom
    Me.frChange.Location = New System.Drawing.Point(0, 471)
    Me.frChange.Name = "frChange"
    Me.frChange.Size = New System.Drawing.Size(804, 80)
    Me.frChange.TabIndex = 2
    Me.frChange.TabStop = False
    '
    'cboMarkerColor
    '
    Me.cboMarkerColor.Enabled = False
    Me.cboMarkerColor.FormattingEnabled = True
    Me.cboMarkerColor.Location = New System.Drawing.Point(560, 39)
    Me.cboMarkerColor.Name = "cboMarkerColor"
    Me.cboMarkerColor.Size = New System.Drawing.Size(63, 21)
    Me.cboMarkerColor.TabIndex = 11
    '
    'lblMarkerColor
    '
    Me.lblMarkerColor.AutoSize = True
    Me.lblMarkerColor.Location = New System.Drawing.Point(557, 16)
    Me.lblMarkerColor.Name = "lblMarkerColor"
    Me.lblMarkerColor.Size = New System.Drawing.Size(66, 13)
    Me.lblMarkerColor.TabIndex = 10
    Me.lblMarkerColor.Text = "Marker color"
    '
    'lblMarkerStyle
    '
    Me.lblMarkerStyle.AutoSize = True
    Me.lblMarkerStyle.Location = New System.Drawing.Point(466, 16)
    Me.lblMarkerStyle.Name = "lblMarkerStyle"
    Me.lblMarkerStyle.Size = New System.Drawing.Size(64, 13)
    Me.lblMarkerStyle.TabIndex = 9
    Me.lblMarkerStyle.Text = "Marker style"
    '
    'cboMarkerStyle
    '
    Me.cboMarkerStyle.Enabled = False
    Me.cboMarkerStyle.FormattingEnabled = True
    Me.cboMarkerStyle.Location = New System.Drawing.Point(469, 40)
    Me.cboMarkerStyle.Name = "cboMarkerStyle"
    Me.cboMarkerStyle.Size = New System.Drawing.Size(61, 21)
    Me.cboMarkerStyle.TabIndex = 8
    '
    'lblMarkerSize
    '
    Me.lblMarkerSize.AutoSize = True
    Me.lblMarkerSize.Location = New System.Drawing.Point(392, 16)
    Me.lblMarkerSize.Name = "lblMarkerSize"
    Me.lblMarkerSize.Size = New System.Drawing.Size(61, 13)
    Me.lblMarkerSize.TabIndex = 7
    Me.lblMarkerSize.Text = "Marker size"
    '
    'udMarkerSize
    '
    Me.udMarkerSize.Enabled = False
    Me.udMarkerSize.Location = New System.Drawing.Point(395, 40)
    Me.udMarkerSize.Maximum = New Decimal(New Integer() {40, 0, 0, 0})
    Me.udMarkerSize.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
    Me.udMarkerSize.Name = "udMarkerSize"
    Me.udMarkerSize.Size = New System.Drawing.Size(54, 20)
    Me.udMarkerSize.TabIndex = 6
    Me.udMarkerSize.Value = New Decimal(New Integer() {10, 0, 0, 0})
    '
    'lblBarWidth
    '
    Me.lblBarWidth.AutoSize = True
    Me.lblBarWidth.Location = New System.Drawing.Point(298, 16)
    Me.lblBarWidth.Name = "lblBarWidth"
    Me.lblBarWidth.Size = New System.Drawing.Size(51, 13)
    Me.lblBarWidth.TabIndex = 5
    Me.lblBarWidth.Text = "Bar width"
    '
    'udBarWidth
    '
    Me.udBarWidth.DecimalPlaces = 2
    Me.udBarWidth.Enabled = False
    Me.udBarWidth.Increment = New Decimal(New Integer() {2, 0, 0, 131072})
    Me.udBarWidth.Location = New System.Drawing.Point(301, 41)
    Me.udBarWidth.Maximum = New Decimal(New Integer() {20, 0, 0, 65536})
    Me.udBarWidth.Minimum = New Decimal(New Integer() {1, 0, 0, 131072})
    Me.udBarWidth.Name = "udBarWidth"
    Me.udBarWidth.Size = New System.Drawing.Size(58, 20)
    Me.udBarWidth.TabIndex = 4
    Me.udBarWidth.Value = New Decimal(New Integer() {1, 0, 0, 0})
    '
    'lblFontSize
    '
    Me.lblFontSize.AutoSize = True
    Me.lblFontSize.Location = New System.Drawing.Point(211, 16)
    Me.lblFontSize.Name = "lblFontSize"
    Me.lblFontSize.Size = New System.Drawing.Size(49, 13)
    Me.lblFontSize.TabIndex = 3
    Me.lblFontSize.Text = "Font size"
    '
    'NumericUpDown1
    '
    Me.NumericUpDown1.Location = New System.Drawing.Point(214, 41)
    Me.NumericUpDown1.Maximum = New Decimal(New Integer() {36, 0, 0, 0})
    Me.NumericUpDown1.Minimum = New Decimal(New Integer() {6, 0, 0, 0})
    Me.NumericUpDown1.Name = "NumericUpDown1"
    Me.NumericUpDown1.Size = New System.Drawing.Size(53, 20)
    Me.NumericUpDown1.TabIndex = 2
    Me.NumericUpDown1.Value = New Decimal(New Integer() {8, 0, 0, 0})
    '
    'lblGraphType
    '
    Me.lblGraphType.AutoSize = True
    Me.lblGraphType.Location = New System.Drawing.Point(6, 16)
    Me.lblGraphType.Name = "lblGraphType"
    Me.lblGraphType.Size = New System.Drawing.Size(59, 13)
    Me.lblGraphType.TabIndex = 1
    Me.lblGraphType.Text = "Graph type"
    '
    'cboGraphType
    '
    Me.cboGraphType.FormattingEnabled = True
    Me.cboGraphType.Location = New System.Drawing.Point(6, 40)
    Me.cboGraphType.Name = "cboGraphType"
    Me.cboGraphType.Size = New System.Drawing.Size(190, 21)
    Me.cboGraphType.TabIndex = 0
    '
    'GraphMenu
    '
    Me.GraphMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFile, Me.mnuEdit, Me.mnuGraph, Me.mnuHelp})
    Me.GraphMenu.Location = New System.Drawing.Point(0, 0)
    Me.GraphMenu.Name = "GraphMenu"
    Me.GraphMenu.Size = New System.Drawing.Size(804, 24)
    Me.GraphMenu.TabIndex = 3
    Me.GraphMenu.Text = "gMenu"
    '
    'mnuFile
    '
    Me.mnuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFileSave, Me.mnuFileExit})
    Me.mnuFile.Name = "mnuFile"
    Me.mnuFile.Size = New System.Drawing.Size(37, 20)
    Me.mnuFile.Text = "File"
    '
    'mnuFileSave
    '
    Me.mnuFileSave.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFileSaveEMF, Me.mnuFileSaveBMP})
    Me.mnuFileSave.Name = "mnuFileSave"
    Me.mnuFileSave.Size = New System.Drawing.Size(152, 22)
    Me.mnuFileSave.Text = "Save"
    '
    'mnuFileSaveEMF
    '
    Me.mnuFileSaveEMF.Name = "mnuFileSaveEMF"
    Me.mnuFileSaveEMF.Size = New System.Drawing.Size(152, 22)
    Me.mnuFileSaveEMF.Text = "To EMF"
    '
    'mnuFileSaveBMP
    '
    Me.mnuFileSaveBMP.Name = "mnuFileSaveBMP"
    Me.mnuFileSaveBMP.Size = New System.Drawing.Size(152, 22)
    Me.mnuFileSaveBMP.Text = "To BMP"
    '
    'mnuFileExit
    '
    Me.mnuFileExit.Name = "mnuFileExit"
    Me.mnuFileExit.Size = New System.Drawing.Size(152, 22)
    Me.mnuFileExit.Text = "Exit"
    '
    'mnuEdit
    '
    Me.mnuEdit.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuEditCopyEMF, Me.mnuEditCopyBMP, Me.mnuCopyData})
    Me.mnuEdit.Name = "mnuEdit"
    Me.mnuEdit.Size = New System.Drawing.Size(39, 20)
    Me.mnuEdit.Text = "Edit"
    '
    'mnuEditCopyEMF
    '
    Me.mnuEditCopyEMF.Name = "mnuEditCopyEMF"
    Me.mnuEditCopyEMF.Size = New System.Drawing.Size(152, 22)
    Me.mnuEditCopyEMF.Text = "Copy as EMF"
    '
    'mnuEditCopyBMP
    '
    Me.mnuEditCopyBMP.Name = "mnuEditCopyBMP"
    Me.mnuEditCopyBMP.Size = New System.Drawing.Size(152, 22)
    Me.mnuEditCopyBMP.Text = "Copy as BMP"
    '
    'mnuCopyData
    '
    Me.mnuCopyData.Name = "mnuCopyData"
    Me.mnuCopyData.Size = New System.Drawing.Size(152, 22)
    Me.mnuCopyData.Text = "Copy data"
    '
    'mnuGraph
    '
    Me.mnuGraph.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuGraphMinX, Me.mnuGraphMaxX, Me.ToolStripMenuItem1, Me.mnuGraphMinY, Me.mnuGraphMaxY})
    Me.mnuGraph.Name = "mnuGraph"
    Me.mnuGraph.Size = New System.Drawing.Size(51, 20)
    Me.mnuGraph.Text = "Graph"
    Me.mnuGraph.Visible = False
    '
    'mnuGraphMinX
    '
    Me.mnuGraphMinX.Name = "mnuGraphMinX"
    Me.mnuGraphMinX.Size = New System.Drawing.Size(157, 22)
    Me.mnuGraphMinX.Text = "Set minimum X"
    '
    'mnuGraphMaxX
    '
    Me.mnuGraphMaxX.Name = "mnuGraphMaxX"
    Me.mnuGraphMaxX.Size = New System.Drawing.Size(157, 22)
    Me.mnuGraphMaxX.Text = "Set maximum X"
    '
    'ToolStripMenuItem1
    '
    Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
    Me.ToolStripMenuItem1.Size = New System.Drawing.Size(154, 6)
    '
    'mnuGraphMinY
    '
    Me.mnuGraphMinY.Name = "mnuGraphMinY"
    Me.mnuGraphMinY.Size = New System.Drawing.Size(157, 22)
    Me.mnuGraphMinY.Text = "Set minimum Y"
    '
    'mnuGraphMaxY
    '
    Me.mnuGraphMaxY.Name = "mnuGraphMaxY"
    Me.mnuGraphMaxY.Size = New System.Drawing.Size(157, 22)
    Me.mnuGraphMaxY.Text = "Set maximum Y"
    '
    'mnuHelp
    '
    Me.mnuHelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuHelpGeneral})
    Me.mnuHelp.Name = "mnuHelp"
    Me.mnuHelp.Size = New System.Drawing.Size(44, 20)
    Me.mnuHelp.Text = "Help"
    '
    'mnuHelpGeneral
    '
    Me.mnuHelpGeneral.Name = "mnuHelpGeneral"
    Me.mnuHelpGeneral.Size = New System.Drawing.Size(114, 22)
    Me.mnuHelpGeneral.Text = "General"
    '
    'PrintDialog1
    '
    Me.PrintDialog1.UseEXDialog = True
    '
    'frmZDGraphics
    '
    Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
    Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
    Me.ClientSize = New System.Drawing.Size(804, 551)
    Me.Controls.Add(Me.GraphMenu)
    Me.Controls.Add(Me.frChange)
    Me.Controls.Add(Me.ZG1)
    Me.Name = "frmZDGraphics"
    Me.Text = "ARSDA for Linux/Mac (using ZedGraph)"
    Me.frChange.ResumeLayout(False)
    Me.frChange.PerformLayout()
    CType(Me.udMarkerSize, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.udBarWidth, System.ComponentModel.ISupportInitialize).EndInit()
    CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
    Me.GraphMenu.ResumeLayout(False)
    Me.GraphMenu.PerformLayout()
    Me.ResumeLayout(False)
    Me.PerformLayout()

  End Sub
  Friend WithEvents ZG1 As ZedGraph.ZedGraphControl
  Friend WithEvents frChange As System.Windows.Forms.GroupBox
  Friend WithEvents cboMarkerColor As System.Windows.Forms.ComboBox
  Friend WithEvents lblMarkerColor As System.Windows.Forms.Label
  Friend WithEvents lblMarkerStyle As System.Windows.Forms.Label
  Friend WithEvents cboMarkerStyle As System.Windows.Forms.ComboBox
  Friend WithEvents lblMarkerSize As System.Windows.Forms.Label
  Friend WithEvents udMarkerSize As System.Windows.Forms.NumericUpDown
  Friend WithEvents lblBarWidth As System.Windows.Forms.Label
  Friend WithEvents udBarWidth As System.Windows.Forms.NumericUpDown
  Friend WithEvents lblFontSize As System.Windows.Forms.Label
  Friend WithEvents NumericUpDown1 As System.Windows.Forms.NumericUpDown
  Friend WithEvents lblGraphType As System.Windows.Forms.Label
  Friend WithEvents cboGraphType As System.Windows.Forms.ComboBox
  Friend WithEvents GraphMenu As System.Windows.Forms.MenuStrip
  Friend WithEvents mnuFile As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuFileSave As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuFileSaveEMF As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuFileSaveBMP As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuFileExit As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuEdit As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuEditCopyEMF As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuEditCopyBMP As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuCopyData As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuGraph As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuGraphMinX As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuGraphMaxX As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
  Friend WithEvents mnuGraphMinY As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuGraphMaxY As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuHelp As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents mnuHelpGeneral As System.Windows.Forms.ToolStripMenuItem
  Friend WithEvents PrintDialog1 As System.Windows.Forms.PrintDialog
  Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
End Class
