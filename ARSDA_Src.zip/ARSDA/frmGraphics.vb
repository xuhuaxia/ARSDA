﻿Imports System.Windows.Forms.DataVisualization.Charting
Imports System.Math
Imports System.Data.OleDb
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Drawing.Printing
Imports System.Runtime.InteropServices
Imports System.Text

Public Class frmGraphics
  'The X and Y grid lines can be changed by Chart1.ChartAreas(0).AxisX.MajorGrid.Enabled = false
  '                                         Chart1.ChartAreas(0).AxisY.MajorGrid.Enabled = false;
  'bi-variate plot
  Private mSeries1Name As String
  Private WithEvents PrintDocument1 As PrintDocument = New PrintDocument
  Private PrintPreviewDialog1 As New PrintPreviewDialog
  Private mXArray As Object, mYArray As Object
  Private WithEvents PDB As New ToolStripButton("Printer")


  Sub DrawGraphFromDB(ByVal sAccessDbFileName As String, ByVal sTableName As String, _
                      ByVal sDatasetName As String, ByVal sNameX As String, ByVal sNameY As String, _
                      ByVal ChartType As SeriesChartType, Optional ByVal sTitle As String = "")
    'sNameY is the column name in the Access DB table
    Dim strConn As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & sAccessDbFileName & ";Persist Security Info=False;"

    Dim tblFields As String = "SELECT * from " & sTableName

    Dim conn As New OleDbConnection(strConn)
    Dim oCmd As New OleDbCommand(tblFields, conn)
    Dim oData As New OleDbDataAdapter(tblFields, conn)
    Dim ds As New DataSet
    Dim Series1 As Series

    conn.Open()
    oData.Fill(ds, sTableName)
    conn.Close()

    Graph1.DataSource = ds.Tables(sTableName)
    mSeries1Name = sTableName
    Graph1.Series.Clear()
    Series1 = Graph1.Series.Add(sDatasetName)
    Graph1.Series(Series1.Name).XValueMember = sNameX
    Graph1.Series(Series1.Name).YValueMembers = sNameY
    Graph1.Series(Series1.Name).ChartType = ChartType
    Graph1.ChartAreas(0).AxisX.Title = sNameX
    Graph1.ChartAreas(0).AxisY.Title = sNameY
    Me.ShowDialog()
    'Graph1.Size = New System.Drawing.Size(780, 350)
    Series1 = Nothing
  End Sub

  'bi-variate plot
  Sub DrawGraph(ByVal X As Object, ByVal Y As Object, ByVal NumPoint As Integer, _
                ByVal sNameX As String, ByVal sNameY As String, ByVal ChartType As SeriesChartType, Optional ByVal sTitle As String = "")
    Dim Series1 As Series
    Graph1.Series.Clear()
    mSeries1Name = "Series1"
    Series1 = Graph1.Series.Add(mSeries1Name)
    Graph1.Series(mSeries1Name).Points.DataBindXY(X, Y)
    Graph1.Series(Series1.Name).XValueMember = sNameX
    Graph1.Series(Series1.Name).YValueMembers = sNameY
    Graph1.Series(Series1.Name).ChartType = ChartType
    Graph1.ChartAreas(0).AxisX.Title = sNameX
    Graph1.ChartAreas(0).AxisY.Title = sNameY
    mXArray = X
    mYArray = Y
    Me.ShowDialog()
    'Graph1.Size = New System.Drawing.Size(780, 350)
    Graph1.Series.Clear()
    Series1 = Nothing

  End Sub


  Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileExit.Click
    Me.Close()
  End Sub

  Private Sub frmGraphics_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    With cboGraphType
      .Items.Clear()
      .Items.Add("Area")
      .Items.Add("Bar")
      .Items.Add("BoxPlot")
      .Items.Add("Bubble")
      .Items.Add("Candlestick")
      .Items.Add("Column")
      .Items.Add("Doughnut")
      .Items.Add("ErrorBar")
      .Items.Add("FastLine")
      .Items.Add("FastPoint")
      .Items.Add("Funnel")
      .Items.Add("Kagi")
      .Items.Add("Line")
      .Items.Add("Pie")
      .Items.Add("Point")
      .Items.Add("PointAndFigure")
      .Items.Add("Polar")
      .Items.Add("Pyramid")
      .Items.Add("Radar")
      .Items.Add("Range")
      .Items.Add("RangeBar")
      .Items.Add("RangeColumn")
      .Items.Add("Renko")
      .Items.Add("Spline")
      .Items.Add("SplineArea")
      .Items.Add("SplineRange")
      .Items.Add("StackedArea")
      .Items.Add("StackedArea100")
      .Items.Add("StackedBar")
      .Items.Add("StackedBar100")
      .Items.Add("StackedColumn")
      .Items.Add("StackedColumn100")
      .Items.Add("StepLine")
      .Items.Add("Stock")
      .Items.Add("ThreeLineBreak")
    End With
    With cboMarkerStyle.Items
      .Clear()
      .Add("Circle")
      .Add("Cross")
      .Add("Diamond")
      .Add("None")
      .Add("Square")
      .Add("Star10")
      .Add("Star4")
      .Add("Star5")
      .Add("Star6")
      .Add("Triangle")
    End With
    With cboMarkerColor.Items
      .Clear()
      .Add("Aqua")
      .Add("Azure")
      .Add("Black")
      .Add("Blue")
      .Add("Brown")
      .Add("Crimson")
      .Add("Cyan")
      .Add("Green")
      .Add("Purple")
      .Add("Red")
      .Add("Violet")
      .Add("White")
      .Add("Yellow")
    End With
  End Sub

  Private Sub cboGraphType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboGraphType.SelectedIndexChanged
    Select Case cboGraphType.SelectedIndex
      Case 0
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.Area
      Case 1
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.Bar
      Case 2
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.BoxPlot
      Case 3
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.Bubble
      Case 4
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.Candlestick
      Case 5
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.Column
      Case 6
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.Doughnut
      Case 7
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.ErrorBar
      Case 8
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.FastLine
      Case 9
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.FastPoint
      Case 10
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.Funnel
      Case 11
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.Kagi
      Case 12
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.Line
      Case 13
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.Pie
      Case 14
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.Point
      Case 15
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.PointAndFigure
      Case 16
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.Polar
      Case 17
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.Pyramid
      Case 18
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.Radar
      Case 19
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.Range
      Case 20
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.RangeBar
      Case 21
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.RangeColumn
      Case 22
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.Renko
      Case 23
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.Spline
      Case 24
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.SplineArea
      Case 25
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.SplineRange
      Case 26
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.StackedArea
      Case 27
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.StackedArea100
      Case 28
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.StackedBar
      Case 29
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.StackedBar100
      Case 30
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.StackedColumn
      Case 31
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.StackedColumn100
      Case 32
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.StepLine
      Case 33
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.Stock
      Case 34
        Graph1.Series(mSeries1Name).ChartType = SeriesChartType.ThreeLineBreak
    End Select

  End Sub

  Private Sub CopyAsEnhancedMetafileToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuEditCopyEMF.Click
    Using chartdata As System.IO.MemoryStream = New System.IO.MemoryStream
      Graph1.SaveImage(chartdata, DataVisualization.Charting.ChartImageFormat.Emf)
      chartdata.Seek(0, IO.SeekOrigin.Begin)
      Dim metafile As Imaging.Metafile = New Imaging.Metafile(chartdata)
      ClipboardMetafileHelper.PutEnhMetafileOnClipboard(Me.Handle, metafile)
    End Using
  End Sub

  Private Sub mnuFilePrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFilePrint.Click
    'call the print preview dialog
    'select the print button on the print preview dialog to print the chart
    Try
      PrintPreviewDialog1.Document = PrintDocument1
      PrintDialog1.Document = PrintDocument1
      CType(PrintPreviewDialog1.Controls(1), ToolStrip).Items.Add(PDB)
      PrintPreviewDialog1.ShowDialog()
    Catch ex As Exception
      MsgBox(ex.ToString)
    End Try
  End Sub

  Private Sub PDB_Click1(ByVal sender As Object, ByVal e As EventArgs) Handles PDB.Click
    PrintDialog1.ShowDialog()
  End Sub

  Private Sub mnuCopyData_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuCopyData.Click
    Dim I As Integer, UppInd As Integer
    Dim sb As New StringBuilder

    UppInd = UBound(mXArray)
    For I = 0 To UppInd
      sb.Append(mXArray(I).ToString & vbTab & mYArray(I) & vbCrLf)
    Next
    Clipboard.Clear()
    Clipboard.SetText(sb.ToString)
  End Sub
  Private Sub PrintDocument1_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
    'draw the preview or printer page
    'convert from 100ths of inch to pixels
    e.Graphics.PageUnit = GraphicsUnit.Pixel
    Dim xf As Single = e.Graphics.DpiX / 100
    Dim yf As Single = e.Graphics.DpiY / 100

    'printed page margin sizes
    Dim marginwidth As Integer = CInt(e.MarginBounds.Width * xf)
    Dim marginheight As Integer = CInt(e.MarginBounds.Height * yf)
    Dim l, t, w, h As Integer

    'size the printed chart to the page margins mantaining chart aspect and centered on the page
    Dim chartAspectRatio As Single = CSng(Graph1.ClientSize.Width / Graph1.ClientSize.Height)
    If chartAspectRatio > marginwidth / marginheight Then
      w = marginwidth
      h = CInt(w / chartAspectRatio)
      t = CInt((e.MarginBounds.Top * yf) + CInt((marginheight / 2 - (h / 2))))
      l = CInt(e.MarginBounds.Left * xf)
    Else
      h = marginheight
      w = CInt(h * chartAspectRatio)
      t = CInt(e.MarginBounds.Top * yf)
      l = CInt((e.MarginBounds.Left * xf) + CInt((marginwidth / 2) - (w / 2)))
    End If

    'create the metafile from the chart image
    Dim _stream2 As MemoryStream = Nothing

    Using stream2 As New MemoryStream()
      Graph1.SaveImage(stream2, ChartImageFormat.Emf)
      _stream2 = New MemoryStream(stream2.GetBuffer())

      'draw the metafile on the printer page
      Using _metaFile As Metafile = New Metafile(_stream2)
        e.Graphics.SmoothingMode = Drawing2D.SmoothingMode.AntiAlias
        e.Graphics.DrawImage(_metaFile, l, t, w, h)
      End Using
    End Using
  End Sub

  Private Sub mnuEditCopyBMP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuEditCopyBMP.Click
    ' Create a memory stream to save  the chart image
    Dim stream As New System.IO.MemoryStream()
    ' Save the chart image to the stream

    Graph1.SaveImage(stream, System.Drawing.Imaging.ImageFormat.Bmp)

    ' Create a bitmap using the stream

    Dim bmp As New Bitmap(stream)

    ' Save the bitmap to the clipboard

    Clipboard.SetDataObject(bmp)
  End Sub

  Private Sub mnuFileSaveEMF_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileSaveEMF.Click
    Dim sOutFile As String = GetSaveFileName("Save to...", "emf", SaveFileDialog1, CurDir)
    If sOutFile <> "" Then
      Graph1.SaveImage(sOutFile, ChartImageFormat.Emf)
    End If
  End Sub

  Private Sub mnuFileSaveBMP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuFileSaveBMP.Click
    Dim sOutFile As String = GetSaveFileName("Save to...", "emf", SaveFileDialog1, CurDir)
    If sOutFile <> "" Then
      Graph1.SaveImage(sOutFile, ChartImageFormat.Bmp)
    End If

  End Sub

  Private Sub NumericUpDown1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown1.ValueChanged
    'Graph1.ChartAreas(0).AxisX.LabelAutoFitStyle = LabelAutoFitStyles.None
    'Graph1.ChartAreas(0).AxisY.LabelAutoFitStyle = LabelAutoFitStyles.None
    Graph1.ChartAreas(0).AxisX.LabelStyle.Font = New System.Drawing.Font("Microsoft Sans Serif", CSng(NumericUpDown1.Value))
    Graph1.ChartAreas(0).AxisY.LabelStyle.Font = New System.Drawing.Font("Microsoft Sans Serif", CSng(NumericUpDown1.Value))
    Graph1.ChartAreas(0).AxisX.TitleFont = New System.Drawing.Font("Microsoft Sans Serif", CSng(NumericUpDown1.Value))
    Graph1.ChartAreas(0).AxisY.TitleFont = New System.Drawing.Font("Microsoft Sans Serif", CSng(NumericUpDown1.Value))
  End Sub

  Private Sub NumericUpDown2_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles udBarWidth.ValueChanged
    Graph1.Series(0)("PointWidth") = udBarWidth.Value
  End Sub

  Private Sub NumericUpDown2_ValueChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles udMarkerSize.ValueChanged
    Graph1.Series(0).MarkerSize = udMarkerSize.Value

  End Sub

  Private Sub cboMarkerStyle_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboMarkerStyle.SelectedIndexChanged
    Select Case cboMarkerStyle.SelectedIndex
      Case 0
        Graph1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Circle
      Case 1
        Graph1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Cross
      Case 2
        Graph1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Diamond
      Case 3
        Graph1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.None
      Case 4
        Graph1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Square
      Case 5
        Graph1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Star10
      Case 6
        Graph1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Star4
      Case 7
        Graph1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Star5
      Case 8
        Graph1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Star6
      Case 9
        Graph1.Series(0).MarkerStyle = DataVisualization.Charting.MarkerStyle.Triangle
    End Select

  End Sub

  Private Sub cboMarkerColor_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboMarkerColor.SelectedIndexChanged
    Select Case cboMarkerColor.SelectedIndex
      Case 0
        Graph1.Series(0).MarkerColor = Drawing.Color.Aqua
      Case 1
        Graph1.Series(0).MarkerColor = Drawing.Color.Azure
      Case 2
        Graph1.Series(0).MarkerColor = Drawing.Color.Black
      Case 3
        Graph1.Series(0).MarkerColor = Drawing.Color.Blue
      Case 4
        Graph1.Series(0).MarkerColor = Drawing.Color.Brown
      Case 5
        Graph1.Series(0).MarkerColor = Drawing.Color.Crimson
      Case 6
        Graph1.Series(0).MarkerColor = Drawing.Color.Cyan
      Case 7
        Graph1.Series(0).MarkerColor = Drawing.Color.Green
      Case 8
        Graph1.Series(0).MarkerColor = Drawing.Color.Purple
      Case 9
        Graph1.Series(0).MarkerColor = Drawing.Color.Red
      Case 10
        Graph1.Series(0).MarkerColor = Drawing.Color.Violet
      Case 11
        Graph1.Series(0).MarkerColor = Drawing.Color.White
      Case 12
        Graph1.Series(0).MarkerColor = Drawing.Color.Yellow
    End Select
  End Sub

  Private Sub SetMinimumXToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuGraphMinX.Click
    Dim MinX As Double
    MinX = CDbl(InputBox("Enter minimum X", "Input"))
    Graph1.ChartAreas(0).AxisX.Minimum = MinX
  End Sub

  Private Sub mnuGraphMaxX_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuGraphMaxX.Click
    Dim MaxX As Double
    MaxX = CDbl(InputBox("Enter minimum X", "Input"))
    Graph1.ChartAreas(0).AxisX.Maximum = MaxX

  End Sub

  Private Sub mnuGraphMinY_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuGraphMinY.Click
    Dim MinY As Double
    MinY = CDbl(InputBox("Enter minimum Y", "Input"))
    Graph1.ChartAreas(0).AxisY.Minimum = MinY

  End Sub

  Private Sub mnuGraphMaxY_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mnuGraphMaxY.Click
    Dim MaxY As Double
    MaxY = CDbl(InputBox("Enter minimum Y", "Input"))
    Graph1.ChartAreas(0).AxisY.Maximum = MaxY
  End Sub
End Class